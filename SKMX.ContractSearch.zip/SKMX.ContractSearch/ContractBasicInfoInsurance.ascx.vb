﻿Imports DotNetNuke
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Text
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Common.Globals
Imports DotNetNuke.Services.Exceptions
Imports System.Web.Security
Imports System.Security.Permissions
Imports System.Net

Namespace Skandia.Mx.Retail.DNN.ContractSearch
    Public MustInherit Class ContractBasicInfoInsurance

        Inherits Entities.Modules.PortalModuleBase

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            Try
                If PortalSecurity.IsInRole(PortalSettings.RegisteredRoleName.ToString) And Not Session.Item("_ContractSelectedInsurance") Is Nothing Then

                    Dim Client As System.Collections.Specialized.ListDictionary = CType(Session.Item("_ContractSelectedInsurance"), System.Collections.Specialized.ListDictionary)
                    Dim service As New InsuranceContractRetailServiceSvcProxy.InsuranceContractRetailServiceClient
                    Dim request As New InsuranceContractRetailServiceSvcProxy.ContractInstanceRequest
                    Dim response As New InsuranceContractRetailServiceSvcProxy.ContractInstanceDetailInfoResponse
                    Dim Contract_Instance As String
                    Dim Contract_Insurance As String
                    Dim ContractInsuranceId As String

                    request.DCContractInstanceRequest = New InsuranceContractRetailServiceSvcProxy.DCContractInstanceRequest
                    request.DCContractInstanceRequest.ContractInstance = New InsuranceContractRetailServiceSvcProxy.ContractInstance
                    request.DCContractInstanceRequest.ContractInstance.Insurance = New InsuranceContractRetailServiceSvcProxy.CatalogEntity

                    'CHAJUA  [2011/06/12] check for instance and benefit session  
                    If (Not Client.Item("ContractProductId") Is Nothing) And (Not Client.Item("ContractPlanId") Is Nothing) Then
                        Contract_Instance = Convert.ToString(Client.Item("ContractProductId"))
                        Contract_Insurance = Convert.ToString(Client.Item("ContractPlanId"))
                        ContractInsuranceId = Convert.ToString(Client.Item("ContractNumber"))
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoBenefitSelected", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        Me.tblGeneralInformation.Visible = False
                        Return
                    End If

                    request.DCContractInstanceRequest.ContractInstance.ContractIdentifier = ContractInsuranceId
                    request.DCContractInstanceRequest.ContractInstance.InstanceIdentifier = Contract_Instance
                    request.DCContractInstanceRequest.ContractInstance.Insurance.Identifier = Contract_Insurance

                    response.ContractInstanceDetailInfo = service.GetContractInstanceDetailInfo(request).ContractInstanceDetailInfo

                    If Not response Is Nothing Then
                        If (response.ContractInstanceDetailInfo.BeneficiaryList.Length > 0) And (Not response.ContractInstanceDetailInfo.Owner Is Nothing) Then
                            FillDataBenefit(response)
                            FillDataBeneficiary(response)
                            FillDataPremium(response)
                        End If
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoSelectedContract", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If

                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoSelectedContract", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    Me.tblGeneralInformation.Visible = False
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
        ''' <summary>
        ''' Fill Dataset with insurance contracts
        ''' </summary>
        ''' <param name="contratosIns"></param>
        ''' <remarks></remarks>
        Private Sub FillDataBenefit(ByVal contratosIns As InsuranceContractRetailServiceSvcProxy.ContractInstanceDetailInfoResponse)

            If contratosIns Is Nothing Then
                Return
            End If

            Dim dsBenefit As New DataSet
            Dim dr As DataRow
            Dim table As New DataTable

            'Create the table for the benefit
            table.Columns.Add("NombreBeneficio", Type.GetType("System.String"))
            table.Columns.Add("SumaAsegurada", Type.GetType("System.String"))
            table.Columns.Add("FechadeContratacion", Type.GetType("System.String"))
            table.Columns.Add("Vigencia", Type.GetType("System.String"))
            'GONERI-(20110629) Add new column Costo Total de Prima and drop some columns
            table.Columns.Add("CostoTotalPrima", Type.GetType("System.String"))
            dsBenefit.Tables.Add(table)

            'Set the benefit Information
            dr = table.NewRow
            'GONERI-(20110629) change Benefit name format
            dr("NombreBeneficio") = contratosIns.ContractInstanceDetailInfo.InsuranceContract.ContractInstance.Insurance.Name
            dr("FechadeContratacion") = contratosIns.ContractInstanceDetailInfo.PolicyInitialDate.ToString("dd/MM/yyyy")
            If Not Convert.ToString(contratosIns.ContractInstanceDetailInfo.PolicyFinalDate) Is Nothing And (Convert.ToString(contratosIns.ContractInstanceDetailInfo.PolicyFinalDate) <> "") And
                 contratosIns.ContractInstanceDetailInfo.LifeTimeCoverage = False Then
                dr("Vigencia") = contratosIns.ContractInstanceDetailInfo.PolicyFinalDate.ToString("dd/MM/yyyy")
            Else
                dr("Vigencia") = DotNetNuke.Services.Localization.Localization.GetString("VigenciaDsc", Me.LocalResourceFile)
            End If
            If (contratosIns.ContractInstanceDetailInfo.InsuranceContract.Status.Identifier = "3") And (contratosIns.ContractInstanceDetailInfo.InsuranceContract.Suspended = False) And
                (contratosIns.ContractInstanceDetailInfo.InsuranceContract.ClaimProcess = False) Then
                dr("SumaAsegurada") = Convert.ToString(contratosIns.ContractInstanceDetailInfo.InsuranceContract.InsuranceAmount)
            ElseIf contratosIns.ContractInstanceDetailInfo.InsuranceContract.Suspended = True Then
                dr("SumaAsegurada") = DotNetNuke.Services.Localization.Localization.GetString("SuspensionDsc", Me.LocalResourceFile)
            ElseIf contratosIns.ContractInstanceDetailInfo.InsuranceContract.ClaimProcess = True Then
                dr("SumaAsegurada") = DotNetNuke.Services.Localization.Localization.GetString("ProcesoReclamoDsc", Me.LocalResourceFile)
            End If
	    
            dr("CostoTotalPrima") = FormatCurrency(contratosIns.ContractInstanceDetailInfo.InsuranceContract.PremiumAmount, 2).ToString() + " " +
            contratosIns.ContractInstanceDetailInfo.InsuranceContract.PeriodFrequency.Name


            table.Rows.Add(dr)

            FillHeadBenefit()

            For Each tableIn As DataTable In dsBenefit.Tables
                addTableDisplayBenefit(tableIn)
            Next
        End Sub


        ''' <summary>
        ''' Fill Dataset with the beneficiarys 
        ''' </summary>
        ''' <param name="contratosIns"></param>
        ''' <remarks></remarks>
        Private Sub FillDataBeneficiary(ByVal contratosIns As InsuranceContractRetailServiceSvcProxy.ContractInstanceDetailInfoResponse)

            If contratosIns Is Nothing Then
                Return
            End If

            If contratosIns.ContractInstanceDetailInfo.BeneficiaryList.Length = 0 Then
                Return
            End If

            Dim dsBeneficiary As New DataSet
            Dim dr As DataRow
            Dim table As New DataTable

            table.Columns.Add("Personas", Type.GetType("System.String"))
            table.Columns.Add("Nombre", Type.GetType("System.String"))
            table.Columns.Add("FechadeNacimiento", Type.GetType("System.String"))
            dsBeneficiary.Tables.Add(table)
            'GONERI-(20110629) Validate the portal, setting the seccion to show
            If PortalSettings.PortalId.ToString = DotNetNuke.Services.Localization.Localization.GetString("FPsPortalId", Me.LocalResourceFile) Then 'FP's Portal
                'Asegurado
                dr = table.NewRow
                dr("Personas") = contratosIns.ContractInstanceDetailInfo.Insured.PersonType.ToString
                dr("Nombre") = contratosIns.ContractInstanceDetailInfo.Insured.FirstName + " " + contratosIns.ContractInstanceDetailInfo.Insured.LastNameOne +
                    " " + contratosIns.ContractInstanceDetailInfo.Insured.LastNameTwo
                dr("FechadeNacimiento") = contratosIns.ContractInstanceDetailInfo.Insured.BirthDate.ToString("dd/MM/yyyy")
                table.Rows.Add(dr)
            Else

                'Beneficiarios
                For Each beneficiary As InsuranceContractRetailServiceSvcProxy.Beneficiary In contratosIns.ContractInstanceDetailInfo.BeneficiaryList
                    dr = table.NewRow
                    dr("Personas") = beneficiary.Person.PersonType.ToString
                    dr("Nombre") = beneficiary.Person.FirstName + " " + beneficiary.Person.LastNameOne + " " + beneficiary.Person.LastNameTwo
                    dr("FechadeNacimiento") = beneficiary.Person.BirthDate.ToString("dd/MM/yyyy")
                    table.Rows.Add(dr)
                Next

                'Asegurado
                dr = table.NewRow
                dr("Personas") = contratosIns.ContractInstanceDetailInfo.Insured.PersonType.ToString
                dr("Nombre") = contratosIns.ContractInstanceDetailInfo.Insured.FirstName + " " + contratosIns.ContractInstanceDetailInfo.Insured.LastNameOne +
                    " " + contratosIns.ContractInstanceDetailInfo.Insured.LastNameTwo
                dr("FechadeNacimiento") = contratosIns.ContractInstanceDetailInfo.Insured.BirthDate.ToString("dd/MM/yyyy")
                table.Rows.Add(dr)
            End If

            FillHeadBeneficiary()
            addTableDisplayBeneficiary(table)

        End Sub

        ''' <summary>
        ''' Fill Dataset with the Premium detail 
        ''' </summary>
        ''' <param name="contratosIns"></param>
        ''' <remarks></remarks>
        Private Sub FillDataPremium(ByVal contratosIns As InsuranceContractRetailServiceSvcProxy.ContractInstanceDetailInfoResponse)

            If contratosIns Is Nothing Then
                Return
            End If

            td_TitlePrimDetail.Visible = False
            If contratosIns.ContractInstanceDetailInfo.BeneficiaryList.Length = 0 Then
                Return
            End If

            Dim dsPremium As New DataSet
            Dim dr As DataRow
            Dim table As New DataTable

            table.Columns.Add("IncrementoAnual", Type.GetType("System.String"))
            table.Columns.Add("EstadodelContrato", Type.GetType("System.String"))
            table.Columns.Add("DependedelBeneficio", Type.GetType("System.String"))

            dsPremium.Tables.Add(table)

            'Asegurado
            dr = table.NewRow

            dr("IncrementoAnual") = contratosIns.ContractInstanceDetailInfo.InsuranceRateAnualIncrement.Name
            dr("EstadodelContrato") = contratosIns.ContractInstanceDetailInfo.InsuranceContract.Status.Name
            If Not contratosIns.ContractInstanceDetailInfo.DependentBenefit.Identifier Is Nothing And contratosIns.ContractInstanceDetailInfo.DependentBenefit.Identifier <> "" Then
                dr("DependedelBeneficio") = contratosIns.ContractInstanceDetailInfo.DependentBenefit.Identifier + "/" + contratosIns.ContractInstanceDetailInfo.InsuranceContract.ContractInstance.InstanceIdentifier
            Else
                dr("DependedelBeneficio") = ""
            End If

            table.Rows.Add(dr)

            'FillHeadPremium()
            addTableDisplayPremium(table)

        End Sub

        ''' <summary>
        ''' Fill Header  with the benefits
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub FillHeadBenefit()
            'this method fill the head by the table 
            'GONERI-(20110629) Drop the column
            Dim trowHead As TableRow = New TableRow

            Dim tcell1 As TableCell = New TableCell
            Dim tcell2 As TableCell = New TableCell
            Dim tcell3 As TableCell = New TableCell
            Dim tcell4 As TableCell = New TableCell
            Dim tcell5 As TableCell = New TableCell

            tcell1.CssClass = "TDTextTableHeader2"
            tcell2.CssClass = "TDTextTableHeader2"
            tcell3.CssClass = "TDTextTableHeader2"
            tcell4.CssClass = "TDTextTableHeader2"
            tcell5.CssClass = "TDTextTableHeader2"

            tcell1.Text = "<center><b>Nombre de Beneficio</b></center>"
            tcell2.Text = "<center><b>Fecha de Contrataci&oacute;n</b></center>"
            tcell3.Text = "<center><b>Vigencia</b></center>"
            tcell4.Text = "<center><b>Suma Asegurada</b></center>"
            tcell5.Text = "<center><b>Prima</b></center>"

            trowHead.Cells.Add(tcell1)
            trowHead.Cells.Add(tcell2)
            trowHead.Cells.Add(tcell3)
            trowHead.Cells.Add(tcell4)
            trowHead.Cells.Add(tcell5)

            trowHead.BackColor = System.Drawing.Color.FromArgb(0, 51, 153)
            trowHead.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255)

            tblBenefit.Rows.Add(trowHead)
        End Sub

        ''' <summary>
        ''' Fill Header  with the Premium
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub FillHeadPremium()
            'this method fill the head by the table 
            Dim trowHead As TableRow = New TableRow

            Dim tcell1 As TableCell = New TableCell
            Dim tcell2 As TableCell = New TableCell

            tcell1.CssClass = "TDTextTableHeader2"
            tcell2.CssClass = "TDTextTableHeader2"

            tcell1.Text = "<center><b>Beneficio</b></center>"
            tcell2.Text = "<center><b>Costo de Prima</b></center>"

            trowHead.Cells.Add(tcell1)
            trowHead.Cells.Add(tcell2)

            trowHead.BackColor = System.Drawing.Color.FromArgb(0, 51, 153)
            trowHead.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255)

            tblPrime.Rows.Add(trowHead)
        End Sub

        ''' <summary>
        ''' Fill Header  with the beneficiarys
        ''' </summary>
        ''' <remarks></remarks>
        Private Sub FillHeadBeneficiary()
            'this method fill the head by the table 
            'GONERI-(20110629) Drop the column and change the first name column
            Dim trowHead As TableRow = New TableRow

            Dim tcell1 As TableCell = New TableCell
            Dim tcell2 As TableCell = New TableCell
            Dim tcell3 As TableCell = New TableCell

            tcell1.CssClass = "TDTextTableHeader2"
            tcell2.CssClass = "TDTextTableHeader2"
            tcell3.CssClass = "TDTextTableHeader2"

            tcell1.Text = "<center><b>Parte</b></center>"
            tcell2.Text = "<center><b>Nombre</b></center>"
            tcell3.Text = "<center><b>Fecha de Nacimiento</b></center>"

            trowHead.Cells.Add(tcell1)
            trowHead.Cells.Add(tcell2)
            trowHead.Cells.Add(tcell3)

            trowHead.BackColor = System.Drawing.Color.FromArgb(0, 51, 153)
            trowHead.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255)

            tblBeneficiary.Rows.Add(trowHead)
        End Sub

        ''' <summary>
        ''' Fill the table with the Benefit Information
        ''' </summary>
        ''' <param name="tableBenefits"></param>
        ''' <remarks></remarks>
        Public Sub addTableDisplayBenefit(ByVal tableBenefits As DataTable)

            '--- DECLARACION DE VARIABLES ------------------------------------------------------
            Dim trowtitle As TableRow = New TableRow
            Dim tcell1 As TableCell = New TableCell
            Dim counter As Int16
            '------------------------------------------------------------------------------------

            'Insurance Type
            tcell1.CssClass = "TDTextTableCell4"
            tcell1.Text = tableBenefits.TableName.ToString()
            trowtitle.Cells.Add(tcell1)
            trowtitle.BackColor = System.Drawing.Color.FromArgb(204, 204, 204)
            'GONERI-(20110629) Add new column to the table and format it
            'Contracts
            For Each dr As DataRow In tableBenefits.Rows

                Dim width As System.Web.UI.WebControls.Unit

                Dim trow As TableRow = New TableRow
                Dim trow2 As TableRow = New TableRow
                Dim trow3 As TableRow = New TableRow
                Dim trow4 As TableRow = New TableRow
                Dim trow5 As TableRow = New TableRow

                trow.EnableViewState = True
                trow2.EnableViewState = True

                Dim tcellBenefit As TableCell = New TableCell
                tcellBenefit.Width = width.Parse("100")
                tcellBenefit.EnableViewState = True

                Dim tcellDateIni As TableCell = New TableCell
                tcellDateIni.Width = width.Parse("200")
                tcellDateIni.EnableViewState = True

                Dim tcellSumaAsegurada As TableCell = New TableCell
                tcellSumaAsegurada.Width = width.Parse("120")
                tcellSumaAsegurada.EnableViewState = True

                Dim tcellVigency As TableCell = New TableCell
                tcellVigency.Width = width.Parse("120")
                tcellVigency.EnableViewState = True

                Dim tcellPrima As TableCell = New TableCell
                tcellPrima.Width = width.Parse("120")
                tcellPrima.EnableViewState = True

                tcellBenefit.Text = dr("NombreBeneficio")
                tcellBenefit.HorizontalAlign = HorizontalAlign.Left

                tcellDateIni.Text = dr("FechadeContratacion")
                tcellDateIni.HorizontalAlign = HorizontalAlign.Center

                tcellVigency.Text = dr("Vigencia")
                tcellVigency.HorizontalAlign = HorizontalAlign.Center

                If dr("SumaAsegurada") <> DotNetNuke.Services.Localization.Localization.GetString("SuspensionDsc", Me.LocalResourceFile) And
                    dr("SumaAsegurada") <> DotNetNuke.Services.Localization.Localization.GetString("ProcesoReclamoDsc", Me.LocalResourceFile) Then
                    tcellSumaAsegurada.Text = FormatCurrency(dr("SumaAsegurada"), 2)
                Else
                    tcellSumaAsegurada.Text = dr("SumaAsegurada")
                End If
                tcellSumaAsegurada.HorizontalAlign = HorizontalAlign.Right

                tcellPrima.Text = dr("CostoTotalPrima")
                tcellPrima.HorizontalAlign = HorizontalAlign.Center


                trow.Cells.Add(tcellBenefit)
                trow.Cells.Add(tcellDateIni)
                trow.Cells.Add(tcellVigency)
                trow.Cells.Add(tcellSumaAsegurada)
                trow.Cells.Add(tcellPrima)

                If counter Mod 2 = 0 Then
                    trow.CssClass = "TDTextTableCell4"
                    trow2.CssClass = "TDTextTableCell"
                    trow3.CssClass = "TDTextTableCell4"
                    trow4.CssClass = "TDTextTableCell"
                    trow5.CssClass = "TDTextTableCell4"
                Else
                    trow.CssClass = "TDTextTableCell4"
                    trow2.CssClass = "TDTextTableCell"
                    trow3.CssClass = "TDTextTableCell4"
                    trow4.CssClass = "TDTextTableCell"
                    trow5.CssClass = "TDTextTableCell4"
                End If

                counter += 1
                tblBenefit.Rows.Add(trow)
                tblBenefit.Rows.Add(trow2)
                tblBenefit.Rows.Add(trow3)
                tblBenefit.Rows.Add(trow4)
                tblBenefit.Rows.Add(trow5)
            Next
        End Sub

        ''' <summary>
        ''' Fill the table with the Benefit Information
        ''' </summary>
        ''' <param name="tableBeneficiary"></param>
        ''' <remarks></remarks>
        Public Sub addTableDisplayBeneficiary(ByVal tableBeneficiary As DataTable)

            '--- DECLARACION DE VARIABLES ------------------------------------------------------
            Dim trowtitle As TableRow = New TableRow
            Dim tcell1 As TableCell = New TableCell
            Dim counter As Int16
            '------------------------------------------------------------------------------------

            'Insurance Type
            tcell1.CssClass = "TDTextTableCell4"
            tcell1.Text = tableBeneficiary.TableName.ToString()
            trowtitle.Cells.Add(tcell1)
            trowtitle.BackColor = System.Drawing.Color.FromArgb(204, 204, 204)

            'Contracts
            For Each dr As DataRow In tableBeneficiary.Rows

                Dim width As System.Web.UI.WebControls.Unit

                Dim trow As TableRow = New TableRow
                Dim trow2 As TableRow = New TableRow

                trow.EnableViewState = True
                trow2.EnableViewState = True

                Dim tcellPersona As TableCell = New TableCell
                tcellPersona.Width = width.Parse("100")
                tcellPersona.EnableViewState = True

                Dim tcellNombre As TableCell = New TableCell
                tcellNombre.Width = width.Parse("200")
                tcellNombre.EnableViewState = True

                Dim tcellBirthDate As TableCell = New TableCell
                tcellBirthDate.Width = width.Parse("120")
                tcellBirthDate.EnableViewState = True

                tcellPersona.Text = dr("Personas")
                tcellPersona.HorizontalAlign = HorizontalAlign.Left

                tcellNombre.Text = dr("Nombre")
                tcellNombre.HorizontalAlign = HorizontalAlign.Left

                tcellBirthDate.Text = dr("FechadeNacimiento")
                tcellBirthDate.HorizontalAlign = HorizontalAlign.Center


                trow.Cells.Add(tcellPersona)
                trow.Cells.Add(tcellNombre)
                trow.Cells.Add(tcellBirthDate)

                If counter Mod 2 = 0 Then
                    trow.CssClass = "TDTextTableCell4"
                Else
                    trow.CssClass = "TDTextTableCell"
                End If

                counter += 1
                tblBeneficiary.Rows.Add(trow)
            Next
        End Sub

        ''' <summary>
        ''' Fill the table with the Premium Information
        ''' </summary>
        ''' <param name="tablePremium"></param>
        ''' <remarks></remarks>
        Public Sub addTableDisplayPremium(ByVal tablePremium As DataTable)

            '--- DECLARACION DE VARIABLES ------------------------------------------------------
            Dim trowtitle As TableRow = New TableRow
            Dim tcell1 As TableCell = New TableCell
            Dim counter As Int16
            '------------------------------------------------------------------------------------

            'Insurance Type
            tcell1.CssClass = "TDTextTableCell4"
            tcell1.Text = tablePremium.TableName.ToString()
            trowtitle.Cells.Add(tcell1)
            trowtitle.BackColor = System.Drawing.Color.FromArgb(204, 204, 204)

            'Contracts
            For Each dr As DataRow In tablePremium.Rows

                Dim width As System.Web.UI.WebControls.Unit

                Dim trow As TableRow = New TableRow
                Dim trow2 As TableRow = New TableRow
                Dim trow3 As TableRow = New TableRow

                trow.EnableViewState = True
                trow2.EnableViewState = True
                trow3.EnableViewState = True
		
                'GONERI-(20110629) Change layout of table and fill data
                Dim tcellIncrement As TableCell = New TableCell
                tcellIncrement.Width = width.Parse("300")
                tcellIncrement.EnableViewState = True

                Dim tcellStatus As TableCell = New TableCell
                tcellStatus.Width = width.Parse("120")
                tcellStatus.EnableViewState = True

                Dim tcelldeBen As TableCell = New TableCell
                tcelldeBen.Width = width.Parse("300")
                tcelldeBen.EnableViewState = True

                tcellIncrement.Text = "<b>" + DotNetNuke.Services.Localization.Localization.GetString("IncrementoAnualDsc", Me.LocalResourceFile) + "</b> " + dr("IncrementoAnual")
                tcellStatus.Text = "<b>" + DotNetNuke.Services.Localization.Localization.GetString("EstadoDsc", Me.LocalResourceFile) + "</b> " + dr("EstadodelContrato")
                tcelldeBen.Text = "<b>" + DotNetNuke.Services.Localization.Localization.GetString("DependBeneficio", Me.LocalResourceFile) + "</b> " + dr("DependedelBeneficio")


                trow.Cells.Add(tcellIncrement)
                trow.Height = CType(CInt(10), Unit)
                trow2.Cells.Add(tcellStatus)
                trow2.Height = CType(CInt(10), Unit)
                If Not dr("DependedelBeneficio") Is Nothing And dr("DependedelBeneficio") <> "" Then
                    trow3.Cells.Add(tcelldeBen)
                    trow3.Height = CType(CInt(10), Unit)
                End If

                If counter Mod 2 = 0 Then
                    trow.CssClass = "TDTextTableCell4"
                    trow2.CssClass = "TDTextTableCell"
                    trow3.CssClass = "TDTextTableCell4"
                Else
                    trow.CssClass = "TDTextTableCell"
                    trow2.CssClass = "TDTextTableCell4"
                    trow3.CssClass = "TDTextTableCell"
                End If

                counter += 1
                tblPrime.Rows.Add(trow)
                tblPrime.Rows.Add(trow2)
                tblPrime.Rows.Add(trow3)
            Next
        End Sub

    End Class
End Namespace
