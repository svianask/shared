'Creado por: Freeze Code Networks S. C.
'Fecha de Creaci�n: 23 de Octubre de 2006
'Ultima Modificaci�n: 23 de Octubre de 2006
'Ultima Modificaci�n: 12 de Octubre de 2010

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Services.Exceptions

Imports Skandia.Mx.DNN.Utilities

Namespace Skandia.Mx.Retail.DNN.ContractSearch

    Public Class SavingsAdvanced
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        Protected WithEvents lblSavingObjective As System.Web.UI.WebControls.Label
        Protected WithEvents lblInitialDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblMonthContribution As System.Web.UI.WebControls.Label
        Protected WithEvents lblInitialContribution As System.Web.UI.WebControls.Label
        Protected WithEvents lblInitialContributionDetail As System.Web.UI.WebControls.Label
        Protected WithEvents lblTerm As System.Web.UI.WebControls.Label
        Protected WithEvents lblMOC As System.Web.UI.WebControls.Label
        Protected WithEvents lblMonthsOnPlan As System.Web.UI.WebControls.Label
        Protected WithEvents pnlMocAndMonths As System.Web.UI.WebControls.Panel
        Protected WithEvents lblSuggestedMonthlyContribution As System.Web.UI.WebControls.Label
        Protected WithEvents lblMonthRate As System.Web.UI.WebControls.Label
        Protected WithEvents lblFirstYear As System.Web.UI.WebControls.Label
        Protected WithEvents lblSecondYear As System.Web.UI.WebControls.Label
        Protected WithEvents lblInflationRate As System.Web.UI.WebControls.Label
        Protected WithEvents pnlRate As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlMySavingPlan As System.Web.UI.WebControls.Panel
        Protected WithEvents lblRegularPremiumTerm As System.Web.UI.WebControls.Label
        Protected WithEvents lblTodaySavingObjective As System.Web.UI.WebControls.Label
        Protected WithEvents lblContributionsNet As System.Web.UI.WebControls.Label
        Protected WithEvents lblTodaySavingContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblContractBalance As System.Web.UI.WebControls.Label
        Protected WithEvents lblExpectedMonthlyContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblCurrentLifeInsurace As System.Web.UI.WebControls.Label
        Protected WithEvents lblCurrentMonthlyContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblWithdrawals As System.Web.UI.WebControls.Label
        Protected WithEvents lblMonthlyContributionRest As System.Web.UI.WebControls.Label
        Protected WithEvents lblAmountContributionsRest As System.Web.UI.WebControls.Label
        Protected WithEvents lblDeathBenefit As System.Web.UI.WebControls.Label
        Protected WithEvents lblFreeWithdrawalsAmount As System.Web.UI.WebControls.Label
        Protected WithEvents pnlFreeWithdrawalsAmount As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlAdvanceToday As System.Web.UI.WebControls.Panel
        Protected WithEvents lblOverdueMonthlyContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblOverdueMonthlyContributionsAmount As System.Web.UI.WebControls.Label
        Protected WithEvents lblNoConsecutiveOverdueContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblConsecutiveOverdueContributions As System.Web.UI.WebControls.Label
        Protected WithEvents lblContractStatus As System.Web.UI.WebControls.Label
        Protected WithEvents lblType As System.Web.UI.WebControls.Label
        Protected WithEvents pnl_NMNC As System.Web.UI.WebControls.Panel
        Protected WithEvents imgWarning As System.Web.UI.WebControls.Image
        Protected WithEvents pnlPayments As System.Web.UI.WebControls.Panel
        Protected WithEvents lblBank As System.Web.UI.WebControls.Label
        Protected WithEvents lblPeriod As System.Web.UI.WebControls.Label
        Protected WithEvents lblAccount As System.Web.UI.WebControls.Label
        Protected WithEvents lblAmount As System.Web.UI.WebControls.Label
        Protected WithEvents pnlDomiciliacion As System.Web.UI.WebControls.Panel
        Protected WithEvents imgEtiqFinanciera As System.Web.UI.WebControls.Image
        Protected WithEvents pnlSavingsAdvance As System.Web.UI.WebControls.Panel
        Protected WithEvents tblMySavingPlan As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblAdvanceToday As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblPayments As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents trOverduePayments As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents trNotOverduePayments As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents tblDomiciliacion As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents trHasntDomiciliacion As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents trHasDomiciliacion As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblDomiciliacion As System.Web.UI.WebControls.Label
        Protected WithEvents lblProrroga As System.Web.UI.WebControls.Label
        Protected WithEvents lblHaveProrrogation As System.Web.UI.WebControls.Label
        Protected WithEvents trHaveProrrogation As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblLifeInsurance As System.Web.UI.WebControls.Label
        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Public strCurrentSA As String
        Public blVisibleCSA As Boolean
        Public strInitialSA As String

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'MunMig 05Oct09
            imgEtiqFinanciera.ImageUrl = DotNetNuke.Services.Localization.Localization.GetString("ImgEtiqFinanciera", Me.LocalResourceFile) 'PortalSettings.ActiveTab.SkinPath & "Images/imgEtiqFinanciera.gif" 'Load the image from the current portal
            strCurrentSA = DotNetNuke.Services.Localization.Localization.GetString("CurrentSA", Me.LocalResourceFile)
            strInitialSA = DotNetNuke.Services.Localization.Localization.GetString("InitialSA", Me.LocalResourceFile)
            blVisibleCSA = Convert.ToBoolean(DotNetNuke.Services.Localization.Localization.GetString("VisibleCSA", Me.LocalResourceFile))
            '
            Dim ProductId As String = String.Empty
            Dim PlanId As String = String.Empty
            Try
                If Not IsPostBack Then

                    If Not Session.Item("_ContractSelected") Is Nothing Then

                        Dim IsContractSelected As String = String.Empty

                        IsContractSelected = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))

                        If IsContractSelected <> "" Then
                            'Validacion del Contrato :no esta dado de alta en el sistema(RA)
                            If Not ContractPaymentPlanIsComplete(IsContractSelected, PlanId, ProductId) Then
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoPaymentPlan", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                                pnlSavingsAdvance.Visible = False
                                Return
                            End If

                            pnlSavingsAdvance.Visible = True


                            Dim NotValPlan() As String = Split(DotNetNuke.Services.Localization.Localization.GetString("NotValidPlan", Me.LocalResourceFile), ",")
                            Dim ValProduct As String = DotNetNuke.Services.Localization.Localization.GetString("ValidProduct", Me.LocalResourceFile)
                            Dim flagNotValPlan As Boolean

                            For Each str As String In NotValPlan
                                If str = PlanId Then
                                    flagNotValPlan = True
                                End If
                            Next

                            If ProductId = ValProduct And Not flagNotValPlan Then
                                Page.DataBind()
                                FillData()
                            Else
                                pnlSavingsAdvance.Visible = False
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoPlanCommittedSaving", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            pnlSavingsAdvance.Visible = False
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoContracts", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else

                        pnlSavingsAdvance.Visible = False
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoSelectContract", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                    End If
                End If
            Catch ex As Exception
                pnlSavingsAdvance.Visible = False
                ProcessModuleLoadException(Me, ex)
            End Try
        End Sub

#Region "Methods"

        Public Sub FillData()
            Try
                Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
                Dim req As New InvestmentContractRetailServiceSvcProxy.ContractRequest
                Dim respSavingInfo As New InvestmentContractRetailServiceSvcProxy.InvestmentContractDetailInfoResponse
                Dim respBalanceAmount As New InvestmentContractRetailServiceSvcProxy.InvestmentContractBalanceResponse
                Dim respDebitInfo As New InvestmentContractRetailServiceSvcProxy.ContractDirectDebitBasicInfoResponse
                Dim tempDate As New DateTime
                Dim actualValidDateValue As Decimal
                Dim lastValidDateValue As Decimal
                Dim indicatorValue As Decimal = 0
                Dim lifeInsurance As Decimal = 0
                Dim initialDate As DateTime = DateTime.MinValue
                Dim tmpDate As New DateTime
                Dim dayBegin As Integer
                req.ContractIdentifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                respSavingInfo = service.GetContractDetailInfo(req)
                respBalanceAmount = service.GetContractBalance(req)

                If Not ((respSavingInfo Is Nothing) And (respBalanceAmount Is Nothing)) Then

                    If respSavingInfo.InvestmentContractDetail.InvestmentContract.Status.Identifier = "5" Or respSavingInfo.InvestmentContractDetail.InvestmentContract.Status.Identifier = "10" Then

                        'MI PLAN DE AHORRO  
                        lblSavingObjective.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.SavingObjective.ToString("C")
                        lblMonthContribution.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.MonthlyContribution.ToString("C")
                        lblTerm.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.RegularPremiumTerm.ToString() + " Meses"
                        initialDate = GetContractBeginningDate(respSavingInfo.TransactionsSummaryInfo.FirstContributionDate, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate)
                        lblInitialDate.Text = GetMonthName(initialDate.Month) + " de " + initialDate.Year.ToString("0000")

                        If respSavingInfo.OperationalSummaryInfo.MonthsOnPlan > 12 Then

                            tempDate = VerifyValidDateTime(DateTime.Now.Year, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Month, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Day) 'MUNMIG
                            'tempDate = New DateTime(DateTime.Now.Year, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Month, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Day)

                            If (tempDate > DateTime.Now.Date) Then
                                tempDate = New DateTime(DateTime.Now.Year - 1, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Month, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Day)
                            End If
                            'Periodo de la tasa de inflacion.
                            lblMonthRate.Text = GetMonthName(tempDate.Month).ToUpper() + " / "
                            lblSecondYear.Text = tempDate.Year.ToString("0000")
                            lblFirstYear.Text = (tempDate.Year - 1).ToString("0000") + " - "

                            'Tasa de inflacion.
                            dayBegin = initialDate.Day
                            tmpDate = VerifyValidDateTime(DateTime.Now.Year, initialDate.Month, dayBegin)
                            If (tmpDate < DateTime.Now.Date) Then
                                actualValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year, initialDate.Month, 1)))
                                lastValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year - 1, initialDate.Month, 1)))
                            Else
                                actualValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year, initialDate.Month, 1)))
                                lastValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year - 2, initialDate.Month, 1)))
                            End If
                            If (actualValidDateValue > 0 And lastValidDateValue > 0) Then

                                indicatorValue = (actualValidDateValue / lastValidDateValue) - 1
                            End If

                            lblInflationRate.Text = indicatorValue.ToString("P")

                            'Aportacion Mensual sugerida por Skandia.
                            lblSuggestedMonthlyContribution.Text = respSavingInfo.SavingAdvanceInfo.MonthlyContributionByInflation.ToString("C")

                            pnlRate.Style.Item("display") = "block"

                        Else
                            pnlRate.Style.Item("display") = "none"

                        End If

                        lblInitialContribution.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.InitialContributionAgreed.ToString("C")
                        If respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.InitialContributionType.Identifier = "5" Then
                            lblInitialContributionDetail.Text = DotNetNuke.Services.Localization.Localization.GetString("InitialContributionA", Me.LocalResourceFile)
                        ElseIf respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.InitialContributionType.Identifier = "10" Then
                            lblInitialContributionDetail.Text = DotNetNuke.Services.Localization.Localization.GetString("InitialContributionB", Me.LocalResourceFile)
                        Else
                            lblInitialContributionDetail.Text = DotNetNuke.Services.Localization.Localization.GetString("InitialContributionC", Me.LocalResourceFile)
                        End If

                        lblMOC.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.MonthlyObjectContribution.ToString("C")
                        lblMonthsOnPlan.Text = respSavingInfo.OperationalSummaryInfo.MonthsOnPlan.ToString()

                        'MI AVANCE DE AHORRO HASTA HOY
                        lblRegularPremiumTerm.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.RegularPremiumTerm.ToString()
                        lblCurrentMonthlyContributions.Text = respSavingInfo.SavingAdvanceInfo.CurrentNumContributions.ToString("N")
                        lblExpectedMonthlyContributions.Text = respSavingInfo.SavingAdvanceInfo.MustHaveNumContributions.ToString()
                        lblTodaySavingContributions.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.SumOfPremiums.ToString("C")
                        lblTodaySavingObjective.Text = respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.SavingObjective.ToString("C")
                        lblContributions.Text = respSavingInfo.TransactionsSummaryInfo.TotalContributionsAmount.ToString("C")
                        lblWithdrawals.Text = respSavingInfo.TransactionsSummaryInfo.TotalWithdrawalsAmount.ToString("C")
                        Dim result As Double
                        result = Convert.ToDouble(respSavingInfo.TransactionsSummaryInfo.TotalContributionsAmount - respSavingInfo.TransactionsSummaryInfo.TotalWithdrawalsAmount)
                        If result <= 0 Then
                            result = 0
                        End If
                        lblContributionsNet.Text = result.ToString("C")


                        lblContractBalance.Text = GetBalanceAmount(respBalanceAmount).ToString("C")

                        If respSavingInfo.TransactionsSummaryInfo.TotalContributionsAmount <= 0 Then
                            lblInitialDate.Text = String.Empty
                            pnlPayments.Visible = False
                        End If


                        Dim contractId As String = String.Empty
                        contractId = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))



                        If (IsPlanRS2010(contractId, respSavingInfo.InvestmentContractDetail.InvestmentContract.Plan.PlanGeneric.Identifier) Or IsPlanRSBefore2010(contractId, respSavingInfo.InvestmentContractDetail.InvestmentContract.Plan.PlanGeneric.Identifier) Or IsPlanGoalAccomplished(contractId, respSavingInfo.InvestmentContractDetail.InvestmentContract.Plan.PlanGeneric.Identifier)) Then

                            If ((respSavingInfo.InvestmentContractDetail.InvestmentContract.Status.Identifier = "5" Or respSavingInfo.InvestmentContractDetail.InvestmentContract.Status.Identifier = "10") And (respSavingInfo.OperationalSummaryInfo.OperationalStatus.Identifier = "5")) Then
                                Dim insuredAmountHistory As Decimal = 0
                                Dim deathBenefit As Decimal = 0
                                
                                '15/07/2019 MCO - Inicio de cambio
                                lblLifeInsurance.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.InitialInsuredAmount.ToString("C"))

                                If blVisibleCSA = True Then
                                    'Suma Asegurada Inicial
                                    lblCurrentLifeInsurace.Style.Item("color") = "red"
                                    lblCurrentLifeInsurace.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.CurrentInsuredAmount.ToString("C"))
                                    'Beneficio por Fallecimiento
                                    lblDeathBenefit.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.DeathBenefit.ToString("C"))
                                Else
                                    'Suma Asegurada Inicial
                                    lblCurrentLifeInsurace.Text = "No Disponible"
                                    'Beneficio por Fallecimiento
                                    lblDeathBenefit.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.DeathBenefit.ToString("C"))
                                End If

                            Else
                                lblCurrentLifeInsurace.Text = "$0.00"
                                lblDeathBenefit.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.DeathBenefit.ToString("C"))
                                lblLifeInsurance.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.InitialInsuredAmount.ToString("C"))
                            End If


                        Else

                            If respSavingInfo.SavingAdvanceInfo.DelayedNumContributions > 0 Then
                                If blVisibleCSA = True Then
                                    lblCurrentLifeInsurace.Text = "$0.00"
                                    lblCurrentLifeInsurace.Style.Item("color") = "red"
                                    'Beneficio por Fallecimiento
                                    lblDeathBenefit.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.DeathBenefit.ToString("C"))
                                Else
                                    'Suma Asegurada Inicial
                                    lblCurrentLifeInsurace.Text = "No Disponible"
                                    'Beneficio por Fallecimiento
                                    lblDeathBenefit.Text = "No Disponible"
                                End If
                                lblLifeInsurance.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.InitialInsuredAmount.ToString("C"))

                            Else
                                If blVisibleCSA = True Then
                                    lblCurrentLifeInsurace.Style.Item("color") = "black"
                                    lblCurrentLifeInsurace.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.CurrentInsuredAmount.ToString("C"))
                                    'Beneficio por Fallecimiento
                                    lblDeathBenefit.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.DeathBenefit.ToString("C"))
                                Else
                                    'Suma Asegurada Inicial
                                    lblCurrentLifeInsurace.Text = "No Disponible"
                                    'Beneficio por Fallecimiento
                                    lblDeathBenefit.Text = "No Disponible"
                                End If
                                lblLifeInsurance.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.InitialInsuredAmount.ToString("C"))
                                lblLifeInsurance.Style.Item("color") = "black"

                                If respSavingInfo.OperationalSummaryInfo.OperationalStatus.Identifier = "15" And (lblContractBalance.Text * 0.01) < (respSavingInfo.SavingAdvanceInfo.CurrentLifeInsuranceAmount) Then
                                    If blVisibleCSA = True Then
                                        lblCurrentLifeInsurace.Style.Item("color") = "red"
                                        'Suma Asegurada Inicial
                                        lblCurrentLifeInsurace.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.InitialInsuredAmount.ToString("C"))
                                    Else
                                        'Suma Asegurada Inicial
                                        lblCurrentLifeInsurace.Text = "No Disponible"
                                        'Beneficio por Fallecimiento
                                        lblDeathBenefit.Text = "No Disponible"
                                    End If
                                End If
                            End If
                        End If


                        Dim MonthlyContributionRest As Double = Convert.ToDouble((respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.RegularPremiumTerm - respSavingInfo.SavingAdvanceInfo.CurrentNumContributions))
                        Dim AmountContributionsRest As Double = Convert.ToDouble(((respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.RegularPremiumTerm - respSavingInfo.SavingAdvanceInfo.CurrentNumContributions) * respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.MonthlyObjectContribution))

                        lblMonthlyContributionRest.Text = Convert.ToDouble(IIf(MonthlyContributionRest > 0, MonthlyContributionRest, 0)).ToString("N")
                        lblAmountContributionsRest.Text = Convert.ToDouble(IIf(AmountContributionsRest > 0, AmountContributionsRest, 0)).ToString("C")
                        'lblFreeWithdrawalsAmount.Text = respSavingInfo.SavingAdvanceInfo.ExceededContributionAmount.ToString("C")
                        lblFreeWithdrawalsAmount.Text = (Math.Truncate(respSavingInfo.SavingAdvanceInfo.ExceededContributionAmount * 100) / 100).ToString("C")

                        'PLAN DE PAGOS ATRASADOS
                        If respSavingInfo.SavingAdvanceInfo.DelayedNumContributions > 0 Then
                            lblOverdueMonthlyContributions.Text = respSavingInfo.SavingAdvanceInfo.DelayedNumContributions.ToString("N")
                            lblOverdueMonthlyContributionsAmount.Text = respSavingInfo.SavingAdvanceInfo.DelayedContributionAmount.ToString("C")

                            lblConsecutiveOverdueContributions.Text = respSavingInfo.SavingAdvanceInfo.ConsecutiveDelayedNumContributions.ToString()
                            lblConsecutiveOverdueContributions.Style.Item("color") = Convert.ToString(IIf(respSavingInfo.SavingAdvanceInfo.ConsecutiveDelayedNumContributions > 3, "red", "black"))

                            lblNoConsecutiveOverdueContributions.Text = respSavingInfo.SavingAdvanceInfo.NoConsecutiveDelayedNumContributions
                            lblNoConsecutiveOverdueContributions.Style.Item("color") = Convert.ToString(IIf(respSavingInfo.SavingAdvanceInfo.NoConsecutiveDelayedNumContributions > 6, "red", "black"))

                            trOverduePayments.Visible = True
                            trNotOverduePayments.Visible = False
                            trHaveProrrogation.Visible = False
                        Else
                            trOverduePayments.Visible = False
                            trNotOverduePayments.Visible = True
                            trHaveProrrogation.Visible = True
                        End If

                        'DOMICILIACION
                        respDebitInfo = service.GetContractDirectDebitBasicInfo(req)
                        If respDebitInfo.ContractDirectDebitBasicInfo.DebitBankAccount.TheBank.Name <> "" Then
                            lblBank.Text = respDebitInfo.ContractDirectDebitBasicInfo.DebitBankAccount.TheBank.Name
                            lblPeriod.Text = respDebitInfo.ContractDirectDebitBasicInfo.DebitDay.ToString()
                            lblAccount.Text = respDebitInfo.ContractDirectDebitBasicInfo.DebitBankAccount.AccountNumber
                            lblAmount.Text = respDebitInfo.ContractDirectDebitBasicInfo.DebitAmount.ToString("C")
                            trHasDomiciliacion.Visible = True
                            trHasntDomiciliacion.Visible = False
                            lblType.Text = respDebitInfo.ContractDirectDebitBasicInfo.ServiceStatus.Name
                        Else
                            trHasDomiciliacion.Visible = False
                            trHasntDomiciliacion.Visible = True
                        End If

                        DisplaySocOrRetail(respSavingInfo.InvestmentContractDetail.InvestmentContract.Status.Identifier, respSavingInfo.InvestmentContractDetail.InvestmentContract.Status.Name, respSavingInfo.SavingAdvanceInfo.HaveProrogation)
                    Else

                        pnlSavingsAdvance.Visible = False
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "El contrato seleccionado no se encuentra Activo.", DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                    End If

                Else

                    pnlSavingsAdvance.Visible = False
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "No existe informaci�n disponible para el contrato.", DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)

                End If

            Catch ex As Exception
                Throw
            End Try
        End Sub

        Public Function GetMonthName(ByVal monthNumber As Integer) As String

            Dim MonthsName() As String = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"}

            If monthNumber >= 1 And monthNumber <= 12 Then
                Return MonthsName(monthNumber - 1)
            Else
                Return "Mes Indefinido"
            End If

        End Function

        Public Sub DisplaySocOrRetail(ByVal contractStatusId As String, ByVal contractStatusDsc As String, ByVal ProrogationActive As Boolean)

            Dim visibleCtes As Boolean = False
            Dim strApp() As String = DotNetNuke.Services.Localization.Localization.GetString("EnableMOC_ER", Me.LocalResourceFile).Split("|")
            Dim strStyle = String.Empty

            For i As Integer = 0 To strApp.Length - 1
                Dim namesApp() As String = strApp(i).Split(",")
                If PortalSettings.PortalName = namesApp(0).ToString.Trim() Then
                    visibleCtes = CType(namesApp(1).ToString(), Boolean)
                    Exit For
                End If
            Next

            pnlMocAndMonths.Visible = visibleCtes
            pnlFreeWithdrawalsAmount.Visible = visibleCtes
            pnl_NMNC.Visible = visibleCtes

            If visibleCtes Then
                lblContractStatus.Text = contractStatusDsc
                lblProrroga.Text = IIf(ProrogationActive, "Si", "No")
                lblHaveProrrogation.Text = IIf(ProrogationActive, "Si", "No")
            Else
                lblContractStatus.Text = Convert.ToString(IIf(contractStatusId = "5" Or contractStatusId = "135", DotNetNuke.Services.Localization.Localization.GetString("ActiveAndReactive", Me.LocalResourceFile), DotNetNuke.Services.Localization.Localization.GetString("PaidUp", Me.LocalResourceFile)))
            End If
        End Sub

#End Region

#Region "Properties"
        ReadOnly Property PlanName() As String
            Get
                Return "<b>Mi plan de ahorro para " + Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractPlan")) + "</b>"
            End Get
        End Property
#End Region

        Private Function ContractPaymentPlanIsComplete(ByVal contract As String, ByRef planId As String, ByRef productId As String) As Boolean

            Dim req As New InvestmentContractRetailServiceSvcProxy.ContractRequest
            Dim res As InvestmentContractRetailServiceSvcProxy.InvestmentContractDetailInfoResponse
            Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
            Dim flag As Boolean = True
            req.ContractIdentifier = contract
            res = service.GetContractDetailInfo(req)

            If Not res Is Nothing Then
                If res.InvestmentContractDetail.InvestmentContract.Plan.PlanGeneric.Identifier = String.Empty Then
                    flag = False
                Else
                    planId = res.InvestmentContractDetail.InvestmentContract.Plan.PlanGeneric.Identifier
                    productId = res.InvestmentContractDetail.InvestmentContract.Product.Identifier
                End If
            End If
            Return flag
        End Function

        'MUNMIG - 18MAR09 
        Private Function VerifyValidDateTime(ByVal yearFind As Integer, ByVal monthFind As Integer, ByVal dayFind As Integer) As DateTime

            Dim dayNumbers As Integer = Convert.ToInt32(DateTime.DaysInMonth(yearFind, 2))
            Dim validDate As DateTime = DateTime.MinValue

            If monthFind = 2 And dayFind > 28 Then
                validDate = New DateTime(yearFind, monthFind, dayNumbers)
            Else
                validDate = New DateTime(yearFind, monthFind, dayFind)
            End If

            Return validDate
        End Function

        Private Function GetContractBeginningDate(ByVal FirstContribution As DateTime, ByVal DateSOC As DateTime) As DateTime

            Dim beginningDate As DateTime = New DateTime(1900, 1, 1)

            If (FirstContribution.Ticks >= DateSOC.Ticks) Then
                beginningDate = FirstContribution
            Else
                beginningDate = DateSOC
            End If

            If (beginningDate.Ticks = New DateTime(1900, 1, 1).Ticks) Then
                beginningDate = DateTime.Now
            End If
            Return beginningDate

        End Function

        Private Function GetBalanceAmount(ByRef responseBalance As InvestmentContractRetailServiceSvcProxy.InvestmentContractBalanceResponse) As Double

            Dim counterElem As Integer = 0
            Dim Total As Double = 0

            Dim FundTable As DataTable = New System.Data.DataTable
            Dim FundTable_cash As DataTable = New System.Data.DataTable()

            Dim Totals() As Double = {0, 0, 0, 0}
            'Obtencion de lista de fondos
            For Each Fund As InvestmentContractRetailServiceSvcProxy.InvestmentFundValue In responseBalance.Balance.InvestmentFundsBalance
                counterElem = counterElem + 1
                Total = Total + Fund.MarketValue.Sale 'saldo en fondos
            Next
            counterElem = 0
            'Obtencion de lista de fondos efectivo
            For k = 0 To responseBalance.Balance.CashBalance.Length - 1
                counterElem = counterElem + 1

                If (responseBalance.Balance.CashBalance(k).InvestmentFund.Identifier.Equals("EF. LIQUIDADO")) Then

                    Total = Total + responseBalance.Balance.CashBalance(k).MarketValue.Sale 'Posicion en valores

                ElseIf responseBalance.Balance.CashBalance(k).InvestmentFund.Identifier.Equals("EFECTIVO") Then

                    Totals(2) = responseBalance.Balance.CashBalance(k).MarketValue.Sale 'Total Efectivo

                Else
                    Totals(1) = responseBalance.Balance.CashBalance(k).MarketValue.Sale 'Total operaciones pendientes
                End If
            Next
            Totals(0) = Total
            Totals(3) = Totals(0) + Totals(1) + Totals(2) 'Posicion en valores, Op. Pendientes, Efectivo, Posicion total.
            Return Totals(3)
        End Function
        Private Function GetFinancialIndicatorResponse(ByVal anniversaryYear As DateTime) As InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsResponse
            Dim serviceFinancialIndicator As New InvestmentFundRetailServiceSvcProxy.InvestmentFundRetailServiceContractClient
            Dim reqFinancialIndicator As New InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsRequest
            Dim respFinancialIndicator As New InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsResponse
            Dim indicatorList() As Short = {105}
            reqFinancialIndicator.DCFinancialIndicatorsRequest = New InvestmentFundRetailServiceSvcProxy.DCFinancialIndicatorsRequest
            reqFinancialIndicator.DCFinancialIndicatorsRequest.IndicatorDate = anniversaryYear
            reqFinancialIndicator.DCFinancialIndicatorsRequest.IndicatorsId = indicatorList
            respFinancialIndicator = serviceFinancialIndicator.GetFinancialIndicators(reqFinancialIndicator)
            Return respFinancialIndicator
        End Function
        Private Function GetValueIndicator(ByVal response As InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsResponse) As Decimal
            Dim validDateValue As Decimal
            For Each indicator As InvestmentFundRetailServiceSvcProxy.FinancialIndicatorValue In response.Indicators
                validDateValue = indicator.Value
            Next
            Return validDateValue
        End Function

        'Valida si el plan actual pertenece a los nuevos planes RS 2010
        Public Function IsPlanRS2010(ByVal contractId As String, ByVal planIdentifier As String) As Boolean

            Dim isRS2010 As Boolean
            Try
                Dim serParm As New ParametersRepositoryRetailServiceSvcProxy.ParametersRepositoryRetailServiceContractClient
                Dim reqParm As New ParametersRepositoryRetailServiceSvcProxy.ParameterRequest
                Dim resParm As ParametersRepositoryRetailServiceSvcProxy.ParameterResponse
                Dim paramDC As New ParametersRepositoryRetailServiceSvcProxy.DCParameterRequest

                Dim plansRS2010 As Array


                paramDC.Product = ParametersRepositoryRetailServiceSvcProxy.ProductTypeProduct.RegularSaving
                paramDC.ParameterType = ParametersRepositoryRetailServiceSvcProxy.ParametersType.SKNBSPLNRS1
                paramDC.ContractIdentifier = contractId
                paramDC.PlanIdentifier = planIdentifier
                paramDC.ContractAttributeType = ParametersRepositoryRetailServiceSvcProxy.ContractAttributeType.Standar
                paramDC.ReferentialValue = Double.NaN
                reqParm.DCParameterRequest = paramDC

                resParm = serParm.GetParameter(reqParm)

                If resParm.ParameterValueInfo.Success Then
                    isRS2010 = False
                    plansRS2010 = resParm.ParameterValueInfo.ParameterString.Split("|")
                    For Each planId In plansRS2010
                        If planId = planIdentifier Then
                            isRS2010 = True
                            Exit For
                        End If
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try

            Return isRS2010

        End Function



        'Valida si el plan actual pertenece a los nuevos planes RS ANTES DE 2010
        Public Function IsPlanRSBefore2010(ByVal contractId As String, ByVal planIdentifier As String) As Boolean

            Dim isRSBefore2010 As Boolean
            Try
                Dim serParm As New ParametersRepositoryRetailServiceSvcProxy.ParametersRepositoryRetailServiceContractClient
                Dim reqParm As New ParametersRepositoryRetailServiceSvcProxy.ParameterRequest
                Dim resParm As ParametersRepositoryRetailServiceSvcProxy.ParameterResponse
                Dim paramDC As New ParametersRepositoryRetailServiceSvcProxy.DCParameterRequest

                Dim plansRSBefore2010 As Array


                paramDC.Product = ParametersRepositoryRetailServiceSvcProxy.ProductTypeProduct.RegularSaving
                paramDC.ParameterType = ParametersRepositoryRetailServiceSvcProxy.ParametersType.SKNBSPLNRS0
                paramDC.ContractIdentifier = contractId
                paramDC.PlanIdentifier = planIdentifier
                paramDC.ContractAttributeType = ParametersRepositoryRetailServiceSvcProxy.ContractAttributeType.Standar
                paramDC.ReferentialValue = Double.NaN
                reqParm.DCParameterRequest = paramDC

                resParm = serParm.GetParameter(reqParm)

                If resParm.ParameterValueInfo.Success Then
                    isRSBefore2010 = False
                    plansRSBefore2010 = resParm.ParameterValueInfo.ParameterString.Split("|")
                    For Each planId In plansRSBefore2010
                        If planId = planIdentifier Then
                            isRSBefore2010 = True
                            Exit For
                        End If
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try

            Return isRSBefore2010

        End Function


        'Valida si el plan actual pertenece a los planes meta cumplida
        Public Function IsPlanGoalAccomplished(ByVal contractId As String, ByVal planIdentifier As String) As Boolean

            Dim isGoalAccomplished As Boolean
            Try
                Dim serParm As New ParametersRepositoryRetailServiceSvcProxy.ParametersRepositoryRetailServiceContractClient
                Dim reqParm As New ParametersRepositoryRetailServiceSvcProxy.ParameterRequest
                Dim resParm As ParametersRepositoryRetailServiceSvcProxy.ParameterResponse
                Dim paramDC As New ParametersRepositoryRetailServiceSvcProxy.DCParameterRequest

                Dim plansGoalAccomplished As Array


                paramDC.Product = ParametersRepositoryRetailServiceSvcProxy.ProductTypeProduct.RegularSaving
                paramDC.ParameterType = ParametersRepositoryRetailServiceSvcProxy.ParametersType.SKNBSPLNMC
                paramDC.ContractIdentifier = contractId
                paramDC.PlanIdentifier = planIdentifier
                paramDC.ContractAttributeType = ParametersRepositoryRetailServiceSvcProxy.ContractAttributeType.Standar
                paramDC.ReferentialValue = Double.NaN
                reqParm.DCParameterRequest = paramDC

                resParm = serParm.GetParameter(reqParm)

                If resParm.ParameterValueInfo.Success Then
                    isGoalAccomplished = False
                    plansGoalAccomplished = resParm.ParameterValueInfo.ParameterString.Split("|")
                    For Each planId In plansGoalAccomplished
                        If planId = planIdentifier Then
                            isGoalAccomplished = True
                            Exit For
                        End If
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try

            Return isGoalAccomplished

        End Function


        'Obtienen la suma asegurada del historico
        Public Function GetInsuredAmountByHistoric(ByVal contractIdentifier) As Decimal

            Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient

            Dim req As New InvestmentContractRetailServiceSvcProxy.ContractRequest
            Dim res As New InvestmentContractRetailServiceSvcProxy.ContractInsuredAmountInfoResponse
            Dim currentCalcPeriodo As Integer = 0
            Dim currentInsuredMount As Decimal = 0
            req.ContractIdentifier = contractIdentifier
            res = service.GetContractInsuredAmountPeriod(req)

            If Not res Is Nothing Then
                For Each item As InvestmentContractRetailServiceSvcProxy.ContractInsuredAmountInfo In res.ContractInsuredAmountInfoList

                    If item.calcPeriod > currentCalcPeriodo Then
                        currentCalcPeriodo = item.calcPeriod
                        If item.CurrentInsuredAmount = vbNull Then
                            currentInsuredMount = 0
                        Else
                            currentInsuredMount = Convert.ToDecimal(item.CurrentInsuredAmount)
                        End If

                    End If
                Next
            End If

            Return currentInsuredMount


        End Function

        Private Function GetInsuredAmount(ByVal ContratoID As String) As InsuranceAmountServiceSvcProxy.InsuredAmountResponse

            '15/07/2019 MCO - Inicio de cambio
            Dim InsuredAmountService As New InsuranceAmountServiceSvcProxy.InsuranceAmountServiceContractClient
            Dim requesInsuredAmount As New InsuranceAmountServiceSvcProxy.InsuredAmountRequest
            Dim responseInsuredAmount As New InsuranceAmountServiceSvcProxy.InsuredAmountResponse

            requesInsuredAmount.ContractIdentifier = ContratoID
            requesInsuredAmount.CalculationDate = (Date.Today)

            'Invocaci�n al servicio de Suma Asegurada
            responseInsuredAmount = InsuredAmountService.GetInsuredAmountContract(requesInsuredAmount)
            Return responseInsuredAmount

        End Function

        Private Function SetFormat(ByVal Valor As Double) As String
            Return FormatCurrency(Math.Round(Convert.ToDecimal(Valor), 2))
        End Function

    End Class
End Namespace
