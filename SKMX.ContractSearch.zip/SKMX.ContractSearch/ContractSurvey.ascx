﻿<%@ Control Language="vb" AutoEventWireup="false" CodeBehind="ContractSurvey.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.ContractSurvey" %>
<%@ Register Assembly="SkCo.Survey.WebControl" Namespace="SkCo.Survey.WebControl"
    TagPrefix="cc1" %>
    <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css"
    rel="stylesheet" type="text/css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
<script type="text/javascript">

    function openStaticPopup() {
        $(document).ready(function () {
            $("#dialog").dialog({ modal: true }
            );
            $("#dialog").dialog("option", "height", 300);
            $("#dialog").dialog("option", "width", 1100);
            $("#dialog").dialog("option", "position", 'center');
            //$("#dialog").dialog("option", "title", 'Mi jquery dialog');
            $("#dialog").dialog("option", "title", '');
            //$("#dialog").dialog("option", "buttons", [ { text: "Ok",  click: function () { $(this).dialog("close"); } }]);
        });
    }

    window.onload = openStaticPopup;
</script>
<style type="text/css">
    .TextTableHeader1
    {
        font-size: xx-small;
        border-top-width: 0px;
        border-right-width: 0px;
        border-bottom-width: 1px;
        border-left-width: 0px;
        border-top-style: solid;
        border-right-style: solid;
        border-bottom-style: solid;
        border-left-style: solid;
        border-top-color: #CCCCCC;
        border-right-color: #CCCCCC;
        border-bottom-color: #CCCCCC;
        border-left-color: #CCCCCC;
    }
    
    
    
    .DisplayTable2Header
    {
        text-align: left;
        padding: 2px;
        border-top-width: 1px;
        border-right-width: 1px;
        border-bottom-width: 1px;
        border-left-width: 1px;
        border-top-style: solid;
        border-right-style: solid;
        border-bottom-style: solid;
        border-left-style: solid;
        border-top-color: #FFFFFF;
        border-right-color: #FFFFFF;
        border-bottom-color: #AEDDE6;
        border-left-color: #FFFFFF;
    }
</style>
<%--<b>hooola</b> <a href="javascript:;" onclick="openStaticPopup()" title="Static example">
    Open a popup using a html content from a hidden element.</a>--%>
<div id="dialog" title="Dialog Title">
<%--    I'm in a dialog<br>--%>
    <%--<a href="">liga</a>--%>
    <cc1:ListSurveyContainer ID="ListSurveyContainer1" runat="server" ShowDescription="True"
        ShowNumbering="True" SurveyId="17" />
    <asp:Panel ID="pnlContainer" runat="server">
        <asp:Label ID="lblMessage" runat="server" Font-Bold="true"></asp:Label>
        <asp:LinkButton ID="lnkEnviar" runat="server" OnClick="lnkEnviar_Click">Enviar</asp:LinkButton>
    </asp:Panel>
</div>
