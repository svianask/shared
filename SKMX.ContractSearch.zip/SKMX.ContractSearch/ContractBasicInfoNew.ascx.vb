'Creado por: Freeze Code Networks S. C.
'Fecha de Creaci�n: 23 de Junio de 2006
'Ultima Modificaci�n: 10 de Agosto de 2006

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Services.Exceptions

Imports Skandia.Mx.DNN.Utilities

Namespace Skandia.Mx.Retail.DNN.ContractSearch

    Public MustInherit Class ContractBasicInfoNew
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase


#Region "Controls"
        Protected WithEvents lblContract As System.Web.UI.WebControls.Label
        Protected WithEvents lblName As System.Web.UI.WebControls.Label
        Protected WithEvents lblReferenceNumber As System.Web.UI.WebControls.Label
        Protected WithEvents lblObjectiveAmountResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblmonthlyContributionResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblSumOfPremiumsResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblInitialContributionResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblInitialContributionType As System.Web.UI.WebControls.Label
        Protected WithEvents lblAmountAssuredMax As System.Web.UI.WebControls.Label
        Protected WithEvents cmdBack As System.Web.UI.WebControls.LinkButton
        Protected WithEvents tblContractRegularSavings As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblSavingInfo As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblClientInfo As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents plmonthlyContribution As System.Web.UI.WebControls.Label
        Protected WithEvents plBalanceDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblBalanceDate As System.Web.UI.WebControls.Label
        Protected WithEvents plnContractRegularSavings As System.Web.UI.WebControls.Panel
        Protected WithEvents plnTotal As System.Web.UI.WebControls.Panel
        Protected WithEvents tblTotal As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents plContract As System.Web.UI.WebControls.Label
        Protected WithEvents plName As System.Web.UI.WebControls.Label
        Protected WithEvents plReferenceNumber As System.Web.UI.WebControls.Label
        Protected WithEvents tblGeneralInformation As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents lblError As System.Web.UI.WebControls.Label
        Protected WithEvents lblDinamicMessage As System.Web.UI.WebControls.Label
        Protected WithEvents lblDeductibility As System.Web.UI.WebControls.Label
        Protected WithEvents pnlDeductibility As System.Web.UI.WebControls.Panel
        Protected WithEvents tblDeductibility As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents aMoreInformation As System.Web.UI.HtmlControls.HtmlAnchor
        Protected WithEvents lblContractRegularSavingsHeader As System.Web.UI.WebControls.Label
        Protected WithEvents plObjectiveAmount As System.Web.UI.WebControls.Label
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim service As New ContractSvcProxy.ContractServicesClient

                'service.Credentials = System.Net.CredentialCache.DefaultCredentials
                'service.Timeout = 300000
                'service.RequestHeaderValue = New ContractProxy.RequestHeader
                'service.RequestHeaderValue.Headers = Skandia.OperationCenter.Utilities.WebServiceUtility.PopulateHeaderValues(UserController.GetCurrentUserInfo().Username, "SkandiaOperationCenter")

                Dim req1 As New ContractSvcProxy.Contract1
                Dim res As ContractSvcProxy.RetailContractBasicInfoResponse

                Dim fondo As New ContractSvcProxy.InvesmentFundValue

                req1.Identifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))

                If req1.Identifier <> "" Then
                    If Not req1.Identifier.StartsWith("0") Then

                        res = service.GetRetailContractBasicInfo(req1)

                        service = New ContractSvcProxy.ContractServicesClient
                        'service.Credentials = System.Net.CredentialCache.DefaultCredentials
                        'service.Timeout = 300000
                        'service.RequestHeaderValue = New ContractProxy.RequestHeader
                        'service.RequestHeaderValue.Headers = Skandia.OperationCenter.Utilities.WebServiceUtility.PopulateHeaderValues(UserController.GetCurrentUserInfo().Username, "SkandiaOperationCenter")
                        Dim req2 As New ContractSvcProxy.Contract1
                        Dim resp As New ContractSvcProxy.InvesmentContractBalance1

                        req2.Identifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                        resp = service.GetInvesmentContractBalance(req2)

                        If Not res Is Nothing And Not resp Is Nothing Then
                            FillData(res, resp)
                        End If

                        DisplayDinamicMessage()
                        DisplayDeductibility()
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Opci�n no v�lida. Primero deber� seleccionar el tipo de plan de inversi�n que desea consultar desde la opci�n 'Mis Contratos'.", DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        tblGeneralInformation.Visible = False
                    End If
                Else
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "No se han encontrado contratos.", DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    tblGeneralInformation.Visible = False
                End If
            Catch Exc As Exception

                tblGeneralInformation.Visible = False
                ProcessModuleLoadException(Me, Exc)
                'DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "La informaci�n general no esta disponible por el momento. Por favor contacte al Centro de Atenci�n al Inversionista.", DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)

            End Try
        End Sub

        Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
            Response.Redirect(NavigateURL())
        End Sub

#End Region

#Region "Methods"

        Private Sub FillData(ByVal res As ContractSvcProxy.RetailContractBasicInfoResponse, ByVal values As ContractSvcProxy.InvesmentContractBalance1)

            Dim fondo As New ContractSvcProxy.InvesmentFundValue
            Dim total As Double = 0
            Dim efectivo As Double = 0
            Dim k As Integer = 0
            Dim contratoId As String

            'FLOMAR 07Mar2011
            contratoId = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
            lblContract.Text = contratoId
            lblName.Text = res.ClientInfo.FirstName + " " + res.ClientInfo.MiddleName + " " + res.ClientInfo.LastName

            Dim resContractData As InvestmentContractRetailServiceSvcProxy.InvestmentContractBasicInfoResponse
            Dim serContractData As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
            Dim reqContractData As New InvestmentContractRetailServiceSvcProxy.ContractRequest
            reqContractData.ContractIdentifier = contratoId
            resContractData = serContractData.GetContractBasicInfo(reqContractData)

            Dim serParmNotRef As New ParametersRepositoryRetailServiceSvcProxy.ParametersRepositoryRetailServiceContractClient
            Dim reqParmNotRef As New ParametersRepositoryRetailServiceSvcProxy.ParameterRequest
            Dim resParmNotRef As ParametersRepositoryRetailServiceSvcProxy.ParameterResponse
            Dim paramDCNotRef As New ParametersRepositoryRetailServiceSvcProxy.DCParameterRequest

            If Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractProduct")) = DotNetNuke.Services.Localization.Localization.GetString("ProductRS", Me.LocalResourceFile) Then
                paramDCNotRef.Product = ParametersRepositoryRetailServiceSvcProxy.ProductTypeProduct.RegularSaving
            Else
                paramDCNotRef.Product = ParametersRepositoryRetailServiceSvcProxy.ProductTypeProduct.GlobalTrust
            End If

            paramDCNotRef.ParameterType = ParametersRepositoryRetailServiceSvcProxy.ParametersType.SKNNOTREF01
            paramDCNotRef.ContractIdentifier = contratoId
            paramDCNotRef.PlanIdentifier = resContractData.DCInvestmentContractBasicInfoResponse.InvestmentContract.Plan.PlanGeneric.Identifier
            paramDCNotRef.ContractAttributeType = ParametersRepositoryRetailServiceSvcProxy.ContractAttributeType.Standar 'Normal-5 Vanity-10
            paramDCNotRef.ReferentialValue = Double.NaN
            reqParmNotRef.DCParameterRequest = paramDCNotRef
            resParmNotRef = serParmNotRef.GetParameter(reqParmNotRef)

            If resParmNotRef.ParameterValueInfo.Success Then
                If resParmNotRef.ParameterValueInfo.ParameterValue = 1 Then
                    lblReferenceNumber.Text = "No Aplica."
                Else
                    Dim Retentions As New ContractSearchCommon
                    If DotNetNuke.Services.Localization.Localization.GetString("Flag", Me.LocalResourceFile) = "1" Then
                        If Retentions.HasRetentionsInRoles(contratoId, DotNetNuke.Services.Localization.Localization.GetString("Roles", Me.LocalResourceFile)) Or Not Retentions.ContractPaymentPlanIsComplete(contratoId, MyBase.PortalSettings.PortalName.Trim()) Then
                            lblReferenceNumber.Text = DotNetNuke.Services.Localization.Localization.GetString("Availability", Me.LocalResourceFile)
                        Else
                            lblReferenceNumber.Text = res.ContractInfo.ReferenceNumber
                        End If
                    Else
                        lblReferenceNumber.Text = res.ContractInfo.ReferenceNumber
                    End If
                End If
            End If


            '=====================================================================================================================

            If res.ContractInfo.ProductType = ContractSvcProxy.RetailProductType.RegularSaving And res.ContractInfo.ThePlan.Identifier <> "95" Then
                lblmonthlyContributionResult.Text = Convert.ToString(NotNull(res.ContractInfo.MonthlyContribution.ToString("C"), ""))
                lblObjectiveAmountResult.Text = Convert.ToString(NotNull(res.ContractInfo.SavingObjective.ToString("C"), ""))
                plnContractRegularSavings.Visible = True
            Else
                plnContractRegularSavings.Visible = False
            End If

            'Obtiene el total de los fondos que tiene el contrato seleccionado
            For Each fondo In values.Portfolio
                total = total + fondo.MarketValue
            Next

            'Obtiene el efectivo si es que existe
            For k = 0 To values.Cash.Length - 1
                If values.Cash(k).TheInvesmentFund.InvestmentFundIdentifier.Equals("EF. LIQUIDADO") Then
                    total = total + values.Cash(k).MarketValue
                Else
                    efectivo = efectivo + values.Cash(k).MarketValue
                End If
            Next

            'Obtiene el total m�s efectivo y se lo asigna al Label
            total = total + efectivo
            lblBalanceDate.Text = Convert.ToString(NotNull(total.ToString("C"), ""))

        End Sub

        Private Function BuildURL(ByVal PortalID As Integer, ByVal FriendlyName As String) As String

            Dim strURL As String = "~/" & glbDefaultPage

            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo = objModules.GetModuleByDefinition(PortalID, FriendlyName)
            If Not objModule Is Nothing Then
                strURL = NavigateURL(objModule.TabID)
            End If

            Return strURL

        End Function

        Private Function NotNull(ByVal Value01 As Object, ByVal Value02 As Object) As Object

            Dim dec As Decimal
            Dim dte As DateTime
            If Convert.ToString(Value01).Equals(dec.MinValue.ToString("C")) _
            Or Convert.ToString(Value01).Equals(dte.MinValue.ToString("yyyy-MM-dd")) _
            Or Convert.ToString(Value01).Equals("-1") Then
                Return Value02
            Else
                Return Value01
            End If

        End Function

        Public Sub DisplayDinamicMessage()
            Dim reqContractData As New ContractSvcProxy.Contract1
            Dim resContractData As New ContractSvcProxy.InvesmentContract1
            Dim serContractData As New ContractSvcProxy.ContractServicesClient
            Dim ContractNumber As String

            ContractNumber = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))

            reqContractData.Identifier = ContractNumber
            'serContractData.Credentials = System.Net.CredentialCache.DefaultCredentials
            'serContractData.Timeout = 300000

            resContractData = serContractData.GetContractPlanIdentifier(reqContractData)

            If Not resContractData Is Nothing Then

                Dim reqParameter As New ParametersSvcProxy.GetParameterRequest
                Dim resParameter As New ParametersSvcProxy.GetParameterResponse
                Dim serParameter As New ParametersSvcProxy.ParametersServiceClient

                'serParameter.Credentials = System.Net.CredentialCache.DefaultCredentials
                'serParameter.Timeout = 300000
                'serParameter.RequestHeaderValue = New ParametersProxy.RequestHeader
                'serParameter.RequestHeaderValue.Headers = Skandia.OperationCenter.Utilities.WebServiceUtility.PopulateHeaderValues(UserController.GetCurrentUserInfo().Username, "SkandiaOperationCenter")


                reqParameter.ContractIdentifier = ContractNumber
                reqParameter.ProductIdentifier = resContractData.Product
                reqParameter.PlanIdentifier = resContractData.Plan
                reqParameter.ParameterList = ParametersSvcProxy.ParameterList.CNTSTBSCINF
                reqParameter.ReferentialValue = -1

                If reqParameter.ContractIdentifier <> "" Or reqParameter.ProductIdentifier <> "" Or reqParameter.PlanIdentifier <> "" Then

                    resParameter = serParameter.GetParameter(reqParameter)

                    If Not resParameter Is Nothing Then

                        If resParameter.ParameterValue.ParameterDataType = ParametersSvcProxy.ParameterDataTypes.StringData And resParameter.ParameterValue.ParameterString <> "" Then
                            lblDinamicMessage.Text = resParameter.ParameterValue.ParameterString
                        End If
                    End If

                Else
                    lblDinamicMessage.Text = "Error en los par�metros"
                End If

            End If

        End Sub

        Public Sub DisplayDeductibility()

            Try
                Dim reqPlanId As New ContractSvcProxy.Contract1
                Dim resPlanId As New ContractSvcProxy.InvesmentContract1
                Dim serPlanId As New ContractSvcProxy.ContractServicesClient

                Dim reqParameter As New ParametersSvcProxy.GetParameterRequest
                Dim resParameter As New ParametersSvcProxy.GetParameterResponse
                Dim serParameter As New ParametersSvcProxy.ParametersServiceClient

                Dim ContractId As String = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                Dim Message As String = String.Empty

                aMoreInformation.Visible = False

                reqPlanId.Identifier = ContractId
                'serPlanId.Credentials = System.Net.CredentialCache.DefaultCredentials
                'serPlanId.Timeout = 300000

                resPlanId = serPlanId.GetContractPlanIdentifier(reqPlanId)

                If Not resPlanId Is Nothing Then

                    'serParameter.Credentials = System.Net.CredentialCache.DefaultCredentials
                    'serParameter.Timeout = 300000

                    reqParameter.ContractIdentifier = ContractId
                    reqParameter.ProductIdentifier = resPlanId.Product
                    reqParameter.PlanIdentifier = resPlanId.Plan
                    reqParameter.ParameterList = ParametersSvcProxy.ParameterList.PLNFGAPLDDC
                    reqParameter.ReferentialValue = -1

                    resParameter = serParameter.GetParameter(reqParameter)

                    If Not resParameter Is Nothing Then

                        If resParameter.ParameterValue.ParameterDataType = ParametersSvcProxy.ParameterDataTypes.DoubleData Then

                            If resParameter.ParameterValue.ParameterValue = 0 Then
                                Message = DotNetNuke.Services.Localization.Localization.GetString("plNoDeductible", Me.LocalResourceFile)
                                aMoreInformation.Visible = True
                            ElseIf resParameter.ParameterValue.ParameterValue = 1 Then
                                Message = DotNetNuke.Services.Localization.Localization.GetString("plDeductible", Me.LocalResourceFile)
                            Else
                                Message = DotNetNuke.Services.Localization.Localization.GetString("plNotApply", Me.LocalResourceFile)
                                aMoreInformation.Visible = True
                            End If

                        End If

                    End If

                End If

                If pnlDeductibility.Visible = False Then
                    pnlDeductibility.Visible = True
                End If

                lblDeductibility.Text = Message

            Catch ex As Exception

                pnlDeductibility.Visible = False

            End Try

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


    End Class

End Namespace