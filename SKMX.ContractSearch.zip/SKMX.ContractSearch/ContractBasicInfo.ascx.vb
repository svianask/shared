Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security

Imports Skandia.Mx.DNN.Utilities
Imports DotNetNuke.Entities.Users

Namespace Skandia.Mx.Retail.DNN.ContractSearch

    Public MustInherit Class ContractBasicInfo
        Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable

        Private Const ActionContractUpdate As String = "ContractUpdate.Action"
        'Private Const ActionContractWelcomeKit As String = "ContractWelcomeKit.Action"
        'Private Const ActionContractBalance As String = "ContractBalance.Action"
        'Private Const ActionContractAllocation As String = "ContractAllocation.Action"
        'Private Const ActionContractTansferFunds As String = "ContractTranferFunds.Action"
        'Private Const ActionAsignacionNip As String = "AsignacionNip.Action"

#Region "Controls"
        Protected WithEvents lblContract As System.Web.UI.WebControls.Label
        Protected WithEvents lblName As System.Web.UI.WebControls.Label
        Protected WithEvents lblRFC As System.Web.UI.WebControls.Label
        Protected WithEvents lblAddress1 As System.Web.UI.WebControls.Label
        Protected WithEvents lblAddress2 As System.Web.UI.WebControls.Label
        Protected WithEvents lblAddress3 As System.Web.UI.WebControls.Label
        Protected WithEvents lblHomePhone As System.Web.UI.WebControls.Label
        Protected WithEvents lblGrender As System.Web.UI.WebControls.Label
        Protected WithEvents lblBirthDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblMaritalStatus As System.Web.UI.WebControls.Label
        Protected WithEvents lblStartDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblFP As System.Web.UI.WebControls.Label
        Protected WithEvents cmdBack As System.Web.UI.WebControls.LinkButton
        Protected WithEvents pnlContractBasicInfo As System.Web.UI.WebControls.Panel
        Protected WithEvents lblmonthlyContributionResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblContributionsResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblObjectiveAmountResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblInitialContributionResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblEndDateResult As System.Web.UI.WebControls.Label
        Protected WithEvents tblContractRegularSavings As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblContractInfo As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents lblReferenceNumber As System.Web.UI.WebControls.Label
        Protected WithEvents lblGiveReferenceInfo As System.Web.UI.WebControls.Label
        Protected WithEvents plnContractRegularSavings As System.Web.UI.WebControls.Panel
        Protected WithEvents lblInitialContributionType As System.Web.UI.WebControls.Label
        Protected WithEvents lblSumOfPremiumsResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblAmountAssuredMax As System.Web.UI.WebControls.Label
        Protected WithEvents lblInsuranceAmount As System.Web.UI.WebControls.Label
        Protected WithEvents lblInsuranceAmountNote As System.Web.UI.WebControls.Label
        Protected WithEvents lblDeductibilityResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblStatusResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblTotalRetentions As System.Web.UI.WebControls.Label
        Protected WithEvents lblSpecialInstructions As System.Web.UI.WebControls.Label
        Protected WithEvents lblOperStatusResult As System.Web.UI.WebControls.Label
        Protected WithEvents lblSegmento As System.Web.UI.WebControls.Label
        Protected WithEvents plEndDate As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents plInsuranceAmount As DotNetNuke.UI.UserControls.LabelControl
        Protected WithEvents plAmounAssuredMax As DotNetNuke.UI.UserControls.LabelControl
#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If PortalSecurity.IsInRole(PortalSettings.RegisteredRoleName.ToString) And Not Session.Item("_ContractSelected") Is Nothing Then
                    Dim cntBlocked As String
                    cntBlocked = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("BlockedMsg")) 'MunMig - 13Abr10
                    If Not cntBlocked.Equals(String.Empty) Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, cntBlocked, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If


                    Dim service As New ContractSvcProxy.ContractServicesClient
                    ' service.Credentials = System.Net.CredentialCache.DefaultCredentials
                    ' service.RequestHeaderValue = New ContractProxy.RequestHeader
                    'service.RequestHeaderValue.Headers = WebServiceUtility.PopulateHeaderValues()
                    ' service.Timeout = 300000

                    Dim req As New ContractSvcProxy.Contract1
                    Dim res As ContractSvcProxy.RetailContractBasicInfoResponse
                    req.Identifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) 'EUGMAR [2006-06-07]

                    res = service.GetRetailContractBasicInfo(req)
                    FillData(res)
                Else
                    Response.Redirect(NavigateURL("Access Denied"), True)
                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
            Response.Redirect(NavigateURL())
        End Sub

#End Region

#Region "Methods"

        Private Sub FillData(ByVal res As ContractSvcProxy.RetailContractBasicInfoResponse)

            Dim Message As String = String.Empty

            Dim contratoId As String = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) 'EUGMAR [2006-06-07]
            'lblContract.Text = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) 'EUGMAR [2006-06-07]
            lblContract.Text = contratoId
            lblName.Text = res.ClientInfo.FirstName + " " + res.ClientInfo.MiddleName + " " + res.ClientInfo.LastName
            lblRFC.Text = res.ClientInfo.RFCCURP
            lblAddress1.Text = res.ClientInfo.HomeAddress.LineOne
            lblAddress2.Text = res.ClientInfo.HomeAddress.LineTwo
            lblAddress3.Text = res.ClientInfo.HomeAddress.Country + ", " + res.ClientInfo.HomeAddress.City
            lblHomePhone.Text = res.ClientInfo.HomePhone
            lblGrender.Text = res.ClientInfo.Grender
            lblBirthDate.Text = res.ClientInfo.BirthDate.ToString("yyyy-MM-dd")
            lblMaritalStatus.Text = res.ClientInfo.MaritalStatus
            'LUNBRU 11-May-2007
            Dim Retentions As New ContractSearchCommon
            Dim contract As String

            'FLOMAR 04Mar11
            Dim resContractData As InvestmentContractRetailServiceSvcProxy.InvestmentContractBasicInfoResponse
            Dim serContractData As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
            Dim reqContractData As New InvestmentContractRetailServiceSvcProxy.ContractRequest
            reqContractData.ContractIdentifier = contratoId
            resContractData = serContractData.GetContractBasicInfo(reqContractData)

            Dim serParmNotRef As New ParametersRepositoryRetailServiceSvcProxy.ParametersRepositoryRetailServiceContractClient
            Dim reqParmNotRef As New ParametersRepositoryRetailServiceSvcProxy.ParameterRequest
            Dim resParmNotRef As ParametersRepositoryRetailServiceSvcProxy.ParameterResponse
            Dim paramDCNotRef As New ParametersRepositoryRetailServiceSvcProxy.DCParameterRequest

            If resContractData.DCInvestmentContractBasicInfoResponse.InvestmentContract.Plan.PlanGeneric.Identifier <> "" Then
                paramDCNotRef.Product = resContractData.DCInvestmentContractBasicInfoResponse.InvestmentContract.Product.Identifier
                paramDCNotRef.ParameterType = ParametersRepositoryRetailServiceSvcProxy.ParametersType.SKNNOTREF01
                paramDCNotRef.ContractIdentifier = contratoId
                paramDCNotRef.PlanIdentifier = resContractData.DCInvestmentContractBasicInfoResponse.InvestmentContract.Plan.PlanGeneric.Identifier
                paramDCNotRef.ContractAttributeType = ParametersRepositoryRetailServiceSvcProxy.ContractAttributeType.Standar 'Normal-5 Vanity-10
                paramDCNotRef.ReferentialValue = Double.NaN
                reqParmNotRef.DCParameterRequest = paramDCNotRef

                resParmNotRef = serParmNotRef.GetParameter(reqParmNotRef)

                If resParmNotRef.ParameterValueInfo.Success Then

                    If resParmNotRef.ParameterValueInfo.ParameterValue = 1 Then
                        If DotNetNuke.Services.Localization.Localization.GetString("Flag", Me.LocalResourceFile) = "1" Then
                            If Retentions.HasRetentionsInRoles(contract, DotNetNuke.Services.Localization.Localization.GetString("Roles", Me.LocalResourceFile)) Or Not Retentions.ContractPaymentPlanIsComplete(contract, MyBase.PortalSettings.PortalName.Trim()) Then
                                lblReferenceNumber.Text = DotNetNuke.Services.Localization.Localization.GetString("Availability", Me.LocalResourceFile)
                            Else
                                '2011/05/09 FLOMAR SHOW REF FOR SOC
                                If PortalSettings.PortalId.ToString <> DotNetNuke.Services.Localization.Localization.GetString("SocPortalId", Me.LocalResourceFile) Then 'PortalClientes
                                    lblReferenceNumber.Text = "No Aplica."
                                Else 'SOC
                                    lblGiveReferenceInfo.Text = DotNetNuke.Services.Localization.Localization.GetString("GiveReferenceInfo", Me.LocalResourceFile)
                                    lblGiveReferenceInfo.Visible = True
                                    lblReferenceNumber.Text = res.ContractInfo.ReferenceNumber
                                End If
                            End If
                        Else
                            '2011/05/09 FLOMAR SHOW REF FOR SOC
                            If PortalSettings.PortalId.ToString <> DotNetNuke.Services.Localization.Localization.GetString("SocPortalId", Me.LocalResourceFile) Then 'PortalClientes
                                lblReferenceNumber.Text = "No Aplica."
                            Else 'SOC
                                lblGiveReferenceInfo.Text = DotNetNuke.Services.Localization.Localization.GetString("GiveReferenceInfo", Me.LocalResourceFile)
                                lblGiveReferenceInfo.Visible = True
                                lblReferenceNumber.Text = res.ContractInfo.ReferenceNumber
                            End If
                        End If
                    Else
                        If DotNetNuke.Services.Localization.Localization.GetString("Flag", Me.LocalResourceFile) = "1" Then
                            If Retentions.HasRetentionsInRoles(contract, DotNetNuke.Services.Localization.Localization.GetString("Roles", Me.LocalResourceFile)) Or Not Retentions.ContractPaymentPlanIsComplete(contract, MyBase.PortalSettings.PortalName.Trim()) Then
                                lblReferenceNumber.Text = DotNetNuke.Services.Localization.Localization.GetString("Availability", Me.LocalResourceFile)
                            Else
                                lblReferenceNumber.Text = res.ContractInfo.ReferenceNumber
                            End If
                        Else
                            lblReferenceNumber.Text = res.ContractInfo.ReferenceNumber
                        End If
                    End If

                End If
            Else
                lblReferenceNumber.Text = "No Disponible"
            End If
            '===========================

            lblFP.Text = res.ContractInfo.FinancialPlannerNumber
            lblStartDate.Text = Convert.ToString(NotNull(res.ContractInfo.OpeningDate.ToString("yyyy-MM-dd"), ""))
            lblStatusResult.Text = res.ContractInfo.Status.Name
            lblOperStatusResult.Text = res.ContractInfo.OperationalStatus.Name
            lblTotalRetentions.Text = Retentions.GetRetentionsNumberByRol(contract).ToString 'Retentions.TotalRetentions.ToString 'LunBru 11-May-2007
            lblSpecialInstructions.Text = res.ContractInfo.SpecialInstructions  'FLOLUI - 15/08/2008
            lblSegmento.Text = res.ClientInfo.ClientSegment.Name     '(PMX) MUNMIG 05Jun09
            'GetSegmento(contratoId, res.ContractInfo.Status.Name) ' MUNMIG - 12/Nov/08

            Message = GetMessage()
            If Message <> "Error" Then
                lblDeductibilityResult.Text = Message
            End If

            If res.ContractInfo.ProductType = ContractSvcProxy.RetailProductType.RegularSaving Then
                lblmonthlyContributionResult.Text = Convert.ToString(NotNull(res.ContractInfo.MonthlyContribution.ToString("C"), ""))
                lblContributionsResult.Text = Convert.ToString(NotNull(res.ContractInfo.RegularPremiumTerm.ToString(), ""))
                lblObjectiveAmountResult.Text = Convert.ToString(NotNull(res.ContractInfo.SavingObjective.ToString("C"), ""))
                lblSumOfPremiumsResult.Text = Convert.ToString(NotNull(res.ContractInfo.SumOfPremiums.ToString("C"), ""))
                lblInitialContributionResult.Text = Convert.ToString(NotNull(res.ContractInfo.InitialContribution.ToString("C"), ""))
                lblEndDateResult.Text = Convert.ToString(NotNull(res.ContractInfo.TermDate.ToString("yyyy-MM-dd"), ""))
                lblInitialContributionType.Text = res.ContractInfo.TheInitialContributionType.Name
                plEndDate.Visible = True
                lblEndDateResult.Visible = True
                plnContractRegularSavings.Visible = True

                Dim req As New ContractSvcProxy.InvesmentContract1
                Dim resp As New ContractSvcProxy.RetailPoliza
                Dim service As New ContractSvcProxy.ContractServicesClient
                'service.Credentials = System.Net.CredentialCache.DefaultCredentials
                'service.RequestHeaderValue = New ContractProxy.RequestHeader
                'service.RequestHeaderValue.Headers = WebServiceUtility.PopulateHeaderValues()

                req.ContractNumber = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) 'EUGMAR [2006-06-07]
                req.ProductType = ContractSvcProxy.RetailProductType.RegularSaving
                resp = service.GetRetailPoliza(req)
                lblAmountAssuredMax.Text = Convert.ToString(NotNull(resp.TheInsured.InsuranceAmount.ToString("C"), ""))

                plInsuranceAmount.Visible = False
                lblInsuranceAmount.Visible = False
                lblInsuranceAmountNote.Visible = False

                If res.ContractInfo.OperationalStatus.Identifier = "15" Then

                    Dim serParm As New ParametersRepositoryRetailServiceSvcProxy.ParametersRepositoryRetailServiceContractClient
                    Dim reqParm As New ParametersRepositoryRetailServiceSvcProxy.ParameterRequest
                    Dim resParm As ParametersRepositoryRetailServiceSvcProxy.ParameterResponse
                    Dim paramDC As New ParametersRepositoryRetailServiceSvcProxy.DCParameterRequest

                    Dim plansCS As Array
                    Dim isCSPlan As Boolean

                    paramDC.Product = ParametersRepositoryRetailServiceSvcProxy.ProductTypeProduct.RegularSaving
                    paramDC.ParameterType = ParametersRepositoryRetailServiceSvcProxy.ParametersType.SKNBSPLNCS
                    paramDC.ContractIdentifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                    paramDC.PlanIdentifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractPlanId"))
                    paramDC.ContractAttributeType = ParametersRepositoryRetailServiceSvcProxy.ContractAttributeType.Standar
                    paramDC.ReferentialValue = Double.NaN
                    reqParm.DCParameterRequest = paramDC

                    resParm = serParm.GetParameter(reqParm)

                    If resParm.ParameterValueInfo.Success Then
                        isCSPlan = False
                        plansCS = resParm.ParameterValueInfo.ParameterString.Split("|")
                        For Each planId In plansCS
                            If planId = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractPlanId")) Then
                                isCSPlan = True
                                Exit For
                            End If
                        Next
                    End If

                    If Not isCSPlan Then

                        Dim serContractDetailInfo As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
                        Dim reqContractDetailInfo As New InvestmentContractRetailServiceSvcProxy.ContractRequest
                        Dim resSavingInfo As New InvestmentContractRetailServiceSvcProxy.InvestmentContractDetailInfoResponse
                        Dim resBalanceAmount As New InvestmentContractRetailServiceSvcProxy.InvestmentContractBalanceResponse

                        reqContractDetailInfo.ContractIdentifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))

                        resBalanceAmount = serContractDetailInfo.GetContractBalance(reqContractDetailInfo)
                        resSavingInfo = serContractDetailInfo.GetContractDetailInfo(reqContractDetailInfo)


                        If Not ((resBalanceAmount Is Nothing) And (resSavingInfo Is Nothing)) Then
                            Dim contractBalance As Double
                            contractBalance = GetBalanceAmount(resBalanceAmount)

                            If (contractBalance * 0.01) < (resSavingInfo.SavingAdvanceInfo.CurrentLifeInsuranceAmount) Then
                                plInsuranceAmount.Visible = True
                                lblInsuranceAmount.Visible = True
                                lblInsuranceAmountNote.Visible = True
                                lblInsuranceAmount.Text = Convert.ToString(NotNull((contractBalance * 0.01).ToString("C"), ""))
                                lblInsuranceAmountNote.Text = DotNetNuke.Services.Localization.Localization.GetString("InsureLifeNote", Me.LocalResourceFile)

                                plAmounAssuredMax.Visible = False
                                lblAmountAssuredMax.Visible = False

                            End If

                        End If

                    End If

                End If

            End If

        End Sub

        Private Function BuildURL(ByVal PortalID As Integer, ByVal FriendlyName As String) As String

            Dim strURL As String = "~/" & glbDefaultPage

            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo = objModules.GetModuleByDefinition(PortalID, FriendlyName)

            If Not objModule Is Nothing Then
                strURL = NavigateURL(objModule.TabID)
            End If

            Return strURL

        End Function

        Private Function NotNull(ByVal Value01 As Object, ByVal Value02 As Object) As Object

            Dim dec As Decimal
            Dim dte As DateTime
            If Convert.ToString(Value01).Equals(dec.MinValue.ToString("C")) _
            Or Convert.ToString(Value01).Equals(dte.MinValue.ToString("yyyy-MM-dd")) _
            Or Convert.ToString(Value01).Equals("-1") Then
                Return Value02
            Else
                Return Value01
            End If

        End Function

        Private Function GetMessage() As String
            Try
                Dim reqPlanId As New ContractSvcProxy.Contract1
                Dim resPlanId As New ContractSvcProxy.InvesmentContract1
                Dim serPlanId As New ContractSvcProxy.ContractServicesClient

                Dim reqParameter As New ParametersSvcProxy.GetParameterRequest
                Dim resParameter As New ParametersSvcProxy.GetParameterResponse
                Dim serParameter As New ParametersSvcProxy.ParametersServiceClient

                Dim ContractId As String = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                Dim Message As String = String.Empty

                reqPlanId.Identifier = ContractId
                'serPlanId.Credentials = System.Net.CredentialCache.DefaultCredentials
                'serPlanId.Timeout = 300000

                resPlanId = serPlanId.GetContractPlanIdentifier(reqPlanId)

                If Not resPlanId Is Nothing Then

                    If Not Session("_ContractSelected") Is Nothing Then 'MUNMIG - 02Mar10 - TransferDNN5
                        CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Add("ContractPlanId", resPlanId.Plan)
                    End If

                    'serParameter.Credentials = System.Net.CredentialCache.DefaultCredentials
                    'serParameter.Timeout = 300000

                    reqParameter.ContractIdentifier = ContractId
                    reqParameter.ProductIdentifier = resPlanId.Product
                    reqParameter.PlanIdentifier = resPlanId.Plan
                    reqParameter.ParameterList = ParametersSvcProxy.ParameterList.PLNFGAPLDDC
                    reqParameter.ReferentialValue = Double.NaN

                    resParameter = serParameter.GetParameter(reqParameter)

                    If Not resParameter Is Nothing Then

                        If resParameter.ParameterValue.ParameterDataType = ParametersSvcProxy.ParameterDataTypes.DoubleData Then

                            If resParameter.ParameterValue.ParameterValue = 0 Then
                                Message = DotNetNuke.Services.Localization.Localization.GetString("plNoDeductible", Me.LocalResourceFile)
                            ElseIf resParameter.ParameterValue.ParameterValue = 1 Then
                                Message = DotNetNuke.Services.Localization.Localization.GetString("plDeductible", Me.LocalResourceFile)
                            Else
                                Message = DotNetNuke.Services.Localization.Localization.GetString("plNotApply", Me.LocalResourceFile)
                            End If

                        End If

                    End If

                End If

                Return Message

            Catch ex As Exception

                Return "Error"

            End Try

        End Function


        Private Function GetBalanceAmount(ByRef responseBalance As InvestmentContractRetailServiceSvcProxy.InvestmentContractBalanceResponse) As Double

            Dim counterElem As Integer = 0
            Dim Total As Double = 0

            Dim FundTable As DataTable = New System.Data.DataTable
            Dim FundTable_cash As DataTable = New System.Data.DataTable()

            Dim Totals() As Double = {0, 0, 0, 0}
            'Obtencion de lista de fondos
            For Each Fund As InvestmentContractRetailServiceSvcProxy.InvestmentFundValue In responseBalance.Balance.InvestmentFundsBalance
                counterElem = counterElem + 1
                Total = Total + Fund.MarketValue.Sale 'saldo en fondos
            Next
            counterElem = 0
            'Obtencion de lista de fondos efectivo
            For k = 0 To responseBalance.Balance.CashBalance.Length - 1
                counterElem = counterElem + 1

                If (responseBalance.Balance.CashBalance(k).InvestmentFund.Identifier.Equals("EF. LIQUIDADO")) Then

                    Total = Total + responseBalance.Balance.CashBalance(k).MarketValue.Sale 'Posicion en valores

                ElseIf responseBalance.Balance.CashBalance(k).InvestmentFund.Identifier.Equals("EFECTIVO") Then

                    Totals(2) = responseBalance.Balance.CashBalance(k).MarketValue.Sale 'Total Efectivo

                Else
                    Totals(1) = responseBalance.Balance.CashBalance(k).MarketValue.Sale 'Total operaciones pendientes
                End If
            Next
            Totals(0) = Total
            Totals(3) = Totals(0) + Totals(1) + Totals(2) 'Posicion en valores, Op. Pendientes, Efectivo, Posicion total.
            Return Totals(3)

        End Function

        'MUNMIG - 12/Nov/08
        'Private Function GetSegmento(ByVal contractId As String, ByVal status As String) As String
        '    Dim result As String = String.Empty

        '    If status.ToUpper = "CANCELADO" Then
        '        Return Nothing
        '    Else
        '        Dim service As New ContractProxy.ContractService
        '        Dim resp As New ContractProxy.InvesmentContractBalance
        '        Dim fondo As New ContractProxy.InvesmentFundValue
        '        Dim contrato As New ContractProxy.Contract

        '        Dim total As Double = 0

        '        Dim separador() As Char = New Char() {"|"}

        '        Dim segmento() As String = DotNetNuke.Services.Localization.Localization.GetString("plSegment", Me.LocalResourceFile).Split(separador)

        '        Dim segmentoB() As String = DotNetNuke.Services.Localization.Localization.GetString("plRangeSegmentB", Me.LocalResourceFile).Split(separador)
        '        Dim segmentoC() As String = DotNetNuke.Services.Localization.Localization.GetString("plRangeSegmentC", Me.LocalResourceFile).Split(separador)

        '        Dim segCInterval() As Double = {Convert.ToDouble(segmentoC(0)), Convert.ToDouble(segmentoC(1))}
        '        Dim segBInterval() As Double = {Convert.ToDouble(segmentoB(0)), Convert.ToDouble(segmentoB(1))}
        '        Dim segAInterval As Double = Convert.ToDouble(DotNetNuke.Services.Localization.Localization.GetString("plRangeSegmentA", Me.LocalResourceFile).ToString())

        '        service.Credentials = System.Net.CredentialCache.DefaultCredentials
        '        service.Timeout = 300000

        '        contrato.Identifier = contractId
        '        resp = service.GetInvesmentContractBalance(contrato)
        '        If Not resp Is Nothing Then
        '            If resp.Portfolio.Length = 0 Then
        '                result = DotNetNuke.Services.Localization.Localization.GetString("plNoFundToSegment", Me.LocalResourceFile)
        '            ElseIf resp.Portfolio.Length > 0 Then

        '                Dim sum As Double = 0.0
        '                For Each fondo In resp.Portfolio
        '                    sum += fondo.MarketValue
        '                Next

        '                total = Math.Round(sum, 2)

        '                If total = 0 Then
        '                    result = DotNetNuke.Services.Localization.Localization.GetString("plNoFundToSegment", Me.LocalResourceFile)
        '                ElseIf total > segCInterval(0) And total <= segCInterval(1) Then
        '                    result = segmento(0)
        '                ElseIf total >= segBInterval(0) And total <= segBInterval(1) Then
        '                    result = segmento(1)
        '                ElseIf total >= segAInterval Then
        '                    result = segmento(2)
        '                End If
        '            End If

        '        End If

        '    End If

        '    Return result
        'End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Optional Interfaces"
        Public ReadOnly Property ModuleActions() As DotNetNuke.Entities.Modules.Actions.ModuleActionCollection Implements DotNetNuke.Entities.Modules.IActionable.ModuleActions
            Get
                Dim productType As String = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractProductType"))
                Dim urlUpdateContract As String = Request.RawUrl
                Dim urlWelcomeKit As String = Request.RawUrl
                Dim urlBalance As String = Request.RawUrl
                Dim urlAllocation As String = Request.RawUrl
                Dim urlTransfer As String = Request.RawUrl
                Dim urlNip As String = Request.RawUrl

                If productType = "RegularSaving" Then 'EUGMAR [2006-06-07]                    
                    ' urlUpdateContract = NavigateURL() & "?ctl=NewContractInfo&contractid=" & Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) & "&Update=Yes" 'EUGMAR [2006-06-07]
                    urlUpdateContract = NavigateURL() & "?ctl=NewContractInfoController&contractid=" & Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) & "&Update=Yes" 'SALLET [2006-08-30]

                Else
                    'urlUpdateContract = NavigateURL() & "?ctl=NewContractInfoGT&contractid=" & Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) & "&Update=Yes" 'EUGMAR [2006-06-07]
                    urlUpdateContract = NavigateURL() & "?ctl=NewContractInfoController&contractid=" & Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) & "&Update=Yes" 'EUGMAR [2006-06-07]
                End If

                urlWelcomeKit = BuildURL(PortalSettings.PortalId, "Impresi�n WelcomeKit")
                urlBalance = BuildURL(PortalSettings.PortalId, "Valuaci�n")
                urlAllocation = BuildURL(PortalSettings.PortalId, "Portafolio Definido")
                urlTransfer = BuildURL(PortalSettings.PortalId, "Transferencias")
                urlNip = BuildURL(PortalSettings.PortalId, "Asignar NIP")

                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                'Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), "", "", "", EditUrl(), False, DotNetNuke.Security.SecurityAccessLevel.ControlPanel, True, False)
                'Actions.Add(GetNextActionID, Localization.GetString(ActionContractTansferFunds, LocalResourceFile), "", "", "", urlTransfer, False, DotNetNuke.Security.SecurityAccessLevel.ControlPanel, True, False)
                'Actions.Add(GetNextActionID, Localization.GetString(ActionContractAllocation, LocalResourceFile), "", "", "", urlAllocation, False, DotNetNuke.Security.SecurityAccessLevel.ControlPanel, True, False)
                'Actions.Add(GetNextActionID, Localization.GetString(ActionContractBalance, LocalResourceFile), "", "", "", urlBalance, False, DotNetNuke.Security.SecurityAccessLevel.ControlPanel, True, False)
                'Actions.Add(GetNextActionID, Localization.GetString(ActionContractWelcomeKit, LocalResourceFile), "", "", "", urlWelcomeKit, False, DotNetNuke.Security.SecurityAccessLevel.ControlPanel, True, False)
                'Actions.Add(GetNextActionID, Localization.GetString(ActionContractUpdate, LocalResourceFile), "", "", "", urlUpdateContract, False, DotNetNuke.Security.SecurityAccessLevel.ControlPanel, True, False)
                'Actions.Add(GetNextActionID, DotNetNuke.Services.Localization.Localization.GetString(ActionAsignacionNip, LocalResourceFile), "", "", "", urlNip, False, SecurityAccessLevel.ControlPanel, True, False)
                Return Actions
            End Get
        End Property

#End Region
    End Class

End Namespace
