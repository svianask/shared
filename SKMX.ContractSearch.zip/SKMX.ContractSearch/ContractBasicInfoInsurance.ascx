﻿<%@ Control Language="vb" AutoEventWireup="false" CodeBehind="ContractBasicInfoInsurance.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.ContractBasicInfoInsurance" %>
<%@ Register TagPrefix="dnn" TagName="SectionHead" Src="~/controls/SectionHeadControl.ascx" %>
<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>

<table id="tblGeneralInformation" cellSpacing="0" cellPadding="0" align="left" border="0"
	runat="server">
	<tr>
    <td>
    <asp:LinkButton runat="server" Font-Bold="true" ForeColor="Black" Text="Cobertura y beneficios adicionales" BackColor="White" 
    ID="lnkBtnCobertura">
    </asp:LinkButton>
    </td>
    </tr>
    <tr>
		<td>
				<asp:table id="tblBenefit" runat="server" Height="56px">
				</asp:table>
                <asp:table id="tblBeneficiary" runat="server" Height="56px">
				</asp:table>

            </td>
	</tr>
	<tr>
        <td height="15">
        </td>
	</tr>
    <tr>
    <td height="15">
    </td>
	</tr>
	<tr>
    <td id="td_TitlePrimDetail" runat="server">
        <asp:LinkButton runat="server" Font-Bold="true" ForeColor="Black" Text="Detalles de prima" BackColor="White" ID="lnkBtnPrima" Visible="false">
    </asp:LinkButton>
    </td>
    </tr>
    <tr>
		<td>
        <asp:table id="tblPrime" runat="server" Height="56px">
        </asp:table>
		</td>
	</tr>

</table>
