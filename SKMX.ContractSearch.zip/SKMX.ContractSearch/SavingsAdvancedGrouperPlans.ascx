<%@ Control Language="vb" AutoEventWireup="false" CodeBehind="SavingsAdvancedGrouperPlans.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.SavingsAdvancedGrouperPlans" %>
<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Register TagPrefix="dnn" TagName="SectionHead" Src="~/controls/SectionHeadControl.ascx" %>

<asp:Panel ID="pnlSavingsAdvancedGrouperPlans" runat="server" Width="550" CssClass="skGeneralFont">
    <TABLE cellSpacing="0" cellPadding="0" width="550" align="center" border="0">
        <tr>
            <td>
                <asp:panel id="pnlMySavingPlan" Width="550" Runat="server" CssClass="skGeneralFont">                
                    <dnn:sectionhead id="lstMySavingPlan" runat="server" text="<b>Mi Plan Contratado</b>" resourcekey="lstMySavingPlan" isexpanded="true" includerule="True" section="tblMySavingPlan"></dnn:sectionhead>                    
                    <table id="tblMySavingPlan" class="TableStyle" cellSpacing="0" cellPadding="3" width="550" border="0" runat="server">
                        <tr>
                            <td colspan="2" align="center" class="txt_forma">Programa de Aportaciones</td>
                            <td colspan="2" align="center" class="txt_forma">Informaci&oacute;n del Seguro de Vida</td>
                        </tr>
                        <tr>
                            <td class="txt_forma">Inicio de Programa:</td>
                            <td><asp:Label id="lblPlanStartDate" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                            <td class="txt_forma">Inicio de Seguro:</td>
                            <td><asp:Label id="lblInsuranceStartDate" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                        </tr>
                        <tr>
                            <td class="txt_forma">Fin de Programa:</td>
                            <td><asp:Label id="lblPlanEndDate" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                            <td class="txt_forma">Fin de Seguro:</td>
                            <td><asp:Label id="lblInsuranceEndDate" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                        </tr>
                        <tr>
                            <td class="txt_forma">Meta:</td>
                            <td><asp:Label id="lblPlanGoal" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                            <td class="txt_forma"><%=strInitialSA%></td>
                            <td><asp:Label id="lblInsuranceAmount" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                        </tr>
                        <tr>
                            <td class="txt_forma">Aportaci&oacute;n Mensual:</td>
                            <td><asp:Label id="lblMonthlyAmount" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                            <td class="txt_forma"><%=strCurrentSA%></td>
                            <td><asp:Label id="lblCurrentLifeInsuranceAmount" runat="server" CssClass="skGeneralFont"></asp:Label></td>

                        </tr>
                        <tr>
                            <td class="txt_forma">Plazo (meses):</td>
                            <td><asp:Label id="lblPlanMonths" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                            <td class="txt_forma"><asp:Label id="lblInsuranceProfitLabel" runat="server"></asp:Label></td>
                            <td><asp:Label id="lblInsuranceProfit" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                        </tr>
                        <tr>
                            <td class="txt_forma">Suma de Aportaciones:</td>
                            <td><asp:Label id="lblContributionsSum" runat="server" CssClass="skGeneralFont"></asp:Label></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr><td colspan="4">&nbsp;</td></tr>
                        <tr><td colspan="4">&nbsp;</td></tr>
                        <tr><td colspan="4" class="skGeneralFont" align="center" style="background-color:#F1F1F1;text-align: justify">* La suma asegurada para el contrato seleccionado, se actualiza todos los d&iacute;as primero del mes, y se mantiene el monto vigente por el mes es curso.
                            
                        </td></tr>
                        <tr><td colspan="4">&nbsp;</td></tr>
                    </table>                    
                </asp:panel>
            </td>
        </tr>
        <tr>
            <td>
                <asp:panel id="pnlPlanProgress" Width="550" Runat="server" CssClass="skGeneralFont">
                    <dnn:sectionhead id="lstPlanProgress" runat="server" text="<b>Avance de mi plan</b>" resourcekey="lstPlanProgress" isexpanded="true" includerule="True" section="tblPlanProgress"></dnn:sectionhead>
                    <table id="tblPlanProgress" cellSpacing="0" cellPadding="3" width="550" border="0" runat="server">
                        <tr><td colspan="2"><b>Programa de Aportaciones</b></td></tr>
                        <tr>
                            <td colspan="2">
                                <table id="tblDetail" class="headerTable" cellSpacing="0" cellPadding="3" width="550" runat="server" style="border:1px #EFEFEF solid">
                                    <tr class="headerTable" style="color:#FFFFFF;">
                                        <td></td>
                                        <td>&iquest;Qu&eacute; Deber&iacute;a Llevar?</td>
                                        <td>&iquest;Qu&eacute; Llevo?</td>
                                        <td>Por Cumplir</td>
                                    </tr>
                                    <tr class="skMain">
                                        <td>Monto de aportaciones</td>
                                        <td><asp:Label id="lblContributionAmount" runat="server"></asp:Label></td>
                                        <td><asp:Label id="lblContributionCurrentAmount" runat="server"></asp:Label></td>
                                        <td><asp:Label id="lblContributionRemainingAmount" runat="server"></asp:Label></td>
                                    </tr>
                                    <tr class="skMain2">
                                        <td>N&uacute;mero de aportaciones</td>
                                        <td><asp:Label id="lblContributionNumber" runat="server"></asp:Label></td>
                                        <td><asp:Label id="lblContributionCurrentNumber" runat="server"></asp:Label></td>
                                        <td><asp:Label id="lblContributionRemainingNumber" runat="server"></asp:Label></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr class="skGeneralFont">
                            <td><b>Aportaciones Adicionales:</b></td>                            
                            <td><asp:Label id="lblAdditionalContributions" runat="server"></asp:Label></td>                            
                        </tr>
                        <tr class="skGeneralFont"><td colspan="2">&nbsp;</td></tr>
                        <tr class="skGeneralFont">
                            <td><b>Aportaciones a Favor:</b></td>
                            <td><asp:Label id="lblNoContributionsNumberAllowed" runat="server"></asp:Label></td>
                        </tr>                        
                        <tr class="skGeneralFont"><td colspan="2">&nbsp;</td></tr>
                        <tr class="skGeneralFont"><td colspan="2" style="background-color:#F1F1F1;text-align: justify" 
                                align="center">*Aportaciones a Favor: Con el fin de que usted cumpla con su META a pesar de los momentos dif&iacute;ciles que se le pueden presentar, Skandia le otorga la posibilidad de dejar de realizar ciertas aportaciones mensuales a su programa. Para mayor informaci&oacute;n consulte las condiciones generales.</td></tr>
                        <tr class="skGeneralFont"><td colspan="2">&nbsp;</td></tr>
                        <tr class="skGeneralFont"><td colspan="2">&nbsp;</td></tr>
                    </table>
                </asp:panel>
            </td>
        </tr>
        <tr>
            <td>
                <asp:panel id="pnlDirectDebit" Width="550" Runat="server" CssClass="skGeneralFont">
                    <dnn:sectionhead id="lstDirectDebit" runat="server" text="<b>Domiciliaci&oacute;n</b>" resourcekey="lstDirectDebit" isexpanded="true" includerule="True" section="tblDirectDebit"></dnn:sectionhead>
                    <table id="tblDirectDebit" cellSpacing="0" cellPadding="3" width="550" border="0" runat="server">
                        <tr class="skMain">
                            <td>Banco:</td>
                            <td><asp:Label id="lblBancoDomicialiacion" runat="server"></asp:Label></td>
                            <td>Cuenta:</td>
                            <td><asp:Label id="lblCtaDomiciliacion" runat="server"></asp:Label></td>
                        </tr>
                        <tr class="skMain2">
                            <td>D&iacute;a de cobro:</td>
                            <td><asp:Label id="lblDiaCobroDomiciliacion" runat="server"></asp:Label></td>
                            <td>Importe:</td>
                            <td><asp:Label id="lblImporteDomiciliacion" runat="server"></asp:Label></td>
                        </tr>
                        <tr class="skGeneralFont"><td colspan="3">&nbsp;</td></tr>
                        <tr class="skGeneralFont"><td colspan="3">&nbsp;</td></tr>
                    </table>
                </asp:panel>
            </td>            
        </tr>
        <tr>
            <td>
                    <asp:panel id="pnlLeyenda" Width="550" Runat="server" CssClass="skGeneralFont">
                        <tr><td class="txt_forma" colspan="3"><asp:Label id="lblLeyendaActivas" runat="server" 
                                    Font-Bold="True" ForeColor="Black"></asp:Label></td></tr>
                        <tr><td colspan="3">&nbsp;</td></tr>
                    </asp:panel>            
            </td>
        
        </tr>
        <tr>
            <td>
                <asp:panel ID=pnlHistorico Width="550" Runat="server" Visible="false" CssClass="skGeneralFont">                
                    <table id=tblHistorico class="TableStyle" cellSpacing="0" cellPadding="3" width="550" border="0" runat="server">
                    <tr><td class="txt_forma">Hist&oacute;rico del Programa de Aportaciones</td></tr>
                        <tr>
                            <td>
                                <asp:GridView ID="dgvHistoricoAportaciones" runat="server"  
                                    AutoGenerateColumns="false" class="TableStyle"
                                    EnableModelValidation="True"  cellSpacing="0" cellPadding="3" width="550" 
                                    border="1" AllowPaging="True"  >
                                    <AlternatingRowStyle CssClass="skMain2" />
                                    <RowStyle CssClass="skMain" />
                                    <HeaderStyle HorizontalAlign="Center" CssClass="headerTable" />
                                    <Columns>
                                    <asp:BoundField DataField="startDateContractPlan" HeaderText="Inicio de Plan" ItemStyle-CssClass="skGeneralFont" />
                                    <asp:BoundField DataField="monthlyContribution" DataFormatString="{0:C}" HeaderText="Aportaci&oacute;n mensual" ItemStyle-CssClass="skGeneralFont" />
                                    <asp:BoundField DataField="sumContributions" DataFormatString="{0:C}" HeaderText="Suma de aportaciones" ItemStyle-CssClass="skGeneralFont" />
                                    <asp:BoundField DataField="sumInsuredAmount" DataFormatString="{0:C}" HeaderText="Suma Asegurada Vigente" ItemStyle-CssClass="skGeneralFont" />

                                
                                    </Columns>
                                
                                </asp:GridView>
                                </td>
                        </tr>
                        <tr>
                        <%--<td align="center">
								<asp:panel id="pnlRate" Width="550px" Runat="server">
									<table class="TableStyle" width="550" bgColor="#f1f1f1">
										<tr>
											<td class="TDTextTableCell" align="center">Aportaci&oacute;n mensual sugerida por Skandia 
												de acuerdo a la inflaci&oacute;n:
												<asp:Label id="lblSuggestedMonthlyContribution" Runat="server" CssClass="TDTextTableCell"></asp:Label></TD>
										</tr>
										<tr>
											<td class="TDTextTableCell" align="center">La tasa de inflaci&oacute;n en el periodo
												<asp:Label id="lblMonthRate" Runat="server"></asp:Label>
												<asp:Label id="lblFirstYear" Runat="server"></asp:Label>
												<asp:Label id="lblSecondYear" Runat="server"></asp:Label>&nbsp;fue de:
												<asp:Label id="lblInflationRate" Runat="server"></asp:Label></TD>
										</tr>
									</table>
								</asp:panel></td> --%>                    

                        </tr>
                    
                    </table>               
                </asp:panel>            
            </td>
        
        </tr>
    </TABLE>
</asp:Panel>
<style>
    table tr td .grayBorder
    {
        border:1px solid darkgray;
    }
    
    .TableStyle th
    {
    	color:#ffffff;
    	font-size: xx-small;
    	font-weight:bold;
    	
    	}
</style>
