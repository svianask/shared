Imports System.Collections.Specialized
Imports DotNetNuke.Entities.Users
Imports Skandia.Mx.DNN.Utilities

Namespace Skandia.Mx.Retail.DNN.ContractSearch

    Public Class ContractSearchCommon

        Dim _RetentionsNumberByRoles As ListDictionary

        Public Property RetentionsNumberByRoles() As ListDictionary
            Get
                Return _RetentionsNumberByRoles
            End Get
            Set(ByVal Value As ListDictionary)
                _RetentionsNumberByRoles = Value
            End Set
        End Property

        Public Function HasRetentionsInRoles(ByVal contractId As String, ByVal roles As String) As Boolean
            Dim service As New ContractRetentionSvcProxy.ContractRetentionServiceClient
            Dim resp As New ContractRetentionSvcProxy.SearchContractRetentionResponse
            Dim req As New ContractRetentionSvcProxy.SearchContractRetentionRequest


            'service.RequestHeaderValue = New ContractRetentionProxy.RequestHeader
            'service.RequestHeaderValue.Headers = Skandia.OperationCenter.Utilities.WebServiceUtility.PopulateHeaderValues()

            req.ContractId = contractId
            resp = service.GetContractRetentions(req)
            'Me.TotalRetentions = resp.ContractRetentions.Length

            If resp.ContractRetentions.Length() > 0 Then
                'hay retenciones
                Dim delimStr As String = ","
                Dim delimiter As Char() = delimStr.ToCharArray()
                Dim rolesId As String() = Nothing
                Dim totalretentions As Integer = 0
                rolesId = roles.Split(delimiter)

                For I As Integer = 0 To resp.ContractRetentions.Length - 1
                    For J As Integer = 0 To rolesId.Length - 1
                        If resp.ContractRetentions(I).Retention.RetentionRoleId = Convert.ToInt32(rolesId(J)) Then
                            totalretentions = totalretentions + 1
                        End If
                    Next J
                Next I

                If totalretentions > 0 Then
                    Return True
                Else
                    Return False
                End If

            Else
                Return False
            End If
        End Function

        Public Function GetRetentionsNumberByRol(ByVal contractId As String) As Integer
            Dim service As New ContractRetentionSvcProxy.ContractRetentionServiceClient
            Dim resp As New ContractRetentionSvcProxy.SearchContractRetentionResponse
            Dim req As New ContractRetentionSvcProxy.SearchContractRetentionRequest

            'service.Credentials = System.Net.CredentialCache.DefaultCredentials

            req.ContractId = contractId
            resp = service.GetContractRetentions(req)

            If resp.ContractRetentions.Length() > 0 Then
                'hay retenciones
                Dim RetentionRoles As New ListDictionary
                Dim retention As New ContractRetentionSvcProxy.ContractDetailRetention

                For i As Integer = 0 To resp.ContractRetentions.Length - 1
                    If RetentionRoles.Contains(resp.ContractRetentions(i).Retention.RolId) Then
                        RetentionRoles.Item(resp.ContractRetentions(i).Retention.RolId) = Convert.ToInt32(RetentionRoles.Item(resp.ContractRetentions(i).Retention.RolId)) + 1
                    Else
                        RetentionRoles.Add(resp.ContractRetentions(i).Retention.RolId, 1)
                    End If

                Next

                Me.RetentionsNumberByRoles = RetentionRoles

                Return RetentionRoles.Count

            Else
                Return 0
            End If
        End Function

        Public Function ContractPaymentPlanIsComplete(ByVal contract As String, ByVal portal As String) As Boolean

            Dim request As New ContractSvcProxy.SearchNewContractRequest
            Dim response As New ContractSvcProxy.SearchNewContractResponse
            Dim searchService As New ContractSvcProxy.ContractServicesClient
            Dim flag As Boolean = True

            'searchService.Credentials = System.Net.CredentialCache.DefaultCredentials
            'searchService.RequestHeaderValue = New ContractProxy.RequestHeader
            'searchService.RequestHeaderValue.Headers = WebServiceUtility.PopulateHeaderValues()

            request.ContractIdentifier = New ContractSvcProxy.Contract
            request.InitialDate = New DateTime(1900, 1, 1)
            request.ContractIdentifier.Identifier = contract

            response = searchService.SearchForNewContracts(request)

            If Null.IsNull(response) Then
                flag = True
            Else
                For Each foundContract As ContractSvcProxy.FoundNewContractInformation In response.FoundContracts
                    If foundContract.TheContract.ContractNumber.Equals(contract) Then
                        flag = False
                        Exit For
                    End If
                Next
            End If

            Return flag
        End Function

    End Class
End Namespace

