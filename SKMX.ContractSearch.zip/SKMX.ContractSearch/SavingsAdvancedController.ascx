<%@ Control Language="vb" AutoEventWireup="false" CodeBehind="SavingsAdvancedController.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.SavingsAdvancedController" %>
<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Register TagPrefix="dnn" TagName="SectionHead" Src="~/controls/SectionHeadControl.ascx" %>
<asp:Panel ID="pnlSavingsAdvancedController" runat="server" Width="550">
</asp:Panel>