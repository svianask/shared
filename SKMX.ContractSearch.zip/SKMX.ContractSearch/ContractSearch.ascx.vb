Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports System.Net
Imports DotNetNuke.Entities.Users
Imports Skandia.Mx.DNN.Utilities

Namespace Skandia.Mx.Retail.DNN.ContractSearch

    Public MustInherit Class ContractSearch
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

        Private Delegate Function SearchForContractsDEL(ByVal req As InvestmentContractRetailServiceSvcProxy.SearchContractRequest) As InvestmentContractRetailServiceSvcProxy.SearchContactResponse

        Public jQueryPath As String


#Region "Controls"
        Protected WithEvents pnlContractSearch As System.Web.UI.WebControls.Panel
        Protected WithEvents txtSearch As System.Web.UI.WebControls.TextBox
        Protected WithEvents radSearchContract As System.Web.UI.WebControls.RadioButton
        Protected WithEvents radSearchRFC As System.Web.UI.WebControls.RadioButton
        Protected WithEvents radSearchName As System.Web.UI.WebControls.RadioButton
        Protected WithEvents lstPlans As System.Web.UI.WebControls.DropDownList
        Protected WithEvents grdSearchResult As System.Web.UI.WebControls.DataGrid
        Protected WithEvents grdInsuranceResults As System.Web.UI.WebControls.DataGrid
        Protected WithEvents pnlContractSerchResults As System.Web.UI.WebControls.Panel
        Protected WithEvents rfvSearch As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents imbSearch As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lblContractsIn As System.Web.UI.WebControls.Label
        Protected WithEvents lblContracts As System.Web.UI.WebControls.Label
        Protected WithEvents lblHeaderContracts As System.Web.UI.WebControls.Label
        Protected WithEvents lblHeaderContractsIn As System.Web.UI.WebControls.Label
#End Region

  

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ScriptManager.RegisterStartupScript(Me.Page, Page.GetType(), "AnyKey", "PopUp();", True)
                ScriptManager.GetCurrent(Me.Page).AsyncPostBackTimeout = 1800

                jQueryPath = DotNetNuke.Services.Localization.Localization.GetString("jQueryPath", Me.LocalResourceFile)


                imbSearch.ImageUrl = DotNetNuke.Services.Localization.Localization.GetString("btnImgSearch", Me.LocalResourceFile)
                Session.Remove("_ClientAlert")
                '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                'SET USER SESSION TIME OUT TO 30 MINUTES
                Session.Timeout = 30
                If Not Page.IsPostBack Then
                    'MunMig - 15Jul10
                    Dim serv As New ProductsRetailServiceSvcProxy.ProductsRetailServiceContractClient
                    Dim response As ProductsRetailServiceSvcProxy.PlansResponse
                    Dim request As New ProductsRetailServiceSvcProxy.VoidRequest

                    response = serv.GetPlansRetail(request)

                    If Not response Is Nothing And response.Plans.Length > 0 Then
                        Dim currPlan As ProductsRetailServiceSvcProxy.PlanDetail
                        For Each currPlan In response.Plans
                            'Dim item As New ListItem(currPlan.PlanProduct.Name + " - " + currPlan.Name, currPlan.PlanProduct.Identifier + "," + currPlan.Identifier)
                            Dim item As New ListItem(currPlan.Product.Name + " - " + currPlan.Plan.PlanPlatform.Name, currPlan.Product.Identifier + "," + currPlan.Plan.PlanPlatform.Identifier)
                            lstPlans.Items.Add(item)
                        Next
                    Else
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Aviso", "No se obtuvieron planes", Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If

            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub imbSearch_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imbSearch.Click
            Try
                Page.Validate()
                If Not Page.IsValid Then
                    Return
                End If
                'GT and RS Contracts Search
                'BAROMA 09-05-11 GreenLight Funcionality
                Me.lblHeaderContracts.Visible = False
                Me.lblHeaderContractsIn.Visible = False
                Me.lblContracts.Visible = False
                Me.lblContractsIn.Visible = False

                'BAROMA 25-05-11 GreenLight No Funcionality
                Dim greenLightFlag As Int16
                greenLightFlag = 0

                Dim req As New InvestmentContractRetailServiceSvcProxy.SearchContractRequest
                Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient

                req.DCSearchContractRequest = New InvestmentContractRetailServiceSvcProxy.DCSearchContractRequest

                If (Not lstPlans.SelectedValue.Equals("0")) Then
                    req.DCSearchContractRequest.Product = Split(lstPlans.SelectedValue, ",")(0)
                    req.DCSearchContractRequest.Plan = Split(lstPlans.SelectedValue, ",")(1)
                End If

                req.DCSearchContractRequest.SearchPattern = txtSearch.Text
                If Me.radSearchContract.Checked Then
                    req.DCSearchContractRequest.SearchType = InvestmentContractRetailServiceSvcProxy.SearchContractType.ByContract
                ElseIf Me.radSearchName.Checked Then
                    req.DCSearchContractRequest.SearchType = InvestmentContractRetailServiceSvcProxy.SearchContractType.ByName
                ElseIf Me.radSearchRFC.Checked Then
                    req.DCSearchContractRequest.SearchType = InvestmentContractRetailServiceSvcProxy.SearchContractType.ByRFCCURP
                End If

                req.DCSearchContractRequest.SearchProductType = 0
                '-------------------------------------------------------------------------------->
                'GL Contracts Search
                Dim reqIn As New InvestmentContractRetailServiceSvcProxy.SearchContractRequest
                Dim serviceIn As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient

                reqIn.DCSearchContractRequest = New InvestmentContractRetailServiceSvcProxy.DCSearchContractRequest

                reqIn.DCSearchContractRequest.SearchPattern = txtSearch.Text

                If Me.radSearchContract.Checked Then
                    reqIn.DCSearchContractRequest.SearchType = InvestmentContractRetailServiceSvcProxy.SearchContractType.ByContract
                ElseIf Me.radSearchName.Checked Then
                    reqIn.DCSearchContractRequest.SearchType = InvestmentContractRetailServiceSvcProxy.SearchContractType.ByName
                ElseIf Me.radSearchRFC.Checked Then
                    reqIn.DCSearchContractRequest.SearchType = InvestmentContractRetailServiceSvcProxy.SearchContractType.ByRFCCURP
                End If

                reqIn.DCSearchContractRequest.SearchProductType = 1
                '---------------------------------------------------------------------------------->

                Dim respAsync As New SearchForContractsDEL(AddressOf service.SearchForContracts)
                Dim respAsyncIn As New SearchForContractsDEL(AddressOf serviceIn.SearchForContracts)

                Dim res As InvestmentContractRetailServiceSvcProxy.SearchContactResponse
                Dim resIn As InvestmentContractRetailServiceSvcProxy.SearchContactResponse

                'BAROMA 25-05-11 GreenLight No Funcionality
                If greenLightFlag = Convert.ToInt16(DotNetNuke.Services.Localization.Localization.GetString("FlagNoGreenLight", Me.LocalResourceFile)) Then
                    Dim ar1 As IAsyncResult = respAsync.BeginInvoke(req, Nothing, Nothing)
                    Dim ar2 As IAsyncResult = respAsyncIn.BeginInvoke(reqIn, Nothing, Nothing)

                    While Not ar1.IsCompleted OrElse Not ar2.IsCompleted
                        System.Threading.Thread.Sleep(50)
                    End While
                    res = respAsync.EndInvoke(ar1)
                    resIn = respAsyncIn.EndInvoke(ar2)

                Else
                    Dim ar1 As IAsyncResult = respAsync.BeginInvoke(req, Nothing, Nothing)
                    Dim ar2 As IAsyncResult = respAsync.BeginInvoke(req, Nothing, Nothing)
                    While Not ar1.IsCompleted
                        System.Threading.Thread.Sleep(50)
                    End While
                    res = respAsync.EndInvoke(ar1)
                    resIn = respAsync.EndInvoke(ar2)
                End If

                If (res.FoundContracts.Length = 0) And (resIn.FoundContracts.Length = 0) Then
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, "Aviso", "No se obtuvieron contratos", Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    Me.grdSearchResult.Visible = False
                    Me.grdSearchResult.DataSource = Nothing
                    Me.grdSearchResult.DataBind()
                    Me.lblHeaderContracts.Visible = False
                    Me.grdInsuranceResults.Visible = False
                    Me.grdInsuranceResults.DataSource = Nothing
                    Me.grdInsuranceResults.DataBind()
                    Me.lblHeaderContractsIn.Visible = False
                Else
                    'initialize session variable for module soc object context with FoundContracts
                    If (Not res Is Nothing And res.FoundContracts.Length > 0) Then

                        Me.grdSearchResult.Visible = True

                        If Session.Item("_ModuleContextSocObject1") Is Nothing Then
                            Session.Add("_ModuleContextSocObject1", New Object)
                        End If

                        Dim arrayMaestro As New List(Of InvestmentContractRetailServiceSvcProxy.FoundContractInformation)
                        Dim arrayDetalle As New List(Of InvestmentContractRetailServiceSvcProxy.FoundContractInformation)

                        For Each item As InvestmentContractRetailServiceSvcProxy.FoundContractInformation In res.FoundContracts

                            If item.PlanInfo.PlanGrouping = False And _
                                item.PlanInfo.PlanGrouped = True Then
                                arrayDetalle.Add(item)
                            Else
                                arrayMaestro.Add(item)
                            End If
                        Next

                        If Session.Item("_ModuleContextSocObject1") Is Nothing Then
                            Session.Add("_ModuleContextSocObject1", New Object)
                        End If
                        Session.Item("_ModuleContextSocObject1") = arrayMaestro 'res.FoundContracts

                        If Session.Item("_ModuleContextSocArrayDetalle") Is Nothing Then
                            Session.Add("_ModuleContextSocArrayDetalle", New Object)
                        End If
                        Session.Item("_ModuleContextSocArrayDetalle") = arrayDetalle 'res.FoundContracts

                        grdSearchResult.DataSource = arrayMaestro 'res.FoundContracts
                        grdSearchResult.CurrentPageIndex = 0
                        If (Not resIn Is Nothing And resIn.FoundContracts.Length > 0) Then
                            grdSearchResult.PageSize = DotNetNuke.Services.Localization.Localization.GetString("pageSize7", Me.LocalResourceFile)
                        Else
                            grdSearchResult.PageSize = DotNetNuke.Services.Localization.Localization.GetString("pageSize15", Me.LocalResourceFile)
                        End If
                        grdSearchResult.DataBind()

                        If res.TopContractsFlag = True Then
                            Me.lblContracts.Visible = True
                            Me.lblContracts.Text = DotNetNuke.Services.Localization.Localization.GetString("msgTopContracts", Me.LocalResourceFile)
                        End If
                        Me.lblHeaderContracts.Visible = True
                    Else
                        Me.grdSearchResult.Visible = False
                        Me.grdSearchResult.DataSource = Nothing
                        Me.grdSearchResult.DataBind()
                        Me.lblHeaderContracts.Visible = False
                    End If

                    'BAROMA 25-05-11 GreenLight No Funcionality
                    If greenLightFlag = Convert.ToInt16(DotNetNuke.Services.Localization.Localization.GetString("FlagNoGreenLight", Me.LocalResourceFile)) Then

                        'BAROMA 10/05/11 GreenLight Funcionality
                        If (Not resIn Is Nothing And resIn.FoundContracts.Length > 0) Then
                            'GONERI-(20110629) Add secction for discrimate contract with two benefits, etc
                            Dim FoundContractsNew As New List(Of InvestmentContractRetailServiceSvcProxy.FoundContractInformation)
                            Dim FoundContractDic As New System.Collections.Specialized.ListDictionary

                            Dim plnDisabledArray As List(Of String) = DotNetNuke.Services.Localization.Localization.GetString("plnDisabled", Me.LocalResourceFile).ToString().Split("|").ToList()

                            For Each FoundContract As InvestmentContractRetailServiceSvcProxy.FoundContractInformation In resIn.FoundContracts
                                If Not (FoundContractDic.Contains(FoundContract.ContractIdentifier)) Then
                                    FoundContractDic.Add(FoundContract.ContractIdentifier, FoundContract.ContractIdentifier)
                                    If plnDisabledArray.Contains(FoundContract.Plan.PlanGeneric.Name) Then
                                        FoundContract.ContractGrouperIdentifier = FoundContract.ContractIdentifier
                                        FoundContract.ContractIdentifier = ""
                                    End If
                                    FoundContractsNew.Add(FoundContract)
                                End If
                            Next

                            Me.grdInsuranceResults.Visible = True
                            If Session.Item("_ModuleContextSocObject2") Is Nothing Then
                                Session.Add("_ModuleContextSocObject2", New Object)
                            End If
                            Session.Item("_ModuleContextSocObject2") = FoundContractsNew
                            grdInsuranceResults.DataSource = FoundContractsNew
                            grdInsuranceResults.CurrentPageIndex = 0
                            If (Not resIn Is Nothing And resIn.FoundContracts.Length > 0) Then
                                grdInsuranceResults.PageSize = DotNetNuke.Services.Localization.Localization.GetString("pageSize7", Me.LocalResourceFile)
                            Else
                                grdInsuranceResults.PageSize = DotNetNuke.Services.Localization.Localization.GetString("pageSize15", Me.LocalResourceFile)
                            End If
                            grdInsuranceResults.DataBind()

                            If resIn.TopContractsFlag = True Then
                                Me.lblContractsIn.Visible = True
                                Me.lblContractsIn.Text = DotNetNuke.Services.Localization.Localization.GetString("msgTopContracts", Me.LocalResourceFile)
                            End If

                            Me.lblHeaderContractsIn.Visible = True

                        Else
                            Me.grdInsuranceResults.Visible = False
                            Me.grdInsuranceResults.DataSource = Nothing
                            Me.grdInsuranceResults.DataBind()
                            Me.lblHeaderContractsIn.Visible = False
                        End If
                    Else
                        Me.grdInsuranceResults.Visible = False
                        Me.grdInsuranceResults.DataSource = Nothing
                        Me.grdInsuranceResults.DataBind()
                        Me.lblHeaderContractsIn.Visible = False
                    End If

                End If
            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub grdSearchResult_ItemCreated(sender As Object, e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdSearchResult.ItemDataBound
            Try

                If e.Item.ItemType = ListItemType.Item Or _
                    e.Item.ItemType = ListItemType.AlternatingItem Then

                    Dim pnl As Panel = e.Item.FindControl("PopupMenu")

                    If (Not pnl Is Nothing) Then

                        Dim idCta As String = TryCast(e.Item.FindControl("lbtn"), LinkButton).CommandArgument

                        Dim tbl As LiteralControl = TryCast(pnl.Controls(0), LiteralControl)

                        Dim flag As Boolean = False
                        tbl.Text = BuildTableDetail(idCta, flag)

                        If flag Then
                            Dim img As New HtmlImage
                            img.ID = "imgVer"
                            img.Src = DotNetNuke.Services.Localization.Localization.GetString("imgPath", Me.LocalResourceFile)

                            Dim createDiv As New HtmlControls.HtmlGenericControl
                            createDiv.ID = "createDiv"
                            createDiv.Attributes.Add("class", "divLupa")
                            createDiv.Attributes.Add("onmouseover", "$(this).mouseenter(function () {$('#dialog_" + idCta + "').dialog('open'); }).mouseleave(function() {$('.popUp').dialog('close');});")
                            createDiv.Controls.Add(img)
                            e.Item.Cells(0).Controls.Add(createDiv)

                        End If

                    End If

                End If

            Catch ex As Exception
                ProcessModuleLoadException(Me, ex)
            End Try

        End Sub

        Private Function BuildTableDetail(id As String, ByRef flag As Boolean) As String

            Dim tbl As StringBuilder = Nothing

            Try
                tbl = New StringBuilder()

                tbl.Append(String.Format("<div class='popUp' id='dialog_{0}'>", id))
                tbl.Append("<table  cellpadding='3'>")
                tbl.Append("<thead>")
                tbl.Append("<tr class='TDTextTableHeader1'><td>Contrato</td><td>Plan</td></tr>")
                tbl.Append("</thead>")
                tbl.Append("<tbody>")
                For Each item As InvestmentContractRetailServiceSvcProxy.FoundContractInformation In Session.Item("_ModuleContextSocArrayDetalle")
                    If StrComp(item.ContractGrouperIdentifier.Trim(), id.Trim()) = 0 Then
                        tbl.Append("<tr>")
                        tbl.Append("<td>Contrato</td>".Replace("Contrato", item.ContractIdentifier))
                        tbl.Append("<td>Plan</td>".Replace("Plan", item.Plan.PlanPlatform.Name))
                        tbl.Append("</tr>")
                        flag = True
                    End If
                Next
                tbl.Append("</tbody>")
                tbl.Append("<tfoot/>")
                tbl.Append("</table>")
                tbl.Append("</div>")

            Catch ex As Exception
                Throw ex
            End Try

            If flag Then
                Return tbl.ToString()
            Else
                Return String.Empty
            End If

        End Function

        'GONERI-(20110629) Change cast for the session variable
        Private Sub grdSearchResult_PageIndexChange(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdSearchResult.PageIndexChanged
            grdSearchResult.CurrentPageIndex = e.NewPageIndex
            grdSearchResult.DataSource = Session("_ModuleContextSocObject1") 'CType(Session("_ModuleContextSocObject1"), Array)
            grdSearchResult.DataBind()
        End Sub

        'Private Sub grdInsuranceResults_ItemDataBound(sender As Object, e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdInsuranceResults.ItemDataBound

        '    If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then

        '        CType(e.Item.FindControl("lblPaymentType"), Label).Text = GetPaymentType(CType(e.Item.FindControl("hdnContratoId"), HiddenField).Value)


        '    End If

        'End Sub

       

        'GONERI-(20110629) Change cast for the session variable
        Private Sub grdInsuranceResults_PageIndexChange(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdInsuranceResults.PageIndexChanged
            grdInsuranceResults.CurrentPageIndex = e.NewPageIndex
            grdInsuranceResults.DataSource = CType(Session("_ModuleContextSocObject2"), List(Of InvestmentContractRetailServiceSvcProxy.FoundContractInformation))
            grdInsuranceResults.DataBind()
        End Sub

        Public Function URLCreation() As String
            Dim url As String
            ''url = NavigateURL() & "?ctl=ContractBasicInfo" 'EUGMAR [2006-06-07]
            url = NavigateURL() & "?ctl=ContractGeneralInfo" 'CHAJUA [2011-07-05]


            Return url
        End Function


        Private Sub grdSearchResult_ItemCommand(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdSearchResult.ItemCommand

            Select Case (CType(e.CommandSource, System.Web.UI.WebControls.LinkButton)).CommandName.ToString()

                Case "ContractSelected"
                    Dim foundContract As InvestmentContractRetailServiceSvcProxy.FoundContractInformation
                    Dim contractSelected As New System.Collections.Specialized.ListDictionary
                    Dim blocked As Boolean = True
                    Dim Message As String = DotNetNuke.Services.Localization.Localization.GetString("msContractBlocked", Me.LocalResourceFile)
                    'Dim getCteId As Boolean = False
                    Dim msgBlocked As String = String.Empty

                    Dim blockedReq As New InvestmentContractRetailServiceSvcProxy.InvestmentContractBlockedInfoRequest
                    Dim blockedRes As InvestmentContractRetailServiceSvcProxy.InvestmentContractBlockedInfoResponse
                    Dim blockedServ As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
                    Dim flagBlocked As Boolean
                    Dim tabPortalVal As Int32
                    Dim urlPortafolioReport
                    blockedReq.ContractIdentifier = (CType(e.CommandSource, System.Web.UI.WebControls.LinkButton)).CommandArgument.ToString().Trim() 'foundContract.ContractIdentifier
                    blockedReq.UserIdentifier = UserController.GetCurrentUserInfo.Username.Trim().ToUpper()

                    blockedRes = blockedServ.GetContractBlockedInfo(blockedReq)

                    If Not blockedRes.ContractBlockedInfo Is Nothing Then
                        If blockedRes.ContractBlockedInfo.UserBlockedType = InvestmentContractRetailServiceSvcProxy.UserContractBlockedType.Full Then
                            flagBlocked = True
                        ElseIf blockedRes.ContractBlockedInfo.UserBlockedType = InvestmentContractRetailServiceSvcProxy.UserContractBlockedType.Informative Then
                            flagBlocked = False
                        End If
                        msgBlocked = blockedRes.ContractBlockedInfo.BusinessArea.Name & ": " & blockedRes.ContractBlockedInfo.BlockedMessage.Name
                    Else
                        flagBlocked = False
                    End If


                    For Each foundContract In Session("_ModuleContextSocObject1") ''CType(Session("_ModuleContextSocObject1"), Array)

                        If foundContract.ContractIdentifier.Equals((CType(e.CommandSource, System.Web.UI.WebControls.LinkButton)).CommandArgument.ToString()) And flagBlocked = False Then

                            contractSelected.Add("ClientName", foundContract.ClientName)
                            contractSelected.Add("PlanMeta", foundContract.Plan.PlanMeta)
                            contractSelected.Add("ContractNumber", foundContract.ContractIdentifier)
                            contractSelected.Add("ContractPlan", foundContract.Plan.PlanPlatform.Name)
                            contractSelected.Add("PlanComercialName", foundContract.Plan.PlanComercialName.Name)
                            'foundContract.Plan.Name
                            'contractSelected.Add("ContractProduct", foundContract.Product.ProductType.ToString())
                            'contractSelected.Add("ContractProductType", foundContract.Product.ProductType.ToString())
                            contractSelected.Add("ContractProduct", foundContract.Product.ProductType.TheProduct.ToString())
                            contractSelected.Add("ContractProductType", foundContract.Product.ProductType.TheProduct.ToString())
                            contractSelected.Add("ClientRFCCURP", foundContract.ClientRFCCURP) ' MunMig 16Jul10
                            contractSelected.Add("BlockedMsg", msgBlocked)
                            contractSelected.Add("Grouper", IIf(Not foundContract.PlanInfo Is Nothing, foundContract.PlanInfo.PlanGrouping, False))
                            Session.Add("_ContractSelected", contractSelected)
                            Session.Remove("_ContractSelectedInsurance")
                            blocked = False
                            'getCteId = True
                        End If
                    Next
                    'Alblui
                    If Not blocked Then
                        'If getCteId Then
                        '(PMX) MunMig 26May09
                        'Dim req As New ContractProxy.GetContractClientRequest
                        'Dim res As ContractProxy.GetContractClientResponse
                        'Dim service As New ContractProxy.ContractService
                        'service.Credentials = CredentialCache.DefaultCredentials
                        'service.RequestHeaderValue = New ContractProxy.RequestHeader
                        'service.RequestHeaderValue.Headers = WebServiceUtility.PopulateHeaderValues(UserController.GetCurrentUserInfo.Username, _
                        '                                                                            Me.PortalSettings.PortalName)

                        'req.ClienteContract = CType(contractSelected.Item("ContractNumber"), String).Trim()

                        'res = service.GetContractClient(req)
                        'If Not res Is Nothing Then
                        '    If res.Result.Successful = False Then
                        '        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, res.Result.FailureReason, DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        '        Return
                        '    Else
                        '        contractSelected.Add("ClientRFCCURP", res.ClientRFC)
                        '        contractSelected.Add("ClientIdentifier", res.ClientIdentifier)
                        '        contractSelected.Add("ClientSkUserId", res.SkandiaNetCteId)
                        '    End If
                        'End If


                        ''End If

                        'Response.Redirect(URLCreation())
                        tabPortalVal = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("ContractTabId", Me.LocalResourceFile))
                        urlPortafolioReport = NavigateURL(tabPortalVal)
                        Response.Redirect(urlPortafolioReport)

                    Else
                        If Not Session("_ContractSelected") Is Nothing Then
                            Session.Remove("_ContractSelected")
                        End If

                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, msgBlocked, Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        pnlContractSearch.Visible = False
                        pnlContractSerchResults.Visible = False
                    End If

            End Select
        End Sub

        'BAROMA 11/05/11 GreenLight Contracts 
        Private Sub grdInsuranceResults_ItemCommand(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdInsuranceResults.ItemCommand

            Dim cmdArg As String

            cmdArg = (CType(e.CommandSource, System.Web.UI.WebControls.LinkButton)).CommandName.ToString()

            If cmdArg <> "Page" Then
                Dim foundContract As InvestmentContractRetailServiceSvcProxy.FoundContractInformation
                Dim contractSelected As New System.Collections.Specialized.ListDictionary
                Dim tabPortalVal As Int32
                Dim urlPortafolioReport

                'GONERI-(20110629) Change for to iterate the collection.
                For Each foundContract In CType(Session("_ModuleContextSocObject2"), List(Of InvestmentContractRetailServiceSvcProxy.FoundContractInformation))


                    If foundContract.ContractIdentifier.Equals((CType(e.CommandSource, System.Web.UI.WebControls.LinkButton)).CommandArgument.ToString()) And
                        foundContract.Plan.PlanGeneric.Identifier.Equals(cmdArg) Then


                        contractSelected.Add("ClientName", foundContract.ClientName)
                        contractSelected.Add("ContractNumber", foundContract.ContractIdentifier)
                        contractSelected.Add("ContractPlan", foundContract.Plan.PlanPlatform.Name)
                        contractSelected.Add("ContractProduct", foundContract.Product.ProductType.TheProduct.ToString())
                        contractSelected.Add("PlanMeta", foundContract.Plan.PlanMeta)
                        contractSelected.Add("PlanComercialName", foundContract.Plan.PlanComercialName.Name)
                        'CHAJUA  [2011/06/12]  Selection of policy only
                        ' contractSelected.Add("ContractProductId", foundContract.Plan.PlanPlatform.Identifier.ToString())
                        contractSelected.Add("ContractProductType", foundContract.Product.ProductType.TheProduct.ToString())
                        contractSelected.Add("ClientRFCCURP", foundContract.ClientRFCCURP)
                        contractSelected.Add("_ProductName", cmdArg)
                        'CHAJUA  [2011/06/12]  Selection of policy only
                        ' contractSelected.Add("ContractPlanId", foundContract.Plan.PlanGeneric.Identifier.ToString())
                        Session.Add("_ContractSelectedInsurance", contractSelected)
                        Session.Remove("_ContractSelected")
                    End If
                Next
                ' CHAJUA(08 / Jun / 2011)
                'tabPortalVal = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("TabValuacionGreenLightSOC", Me.LocalResourceFile))
                tabPortalVal = TabUrl(cmdArg)


                urlPortafolioReport = NavigateURL(tabPortalVal)
                Response.Redirect(urlPortafolioReport)
            End If
        End Sub

        Private Function TabUrl(ByRef productName As String) As Integer

            Dim tabId As Integer

            If DotNetNuke.Services.Localization.Localization.GetString("ProductosRetailMas", Me.LocalResourceFile).Contains(productName) Then
                tabId = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("TabRetailMass", Me.LocalResourceFile))
            ElseIf DotNetNuke.Services.Localization.Localization.GetString("ProductosOlMutualVive", Me.LocalResourceFile).Contains(productName) Then
                tabId = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("BenefitTabId", Me.LocalResourceFile))
            End If

            Return tabId

        End Function

        Public Function GetProductName(ByRef product As Object) As String

            Dim name As String = String.Empty

            If DotNetNuke.Services.Localization.Localization.GetString("ProductosRetailMas", Me.LocalResourceFile).Contains(product) Then
                name = DotNetNuke.Services.Localization.Localization.GetString("RetailMass", Me.LocalResourceFile).ToString()
            ElseIf DotNetNuke.Services.Localization.Localization.GetString("ProductosOlMutualVive", Me.LocalResourceFile).Contains(product) Then
                name = DotNetNuke.Services.Localization.Localization.GetString("OldMutualVive", Me.LocalResourceFile).ToString()
            End If
            Return name

        End Function

        Public Function GetPaymentType(ByVal contractId) As String
            Dim PaymentTypeResult As String = String.Empty
            Dim responseDetailInfo As New RetailMassServiceSvcProxy.ContractDetailInfoResponse
            Dim client As New RetailMassServiceSvcProxy.RetailMassServiceContractClient

            Try

                Dim response As New RetailMassServiceSvcProxy.ContractRequest
                response.ContractIdentifier = contractId
                responseDetailInfo = client.GetContractDetailInfo(response)
                If responseDetailInfo IsNot Nothing Then
                    PaymentTypeResult = responseDetailInfo.RetailMassContractDetail.RetailMassContract.PaymentType.Name.ToString()
                End If


            Catch exc As Exception
                ProcessModuleLoadException(Me, exc)
            End Try


            Return PaymentTypeResult
        End Function


#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region



    End Class

End Namespace
