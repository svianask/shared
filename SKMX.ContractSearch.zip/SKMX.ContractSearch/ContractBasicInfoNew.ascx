<%@ Register TagPrefix="dnn" TagName="SectionHead" Src="~/controls/SectionHeadControl.ascx" %>
<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Control Language="vb" AutoEventWireup="false" Codebehind="ContractBasicInfoNew.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.ContractBasicInfoNew" %>
<table id="tblGeneralInformation" cellSpacing="0" cellPadding="0" align="left" border="0"
	runat="server">
	<tr>
		<td>
			<TABLE id="tblClientInfo" cellSpacing="0" cellPadding="1" align="left" border="0" runat="server">
				<TR>
					<TD class="txt_forma" align="right" width="200" colSpan="1"><B><asp:label id="plContract" Runat="server">Contrato:</asp:label></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="skGeneralFont" align="left" width="300" colSpan="3"><asp:label id="lblContract" Runat="server"></asp:label></TD>
				</TR>
				<TR>
					<TD class="txt_forma" align="right" width="200"><B><asp:label id="plName" Runat="server">Nombre:</asp:label></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="skGeneralFont" align="left" width="300"><asp:label id="lblName" Runat="server"></asp:label></TD>
				</TR>
				<TR>
					<TD class="txt_forma" align="right" width="200"><B><asp:label id="plReferenceNumber" Runat="server">N&uacute;mero de Referencia*:</asp:label></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="skGeneralFont" align="left" width="300"><asp:label id="lblReferenceNumber" runat="server"></asp:label></TD>
				</TR>
			</TABLE>
		</td>
	</tr>
	<tr>
		<td><br>
			<asp:panel id="plnContractRegularSavings" Runat="server" Visible="false">
				<dnn:sectionhead id="dshSavingInfo" runat="server" text="<b>Mi plan de Ahorro</b>" isexpanded="true"
					includerule="True" resourcekey="dshSavingInfo" section="tblSavingInfo"></dnn:sectionhead>
				<TABLE id="tblSavingInfo" cellSpacing="0" cellPadding="1" align="left" border="0" runat="server">
					<TR>
						<TD align="center" colSpan="7" class="skGeneralFont"><B>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Aportaciones Regulares 
								con Seguro de Vida</B></TD>
					</TR>
					<TR>
						<TD align="center" colSpan="7" class="skGeneralFont">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<asp:Label id="lblContractRegularSavingsHeader" Runat="server" Font-Bold="True">&iquest;Qu&eacute; necesito para 
								lograr mi meta de inversi&oacute;n?</asp:Label></TD>
					</TR>
					<TR>
						<TD colSpan="7">&nbsp;</TD>
					</TR>
					<TR>
						<TD vAlign="top">
							<TABLE cellSpacing="0" cellPadding="1" align="left" border="0">
								<TR>
									<TD class="txt_forma" vAlign="top" align="right" width="200"><B>
											<asp:label id="plmonthlyContribution" Runat="server">Para lograr mi objetivo necesito ahorrar mensualmente:</asp:label></B></TD>
									<TD width="2">&nbsp;</TD>
									<TD class="TDTextTableCell" vAlign="bottom" align="left" width="75" height="19">
										<asp:label id="lblmonthlyContributionResult" Runat="server" CssClass="skGeneralFont"></asp:label></TD>
									<TD width="2">&nbsp;</TD>
								</TR>
							</TABLE>
						</TD>
						<TD vAlign="top">
							<TABLE cellSpacing="0" cellPadding="1" align="left" border="0">
								<TR>
									<TD class="txt_forma" vAlign="top" align="right" width="250" height="15"><B>
											<asp:label id="plObjectiveAmount" Runat="server">Mi compromiso para llegar felizmente<br /> a la meta financiera es de:</asp:label></B></TD>
									<TD width="2">&nbsp;</TD>
									<TD class="TDTextTableCell" vAlign="bottom" align="left" width="75" height="15">
										<asp:label id="lblObjectiveAmountResult" Runat="server" CssClass="skGeneralFont"></asp:label></TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</asp:panel></td>
	</tr>
	<tr>
		<td><br>
			<asp:panel id="plnTotal" Runat="server" Visible="true">
				<TABLE id="tblTotal" cellSpacing="0" cellPadding="1" align="left" border="0" runat="server">
					<TR>
						<TD class="txt_forma" vAlign="top" align="right" width="200"><B>
								<asp:Label id="plBalanceDate" Runat="server">Saldo a la Fecha:</asp:Label></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" vAlign="top" align="left" width="100">
							<asp:label id="lblBalanceDate" Runat="server" CssClass="skGeneralFont"></asp:label></TD>
					</TR>
				</TABLE>
			</asp:panel></td>
	</tr>
	<tr>
		<td>&nbsp;
		</td>
	</tr>
	<tr>
		<td>
			<asp:Panel ID="pnlDeductibility" Runat="server" CssClass="skGeneralFont">
				<dnn:sectionhead id="dshDeductibility" runat="server" text="<b>Deducibilidad</b>" isexpanded="true"
					includerule="True" resourcekey="dshDeductibility" section="tblDeductibility"></dnn:sectionhead>
				<TABLE id="tblDeductibility" cellSpacing="0" cellPadding="0" width="100%" border="0" runat="server">
					<TR>
						<TD align="center">
							<asp:Label id="lblDeductibility" Runat="server" CssClass="skGeneralFont" Font-Bold="True"></asp:Label>&nbsp;<A class="links3" id="aMoreInformation" href="http://www.skandia.com.mx/skandia/portals/anuncios/beneficios_fiscales.htm"
								target="_blank" name="aMoreInformation" runat="server">M&aacute;s 
								Informaci&oacute;n</A></TD>
					</TR>
				</TABLE>
			</asp:Panel>
		</td>
	</tr>
	<tr>
		<td>&nbsp;<br>
		</td>
	</tr>
	<tr>
		<td>
			<table cellSpacing="0" cellPadding="0" align="left" border="0">
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="TDTextTableCell skGeneralFont" align="center">Skandia le recomienda efectuar sus 
						dep&oacute;sitos en efectivo v&iacute;a banca
						electr&oacute;nica, utilizando el servicio de domiciliaci&oacute;n, o 
						en cheque (cruzado) a nombre de <asp:label id="lblDinamicMessage" Runat="server" CssClass="TDTextTableCell skGeneralFont"></asp:label> 
						de manera directa en su banco.<br>
						<br>
						<b>Skandia NO se hace responsable por pagos hechos a los Financial Planners.</b></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="TDTextTableCell skGeneralFont" align="center"><a class="links3" href="http://www.skandia.com.mx/skandia/portals/skandianet/docs/formatos/solicitud_domiciliacion.pdf" target="_blank">Ver 
							Carta de autorizaci&oacute;n para la Domiciliaci&oacute;n.</a></td>
				</tr>
				<tr>
					<td class="TDTextTableCell skGeneralFont" align="left"><asp:label id="lblError" Runat="server"></asp:label></ASP:ADROTATOR></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
