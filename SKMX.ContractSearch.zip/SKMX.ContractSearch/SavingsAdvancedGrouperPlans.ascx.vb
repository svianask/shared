﻿'Company: Intergrupo Mexico.
'Date: 09/12/2014
'Description: Show new savings advanced page for grouper contracts

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Skandia.Mx.DNN.Utilities
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Services.Exceptions
Imports System.Globalization
Imports Newtonsoft.Json

Namespace Skandia.Mx.Retail.DNN.ContractSearch
    Public Class SavingsAdvancedGrouperPlans
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase
        Public Shared resSA As New InvestmentContractRetailServiceSvcProxy.InvestmentContractSavingInfoResponse
        Public strCurrentSA As String
        Public blVisibleCSA As Boolean
        Public strInitialSA As String
        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            Try
                strCurrentSA = DotNetNuke.Services.Localization.Localization.GetString("CurrentSA", Me.LocalResourceFile)
                blVisibleCSA = Convert.ToBoolean(DotNetNuke.Services.Localization.Localization.GetString("VisibleCSA", Me.LocalResourceFile))
                strInitialSA = DotNetNuke.Services.Localization.Localization.GetString("InitialSA", Me.LocalResourceFile)

                Dim IsContractSelected As String = String.Empty
                Dim isContractGrouper As Boolean = False
                If Not IsPostBack Then
                    If Not Session.Item("_ContractSelected") Is Nothing Then
                        IsContractSelected = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                        If IsContractSelected <> "" Then
                            isContractGrouper = CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("Grouper")
                            If isContractGrouper Then
                                pnlLeyenda.Visible = False
                                Me.FillPageData(IsContractSelected)
                            Else
                                pnlSavingsAdvancedGrouperPlans.Visible = False
                                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoSelectGrouperContract", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                        Else
                            pnlSavingsAdvancedGrouperPlans.Visible = False
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoContractContext", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        End If
                    Else
                        pnlSavingsAdvancedGrouperPlans.Visible = False
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoSelectContract", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If
            Catch ex As Exception
                pnlSavingsAdvancedGrouperPlans.Visible = False
                ProcessModuleLoadException(Me, ex)
            End Try
        End Sub
        Public Sub FillPageData(ByVal contractId As String)
            Try
                Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
                Dim reqSA As New InvestmentContractRetailServiceSvcProxy.SavingsAdvancedGrouperContractRequest
                Dim reqDD As New InvestmentContractRetailServiceSvcProxy.ContractRequest
                Dim resDD As New InvestmentContractRetailServiceSvcProxy.ContractDirectDebitBasicInfoResponse



                'Cadena de filtros para aportaciones libres
                Dim elemento As New InvestmentContractRetailServiceSvcProxy.TransactionTypes
                Dim arrCombinacion As String()
                Dim lstFilters(0) As InvestmentContractRetailServiceSvcProxy.TransactionTypes
                Dim strFilters = DotNetNuke.Services.Localization.Localization.GetString("TransactionsTypes", Me.LocalResourceFile)
                Dim arrCombinaciones As String() = strFilters.Split("|")
                ReDim lstFilters(arrCombinaciones.Length - 1)
                Dim indx As Integer = 0
                For Each item As String In arrCombinaciones
                    arrCombinacion = item.Split(",")
                    elemento.tipo_Mercado = arrCombinacion(0).ToString()
                    elemento.tipo_Operacion = arrCombinacion(1).ToString()
                    elemento.tipo_Orden = arrCombinacion(2).ToString()
                    lstFilters(indx) = elemento
                    indx = indx + 1
                Next

                'llamada al servicio para info de avance de ahorro
                reqSA.ContractIdentifier = contractId
                reqSA.Filters = lstFilters
                resSA = service.GetContractSavingInfo(reqSA)

                'llamada al servicio para info de domiciliacion
                reqDD.ContractIdentifier = contractId
                resDD = service.GetDirectDebitContractInfo(reqDD)

                'Pintar datos de resultados
                mostrarDatos(contractId, resSA, resDD)

            Catch ex As Exception
                pnlSavingsAdvancedGrouperPlans.Visible = False
                ProcessModuleLoadException(Me, ex)
            End Try
        End Sub
        Public Sub mostrarDatos(ByVal contractId As String, ByRef savingsA As InvestmentContractRetailServiceSvcProxy.InvestmentContractSavingInfoResponse, ByRef directD As InvestmentContractRetailServiceSvcProxy.ContractDirectDebitBasicInfoResponse)
            Dim guid As String = DotNetNuke.Services.Localization.Localization.GetString("PortalGUID", Me.LocalResourceFile)
            'primera parte de la pantalla
            lblPlanStartDate.Text = Format(Date.Parse(savingsA.SavingAdvanceContractInfo.planInfo.startDate), "dd-MMM-yy").Replace(".", "")
            lblPlanEndDate.Text = Format(Date.Parse(savingsA.SavingAdvanceContractInfo.planInfo.endDate), "dd-MMM-yy").Replace(".", "")
            lblPlanGoal.Text = savingsA.SavingAdvanceContractInfo.planInfo.savingGoal
            lblMonthlyAmount.Text = savingsA.SavingAdvanceContractInfo.planInfo.monthlyContribution.ToString("C", CultureInfo.CurrentCulture)
            lblPlanMonths.Text = savingsA.SavingAdvanceContractInfo.planInfo.monthlyTerm.ToString()
            lblContributionsSum.Text = savingsA.SavingAdvanceContractInfo.planInfo.sumContributionAmount.ToString("C", CultureInfo.CurrentCulture)
            'primera parte de la pantalla (seguro)
            lblInsuranceStartDate.Text = Format(Date.Parse(savingsA.SavingAdvanceContractInfo.insuranceStartDate), "dd-MMM-yy").Replace(".", "")
            lblInsuranceEndDate.Text = Format(Date.Parse(savingsA.SavingAdvanceContractInfo.insuranceEndDate), "dd-MMM-yy").Replace(".", "")
            Dim valuacionAportaciones As Decimal = Me.getValuacion(contractId, savingsA.OffspringGrouperContract.contributionContractId)

            'Cálculo de aporataciones adicionales
            Dim MasterContract = savingsA.OffspringGrouperContract.grouperContractIdentifier
            Dim OrdinalContract = savingsA.OffspringGrouperContract.contributionContractId
            Dim AdditionalContract = savingsA.OffspringGrouperContract.additionalContractId
            Dim Platform = 10
            If (savingsA.InvestmentContractInfo.InvestmentContract.Product.ProductType.ThePlatform <> InvestmentContractRetailServiceSvcProxy.ProductTypePlatform.SIIFAS) Then
                Platform = 5
            End If
            Dim additionalContributions = DetermineAdditionalContributions(MasterContract, OrdinalContract, AdditionalContract, Platform)
            'Cálculo de aporataciones adicionales

            '15/07/2019 MCO - Inicio de cambio        
            'Beneficio por Fallecimiento
            lblInsuranceProfitLabel.Text = savingsA.InvestmentContractInfo.insuranceProfitDsc
            'Suma Asegurada Inicial            
            lblInsuranceAmount.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.InitialInsuredAmount.ToString("C"))

            If blVisibleCSA = True Then
                'Suma Asegurada Actual            
                Me.lblCurrentLifeInsuranceAmount.Text = SetFormat(GetInsuredAmount(contractId).InsuredAmount.CurrentInsuredAmount.ToString("C"))
                lblInsuranceProfit.Text = (SetFormat(GetInsuredAmount(contractId).InsuredAmount.DeathBenefit.ToString("C")))
            Else
                Me.lblCurrentLifeInsuranceAmount.Text = "No Disponible"
                lblInsuranceProfit.Text = "No Disponible"
            End If
            'Fin de cambio-15/07/2019 MCO

            'Segunda sección Aportaciones
            lblContributionAmount.Text = savingsA.SavingAdvanceContractInfo.planInfo.desiredContributionAmount.ToString("C", CultureInfo.CurrentCulture)
            lblContributionCurrentAmount.Text = savingsA.SavingAdvanceContractInfo.planInfo.currentContributionAmount.ToString("C", CultureInfo.CurrentCulture)
            lblContributionRemainingAmount.Text = savingsA.SavingAdvanceContractInfo.planInfo.remainingContributionAmount.ToString("C", CultureInfo.CurrentCulture)
            lblContributionNumber.Text = savingsA.SavingAdvanceContractInfo.planInfo.desiredContributionNumber.ToString()
            lblContributionCurrentNumber.Text = savingsA.SavingAdvanceContractInfo.planInfo.currentContributionNumber.ToString()
            lblContributionRemainingNumber.Text = savingsA.SavingAdvanceContractInfo.planInfo.remainingContributionNumber.ToString()
            lblAdditionalContributions.Text = additionalContributions.ToString("C", CultureInfo.CurrentCulture)
            'lblAdditionalContributions.Text = savingsA.SavingAdvanceContractInfo.planInfo.additionalContribution.ToString("C", CultureInfo.CurrentCulture)
            lblNoContributionsNumberAllowed.Text = savingsA.SavingAdvanceContractInfo.planInfo.numberAllowedNoContributions.ToString()
            ' seccion Domiciliacion            
            If Not directD.ContractDirectDebitBasicInfo Is Nothing Then
                lblBancoDomicialiacion.Text = IIf(directD.ContractDirectDebitBasicInfo.DebitBankAccount.TheBank.Name = "", "", directD.ContractDirectDebitBasicInfo.DebitBankAccount.TheBank.Name)
                lblCtaDomiciliacion.Text = IIf(directD.ContractDirectDebitBasicInfo.DebitBankAccount.AccountNumber.ToString() = "", "", directD.ContractDirectDebitBasicInfo.DebitBankAccount.AccountNumber.ToString())
                lblDiaCobroDomiciliacion.Text = IIf(directD.ContractDirectDebitBasicInfo.DebitDay.ToString() = "", "", directD.ContractDirectDebitBasicInfo.DebitDay.ToString())
                lblImporteDomiciliacion.Text = IIf(directD.ContractDirectDebitBasicInfo.DebitAmount.ToString() = "", "", directD.ContractDirectDebitBasicInfo.DebitAmount.ToString("C", CultureInfo.CurrentCulture))
                If directD.ContractDirectDebitBasicInfo.DebitBankAccount.TheBank.Identifier = 0 Then
                    pnlLeyenda.Visible = True
                    lblLeyendaActivas.Text = "Su domiciliación se encuentra desactivada."
                End If
            Else
                pnlDirectDebit.Visible = False
            End If
            'Historico Aportaciones
            If Me.PortalSettings.GUID.ToString.ToUpper() = guid Then
                pnlHistorico.Visible = True
                dgvHistoricoAportaciones.DataSource = savingsA.SavingAdvanceSummary
                dgvHistoricoAportaciones.DataBind()
                LeyendaInflacion()
            End If

        End Sub
        Public Function getValuacion(ByVal contractId As String, ByVal contributionContract As String)
            Dim request As New InvestmentContractRetailServiceSvcProxy.ContractRetailRequest
            Dim response As New InvestmentContractRetailServiceSvcProxy.ContractRetailBalanceSummaryResponse
            Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
            Dim valuacion As Decimal = 0
            Dim porcentaje As Decimal = DotNetNuke.Services.Localization.Localization.GetString("PorcentajeValuacion", Me.LocalResourceFile)
            request.ContractIdentifier = contractId
            response = service.GetSubContractsBalanceSummary(request)
            If contributionContract = 0 Then
                For Each balance As InvestmentContractRetailServiceSvcProxy.ICRetailBalanceSummary In response.DCContractRetailBalanceResponse.ContractRetailBalanceSummary.RetailBalanceSummary
                    valuacion = valuacion + balance.Balance                    
                Next
            Else
                For Each balance As InvestmentContractRetailServiceSvcProxy.ICRetailBalanceSummary In response.DCContractRetailBalanceResponse.ContractRetailBalanceSummary.RetailBalanceSummary
                    If balance.Contract.ContractIdentifier = resSA.OffspringGrouperContract.contributionContractId Then
                        valuacion = ((balance.Balance * porcentaje))
                    End If
                Next
            End If
            Return valuacion
        End Function

        Public Function LeyendaInflacion()
            Dim service As New InvestmentContractRetailServiceSvcProxy.InvestmentContractRetailServiceContractClient
            Dim req As New InvestmentContractRetailServiceSvcProxy.ContractRequest
            Dim respSavingInfo As New InvestmentContractRetailServiceSvcProxy.InvestmentContractDetailInfoResponse
            Dim tempDate As New DateTime
            Dim actualValidDateValue As Decimal
            Dim lastValidDateValue As Decimal
            Dim indicatorValue As Decimal = 0
            Dim lifeInsurance As Decimal = 0
            Dim initialDate As DateTime = DateTime.MinValue
            Dim tmpDate As New DateTime
            Dim dayBegin As Integer
            req.ContractIdentifier = Convert.ToString(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
            respSavingInfo = service.GetContractDetailInfo(req)

            'If respSavingInfo.OperationalSummaryInfo.MonthsOnPlan > 12 Then

            tempDate = VerifyValidDateTime(DateTime.Now.Year, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Month, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Day) 'MUNMIG

            If (tempDate > DateTime.Now.Date) Then
                tempDate = New DateTime(DateTime.Now.Year - 1, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Month, respSavingInfo.SavingAdvanceInfo.SavingPlanInfo.OpeningDate.Day)
            End If
            'Periodo de la tasa de inflacion.
            'lblMonthRate.Text = GetMonthName(tempDate.Month).ToUpper() + " / "
            'lblSecondYear.Text = tempDate.Year.ToString("0000")
            'lblFirstYear.Text = (tempDate.Year - 1).ToString("0000") + " - "

            'Tasa de inflacion.
            dayBegin = initialDate.Day
            tmpDate = VerifyValidDateTime(DateTime.Now.Year, initialDate.Month, dayBegin)
            If (tmpDate < DateTime.Now.Date) Then
                actualValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year, initialDate.Month, 1)))
                lastValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year - 1, initialDate.Month, 1)))
            Else
                actualValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year, initialDate.Month, 1)))
                lastValidDateValue = GetValueIndicator(GetFinancialIndicatorResponse(New DateTime(DateTime.Now.Year - 2, initialDate.Month, 1)))
            End If
            If (actualValidDateValue > 0 And lastValidDateValue > 0) Then

                indicatorValue = (actualValidDateValue / lastValidDateValue) - 1
            End If

            'lblInflationRate.Text = indicatorValue.ToString("P")
            'Aportacion Mensual sugerida por Skandia.
            'lblSuggestedMonthlyContribution.Text = respSavingInfo.SavingAdvanceInfo.MonthlyContributionByInflation.ToString("C")

            'pnlRate.Style.Item("display") = "block"
            'pnlRate.Visible = True

        End Function
        Private Function GetValueIndicator(ByVal response As InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsResponse) As Decimal
            Dim validDateValue As Decimal
            For Each indicator As InvestmentFundRetailServiceSvcProxy.FinancialIndicatorValue In response.Indicators
                validDateValue = indicator.Value
            Next
            Return validDateValue
        End Function
        Private Function GetFinancialIndicatorResponse(ByVal anniversaryYear As DateTime) As InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsResponse
            Dim serviceFinancialIndicator As New InvestmentFundRetailServiceSvcProxy.InvestmentFundRetailServiceContractClient
            Dim reqFinancialIndicator As New InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsRequest
            Dim respFinancialIndicator As New InvestmentFundRetailServiceSvcProxy.FinancialIndicatorsResponse
            Dim indicatorList() As Short = {105}
            reqFinancialIndicator.DCFinancialIndicatorsRequest = New InvestmentFundRetailServiceSvcProxy.DCFinancialIndicatorsRequest
            reqFinancialIndicator.DCFinancialIndicatorsRequest.IndicatorDate = anniversaryYear
            reqFinancialIndicator.DCFinancialIndicatorsRequest.IndicatorsId = indicatorList
            respFinancialIndicator = serviceFinancialIndicator.GetFinancialIndicators(reqFinancialIndicator)
            Return respFinancialIndicator
        End Function
        Private Function VerifyValidDateTime(ByVal yearFind As Integer, ByVal monthFind As Integer, ByVal dayFind As Integer) As DateTime

            Dim dayNumbers As Integer = Convert.ToInt32(DateTime.DaysInMonth(yearFind, 2))
            Dim validDate As DateTime = DateTime.MinValue

            If monthFind = 2 And dayFind > 28 Then
                validDate = New DateTime(yearFind, monthFind, dayNumbers)
            Else
                validDate = New DateTime(yearFind, monthFind, dayFind)
            End If

            Return validDate
        End Function

        Private Function GetInsuredAmount(ByVal ContratoID As String) As InsuranceAmountServiceSvcProxy.InsuredAmountResponse

            '15/07/2019 MCO - Inicio de cambio
            Dim InsuredAmountService As New InsuranceAmountServiceSvcProxy.InsuranceAmountServiceContractClient
            Dim requesInsuredAmount As New InsuranceAmountServiceSvcProxy.InsuredAmountRequest
            Dim responseInsuredAmount As New InsuranceAmountServiceSvcProxy.InsuredAmountResponse

            requesInsuredAmount.ContractIdentifier = ContratoID
            requesInsuredAmount.CalculationDate = (Date.Today)

            'Invocación al servicio de Suma Asegurada
            responseInsuredAmount = InsuredAmountService.GetInsuredAmountContract(requesInsuredAmount)
            Return responseInsuredAmount

        End Function

        Private Function SetFormat(ByVal Valor As Double) As String
            Return FormatCurrency(Math.Round(Convert.ToDecimal(Valor), 2))
        End Function


        Public Function GetMonthName(ByVal monthNumber As Integer) As String

            Dim MonthsName() As String = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"}

            If monthNumber >= 1 And monthNumber <= 12 Then
                Return MonthsName(monthNumber - 1)
            Else
                Return "Mes Indefinido"
            End If

        End Function
        Protected Sub dgvHistoricoAportaciones_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dgvHistoricoAportaciones.RowDataBound



            If e.Row.RowType = DataControlRowType.DataRow Then
                e.Row.Cells(0).Text = Format(Date.Parse(e.Row.Cells(0).Text), "dd-MMM-yy").Replace(".", "")
            End If




        End Sub

        Protected Sub dgvHistoricoAportaciones_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles dgvHistoricoAportaciones.PageIndexChanging
            Dim gv As GridView = CType(sender, GridView)
            gv.PageIndex = e.NewPageIndex
            dgvHistoricoAportaciones.DataSource = resSA.SavingAdvanceSummary
            dgvHistoricoAportaciones.DataBind()

        End Sub

        Protected Function DetermineAdditionalContributions(ByVal MasterContract As String, ByVal OrdinalContract As String,
                                                            ByVal AdditionalContract As String, ByVal Platform As Integer) As Decimal

            Dim AssociatedContracts As List(Of Object) = New List(Of Object)

            AssociatedContracts.Add(New With {.ContractId = MasterContract, .AssociatedContractId = MasterContract, .AssociatedType = 1})

            If (Not String.IsNullOrEmpty(OrdinalContract)) Then
                AssociatedContracts.Add(New With {.ContractId = OrdinalContract, .AssociatedContractId = MasterContract, .AssociatedType = 2})
            End If

            If (Not String.IsNullOrEmpty(AdditionalContract)) Then
                AssociatedContracts.Add(New With {.ContractId = AdditionalContract, .AssociatedContractId = MasterContract, .AssociatedType = 3})
            End If


            Dim request =
                New With {
                    .AssociatedContracts = AssociatedContracts,
                    .Platform = Platform
                }

            Dim resultNetContributions = New OperationResult()
            Dim contributionsResponse As AdittionalNetContributionsResponse
            Dim jsonContributions As String
            Dim WebRetailApiPath = DotNetNuke.Services.Localization.Localization.GetString("WebRetailApiPath", Me.LocalResourceFile)
            Dim AdittionalNetContributions As Decimal = 0


            jsonContributions = ProxyEngine.SendMSRequestJson(WebRetailApiPath & "ClientContracts/GetAdittionalNetContributions", request, resultNetContributions)
            contributionsResponse = JsonConvert.DeserializeObject(Of AdittionalNetContributionsResponse)(jsonContributions)

            If contributionsResponse.Result.Successful Then
                AdittionalNetContributions = contributionsResponse.AdittionalNetContributions
            End If


            DetermineAdditionalContributions = AdittionalNetContributions
        End Function
    End Class
End Namespace
