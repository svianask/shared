<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Control Language="vb" AutoEventWireup="false" Codebehind="ContractSearch.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.ContractSearch" %>
<link href="~/DesktopModules/SKMX.ContractSearch/CSS/StyleSheet.css" rel="stylesheet" type="text/css" />
<!--La variable global jQueryPath esta inicializada en el evento pageload y contiene la Ruta estática de la ubicación de los archivos en cuestión. La ruta se obtiene Desde el archivo de recursos del proyecto. Para este caso:"/DNNQA/DesktopModules/SKMX.ContractSearch/jQueryComponent/" Esta ruta corresponde a la configuracion de sitio en el IIS-->
<script src="<%=jQueryPath%>jquery.js" type="text/javascript"></script>
<script src="<%=jQueryPath %>jquery-ui-1.8.2.custom.min.js" type="text/javascript"></script>
<!--*************************************************************************-->
<script type="text/javascript" language="javascript">
    function PopUp() {
        $(".popUp").dialog({
            open: function (event, ui) {
                jQuery('.ui-dialog-titlebar').hide();
            },
            modal: false,
            resizable: false,
            draggable: false,
            overlay: { opacity: 0.9, background: "transparent" },
            autoOpen: false,
            closeOnEscape: true,
            closeText: 'Cerrar',
            width: 450
        });
    }
</script>

<asp:panel id="pnlContractSearch" Runat="server">
<TABLE cellSpacing="3" cellPadding="0" width="500" border="0">
		<TR>
			<TD class="TDTextTableCell" noWrap align="left" width="100"><B>
					<DNN:LABEL id="plSearch" text="Buscar:" controlname="plSearch" runat="server"></DNN:LABEL></B></TD>
			<TD class="TDTextTableCell" noWrap align="left" width="300">
				<asp:TextBox id="txtSearch" Runat="server" MaxLength="50" Columns="50" CssClass="skTextBox" ></asp:TextBox>&nbsp;*
				<asp:RequiredFieldValidator id="rfvSearch" Runat="server" CssClass="TDTextTableCell" Display="Dynamic" ErrorMessage="<br>Campo requerido"
					ControlToValidate="txtSearch" resourcekey="rfvSearch"></asp:RequiredFieldValidator></TD>
			<TD align="left">&nbsp;
				<asp:ImageButton id="imbSearch" Runat="server" AlternateText="Buscar"></asp:ImageButton><!--<asp:LinkButton id="btnSearch" Runat="server" CssClass="CommandButton" CausesValidation="True" resourcekey="btnSearch">Buscar</asp:LinkButton></TD>--></TD>
		<TR>
			<TD colSpan="3">
				<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
					<TR>
						<TD class="TDTextTableCell" width="100"><B>
								<DNN:LABEL id="plBy" text="Por:" controlname="plBy" runat="server"></DNN:LABEL></B></TD>
						<TD width="118">
							<asp:RadioButton class="TDTextTableCell" id="radSearchContract" runat="server" Checked="True" GroupName="grpSearch"
								Text="Contrato/Poliza"></asp:RadioButton></TD>
						<TD width="101">
							<asp:RadioButton class="TDTextTableCell" id="radSearchRFC" runat="server" GroupName="grpSearch" Text="RFC"
								Enabled="true"></asp:RadioButton></TD>
						<TD>
							<asp:RadioButton class="TDTextTableCell" id="radSearchName" runat="server" GroupName="grpSearch"
								Text="Nombre" Enabled="true"></asp:RadioButton></TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
		<TR>
			<TD class="TDTextTableCell"><B>
					<DNN:LABEL id="plPlan" text="Plan:" controlname="plPlan" runat="server"></DNN:LABEL></B></TD>
			<TD colSpan="2">
				<asp:DropDownList id="lstPlans" runat="server" CssClass="skTextBox" Width="280px">
					<asp:ListItem Value="0" Selected="True">-- TODOS LOS PLANES --</asp:ListItem>
				</asp:DropDownList></TD>
		</TR>
	</TABLE></HR>
</asp:panel>
<p>&nbsp;</p>

<asp:panel id="pnlContractSerchResults" Runat="server" Visible="true">
	<TABLE id="Table3" height="0" cellSpacing="0" cellPadding="0" width="650" border="0">
        <TR>
            <TD colspan="4">
            <asp:Label ID="lblHeaderContracts" runat="server" Visible="false" Text="Ahorro e Inversiones" Font-Bold="true"></asp:Label>
            </TD>
        </TR>
		<TR>
			<TD>
				<asp:DataGrid id="grdSearchResult" runat="server" AllowSorting="True" PageSize="15" AllowPaging="True"
					AutoGenerateColumns="False" GridLines="Horizontal" BorderWidth="1px">
					<AlternatingItemStyle CssClass="TDTextTableCell" BackColor="#E0DFE3" ></AlternatingItemStyle>
					<ItemStyle CssClass="TDTextTableCell"></ItemStyle>
					<HeaderStyle CssClass="TDTextTableHeader1"></HeaderStyle>
					<Columns >
						<asp:TemplateColumn HeaderText="">
                            <HeaderStyle Font-Bold="True"></HeaderStyle>
                            <ItemStyle Width="60px"></ItemStyle>
                            <ItemTemplate>
                                <asp:Panel BackColor="#EAEAEA" ID="PopupMenu" runat="server">
                                </asp:Panel>
                            </ItemTemplate>
                        </asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Contrato">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
								<asp:LinkButton ID="lbtn"  Runat="server" CommandName="ContractSelected" CausesValidation="False" CommandArgument='<%#DataBinder.Eval(Container.DataItem,"ContractIdentifier")%>'>
									<%#DataBinder.Eval(Container.DataItem, "ContractIdentifier")%>
								</asp:LinkButton>
							</ItemTemplate>
						</asp:TemplateColumn>
						<asp:BoundColumn DataField="ClientName" HeaderText="Nombre">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="270px"></ItemStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="ClientRFCCURP" HeaderText="RFC/CURP">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="115px"></ItemStyle>
						</asp:BoundColumn>
						<asp:TemplateColumn HeaderText="Plan">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="110px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="lblPlan" Runat="server">
									<%#DataBinder.Eval(Container.DataItem, "Plan.PlanPlatform.Name")%>
								</asp:Label>
							</ItemTemplate>							
						</asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Estatus">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="67px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="lblStatus" Runat="server">
									<%#DataBinder.Eval(Container.DataItem,"Status.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Estatus Operaci&#243;n">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="130px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="Label1" Runat="server">
									<%#DataBinder.Eval(Container.DataItem, "OperationStatus.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Nivel de Servicio">
						<HeaderStyle Font-Bold="True"></HeaderStyle>
						<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
								<asp:Label runat="server" ID="lblClientSegment" >
									<%#DataBinder.Eval(Container.DataItem, "ClientSegment.Name") %>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						
					</Columns>
					<PagerStyle Mode="NumericPages"></PagerStyle>
				</asp:DataGrid></TD>
		</TR>
        <TR>
            <TD height ="15">
            </TD>
        </TR>
        <TR>
        <TD>
            <asp:Label ID="lblContracts" runat="server" Visible="false" Font-Size="Smaller"></asp:Label>
        </TD>
        </TR>
        <TR>
            <TD height ="15">
            </TD>
        </TR>
        <TR>
            <TD height ="15">
            </TD>
        </TR> 
        <TR>
            <TD colspan="4">
            <asp:Label ID="lblHeaderContractsIn" runat="server" Visible="false" Text="Seguros" Font-Bold="true"></asp:Label>
            </TD>
        </TR>
        <TR>
            <TD>
			<!-- GONERI-(20110629) Change Column Names and source data -->
            <asp:DataGrid id="grdInsuranceResults" runat="server" AllowSorting="True" PageSize="15" AllowPaging="True"
					AutoGenerateColumns="False" GridLines="Horizontal" BorderWidth="1px">
					<AlternatingItemStyle CssClass="TDTextTableCell" BackColor="#E0DFE3"></AlternatingItemStyle>
					<ItemStyle CssClass="TDTextTableCell"></ItemStyle>
					<HeaderStyle CssClass="TDTextTableHeader1"></HeaderStyle>
					<Columns>
						<asp:TemplateColumn HeaderText="N&#250;mero de P&#243;liza">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
								<asp:LinkButton ID="lbtn" Runat="server"  CommandName='<%#Eval("Plan.PlanGeneric.Identifier")%>'   CausesValidation="false" CommandArgument='<%#DataBinder.Eval(Container.DataItem,"ContractIdentifier")%>'>
									<%#DataBinder.Eval(Container.DataItem, "ContractIdentifier")%>
								</asp:LinkButton>
							<asp:Label ID="lblContratoDeshabilitado" Runat="server" Text='<%#DataBinder.Eval(Container.DataItem, "ContractGrouperIdentifier")%>'/>
							</ItemTemplate>
						</asp:TemplateColumn>
						<asp:BoundColumn DataField="ClientName" HeaderText="Nombre">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="270px"></ItemStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="ClientRFCCURP" HeaderText="RFC/CURP">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="115px"></ItemStyle>
						</asp:BoundColumn>
                        <asp:TemplateColumn HeaderText="ProductoId" Visible="false">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="110px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="lblPlaniD" Runat="server" Text='<%#Bind("Plan.PlanGeneric.Identifier") %>'>								
								</asp:Label>
							</ItemTemplate>							
						</asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Producto">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="110px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="lblPlan" Runat="server" Text='<%#Eval("Plan.PlanGeneric.Name") %>'>
								</asp:Label>
							</ItemTemplate>							
						</asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Estatus">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="67px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="lblStatus" Runat="server">
									<%#DataBinder.Eval(Container.DataItem,"Status.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Estatus Operaci&#243;n">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="130px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="Label1" Runat="server">
									<%#DataBinder.Eval(Container.DataItem, "OperationStatus.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						
						<asp:TemplateColumn HeaderText="Nivel de Servicio">
						<HeaderStyle Font-Bold="True"></HeaderStyle>
						<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
								<asp:Label runat="server" ID="lblClientSegment" >
									<%#DataBinder.Eval(Container.DataItem, "ClientSegment.Name") %>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
                        
                        <asp:TemplateColumn HeaderText="Forma de Pago">
						<HeaderStyle Font-Bold="True"></HeaderStyle>
						<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
                                <asp:HiddenField ID="hdnContratoId" runat="server" Value='<%#DataBinder.Eval(Container.DataItem,"ContractIdentifier")%>' />
								<asp:Label runat="server" ID="lblPaymentType" >
                                   <%#DataBinder.Eval(Container.DataItem, "PaymentType.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>

                        
                        <asp:TemplateColumn  HeaderText="" Visible="False">
						<HeaderStyle Font-Bold="False"></HeaderStyle>
						<ItemStyle Width="0px"></ItemStyle>
							<ItemTemplate>
								<asp:TextBox CssClass="skTextBox" runat="server" Text='<%#Eval("Plan.PlanGeneric.Identifier")%>' ID="hdnContractId" >
                                <%--<%#DataBinder.Eval("Plan.PlanGeneric.Identifier")%>--%>
								</asp:TextBox>
							</ItemTemplate>
						</asp:TemplateColumn>

					</Columns>
					<PagerStyle Mode="NumericPages"></PagerStyle>
				</asp:DataGrid>
            </TD>
        </TR> 
        <TR>
            <TD height ="15">
            </TD>
        </TR>
        <TR>
            <TD>
            <asp:Label ID="lblContractsIn" runat="server" Visible="false" Font-Size="Smaller"></asp:Label>
            </TD>
        </TR>
	</TABLE>
</asp:panel>
<link href="<%=jQueryPath%>jquery-ui-1.8.2.custom.css" rel="Stylesheet" type="text/css" />
<style type="text/css">
    .popUp
    {
        text-align: center;
    }
    .popUp table
    {
        border: 1px solid #006150;
        border-collapse: collapse;
        background-color: #FFFFFF;
        width: 400px;
    }
    
    .popUp table thead
    {
        color: #FFFFFF;
        background-color: #006150;
    }
    .popUp table tbody
    {
        font-size: xx-small;
    }
    .divLupa
    {
    	vertical-align:middle;
    	text-align:center;
    }
</style>
