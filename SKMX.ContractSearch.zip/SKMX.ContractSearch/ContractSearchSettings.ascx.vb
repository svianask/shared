Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports DotNetNuke
Imports System.Net

'Namespace Skandia.Mx.Retail.DNN.ContractSearch

Public Class ContractSearchSettings
    Inherits Entities.Modules.ModuleSettingsBase

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents txtDistribuidor As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Public Overrides Sub LoadSettings()
        Try
            'this needs to execute always to the client script code is registred in InvokePopupCal

            If (Page.IsPostBack = False) Then
                txtDistribuidor.Text = CType(ModuleSettings("DistribuidorConfig"), String)
            End If
        Catch exc As Exception    'Module failed to load

        End Try
    End Sub

    Public Overrides Sub UpdateSettings()
        Try
            Dim objModules As New DotNetNuke.Entities.Modules.ModuleController
            'Update Module Settings                
            objModules.UpdateModuleSetting(ModuleId, "DistribuidorConfig", txtDistribuidor.Text.Trim.ToUpper())
        Catch exc As Exception    'Module failed to load

        End Try

    End Sub
End Class
'End Namespace
