﻿Namespace Skandia.Mx.Retail.DNN.ContractSearch
    Public Class ContractSurvey
        Inherits Entities.Modules.PortalModuleBase

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            If Not Page.IsPostBack Then

                'Dim alarmService As New AlarmServiceReference.AlarmServiceClient
                'Dim alarmRequest As New AlarmServiceReference.GetAlarmsByPersonRequest
                'Dim alarmResponse As AlarmServiceReference.GetAlarmsByPersonResponse
                'Dim dsAlarms As DataSet

                'Dim service As New RelacionamientoService.RelacionamientoServiceSoapClient
                'Dim request As New RelacionamientoService.GetPersonIdByCountryRequest
                'Dim response As New RelacionamientoService.GetPersonIdByCountryResponse
                Dim strErr As String = String.Empty

                'request.CountryId = "MX"
                'request.PersonId = "AIRJ641102ERF" '"AIRJ641102ERF"

                'Try
                '    response = service.GetPersonIdByCountry(request)

                '    If Not response Is Nothing Then

                '        If Not response.GetPersonIdByCountryResult = Integer.MinValue Then
                '            alarmRequest.countryId = "MX"
                '            alarmRequest.idCanal = 0 'Servicio a ctes
                '            alarmRequest.personId = response.GetPersonIdByCountryResult

                '            alarmResponse = alarmService.GetAlarmsByPerson(alarmRequest)

                '            If Not alarmResponse Is Nothing Then
                '                dsAlarms = alarmResponse.GetAlarmsByPersonResult
                '            End If
                '        End If

                '    End If

                'Catch ex As Exception
                '    strErr = ex.Message.ToString() & " :: " & ex.Source.ToString
                'End Try

                'AIRJ641102ERF

                'DotNetNuke.Framework.jQuery.RequestRegistration()

                'ListSurveyContainer1.LoadSurvey("GOBV5910194V9", "MX")
                Try
                    'ListSurveyContainer1.LoadSurvey("AIRJ641102ERF", "MX")
                    lblMessage.Visible = False
                    ListSurveyContainer1.LoadSurvey("LOTG720615DE6", "MX")
                Catch ex As Exception
                    strErr = ex.Message.ToString() & " :: " & ex.Source.ToString
                End Try

                'ListSurveyContainer1.TitleCssClass = ""
                'ListSurveyContainer1.TdQuestionCssClass = "TextTableHeader1"
                'ListSurveyContainer1.TdAnswerCssClass = "DisplayTable2Header"

            End If

        End Sub

        Public Sub lnkEnviar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lnkEnviar.Click
            Dim result As Integer = 0
            Dim err As String

            Try
                'result = ListSurveyContainer1.SaveSurvey("GOBV5910194V9", "MX")
                'result = ListSurveyContainer1.SaveSurvey("AIRJ641102ERF", "MX")
                result = ListSurveyContainer1.SaveSurvey("LOTG720615DE6", "MX")
            Catch ex As Exception
                err = ex.Message & "  >> " & ex.Source
            End Try

            result = 8

            If result > 0 Then
                ListSurveyContainer1.Visible = False
                lblMessage.Text = DotNetNuke.Services.Localization.Localization.GetString("SucessfullSurvey", Me.LocalResourceFile)
                lblMessage.Visible = True
                lnkEnviar.Visible = False
            End If

        End Sub
    End Class

End Namespace

