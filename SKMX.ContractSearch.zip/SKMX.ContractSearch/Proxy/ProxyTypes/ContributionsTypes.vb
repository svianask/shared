﻿

Public Class ContractContributionsResponse
    Public ContractsContributions As ContractContributions
    Public Result As OperationResult
End Class


Public Class ContractContributions
    Public OrdinalContributionsAmount As Decimal
    Public OrdinalContributionsNumber As Integer
    Public AdditionalContributionsAmount As Decimal
    Public AdditionalContributionsNumber As Integer
    Public FirstContributionDate As Date
End Class


Public Class OnDemandContributionsResponse
    Public ContributionsOnDemand As ContributionsOnDemand
    Public Result As OperationResult
End Class

Public Class ContributionsOnDemand
    Public OrdinalContributionsOnDemandAmount As Decimal
    Public AdditionalContributionsOnDemandAmount As Decimal
End Class


Public Class AdittionalNetContributionsResponse
    Public AdittionalNetContributions As Decimal
    Public Result As OperationResult
End Class
