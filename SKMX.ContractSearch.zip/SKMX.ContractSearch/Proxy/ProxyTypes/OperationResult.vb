﻿Public Class OperationResult
    Public Successful As Boolean
    Public SystemMessages As New List(Of SystemMessage)
End Class

Public Class SystemMessage
    Public Message As String
End Class
