﻿Imports System.Net
Imports Newtonsoft.Json

Public Class ProxyEngine

    Public Shared Function SendMSRequestJson(ByVal url As String, ByVal request As Object, ByRef result As OperationResult) As String

        Dim httpClient As New WebClient
        Dim response As String
        Dim jsonRequest = JsonConvert.SerializeObject(request)

        result = New OperationResult
        Dim messageError As New SystemMessage
        jsonRequest = JsonConvert.SerializeObject(request)
        Try
            httpClient.Headers.Add("content-type", "application/json")
            response = Encoding.UTF8.GetString(httpClient.UploadData(url, "POST", Encoding.Default.GetBytes(jsonRequest)))
            result.Successful = True
        Catch ex As Exception
            messageError.Message = ex.Message
            result.SystemMessages.Add(messageError)
            result.Successful = False
            response = String.Empty
        End Try
        Return response
    End Function

End Class


