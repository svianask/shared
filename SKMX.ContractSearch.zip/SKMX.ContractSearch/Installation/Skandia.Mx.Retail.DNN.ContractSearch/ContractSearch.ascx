<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Control Language="vb" AutoEventWireup="false" Codebehind="ContractSearch.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.ContractSearch" %>
<asp:panel id="pnlContractSearch" Runat="server">
<TABLE cellSpacing="3" cellPadding="0" width="500" border="0">
		<TR>
			<TD class="TDTextTableCell" noWrap align="left" width="100"><B>
					<DNN:LABEL id="plSearch" text="Buscar:" controlname="plSearch" runat="server"></DNN:LABEL></B></TD>
			<TD class="TDTextTableCell" noWrap align="left" width="300">
				<asp:TextBox id="txtSearch" Runat="server" MaxLength="50" Columns="50" CssClass="NormalTextBox"></asp:TextBox>&nbsp;*
				<asp:RequiredFieldValidator id="rfvSearch" Runat="server" CssClass="TDTextTableCell" Display="Dynamic" ErrorMessage="<br>Campo requerido"
					ControlToValidate="txtSearch" resourcekey="rfvSearch"></asp:RequiredFieldValidator></TD>
			<TD align="left">&nbsp;
				<asp:ImageButton id="imbSearch" Runat="server" AlternateText="Buscar"></asp:ImageButton><!--<asp:LinkButton id="btnSearch" Runat="server" CssClass="CommandButton" CausesValidation="True" resourcekey="btnSearch">Buscar</asp:LinkButton></TD>--></TD>
		<TR>
			<TD colSpan="3">
				<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
					<TR>
						<TD class="TDTextTableCell" width="100"><B>
								<DNN:LABEL id="plBy" text="Por:" controlname="plBy" runat="server"></DNN:LABEL></B></TD>
						<TD width="118">
							<asp:RadioButton class="TDTextTableCell" id="radSearchContract" runat="server" Checked="True" GroupName="grpSearch"
								Text="Contrato"></asp:RadioButton></TD>
						<TD width="101">
							<asp:RadioButton class="TDTextTableCell" id="radSearchRFC" runat="server" GroupName="grpSearch" Text="RFC"
								Enabled="true"></asp:RadioButton></TD>
						<TD>
							<asp:RadioButton class="TDTextTableCell" id="radSearchName" runat="server" GroupName="grpSearch"
								Text="Nombre" Enabled="true"></asp:RadioButton></TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
		<TR>
			<TD class="TDTextTableCell"><B>
					<DNN:LABEL id="plPlan" text="Plan:" controlname="plPlan" runat="server"></DNN:LABEL></B></TD>
			<TD colSpan="2">
				<asp:DropDownList id="lstPlans" runat="server" CssClass="TDTextTableCell" Width="280px">
					<asp:ListItem Value="0" Selected="True">-- TODOS LOS PLANES --</asp:ListItem>
				</asp:DropDownList></TD>
		</TR>
	</TABLE></HR>
</asp:panel>
<p>&nbsp;</p>
<asp:panel id="pnlContractSerchResults" Runat="server" Visible="true">
	<TABLE id="Table3" height="0" cellSpacing="0" cellPadding="0" width="650" border="0">
		<TR>
			<TD>
				<asp:DataGrid id="grdSearchResult" runat="server" AllowSorting="True" PageSize="15" AllowPaging="True"
					AutoGenerateColumns="False" GridLines="Horizontal" BorderWidth="1px">
					<AlternatingItemStyle CssClass="TDTextTableCell" BackColor="#E0DFE3"></AlternatingItemStyle>
					<ItemStyle CssClass="TDTextTableCell"></ItemStyle>
					<HeaderStyle CssClass="TDTextTableHeader1"></HeaderStyle>
					<Columns>
						<asp:TemplateColumn HeaderText="Contrato">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
								<asp:LinkButton ID="lbtn" Runat="server" CommandName="ContractSelected" CausesValidation=False CommandArgument='<%#DataBinder.Eval(Container.DataItem,"ContractNumber")%>'>
									<%#DataBinder.Eval(Container.DataItem,"ContractNumber")%>
								</asp:LinkButton>
							</ItemTemplate>
						</asp:TemplateColumn>
						<asp:BoundColumn DataField="ClientName" HeaderText="Nombre">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="270px"></ItemStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="ClientRFCCURP" HeaderText="RFC/CURP">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="115px"></ItemStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Plan" HeaderText="Plan">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="110px"></ItemStyle>
						</asp:BoundColumn>
						<asp:TemplateColumn HeaderText="Estatus">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="67px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="lblStatus" Runat="server">
									<%#DataBinder.Eval(Container.DataItem,"Status.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						<asp:TemplateColumn HeaderText="Estatus Operaci&#243;n">
							<HeaderStyle Font-Bold="True"></HeaderStyle>
							<ItemStyle Width="130px"></ItemStyle>
							<ItemTemplate>
								<asp:Label ID="Label1" Runat="server">
									<%#DataBinder.Eval(Container.DataItem,"OperationalStatus.Name")%>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						
						<asp:TemplateColumn HeaderText="Segmento">
						<HeaderStyle Font-Bold="True"></HeaderStyle>
						<ItemStyle Width="60px"></ItemStyle>
							<ItemTemplate>
								<asp:Label runat="server" ID="lblClientSegment" >
									<%#DataBinder.Eval(Container.DataItem, "ClientSegment.Name") %>
								</asp:Label>
							</ItemTemplate>
						</asp:TemplateColumn>
						
					</Columns>
					<PagerStyle Mode="NumericPages"></PagerStyle>
				</asp:DataGrid></TD>
		</TR>
	</TABLE>
</asp:panel>
