<%@ Control Language="vb" AutoEventWireup="false" Codebehind="ContractSearchSettings.ascx.vb" Inherits="ContractSearchSettings" TargetSchema="http://schemas.microsoft.com/intellisense/ie5" %>
<table>
	<tr>
		<td>
			<asp:Label id="Label1" runat="server">Distribuidor</asp:Label></td>
		<td>
			<asp:TextBox id="txtDistribuidor" runat="server"></asp:TextBox></td>
	</tr>
</table>
