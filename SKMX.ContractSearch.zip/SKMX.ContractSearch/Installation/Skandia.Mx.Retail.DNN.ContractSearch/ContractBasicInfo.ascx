<%@ Control Language="vb" AutoEventWireup="false" Codebehind="ContractBasicInfo.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractBasicInfo" %>
<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Register TagPrefix="dnn" TagName="SectionHead" Src="~/controls/SectionHeadControl.ascx" %>
<table cellSpacing="0" cellPadding="0" align="left" border="0">
	<tr>
		<td><asp:panel id="pnlContractBasicInfo" Visible="true" Runat="server">
				<TABLE id="Table1" cellSpacing="0" cellPadding="1" width="402" align="left" border="0">
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plContract" runat="server" controlname="plContract" text="Contrato:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblContract" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plName" runat="server" controlname="plName" text="Nombre:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblName" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plRFC" runat="server" controlname="plRFC" text="RFC/CURP:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblRFC" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plAddress" runat="server" controlname="plAddress" text="Direccion:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblAddress1" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblAddress2" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblAddress3" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plTelephone" runat="server" controlname="plTelephone" text="Telefono:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblHomePhone" runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plSex" runat="server" controlname="plSex" text="Genero:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblGrender" runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plBirthDate" runat="server" controlname="plBirthDate" text="Fecha de Nacimiento:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblBirthDate" runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plMaritalStatus" runat="server" controlname="plMaritalStatus" text="Estado Civil:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblMaritalStatus" runat="server"></asp:label></TD>
					</TR>
				</TABLE>
			</asp:panel></td>
	</tr>
	<tr>
		<td><BR>
			<dnn:sectionhead id="dshContractInfo" runat="server" text="<b>Informacion Contrato</b>" section="tblContractInfo"
				resourcekey="dshContractInfo" includerule="True" isexpanded="true"></dnn:sectionhead>
			<table id="tblContractInfo" cellSpacing="0" cellPadding="1" width="402" align="left" border="0"
				runat="server">
				<TR>
					<TD class="TDTextTableCell" align="right" width="200"><B><DNN:LABEL id="plReferenceNumber" runat="server" controlname="plReferenceNumber" text="Numero de Referencia:"></DNN:LABEL></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="TDTextTableCell" align="left" width="200"><asp:label id="lblReferenceNumber" runat="server"></asp:label></TD>
				</TR>
				<TR>
					<TD class="TDTextTableCell" align="right" width="200"><B><DNN:LABEL id="plFP" runat="server" controlname="plFP" text="Financial Planner:"></DNN:LABEL></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="TDTextTableCell" align="left" width="200"><asp:label id="lblFP" runat="server"></asp:label></TD>
				</TR>
				<TR>
					<TD class="TDTextTableCell" align="right" width="200"><B><DNN:LABEL id="plStartDate" runat="server" controlname="plStartDate" text="Fecha de Inicio de Contrato:"></DNN:LABEL></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="TDTextTableCell" align="left" width="200"><asp:label id="lblStartDate" runat="server"></asp:label></TD>
				</TR>
				<TR>
					<TD class="TDTextTableCell" align="right" width="200"><B><DNN:LABEL id="plEndDate" Visible="False" runat="server" controlname="plEndDate" text="Fecha de Vencimiento:"></DNN:LABEL></B></TD>
					<TD width="2">&nbsp;</TD>
					<TD class="TDTextTableCell" align="left" width="200"><asp:label id="lblEndDateResult" Visible="False" Runat="server"></asp:label></TD>
				</TR>
				<tr>
					<td class="TDTextTableCell" vAlign="top" align="right" width="200"><b><DNN:LABEL id="plDeductibility" runat="server" controlname="plDeductibility" text="Deducibilidad:"></DNN:LABEL></b></td>
					<td width="2">&nbsp;</td>
					<td class="TDTextTableCell" align="left" width="200"><asp:label id="lblDeductibilityResult" Runat="server"></asp:label></td>
				</tr>
				<tr>
					<td class="TDTextTableCell" vAlign="top" align="right" width="200"><b><DNN:LABEL id="plStatus" runat="server" controlname="plStatus" text="Estatus:"></DNN:LABEL></b></td>
					<td width="2">&nbsp;</td>
					<td class="TDTextTableCell" align="left" width="200"><asp:label id="lblStatusResult" Runat="server"></asp:label></td>
				</tr>
				<tr>
					<td class="TDTextTableCell" vAlign="top" align="right" width="200"><b><DNN:LABEL id="plOperationalStatus" runat="server" controlname="plOperationalStatus" text="Estatus Operaci�n:"></DNN:LABEL></b></td>
					<td width="2">&nbsp;</td>
					<td class="TDTextTableCell" align="left" width="200"><asp:label id="lblOperStatusResult" Runat="server"></asp:label></td>
				</tr>
				<tr>
					<td class="TDTextTableCell" vAlign="top" align="right" width="200"><b><DNN:LABEL id="plTotalRetentions" runat="server" controlname="plTotalRetentions" text="Retenciones:"></DNN:LABEL></b></td>
					<td width="2">&nbsp;</td>
					<td class="TDTextTableCell" align="left" width="200"><asp:label id="lblTotalRetentions" Runat="server"></asp:label></td>
				</tr>
				<tr>
					<td class="TDTextTableCell" vAlign="top" align="right" width="200"><b><DNN:LABEL id="plSpecialInstructions" runat="server" controlname="plSpecialInstructions" text="Instrucciones Especiales:"></DNN:LABEL></b></td>
					<td width="2">&nbsp;</td>
					<td class="TDTextTableCell" align="left" width="200">
						<asp:label id="lblSpecialInstructions" Runat="server"></asp:label>
						<%If lblSpecialInstructions.Text.Trim.Length > 0 Then %>
						<script language="JavaScript">
								function inter()
								{ 
									setTimeout('tinter.style.visibility="visible";',200); 
									setTimeout('tinter.style.visibility="hidden";inter()',700); 
								}; 
								inter()
						</script>
						<label id="tinter">
							<font color="red"><b>!</b></font></label>
						<%End If%>
					</td>
				</tr>
				<tr>
					<td class="TDTextTableCell" vAlign="top" align="right" width="200"><b><DNN:LABEL id="plSegmento" runat="server" controlname="plSegmento" text="Segmento:"></DNN:LABEL></b></td>
					<td width="2"></td>
					<td class="TDTextTableCell" align="left" width="200"><asp:label id="lblSegmento" Runat="server" Font-Size="X-Small" ForeColor="ActiveCaption"></asp:label></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td><asp:panel id="plnContractRegularSavings" Visible="false" Runat="server"><BR>
				<dnn:sectionhead id="dshContractRegularSavings" runat="server" text="<b>Plan de Pagos</b>" isexpanded="true"
					includerule="True" resourcekey="dshContractRegularSavings" section="tblContractRegularSavings"></dnn:sectionhead>
				<TABLE id="tblContractRegularSavings" cellSpacing="0" cellPadding="1" width="402" align="left"
					border="0" runat="server">
					<TR>
						<TD class="TDTextTableCell" align="right" width="200" height="15"><B>
								<DNN:LABEL id="plObjectiveAmount" runat="server" controlname="plObjectiveAmount" text="Objetivo de Ahorro:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200" height="15">
							<asp:label id="lblObjectiveAmountResult" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plContributions" runat="server" controlname="plContributions" text="Plazo Aportaciones:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:label id="lblContributionsResult" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plmonthlyContribution" runat="server" controlname="plmonthlyContribution" text="Contribuci�n Mensual:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200" height="19">
							<asp:label id="lblmonthlyContributionResult" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200" height="15"><B>
								<DNN:LABEL id="plSumOfPremiums" runat="server" controlname="plSumOfPremiums" text="Suma Contribuciones:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200" height="15">
							<asp:label id="lblSumOfPremiumsResult" Runat="server"></asp:label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plInitialContribution" runat="server" controlname="plInitialContribution" text="Contribuci�n Inicial:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:Label id="lblInitialContributionResult" Runat="server"></asp:Label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:Label id="lblInitialContributionType" Runat="server"></asp:Label></TD>
					</TR>
					<TR>
						<TD class="TDTextTableCell" align="right" width="200"><B>
								<DNN:LABEL id="plAmounAssuredMax" runat="server" controlname="plInitialContribution" text="Monto maximo asegurado:"></DNN:LABEL></B></TD>
						<TD width="2">&nbsp;</TD>
						<TD class="TDTextTableCell" align="left" width="200">
							<asp:Label id="lblAmountAssuredMax" Runat="server"></asp:Label></TD>
					</TR>
				</TABLE>
			</asp:panel></td>
	</tr>
	<TR>
		<TD align="right"><BR>
			<asp:linkbutton id="cmdBack" runat="server" CausesValidation="True" CssClass="CommandButton">Regresar</asp:linkbutton></TD>
	</TR>
</table>
