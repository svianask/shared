<%@ Control Language="vb" AutoEventWireup="false" Codebehind="SavingsAdvanced.ascx.vb" Inherits="Skandia.Mx.Retail.DNN.ContractSearch.SavingsAdvanced" %>
<%@ Register TagPrefix="dnn" TagName="Label" Src="~/controls/LabelControl.ascx" %>
<%@ Register TagPrefix="dnn" TagName="SectionHead" Src="~/controls/SectionHeadControl.ascx" %>
<asp:panel id="pnlSavingsAdvance" Runat="server" Width="550">
	<TABLE cellSpacing="0" cellPadding="0" width="550" align="center" border="0">
		<TR>
			<TD>
				<asp:panel id="pnlMySavingPlan" Width="550" Runat="server">
					<dnn:sectionhead id=dshMySavingPlan runat="server" text="<%# PlanName %>" resourcekey="dshMySavingPlan" isexpanded="true" includerule="True" section="tblMySavingPlan">
					</dnn:sectionhead>
					<TABLE id="tblMySavingPlan" cellSpacing="0" cellPadding="3" width="550" border="0" runat="server">
						<TR>
							<TD vAlign="top" width="45%">
								<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Meta de inversi&oacute;n*:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblSavingObjective" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
							<TD width="10%">&nbsp;</TD>
							<TD vAlign="top" width="45%">
								<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Inicio de Plan<BR>
												(Mes 1era. Aportaci&oacute;n):</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblInitialDate" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
						</TR>
						<TR>
							<TD vAlign="top" width="45%">
								<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Ahorro mensual:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblMonthContribution" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
							<TD width="10%">&nbsp;</TD>
							<TD vAlign="top" width="45%">
								<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Aportaci&oacute;n extraordinar&iacute;a<BR>
												inicial:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblInitialContribution" Runat="server"></asp:Label><BR>
											<asp:Label id="lblInitialContributionDetail" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
						</TR>
						<TR>
							<TD vAlign="top" align="left">
								<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Plazo:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblTerm" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
							<TD>&nbsp;</TD>
							<TD vAlign="top">&nbsp;</TD>
						</TR>
						<TR>
							<TD colSpan="3">
								<asp:Panel id="pnlMocAndMonths" Width="550" Runat="server">
									<TABLE cellSpacing="0" cellPadding="3" width="550" border="0">
										<TR>
											<TD vAlign="top" width="45%">
												<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
													<TR>
														<TD class="txt_forma" vAlign="top"><B>MOC:</B></TD>
														<TD></TD>
														<TD class="TDTextTableCell" vAlign="top" align="right">
															<asp:Label id="lblMOC" Runat="server"></asp:Label></TD>
													</TR>
												</TABLE>
											</TD>
											<TD width="10%">&nbsp;</TD>
											<TD vAlign="top" width="45%">
												<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
													<TR>
														<TD class="txt_forma" vAlign="top"><B>Meses en plan:</B></TD>
														<TD>&nbsp;</TD>
														<TD class="TDTextTableCell" vAlign="bottom" align="right">
															<asp:Label id="lblMonthsOnPlan" Runat="server"></asp:Label></TD>
													</TR>
												</TABLE>
											</TD>
										</TR>
									</TABLE>
								</asp:Panel></TD>
						</TR>
						<TR>
							<TD colSpan="3">&nbsp;</TD>
						</TR>
						<TR>
							<TD align="center" colSpan="3">
								<asp:Panel id="pnlRate" Width="550px" Runat="server">
									<TABLE class="TableStyle" width="550" bgColor="#f1f1f1">
										<TR>
											<TD class="TDTextTableCell" align="center">Aportaci&oacute;n mensual sugerida por Skandia 
												de acuerdo a la inflaci&oacute;n:
												<asp:Label id="lblSuggestedMonthlyContribution" Runat="server" CssClass="TDTextTableCell"></asp:Label></TD>
										</TR>
										<TR>
											<TD class="TDTextTableCell" align="center">La tasa de inflaci&oacute;n en el periodo
												<asp:Label id="lblMonthRate" Runat="server"></asp:Label>
												<asp:Label id="lblFirstYear" Runat="server"></asp:Label>
												<asp:Label id="lblSecondYear" Runat="server"></asp:Label>&nbsp;fue de:
												<asp:Label id="lblInflationRate" Runat="server"></asp:Label></TD>
										</TR>
									</TABLE>
								</asp:Panel></TD>
						</TR>
						<TR>
							<TD colSpan="3">&nbsp;</TD>
						</TR>
						<TR>
							<TD class="TDTextTableCell" colSpan="3">* Pesos reales son netos de la inflaci&oacute;n</TD>
						</TR>
					</TABLE>
				</asp:panel></TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD vAlign="top">
				<asp:panel id="pnlAdvanceToday" Width="550" Runat="server">
					<dnn:sectionhead id="dshAdvanceToday" runat="server" text="<b>Mi avance de &#13;&#13;&#10;ahorro hasta hoy</b>"
						resourcekey="dshAdvanceToday" isexpanded="true" includerule="True" section="tblAdvanceToday"></dnn:sectionhead>
					<TABLE id="tblAdvanceToday" cellSpacing="0" cellPadding="0" width="550" border="0" runat="server">
						<TR>
							<TD vAlign="top">
								<TABLE cellSpacing="0" cellPadding="3" border="0">
									<TR>
										<TD class="txt_forma" align="center" colSpan="3"><B>MENSUALIDADES</B></TD>
										<TD rowSpan="8">&nbsp;</TD>
										<TD class="txt_forma" align="center" colSpan="3"><B>IMPORTE</B></TD>
										<TD rowSpan="8">&nbsp;</TD>
										<TD class="txt_forma" align="center" colSpan="3"><B>SEGURO DE VIDA</B></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Comprometidos:</B></TD>
										<TD rowSpan="7">&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblRegularPremiumTerm" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="top"><B>Meta de Aportaciones:</B></TD>
										<TD rowSpan="6">&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblTodaySavingContributions" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="top"><B>Meta de inversi&oacute;n:</B></TD>
										<TD rowSpan="7">&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblTodaySavingObjective" Runat="server"></asp:Label></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Que deber&iacute;a llevar:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblExpectedMonthlyContributions" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="middle"><B>Aportaciones:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblContributions" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="top"><B>Valuaci&oacute;n actual:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblContractBalance" Runat="server"></asp:Label></TD>
									<TR>
									<TR>
										<TD class="txt_forma" vAlign="middle"><B>Que llevo:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblCurrentMonthlyContributions" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="middle"><B>Retiros**:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblWithdrawals" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="top"><B>Seguro de vida:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblCurrentLifeInsurace" Runat="server"></asp:Label></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top" rowSpan="4"><B>Por cumplir:</B></TD>
										<TD class="TDTextTableCell" vAlign="top" align="right" rowSpan="4">
											<asp:Label id="lblMonthlyContributionRest" Runat="server" CssClass="TDTextTableCell"></asp:Label></TD>
										<TD class="txt_forma" vAlign="top"><B>Aportaciones netas:</B></TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblContributionsNet" Runat="server"></asp:Label></TD>
										<TD class="txt_forma" vAlign="top" rowSpan="4"><B>Beneficio por<BR>
												fallecimiento:</B></TD>
										<TD class="TDTextTableCell" vAlign="top" align="right" rowSpan="4">
											<asp:Label id="lblDeathBenefit" Runat="server" CssClass="TDTextTableCell"></asp:Label></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Para completar mi meta de ahorro:</B></TD>
										<TD class="TDTextTableCell" vAlign="middle" align="right">
											<asp:Label id="lblAmountContributionsRest" Runat="server" CssClass="TDTextTableCell"></asp:Label></TD>
									</TR>
									<TR>
										<TD colSpan="3">
											<asp:Panel id="pnlFreeWithdrawalsAmount" Runat="server" Height="46px">
												<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
													<TR>
														<TD class="txt_forma" vAlign="top" width="79"><B>Excedente de retiro sin cargo:</B></TD>
														<TD>&nbsp;</TD>
														<TD class="TDTextTableCell" vAlign="middle" align="right">
															<asp:Label id="lblFreeWithdrawalsAmount" Runat="server"></asp:Label></TD>
													</TR>
												</TABLE>
											</asp:Panel></TD>
									</TR>
									<TR>
										<TD colSpan="7">&nbsp;</TD>
									</TR>
									<TR>
										<TD class="TDTextTableCell" colSpan="11">** Le recordamos que en caso de realizar 
											un retiro parcial o total, se aplicar&aacute; un cargo de acuerdo a lo estipulado en 
											su contrato.</TD>
									</TR>
								</TABLE>
							</TD>
						</TR>
					</TABLE></TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>
				<asp:Panel id="pnlPayments" Width="550px" Runat="server">
					<dnn:sectionhead id="dshPayments" runat="server" text="<b>Plan de pagos atrasados</b>" resourcekey="dshPayments"
						isexpanded="true" includerule="True" section="tblPayments"></dnn:sectionhead>
					<TABLE id="tblPayments" cellSpacing="0" cellPadding="0" width="550" border="0" runat="server">
						<TR id="trOverduePayments" runat="server">
							<TD>
								<TABLE cellSpacing="0" cellPadding="3" width="100%" border="0">
									<TR>
										<TD vAlign="top" width="42%">
											<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
												<TR>
													<TD class="txt_forma" vAlign="top"><B>Mensualidades vencidas:</B></TD>
													<TD>&nbsp;</TD>
													<TD class="TDTextTableCell" vAlign="top" align="right">
														<asp:Label id="lblOverdueMonthlyContributions" Runat="server" ForeColor="Red"></asp:Label></TD>
												</TR>
											</TABLE>
										</TD>
										<TD width="16%">&nbsp;</TD>
										<TD vAlign="top" width="42%">
											<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
												<TR>
													<TD class="txt_forma" vAlign="top"><B>Monto vencido***:</B></TD>
													<TD>&nbsp;</TD>
													<TD class="TDTextTableCell" vAlign="top" align="right">
														<asp:Label id="lblOverdueMonthlyContributionsAmount" Runat="server" ForeColor="Red"></asp:Label></TD>
												</TR>
											</TABLE>
										</TD>
									</TR>
									<TR>
										<TD colSpan="3">
											<asp:Panel id="pnl_NMNC" Width="550" Runat="server">
												<TABLE cellSpacing="0" cellPadding="3" width="550" border="0">
													<TR>
														<TD vAlign="top" width="42%">
															<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
																<TR>
																	<TD class="txt_forma" vAlign="top"><B>Mens. sin aportaci&oacute;n:</B></TD>
																	<TD>&nbsp;</TD>
																	<TD class="TDTextTableCell" vAlign="bottom" align="right">
																		<asp:Label id="lblNoConsecutiveOverdueContributions" Width="9px" Runat="server"></asp:Label></TD>
																</TR>
															</TABLE>
														</TD>
														<TD width="16%">&nbsp;</TD>
														<TD vAlign="top" width="42%">
															<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
																<TR>
																	<TD class="txt_forma" vAlign="top"><B>Mens. vencidas consecutivas:</B></TD>
																	<TD>&nbsp;</TD>
																	<TD class="TDTextTableCell" vAlign="bottom" align="right">
																		<asp:Label id="lblConsecutiveOverdueContributions" Runat="server"></asp:Label></TD>
																</TR>
															</TABLE>
														</TD>
													</TR>
													<TR>
														<TD vAlign="top">
															<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
																<TR>
																	<TD class="txt_forma" vAlign="top"><B>Estado del contrato:</B></TD>
																	<TD>&nbsp;</TD>
																	<TD class="TDTextTableCell" vAlign="top" align="right">
																		<asp:Label id="lblContractStatus" Runat="server"></asp:Label></TD>
																</TR>
															</TABLE>
														</TD>
														<TD width="10%">&nbsp;</TD>
														<TD vAlign="top">&nbsp;</TD>
													</TR>
												</TABLE>
											</asp:Panel></TD>
									</TR>
									<TR>
										<TD colSpan="3">
											<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
												<TR>
													<TD class="TDTextTableCell" vAlign="top">
														<asp:Image id="imgWarning" runat="server" ImageUrl="~/images/Skandia/icons/warning_red.gif"></asp:Image></TD>
													<TD>&nbsp;</TD>
													<TD class="TDTextTableCell">*** Le recomendamos regularizar a la brevedad sus 
														dep&oacute;sitos para asegurar sus objetivos de inversi&oacute;n, recuperar el beneficio del 
														Seguro de Vida y evitar el cargo correspondiente a recuperaci&oacute;n de primas o 
														cancelaci&oacute;n de plan.</TD>
												</TR>
											</TABLE>
										</TD>
									</TR>
								</TABLE>
							</TD>
						</TR>
						<TR id="trNotOverduePayments" runat="server" visible="false">
							<TD class="TDTextTableCell">&iexcl;Felicidades, usted ha cumplido con 
								disciplina su compromiso!, recuerde que nuestro objetivo es acompa&ntilde;arlo a 
								trav&eacute;s del tiempo, revisando peri&oacute;dicamente su objetivo, hasta verlo llegar 
								felizmente a su meta.</TD>
						</TR>
					</TABLE>
				</asp:Panel></TD>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>
				<asp:Panel id="pnlDomiciliacion" Width="550" Runat="server">
					<dnn:sectionhead id="dshDomiciliacion" runat="server" text="<b>Domiciliaci&oacute;n</b>" resourcekey="dshDomiciliacion"
						isexpanded="true" includerule="True" section="tblDomiciliacion"></dnn:sectionhead>
					<TABLE id="tblDomiciliacion" cellSpacing="0" cellPadding="0" width="550" border="0" runat="server">
						<TR id="trHasntDomiciliacion" runat="server">
							<TD class="TDTextTableCell" colSpan="3">
								<asp:Label id="lblDomiciliacion" Runat="server" resourcekey="txtDomiciliacion"></asp:Label></TD>
						</TR>
						<TR id="trHasDomiciliacion" runat="server">
							<TD vAlign="top" width="249">
								<TABLE style="WIDTH: 232px" cellSpacing="0" cellPadding="3" width="232" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Banco:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblBank" Runat="server"></asp:Label></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top"><B>D&iacute;a de Cobro::</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblPeriod" Runat="server"></asp:Label></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top"><B>Tipo Domiciliaci&oacute;n:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblType" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
							<TD width="15%">&nbsp;</TD>
							<TD vAlign="top">
								<TABLE cellSpacing="0" cellPadding="3" width="100%" border="0">
									<TR>
										<TD class="txt_forma" vAlign="top" width="94"><B>Cuenta:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblAccount" Runat="server"></asp:Label></TD>
									</TR>
									<TR>
										<TD class="txt_forma" vAlign="top" width="94"><B>Importe:</B></TD>
										<TD>&nbsp;</TD>
										<TD class="TDTextTableCell" vAlign="top" align="right">
											<asp:Label id="lblAmount" Runat="server"></asp:Label></TD>
									</TR>
								</TABLE>
							</TD>
						</TR>
					</TABLE>
				</asp:Panel></TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD>&nbsp;</TD>
		</TR>
		<TR>
			<TD class="txt_error" align="center">
				<asp:Image id="imgEtiqFinanciera" runat="server"></asp:Image></TD>
		</TR>
	</TABLE>
</asp:panel></asp:panel>
