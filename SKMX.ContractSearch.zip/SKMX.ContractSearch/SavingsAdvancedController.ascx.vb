﻿'Company: Intergrupo Mexico.
'Date: 02/12/2014
'Description: Decide wich SavingsAdvanced page to show.

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Skandia.Mx.DNN.Utilities
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security
Imports DotNetNuke.Services.Exceptions

Namespace Skandia.Mx.Retail.DNN.ContractSearch
    Public Class SavingsAdvancedController
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

        
        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            Try

               
                Dim isContractGrouper As Boolean
                Dim redirectTab As Integer
                If Not IsPostBack Then
                    If Not Session.Item("_ContractSelected") Is Nothing Then
                        If Not IsGrouper Is Nothing Then
                            If IsGrouper.Contains(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber")) Then
                                isContractGrouper = IsGrouper(CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("ContractNumber"))
                            End If
                        Else
                            isContractGrouper = CType(Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary).Item("Grouper")
                        End If
                       
                        If isContractGrouper Then

                            If PortalSettings.GUID.Equals(New Guid(DotNetNuke.Services.Localization.Localization.GetString("PortalSOCGUID", Me.LocalResourceFile))) Then 'SOC
                                redirectTab = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("SavingsAdvancedGrouperTabId", Me.LocalResourceFile))
                            ElseIf PortalSettings.GUID.Equals(New Guid(DotNetNuke.Services.Localization.Localization.GetString("PortalClientesGUID", Me.LocalResourceFile))) Then 'CTES
                                redirectTab = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("SavingsAdvancedGrouperCTETabId", Me.LocalResourceFile))
                            ElseIf PortalSettings.GUID.Equals(New Guid(DotNetNuke.Services.Localization.Localization.GetString("PortalFPGUID", Me.LocalResourceFile))) Then 'FP
                                redirectTab = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("SavingsAdvancedGrouperFPTabId", Me.LocalResourceFile))
                            End If

                            Response.Redirect(NavigateURL(redirectTab))
                        Else
                            If PortalSettings.GUID.Equals(New Guid(DotNetNuke.Services.Localization.Localization.GetString("PortalSOCGUID", Me.LocalResourceFile))) Then 'SOC
                                redirectTab = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("SavingsAdvancedTabId", Me.LocalResourceFile))
                            ElseIf PortalSettings.GUID.Equals(New Guid(DotNetNuke.Services.Localization.Localization.GetString("PortalClientesGUID", Me.LocalResourceFile))) Then 'CTES
                                redirectTab = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("SavingsAdvancedCTETabId", Me.LocalResourceFile))
                            ElseIf PortalSettings.GUID.Equals(New Guid(DotNetNuke.Services.Localization.Localization.GetString("PortalFPGUID", Me.LocalResourceFile))) Then 'FP
                                redirectTab = Convert.ToInt32(DotNetNuke.Services.Localization.Localization.GetString("SavingsAdvancedFPTabId", Me.LocalResourceFile))
                            End If

                            Response.Redirect(NavigateURL(redirectTab))
                        End If
                    Else
                        pnlSavingsAdvancedController.Visible = False
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("NoSelectContract", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End If
                End If
            Catch ex As Exception
                pnlSavingsAdvancedController.Visible = False
                ProcessModuleLoadException(Me, ex)
            End Try
        End Sub

        Public Property IsGrouper() As Hashtable
            Get
                Return Session.Item("_isGrouper")
            End Get
            Set(ByVal value As Hashtable)
                Session.Add("_isGrouper", value)
            End Set
        End Property

    End Class
End Namespace