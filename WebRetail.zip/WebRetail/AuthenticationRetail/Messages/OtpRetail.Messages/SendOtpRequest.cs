﻿namespace OtpRetail.Messages
{
    public class SendOtpRequest
    {
        public string UserName; 
    }
}
