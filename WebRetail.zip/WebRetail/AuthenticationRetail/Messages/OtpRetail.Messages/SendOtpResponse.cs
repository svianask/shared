﻿using Common.Domain;
using OtpRetail.Domain.OtpInformationAggregate;

namespace OtpRetail.Messages
{
    public class SendOtpResponse
    {
        public OperationResult Result;
        public OtpInformation OtpInformation { get; set; }
    }
}
