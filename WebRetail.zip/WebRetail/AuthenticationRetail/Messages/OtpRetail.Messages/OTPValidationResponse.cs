﻿using Common.Domain;
using OtpRetail.Domain.OtpValResultAggregate;

namespace OtpRetail.Messages
{
    public class OTPValidationResponse
    {
        public OperationResult Result;
        public OtpValResult OtpValResult;
    }
}
