﻿using Common.Domain;

namespace OtpRetail.Messages
{
    public class OTPValidationRequest
    {
        public string UserName;
        public string OTP;
    }
}
