﻿using Common.Domain;
using Common.Proxy;
using Notifications.Proxy;
using OtpAuth.Proxy;
using OtpRetail.Domain.OtpInformationAggregate;
using OtpRetail.Domain.OtpValResultAggregate;
using SeriLogH;
using SolvencyAuth.Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace OtpRetail.Application
{
    public class OtpRetailApp : IOtpRetailApp
    {
        private readonly IOtpAuthPrxy _otpAuthPrxy;
        private readonly ISolvencyAuthPrxy _solvencyAuthPrxy;
        private readonly ISeriLogHelper _log;
        private readonly INotificationsPrxy[] _notificationsPrxy;

        public OtpRetailApp(IOtpAuthPrxy otpAuthPrxy, ISolvencyAuthPrxy solvencyAuthPrxy, ISeriLogHelper log, INotificationsPrxy[] notificationsPrxy)
        {
            _otpAuthPrxy = otpAuthPrxy;
            _solvencyAuthPrxy = solvencyAuthPrxy;
            _log = log;
            _notificationsPrxy = notificationsPrxy;
        }

        private delegate OtpInformation delSendNotificationOTP(string userName, out OperationResult result);
        public OtpInformation SendOTP(string userName, out OperationResult result)
        {
            if (string.IsNullOrEmpty(userName)) { throw new ArgumentException("El usuario no puede ser nulo."); }

            OtpInformation otpInformation = null;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Enviando notificacion por email");
                otpInformation = _otpAuthPrxy.GenrateOTPWhitNotificationEmail(userName, out result);
                _log.Debug("{cntx}", new { otpInformation });

                _log.Info("Enviando notificacion asincrona por sms");
                delSendNotificationOTP notificationOTP = _otpAuthPrxy.GenrateOTPWhitNotificationSMS;
                notificationOTP.BeginInvoke(userName, out result, null, null);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información del OTP: {cntx}", new { userName});
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener la información del OTP " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return otpInformation;
        }

        public OtpValResult OTPValidation(string userName, string otp, out OperationResult result)
        {
            if (string.IsNullOrEmpty(userName)) { throw new ArgumentException("El usuario no puede ser nulo"); }
            if (string.IsNullOrEmpty(otp)) { throw new ArgumentException("El otp no puede ser nulo"); }

            OtpValResult otpValResult = null;

            result = new OperationResult();
            int portalId = 0;

            try
            {
                _log.Info("Obteniendo información del portal");
                portalId = int.Parse(ConfigurationManager.AppSettings["Solvency:PortalId"].ToString());
                _log.Debug("{cntx}", new { portalId });

                _log.Info("Realizando la validez y vigencia el OTP");
                otpValResult = _otpAuthPrxy.OTPValidation(userName, portalId, otp, out result);
                _log.Debug("{cntx}", new { otpValResult });
                
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al intentar validar el OTP: {cntx}", new { userName, portalId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al intentar validar el OTP " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return otpValResult;
        }

        private void SendNotificationOTP(string userName, string email, string phoneNumber, string otp)
        {
            try
            {
                _log.Info("Obteniendo datos de la plantilla para envío");
                var notTemplate = NotificationsPrxyTemplates.FillTemplateOTP(userName, email, phoneNumber, otp);
                _log.Debug("{cntx}", notTemplate);

                _log.Info("Enviando notificación");
                var request = new Dictionary<string, object>() { { "notTemplate", notTemplate } };
                var result = _notificationsPrxy.SingleOrDefault(x => x.Key == "Colombia").SendNotificationsAppSync(request);
                //result = _notificationsPrxy.NotificationsAppSync(notTemplate);

                _log.Debug("Resultado del envío: {cntx}", result);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al intentar enviar notificacion OTP: {cntx}", new { userName});
            }
        }

    }
}
