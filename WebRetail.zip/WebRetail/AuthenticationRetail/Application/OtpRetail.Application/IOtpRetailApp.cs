﻿using Common.Domain;
using OtpRetail.Domain.OtpInformationAggregate;
using OtpRetail.Domain.OtpValResultAggregate;

namespace OtpRetail.Application
{
    public interface IOtpRetailApp
    {
        OtpInformation SendOTP(string userName, out OperationResult result);
        OtpValResult OTPValidation(string userName, string otp, out OperationResult result);
    }
}
