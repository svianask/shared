﻿using Common.Domain;
using Common.Proxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using OtpAuth.Proxy;
using OtpRetail.Application;
using OtpRetail.Domain.OtpInformationAggregate;
using OtpRetail.Domain.OtpValResultAggregate;
using SeriLogH;
using SolvencyAuth.Proxy;
using SolvencyRetail.Domain.UserInformationAggregate;
using System;
using System.Configuration;

namespace OtpRetailApplicationTest
{
    [TestClass]
    public class OtpRetailAppTest
    {
        private readonly OtpRetailApp _otpRetailApp;
        private readonly ISeriLogHelper _log;
        private readonly Mock<IOtpAuthPrxy> _otpAuthPrxy;
        private readonly Mock<ISolvencyAuthPrxy> _solvencyAuthPrxy;
        private readonly Mock<INotificationsPrxy[]> _notificationsPrxy;

        public OtpRetailAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = "C:\\Files\\TestWebRetail-.txt";
            ConfigurationManager.AppSettings["Solvency:PortalId"] = "1";

            _otpAuthPrxy = new Mock<IOtpAuthPrxy>();
            _solvencyAuthPrxy = new Mock<ISolvencyAuthPrxy>();
            _notificationsPrxy = new Mock<INotificationsPrxy[]>();
            _log = new SeriLogHelper();

            _otpRetailApp = new OtpRetailApp(_otpAuthPrxy.Object, _solvencyAuthPrxy.Object, _log, _notificationsPrxy.Object);
        }

        [TestMethod, TestCategory("SendOTP")]
        [ExpectedException(typeof(ArgumentException))]
        public void SendOTPTestFail()
        {
            var otp =_otpRetailApp.SendOTP("", out OperationResult result);
        }

        [TestMethod, TestCategory("SendOTP")]
        public void SendOTPTestFailGeneraOTP()
        {
            var otp = _otpRetailApp.SendOTP("SACC660603DQ9", out OperationResult result);
            Assert.IsNull(otp);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("SendOTP")]
        public void SendOTPTestFailGetUserInformation()
        {
            GenerateOTP();
            var otp = _otpRetailApp.SendOTP("SACC660603DQ9", out OperationResult result);
            Assert.IsNull(otp);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("SendOTP")]
        public void SendOTPTestSuccessfull()
        {
            GenerateOTP();
            GetUserInformation();

            var otp = _otpRetailApp.SendOTP("SACC660603DQ9", out OperationResult result);

            Assert.IsNotNull(otp);
            Assert.IsTrue(result.Successful);
        }

        [TestMethod, TestCategory("OTPValidation")]
        [ExpectedException(typeof(ArgumentException))]
        [DataRow("", "452135")]
        [DataRow("SACC660603DQ9", "")]
        public void OTPValidationTestFailParameters(string userName, string otp)
        {
            var valid = _otpRetailApp.OTPValidation(userName, otp, out OperationResult resul);
        }

        [TestMethod, TestCategory("OTPValidation")]
        public void OTPValidationTestFailOtpValidation()
        {
            var valid = _otpRetailApp.OTPValidation("SACC660603DQ9", "524875", out OperationResult resul);

            Assert.IsNull(valid);
            Assert.IsFalse(resul.Successful);
        }

        [TestMethod, TestCategory("OTPValidation")]
        public void OTPValidationTestSuccessful()
        {
            OTPValidation();
            var valid = _otpRetailApp.OTPValidation("SACC660603DQ9", "5458547", out OperationResult result);

            Assert.IsNotNull(valid);
            Assert.IsTrue(result.Successful);
        }

        #region Mocks
        private void GenerateOTP()
        {
            var result = new OperationResult() { Successful = true };
            OtpInformation otp = OtpInformation.Create("SACC660603DQ9", "987763");
            otp.SetDataContact("email@mail.com", "2547554122");
            _otpAuthPrxy.Setup(c => c.GenerateOTP("SACC660603DQ9", 1, out result)).Returns(otp);

        }

        private void GetUserInformation()
        {
            var result = new OperationResult() { Successful = true };
            UserInformation user = UserInformation.Create("SACC660603DQ9", "Nombre", "Apellido paterno", "Apellido materno", 1);
            user.SetComplementaryData("user", "email@mail.com", "5522266587", false);
            _solvencyAuthPrxy.Setup(c => c.GetUserInformation("SACC660603DQ9", 1, out result)).Returns(user);
        }

        private void OTPValidation()
        {
            var result = new OperationResult() { Successful = true };
            OtpValResult valResult = new OtpValResult(false, true);
            _otpAuthPrxy.Setup(c => c.OTPValidation("SACC660603DQ9", 1, "5458547", out result)).Returns(valResult);
        }
        #endregion
    }
}
