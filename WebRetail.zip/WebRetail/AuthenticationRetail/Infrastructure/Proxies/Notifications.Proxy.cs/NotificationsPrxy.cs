﻿using Common.Domain;
using Common.Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using static Notifications.Proxy.NotificationsPrxyTypes;

namespace Notifications.Proxy
{
    public class NotificationsPrxy : INotificationsPrxy
    {
        public string Key { get { return "Colombia"; } }

        
        public OperationResult SendNotificationsAppSync(Dictionary<string, object> notRequest)
        {
            notRequest.TryGetValue("notTemplate", out object objRequest);
            var sendRequest = (SendNotificationDistListRequest)objRequest;

            OperationResult result = new OperationResult();

            WSFSOC.NotificationTemplateN reqTemplate;
            Enum.TryParse(Enum.GetName(typeof(NotificationTemplateN), sendRequest.Plantilla), out reqTemplate);
            string endPoint = ConfigurationManager.AppSettings["NotificationsAppService:Url"].ToString();
            WSFSOC.NotificationsAppServiceContractClient notClient = new WSFSOC.NotificationsAppServiceContractClient(WSFSOC.NotificationsAppServiceContractClient.EndpointConfiguration.NotificationsAppServiceEndpoint, endPoint);
            WSFSOC.SendNotificationDistListNRequest request = new WSFSOC.SendNotificationDistListNRequest
            {
                ContextBusinessN = new WSFSOC.ContextBusinessN
                {
                    Application = sendRequest.ContextBusiness.Application,
                    ClientEmail = sendRequest.ContextBusiness.ClientEmail,
                    ClientIdentifier = sendRequest.ContextBusiness.ClientIdentifier,
                    ClientMobile = sendRequest.ContextBusiness.ClientMobile,
                    Contract = sendRequest.ContextBusiness.Contract,
                    Process = sendRequest.ContextBusiness.Process,
                },
                SendParametersN = new WSFSOC.SendParametersN
                {
                    AdditionalMessages = sendRequest.SendParameters.AdditionalMessages,
                    Amount = sendRequest.SendParameters.Amount,
                    ClientIdentifier = sendRequest.SendParameters.ClientIdentifier,
                    ClientTypeId = sendRequest.SendParameters.ClientTypeId,
                    Contract = sendRequest.SendParameters.Contract,
                    EmailClient = sendRequest.SendParameters.EmailClient,
                    EmailFP = sendRequest.SendParameters.EmailFP,
                    MobileClient = sendRequest.SendParameters.MobileClient,
                    MobileFP = sendRequest.SendParameters.MobileFP
                },
                LstEmail = sendRequest.LstEmail,
                Plantilla = reqTemplate
            };

            WSFSOC.SendNotificationDistListResponse response = notClient.SendNotificationDistListNAsync(request.ContextBusinessN, request.LstEmail, request.Plantilla, request.SendParametersN).GetAwaiter().GetResult();
            result.SystemMessages.Add(new SystemMessage { Message = notClient.Endpoint.ListenUri.ToString(), MessageType = (SystemMessageTypes.Information) });
            result.Successful = response.Result.Successful;
            foreach (WSFSOC.SystemMessage ms in response.Result.SystemMessages)
            {
                result.SystemMessages.Add(new SystemMessage { Message = ms.Message, MessageType = (SystemMessageTypes)((int)ms.MessageType) });
            }

            return result;
        }
    }
}
