﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Notifications.Proxy.NotificationsPrxyTypes;

namespace Notifications.Proxy
{
    public class NotificationsPrxyTemplates
    {

        public static SendNotificationDistListRequest FillTemplateOTP(string userName, string email, string phone, string otp)
        {
            
            Dictionary<string, string> dsMensajes = new Dictionary<string, string>
            {
                { "Email", email },
                { "Poliza", "000000" },
                { "Valor", otp }
            };

            SendNotificationDistListRequest request = new SendNotificationDistListRequest
            {
                ContextBusiness = new ContextBusinessN
                {
                    Application = "Portal Retail",
                    Process = "OTP",
                    ClientEmail = email,
                    ClientMobile = phone,
                    ClientIdentifier = userName,
                    Contract = ""
                },
                SendParameters = new SendParametersN
                {
                    Amount = 0,
                    ClientIdentifier = userName,
                    ClientTypeId = "C",
                    Contract = otp,
                    EmailFP = "",
                    MobileClient = phone,
                    MobileFP = "",
                    EmailClient = email,
                    AdditionalMessages = dsMensajes
                },
                Plantilla = (NotificationTemplateN)Enum.Parse(typeof(NotificationTemplateN), "Solvencia_Pin_OTP"),
                LstEmail = new string[] { }
            };

            return request;
        }
    }
}
