﻿using Common.Domain;
using SolvencyRetail.Domain.UserInformationAggregate;

namespace SolvencyAuth.Proxy
{
    public interface ISolvencyAuthPrxy
    {
        UserInformation GetUserInformation(string userName, int portalId, out OperationResult result);
    }
}
