﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using SolvencyAuth.Proxy.SolvencyAuthMapp;
using SolvencyRetail.Domain.UserInformationAggregate;
using System;
using System.Configuration;

namespace SolvencyAuth.Proxy
{
    public class SolvencyAuthPrxy : ISolvencyAuthPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public SolvencyAuthPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public UserInformation GetUserInformation(string userName, int portalId, out OperationResult result)
        {
            PrxyUserInformationRequest request = new PrxyUserInformationRequest();
            PrxyUserInformationResponse response = new PrxyUserInformationResponse();
            UserInformation userInformation = null;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "Solvency/GetUserInformation";

            request.PortalId = portalId;
            request.UserName = userName;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyUserInformationResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0].Message); }

                userInformation = UserInformationMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return userInformation;
        }

      
    }
}
