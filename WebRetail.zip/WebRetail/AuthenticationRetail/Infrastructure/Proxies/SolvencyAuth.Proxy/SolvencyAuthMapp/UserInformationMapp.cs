﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolvencyRetail.Domain.UserInformationAggregate;

namespace SolvencyAuth.Proxy.SolvencyAuthMapp
{
    public class UserInformationMapp
    {
        internal static UserInformation Mapp(PrxyUserInformationResponse response)
        {
            var prxyUserInfo = response.UserInformation;
            var userInformation = UserInformation
                .Create(prxyUserInfo.UserName, prxyUserInfo.FirstName, prxyUserInfo.LastNameOne, prxyUserInfo.LastNameTwo, prxyUserInfo.Id)
                .SetComplementaryData(prxyUserInfo.Alias, prxyUserInfo.Email, prxyUserInfo.HomePhone, prxyUserInfo.Locked);

            return userInformation;
        }
    }
}
