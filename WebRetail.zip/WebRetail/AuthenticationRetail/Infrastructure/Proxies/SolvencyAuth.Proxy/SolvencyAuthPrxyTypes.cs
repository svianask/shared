﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace SolvencyAuth.Proxy
{
    public class PrxyUserInformationRequest
    {
        public string UserName;
        public int PortalId;
    }

    public class PrxyUserInformationResponse
    {
        public OperationResult Result;
        public PrxyUserInformation UserInformation;
    }

    public class PrxyUserInformation
    {
        public int Id;
        public string UserName;
        public string FirstName;
        public string LastNameOne;
        public string LastNameTwo;
        public bool Locked;
        public string Alias;
        public string Email;
        public string HomePhone;
        public string CountryPhoneCode;
    }


}
