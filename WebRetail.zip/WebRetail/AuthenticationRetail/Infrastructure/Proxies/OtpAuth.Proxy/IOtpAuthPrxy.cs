﻿using Common.Domain;
using OtpRetail.Domain.OtpInformationAggregate;
using OtpRetail.Domain.OtpValResultAggregate;

namespace OtpAuth.Proxy
{
    public interface IOtpAuthPrxy
    {
        OtpInformation GenerateOTP(string userName, int portalId, out OperationResult result);
        OtpValResult OTPValidation(string userName, int portalId, string otp, out OperationResult result);
        OtpInformation GenrateOTPWhitNotificationEmail(string username, out OperationResult result);
        OtpInformation GenrateOTPWhitNotificationSMS(string username, out OperationResult result);
    }
}
