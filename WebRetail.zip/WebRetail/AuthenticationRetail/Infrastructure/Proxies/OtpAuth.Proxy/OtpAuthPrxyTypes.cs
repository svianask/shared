﻿using Common.Domain;

namespace OtpAuth.Proxy
{
    public class PrxyGenerateOTPRequest
    {
        public string UserName;
        public int PortalId;
    }

    public class PrxyGenerateOTPResponse
    {
        public PrxyGenerateOTPResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result;
        public PrxyOtpInformation OtpInformation;
    }
       
    public class PrxyOtpInformation
    {
        public string Id;
        public string NewOTP;
        public UserDataContactPxy UserDataContact;
    }

    public class UserDataContactPxy
    {
        public string Email;
        public string Phone;
    }

    public class PrxyOTPValidationRequest
    {
        public string UserName;
        public int PortalId;
        public string OTP;
    }

    public class PrxyOTPValidationResponse
    {
        public OperationResult Result;
        public PrxyOtpValResult OtpValResult;
    }

    public class PrxyOtpValResult
    {
        public bool Expired;
        public bool Valid;
    }

    public class SendOtpRequestPxy
    {
        public string UserName;
    }
}
