﻿using Common.Domain;
using Newtonsoft.Json;
using OtpAuth.Proxy.OtpAuthMapp;
using OtpRetail.Domain.OtpInformationAggregate;
using OtpRetail.Domain.OtpValResultAggregate;
using Proxy;
using System;
using System.Configuration;

namespace OtpAuth.Proxy
{
    public class OtpAuthPrxy : IOtpAuthPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public OtpAuthPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public OtpInformation GenerateOTP(string userName, int portalId, out OperationResult result)
        {
            PrxyGenerateOTPRequest request = new PrxyGenerateOTPRequest();
            PrxyGenerateOTPResponse response = new PrxyGenerateOTPResponse();
            OtpInformation otpInformation;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "OTP/GenerateOTP";

            request.PortalId = portalId;
            request.UserName = userName;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyGenerateOTPResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0].Message); }

                otpInformation = OtpInformationMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return otpInformation;
        }

        public OtpValResult OTPValidation(string userName, int portalId, string otp, out OperationResult result)
        {
            PrxyOTPValidationRequest request = new PrxyOTPValidationRequest();
            PrxyOTPValidationResponse response = new PrxyOTPValidationResponse();
            OtpValResult otpValResult = null;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "OTP/OTPValidation";

            request.PortalId = portalId;
            request.UserName = userName;
            request.OTP = otp;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyOTPValidationResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0].Message); }

                otpValResult = OtpValResultMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return otpValResult;
        }

        public OtpInformation GenrateOTPWhitNotificationEmail(string username, out OperationResult result)
        {
            SendOtpRequestPxy request = new SendOtpRequestPxy() { UserName = username };
            OtpInformation otpInformation;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["WebRetailAuth:Url"].ToString() + "OTP/SendOTPEmail";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyGenerateOTPResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0].Message); }

                otpInformation = OtpInformationMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return otpInformation;
        }

        public OtpInformation GenrateOTPWhitNotificationSMS(string username, out OperationResult result)
        {
            SendOtpRequestPxy request = new SendOtpRequestPxy() { UserName = username };
            OtpInformation otpInformation;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["WebRetailAuth:Url"].ToString() + "OTP/SendOTP";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyGenerateOTPResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0].Message); }

                otpInformation = OtpInformationMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return otpInformation;
        }
    }
}
