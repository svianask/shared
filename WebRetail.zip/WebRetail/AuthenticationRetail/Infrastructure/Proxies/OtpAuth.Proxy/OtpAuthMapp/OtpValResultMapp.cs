﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OtpRetail.Domain.OtpValResultAggregate;

namespace OtpAuth.Proxy.OtpAuthMapp
{
    public class OtpValResultMapp
    {
        internal static OtpValResult Mapp(PrxyOTPValidationResponse response)
        {
            return new OtpValResult(
                expired: response.OtpValResult.Expired, 
                valid: response.OtpValResult.Valid
            );
        }
    }
}
