﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OtpRetail.Domain.OtpInformationAggregate;

namespace OtpAuth.Proxy.OtpAuthMapp
{
    public class OtpInformationMapp
    {
        internal static OtpInformation Mapp(PrxyGenerateOTPResponse response)
        {
            OtpInformation otpInformation = OtpInformation.Create(response.OtpInformation.Id, response.OtpInformation.NewOTP)
                .SetDataContact(response.OtpInformation.UserDataContact.Email, response.OtpInformation.UserDataContact.Phone);
            return otpInformation;
        }
    }
}
