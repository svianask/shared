﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolvencyRetail.Domain.UserInformationAggregate
{
    public class UserInformation : Entity<int>
    {
        private readonly string _userName;
        private readonly string _firstName;
        private readonly string _lastNameOne;
        private readonly string _lastNameTwo;
        private string _alias;
        private string _email;
        private string _homePhone;
        private bool _locked;


        private UserInformation(string userName, string firstName, string lastNameOne, string lastNameTwo, int userPortalId)
        {
            Id = userPortalId;
            _userName = userName;
            _firstName = firstName;
            _lastNameOne = lastNameOne;
            _lastNameTwo = lastNameTwo;
        }


        public string UserName => _userName;

        public string FirstName => _firstName;

        public string LastNameOne => _lastNameOne;

        public string LastNameTwo => _lastNameTwo;

        public string Alias => _alias;

        public string Email => _email;

        public string HomePhone => _homePhone;

        public bool Locked => _locked;

        public static UserInformation Create(string userName, string firstName, string lastNameOne, string lastNameTwo, int userPortalId)
        {
            return new UserInformation(userName, firstName, lastNameOne, lastNameTwo, userPortalId);
        }


        public UserInformation SetComplementaryData(string alias, string email, string homePhone, bool locked)
        {
            _alias = alias;
            _email = email;
            _homePhone = homePhone;
            _locked = Locked;

            return this;
        }
    }
}
