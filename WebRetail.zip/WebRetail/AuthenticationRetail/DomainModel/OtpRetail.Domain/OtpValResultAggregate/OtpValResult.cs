﻿using Ddd;
using System.Collections.Generic;

namespace OtpRetail.Domain.OtpValResultAggregate
{
    public class OtpValResult : ValueObject<OtpValResult>
    {
        private readonly bool _expired;
        private readonly bool _valid;

        public bool Expired => _expired;

        public bool Valid => _valid;

        public OtpValResult(bool expired, bool valid)
        {
            _expired = expired;
            _valid = valid;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Expired,
                Valid
            };
        }
    }
}
