﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ddd;

namespace SolvencyRetail.Domain.OtpInformationAggregate
{
    public class UserDataContact :  ValueObject<UserDataContact>
    {
        private readonly string _email;
        private readonly string _phone;

        private UserDataContact(string email, string phone)
        {
            _email = email;
            _phone = phone;
        }

        public string Email => _email;

        public string Phone => _phone;

        internal static UserDataContact Create(string email, string phone)
        {
            if (string.IsNullOrEmpty(email)) { throw new ArgumentException("El email no puede ser nulo o vacío."); }
            
            return new UserDataContact(email, phone);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Email,
                Phone
            };
        }
    }
}
