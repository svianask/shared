﻿using Ddd;
using SolvencyRetail.Domain.OtpInformationAggregate;
using System;
using System.Collections.Generic;
using System.Text;

namespace OtpRetail.Domain.OtpInformationAggregate
{
    public class OtpInformation : Entity<string>
    {
        private readonly string _OTP;
        private UserDataContact _userDataContact;

        public OtpInformation(string userName, string OTP, UserDataContact userDataContact)
        {
            Id = userName;
            _OTP = OTP;
            _userDataContact = userDataContact;
        }

        private OtpInformation(string userName, string newOTP)
        {
            Id = userName;
            _OTP = newOTP;
        }

        public string NewOTP => _OTP;

        public UserDataContact UserDataContact => _userDataContact;

        public static OtpInformation Create(string userName, string newOTP)
        {
            if (string.IsNullOrEmpty(userName)) { throw new ArgumentException("userId no puede ser nulo o vacío."); }
            if (newOTP == null) { throw new ArgumentException("newOTP no puede ser nulo."); }

            return new OtpInformation(userName, newOTP);
        }

        public OtpInformation SetDataContact(string email, string phone)
        {
            _userDataContact = UserDataContact.Create(email, phone);
            return this;
        }
    }
}
