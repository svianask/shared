﻿using ClientProfileDomain.ClientProfileAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientProfileApplication
{
    public interface IClientProfileApp
    {
        ClientProfile GetContractProfile(string contractId, out OperationResult result);
    }
}
