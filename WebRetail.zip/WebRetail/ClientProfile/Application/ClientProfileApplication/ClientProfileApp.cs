﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using ClientProfileDomain.ClientProfileAggregate;
using ClientProfileDomain.ContractInfoAggregate;
using ClientProfileDomain.SalesPracticeProfileAggregate;
using ClientProfileDomain.SpContractProfileAggregate;
using ClientProfileProxy;
using Common.Domain;
using SeriLogH;

namespace ClientProfileApplication
{
    public class ClientProfileApp : IClientProfileApp
    {

        delegate ContractInfo delGetContractInfo(string contractId, out OperationResult result);
        delegate List<SalesPracticeProfileItem> delGetProfilingPortfolio(out OperationResult result);
        delegate ClientProfile delGetClientProfile(string contractId, int platform, out OperationResult result);
        delegate ClientProfile delGetPortfolioProfile(string contractId, int platform, out OperationResult result);
        delegate SalesPracticeContractProfile delGetSalesPracticeContractProfile(string contractId, out OperationResult result);

        private readonly ISeriLogHelper _log;
        private readonly ICliProRetPrxy _retailServiceProxy;
        private readonly ICliProRetExtPrxy _retailExtServiceProxy;

        public ClientProfileApp(ISeriLogHelper log,
            ICliProRetPrxy retailServiceProxy,
            ICliProRetExtPrxy retailExtServiceProxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
            _retailExtServiceProxy = retailExtServiceProxy;
        }

        public ClientProfile GetContractProfile(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            ClientProfile clientProfile = null;
            _log.Info("Intentando obtener el perfilamiento de un cliente para el contrato : {cntx}", new { contractId });
            try
            {
                _log.Info("Obteniendo información del contrato");
                _log.Debug("{cntx}", new { contractId });
                delGetContractInfo dGetContractInfo = _retailServiceProxy.GetContractInfo;
                IAsyncResult rGetContractInfo = dGetContractInfo.BeginInvoke(contractId, out result, null, null);

                _log.Info("Obteniendo catálogo de perfiles de practica de ventas");
                delGetProfilingPortfolio dGetProfilingPortfolio = _retailExtServiceProxy.GetProfilingPortfolio;
                IAsyncResult rGetProfilingPortfolio = dGetProfilingPortfolio.BeginInvoke(out result, null, null);

                _log.Info("Esperando información básica del contrato");
                while (!rGetContractInfo.IsCompleted) { Thread.Sleep(20); }

                var contractInfo = dGetContractInfo.EndInvoke(out result, rGetContractInfo);
                var platform = contractInfo.Platform;
                _log.Info("Obteniendo plataforma del contrato");
                _log.Debug("{cntx}", new { contractId, platform });

                _log.Info("Obteniendo perfil de cliente y tipo de servicio para el contrato");
                delGetClientProfile dGetClientProfile = _retailServiceProxy.GetClientProfile;
                IAsyncResult rGetClientProfile = dGetClientProfile.BeginInvoke(contractId, platform, out result, null, null);

                _log.Info("Obteniendo perfil del portafolio para el contrato");
                delGetPortfolioProfile dGetPortfolioProfile = _retailServiceProxy.GetPortfolioProfile;
                IAsyncResult rGetPortfolioProfile = dGetPortfolioProfile.BeginInvoke(contractId, platform, out result, null, null);

                _log.Info("Obteniendo el perfilamiento del contrato para practica de ventas");
                delGetSalesPracticeContractProfile dGetSalesPracticeContractProfile = _retailServiceProxy.GetSalesPracticeContractProfile;
                IAsyncResult rGetSalesPracticeContractProfile = dGetSalesPracticeContractProfile.BeginInvoke(contractId, out result, null, null);

                _log.Info("Esperando procesamiento - perfil del portafolio - perfil de cliente y tipo de servicio - catálogo de perfiles de practica de ventas");
                while (!rGetClientProfile.IsCompleted || !rGetPortfolioProfile.IsCompleted || !rGetProfilingPortfolio.IsCompleted) { Thread.Sleep(20); }

                var salesPracticeProfileItems = dGetProfilingPortfolio.EndInvoke(out result, rGetProfilingPortfolio);
                _log.Debug("{cntx}", new { salesPracticeProfileItems });

                clientProfile = dGetClientProfile.EndInvoke(out result, rGetClientProfile);
                _log.Debug("{cntx}", new { clientProfile.ClientType, clientProfile.ServiceType });

                ClientProfile portfolioProfile = dGetPortfolioProfile.EndInvoke(out result, rGetPortfolioProfile);
                _log.Debug("{cntx}", new { portfolioProfile.PortfolioType });

                _log.Info("Esperando procesamiento - perilamiento del contrato para practica de ventas");
                while (!rGetSalesPracticeContractProfile.IsCompleted) { Thread.Sleep(20); }

                var salesPracticeContractProfile = _retailServiceProxy.GetSalesPracticeContractProfile(contractId, out result);
                _log.Debug("{cntx}", new { salesPracticeContractProfile });

                clientProfile.SetPortfolioType(portfolioProfile.PortfolioType.Identifier, portfolioProfile.PortfolioType.Description);

                var salesPracticeProf = salesPracticeProfileItems.Where(item => item.ProductTypeId == clientProfile.ProductTypeId && item.ClientTypeIdSiff == salesPracticeContractProfile.ClientType_Id).FirstOrDefault();
                if (salesPracticeProf != null)
                {
                    _log.Info("Asignando valores de perfilamiento del catálogo de practica de ventas");
                    clientProfile.SetSalesPracticeProfile(salesPracticeProf.ClientId, salesPracticeProf.ClientDescription, salesPracticeProf.PortfolioId, salesPracticeProf.PortfolioDescription);
                }
                else
                {
                    _log.Info("Asignando valores de perfilamiento por defecto para practica de ventas");
                    clientProfile.SetSalesPracticeProfile(portfolioProfile.ClientType.Identifier, portfolioProfile.ClientType.Description, portfolioProfile.ClientType.Identifier, portfolioProfile.ClientType.Description);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error obtener el perfilamiento de un cliente para el contrato : {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error obtener el perfilamiento de un cliente para el contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return clientProfile;
        }

    }
}
