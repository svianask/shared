﻿using Ddd;

namespace ClientProfileDomain.ClientProfileAggregate
{
    public class ClientProfile : Entity<string>
    {
        private ClientType _clientType;
        private PortfolioType _portfolioType;
        private SalesPracticeProfile _salesPracticeProfile;
        private ServiceType _serviceType;
        private string _productTypeId;

        public ClientProfile(string ContractId)
        {
            Id = ContractId;
        }

        public ClientType ClientType => _clientType;

        public PortfolioType PortfolioType => _portfolioType;

        public SalesPracticeProfile SalesPracticeProfile => _salesPracticeProfile;

        public ServiceType ServiceType => _serviceType;

        public string ProductTypeId => _productTypeId;

        public ClientProfile SetClientType(string identifier, string description)
        {
            this._clientType = new ClientType(identifier, description);
            return this;
        }

        public ClientProfile SetPortfolioType(string identifier, string description)
        {
            this._portfolioType = new PortfolioType(identifier, description);
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cliProfId">client profile id of sales prectice</param>
        /// <param name="cliProfDesc">client profile description of sales prectice</param>
        /// <param name="portfProfId">portfolio profile id of sales prectice</param>
        /// <param name="portfProfDesc">portfolio profile description of sales prectice</param>
        /// <returns>this ContractProfile instance</returns>
        public ClientProfile SetSalesPracticeProfile(string cliProfId, string cliProfDesc, string portfProfId, string portfProfDesc)
        {
            this._salesPracticeProfile = new SalesPracticeProfile(cliProfId, cliProfDesc, portfProfId, portfProfDesc);
            return this;
        }

        public ClientProfile SetServiceType(string identifier, string description)
        {
            this._serviceType = new ServiceType(identifier, description);
            return this;
        }

        public ClientProfile SetProductTypeId(string productTypeId)
        {
            this._productTypeId = productTypeId;
            return this;
        }
    }
}
