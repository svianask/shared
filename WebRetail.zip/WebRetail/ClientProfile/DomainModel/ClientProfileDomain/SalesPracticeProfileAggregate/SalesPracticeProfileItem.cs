﻿using Ddd;
using System.Collections.Generic;

namespace ClientProfileDomain.SalesPracticeProfileAggregate
{
    public class SalesPracticeProfileItem : ValueObject<SalesPracticeProfileItem>
    {
        private readonly string _productTypeId;
        private readonly string _clientTypeIdSiff;
        private string _clientId;
        private string _clientDescription;
        private string _portfolioDescription;
        private string _portfolioId;


        private SalesPracticeProfileItem(string productTypeId, string clientTypeIdSiff)
        {
            _productTypeId = productTypeId;
            _clientTypeIdSiff = clientTypeIdSiff;
        }

        public string ProductTypeId => _productTypeId;

        public string ClientTypeIdSiff => _clientTypeIdSiff;

        public string ClientId => _clientId;

        public string ClientDescription => _clientDescription;

        public string PortfolioDescription => _portfolioDescription;

        public string PortfolioId => _portfolioId;

        public static SalesPracticeProfileItem Create(string productTypeId, string clientTypeIdSiff)
        {
            return new SalesPracticeProfileItem(productTypeId, clientTypeIdSiff);
        }

        public SalesPracticeProfileItem SetClientProfile(string clientId, string clientDescription)
        {
            this._clientId = clientId;
            this._clientDescription = clientDescription;
            return this;
        }

        public SalesPracticeProfileItem SetPortfolioProfile(string portfolioId, string portfolioDescription)
        {
            this._portfolioId = portfolioId;
            this._portfolioDescription = portfolioDescription;
            return this;
        }
               
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ProductTypeId,
                ClientTypeIdSiff,
                ClientId,
                ClientDescription,
                PortfolioDescription,
                PortfolioId
            };
        }

    }
}
