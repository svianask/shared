﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileDomain.SpContractProfileAggregate
{
    public class SalesPracticeContractProfile : ValueObject<SalesPracticeContractProfile>
    {
        private string _clientType_Id;
        private string _clientType_Descrption;
        private string _clientType_ShortDescription;

        public SalesPracticeContractProfile(string clientType_Id, string clientType_Descrption, string clientType_ShortDescription)
        {
            _clientType_Id = clientType_Id;
            _clientType_Descrption = clientType_Descrption;
            _clientType_ShortDescription = clientType_ShortDescription;
        }

        public string ClientType_Id => _clientType_Id;

        public string ClientType_Descrption => _clientType_Descrption;

        public string ClientType_ShortDescription => _clientType_ShortDescription;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ClientType_Id,
                ClientType_Descrption,
                ClientType_ShortDescription
            };
        }
    }
}
