﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileProxy
{
    public class PrxyProfilingPortfolioResponse
    {
        public OperationResult Result;
        public List<PrxySalesPracticeProfile> SalesPracticeProfiles;
    }

    public class PrxySalesPracticeProfile
    {
        public string ProductTypeId;
        public string ClientTypeIdSiff;
        public string ClientId;
        public string ClientDescription;
        public string PortfolioDescription;
        public string PortfolioId;
    }

}
