﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileProxy
{
    public class PrxyContractInfo
    {
        public string Id;
        public short PlanBasId;
        public int Platform;
        public short GoalId;
        public string ContratoAgrupa;
        public DateTime AfiliationDate;
    }

    public class PrxyContractInfoResponse
    {
        public PrxyContractInfo ContractInfo;
        public OperationResult Result;
    }

    public class PrxyContractInfoRequest
    {
        public string ContractId;
    }

    public class PrxyClientProfileResponse
    {
        public PrxyClientProfile ClientProfile;
        public OperationResult Result;
    }
    public class PrxyClientProfileRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class PrxyClientProfile
    {
        public PrxySalesPractClientType ClientType;
        public PrxyServiceType ServiceType;
        public string ProductType;
    }

    public class PrxySalesPractClientType
    {
        public string Id;
        public string Description;
    }

    public class PrxyServiceType
    {
        public string Id;
        public string Description;
    }

    public class PrxyPortfolioProfileResponse
    {
        public PrxySalesPractPortfolioType PortfolioType;
        public OperationResult Result;
    }

    public class PrxyPortfolioProfileRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class PrxySalesPractPortfolioType
    {
        public PrxySalesPractClientType ClientType;
        public string Id;
        public string Description;
    }

    public class PrxySalesPracticeContractProfileRequest
    {
        public string ContractId;
    }

    public class PrxySalesPracticeContractProfileResponse
    {
        public PrxySalesPractContractProfile SalesPracticeContractProfile;
        public OperationResult Result;
    }

    public class PrxySalesPractContractProfile
    {
        public string ClientType_Id;
        public string ClientType_Descrption;
        public string ClientType_ShortDescription;
    }
}
