﻿using ClientProfileDomain.ClientProfileAggregate;
using ClientProfileDomain.ContractInfoAggregate;
using ClientProfileDomain.SpContractProfileAggregate;
using Common.Domain;

namespace ClientProfileProxy
{
    public interface ICliProRetPrxy
    {
        ContractInfo GetContractInfo(string contractId, out OperationResult result);
        ClientProfile GetClientProfile(string contractId, int platform, out OperationResult result);
        ClientProfile GetPortfolioProfile(string contractId, int platform, out OperationResult result);
        SalesPracticeContractProfile GetSalesPracticeContractProfile(string contractId, out OperationResult result); 
    }
}
