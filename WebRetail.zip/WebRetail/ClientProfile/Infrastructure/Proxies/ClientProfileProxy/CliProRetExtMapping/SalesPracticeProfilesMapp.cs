﻿using System.Collections.Generic;
using ClientProfileDomain.SalesPracticeProfileAggregate;


namespace ClientProfileProxy.CliProRetExtMapping
{
    public class SalesPracticeProfilesMapp
    {
        internal static List<SalesPracticeProfileItem> Mapp(PrxyProfilingPortfolioResponse response)
        {
            List<SalesPracticeProfileItem> salesPracticeProfileItems = new List<SalesPracticeProfileItem>();

            response.SalesPracticeProfiles.ForEach(sp => salesPracticeProfileItems
                .Add(
                    SalesPracticeProfileItem
                    .Create( sp.ProductTypeId, sp.ClientTypeIdSiff )
                    .SetClientProfile(sp.ClientId, sp.ClientDescription)
                    .SetPortfolioProfile(sp.PortfolioId, sp.PortfolioDescription)
                )
            );

            return salesPracticeProfileItems;
        }
    }
}
