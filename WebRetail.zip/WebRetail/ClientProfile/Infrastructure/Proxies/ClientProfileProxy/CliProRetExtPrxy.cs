﻿using System;
using System.Collections.Generic;
using System.Configuration;
using ClientProfileDomain.SalesPracticeProfileAggregate;
using ClientProfileProxy.CliProRetExtMapping;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;

namespace ClientProfileProxy
{
    public class CliProRetExtPrxy : ICliProRetExtPrxy
    {

        private readonly IProxyEngine _proxyEngine;

        public CliProRetExtPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<SalesPracticeProfileItem> GetProfilingPortfolio(out OperationResult result)
        {

            PrxyProfilingPortfolioResponse response = new PrxyProfilingPortfolioResponse();
            result = new OperationResult();
            List<SalesPracticeProfileItem> salesPracticeProfileItems = new List<SalesPracticeProfileItem>();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientProfile/GetProfilingPortfolio"; //Controller/Action

            string JsonResult = _proxyEngine.SendMSRequestJson(url, out result, "POST");
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyProfilingPortfolioResponse>(JsonResult);
                salesPracticeProfileItems = SalesPracticeProfilesMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return salesPracticeProfileItems;
        }
    }
}
