﻿using ClientProfileDomain.ClientProfileAggregate;

namespace ClientProfileProxy.CliProRetMapping
{
    public class ContractProfileMapp
    {
        internal static ClientProfile ClientContractMapp(string contractId, PrxyClientProfileResponse response)
        {            
            return new
                ClientProfile(contractId)
                .SetClientType(
                    response.ClientProfile.ClientType.Id, 
                    response.ClientProfile.ClientType.Description
                )
                .SetServiceType(
                    response.ClientProfile.ServiceType.Id,
                    response.ClientProfile.ServiceType.Description
                )
                .SetProductTypeId(
                    response.ClientProfile.ProductType
                );                
        }

        internal static ClientProfile MappPortfolio(string contractId, PrxyPortfolioProfileResponse response)
        {
            return new
                ClientProfile(contractId)
                .SetPortfolioType(
                    response.PortfolioType.Id,
                    response.PortfolioType.Description
                )
                .SetClientType(
                    response.PortfolioType.ClientType.Id,
                    response.PortfolioType.ClientType.Description
                );
                
        }
    }
}
