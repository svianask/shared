﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientProfileDomain.SpContractProfileAggregate;

namespace ClientProfileProxy.CliProRetMapping
{
    public class SalesPracticeContractProfileMapp
    {
        internal static SalesPracticeContractProfile Mapp(string contractId, PrxySalesPracticeContractProfileResponse response)
        {
            SalesPracticeContractProfile salesPracticeContractProfile = null;

            if (response.SalesPracticeContractProfile != null)
                salesPracticeContractProfile = 
                new SalesPracticeContractProfile(
                    clientType_Id: response.SalesPracticeContractProfile.ClientType_Id,
                    clientType_Descrption: response.SalesPracticeContractProfile.ClientType_Descrption,
                    clientType_ShortDescription: response.SalesPracticeContractProfile.ClientType_ShortDescription
                );

            return salesPracticeContractProfile;
        }
    }
}
