﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientProfileDomain.ContractInfoAggregate;

namespace ClientProfileProxy.CliProRetMapping
{
    public class ContractInfoMapp
    {
        internal static ContractInfo Mapp(PrxyContractInfoResponse response)
        {
            return ContractInfo
                .Create(
                    response.ContractInfo.Id,
                    response.ContractInfo.PlanBasId,
                    response.ContractInfo.Platform,
                    response.ContractInfo.GoalId,
                    response.ContractInfo.ContratoAgrupa
                );
        }
    }
}
