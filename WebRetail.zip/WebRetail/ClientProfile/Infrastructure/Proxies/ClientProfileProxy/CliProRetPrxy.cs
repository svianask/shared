﻿using System;
using System.Configuration;
using ClientProfileDomain.ClientProfileAggregate;
using ClientProfileDomain.ContractInfoAggregate;
using ClientProfileDomain.SpContractProfileAggregate;
using ClientProfileProxy.CliProRetMapping;
using Common.Domain; 
using Newtonsoft.Json;
using Proxy;

namespace ClientProfileProxy
{
    public class CliProRetPrxy : ICliProRetPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public CliProRetPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }


        public ContractInfo GetContractInfo(string contractId, out OperationResult result)
        {
            PrxyContractInfoRequest request = new PrxyContractInfoRequest();
            PrxyContractInfoResponse response = new PrxyContractInfoResponse();
            ContractInfo contractDetail = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";
            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractInfoResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                contractDetail = ContractInfoMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractDetail;
        }

        public ClientProfile GetClientProfile(string contractId, int platform, out OperationResult result)
        {

            PrxyClientProfileRequest request = new PrxyClientProfileRequest();
            PrxyClientProfileResponse response = new PrxyClientProfileResponse();
            ClientProfile clientProfile = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetClientProfile";
            request.ContractId = contractId;
            request.Platform = platform;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientProfileResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                clientProfile = ContractProfileMapp.ClientContractMapp(contractId, response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientProfile;
        }


        public ClientProfile GetPortfolioProfile(string contractId, int platform, out OperationResult result)
        {
            PrxyPortfolioProfileRequest request = new PrxyPortfolioProfileRequest();
            PrxyPortfolioProfileResponse response = new PrxyPortfolioProfileResponse();
            ClientProfile contractProfile = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetPortfolioProfile";
            request.ContractId = contractId;
            request.Platform = platform;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyPortfolioProfileResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                contractProfile = ContractProfileMapp.MappPortfolio(contractId, response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return contractProfile;
        }

        public SalesPracticeContractProfile GetSalesPracticeContractProfile(string contractId, out OperationResult result)
        {
            PrxySalesPracticeContractProfileRequest request = new PrxySalesPracticeContractProfileRequest();
            PrxySalesPracticeContractProfileResponse response = new PrxySalesPracticeContractProfileResponse();
            SalesPracticeContractProfile salesPracticeContractProfile = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetSalesPracticeContractProfile";
            request.ContractId = contractId;
            
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxySalesPracticeContractProfileResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                salesPracticeContractProfile = SalesPracticeContractProfileMapp.Mapp(contractId, response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return salesPracticeContractProfile;
        } 
    }
}
