﻿namespace ClientProfileMessages
{
    public class ContractProfileRequest
    {
        private string contractId;

        public ContractProfileRequest(string contractId)
        {
            ContractId = contractId;
        }

        public string ContractId { get => contractId; set => contractId = value; }
    }
}
