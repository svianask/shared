﻿using ClientProfileDomain.ClientProfileAggregate;
using Common.Domain;

namespace ClientProfileMessages
{
    public class ContractProfileResponse
    {
        public ContractProfileResponse()
        {
            Result = new OperationResult();
        }

        public ClientProfile ClientProfile;
        public OperationResult Result;
    }
}
