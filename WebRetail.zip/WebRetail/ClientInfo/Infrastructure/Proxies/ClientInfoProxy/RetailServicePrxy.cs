﻿using ClientInfoDomain.ClientAggregate;
using ClientInfoDomain.ContactInformationAggregate;
using ClientInfoProxy.Mapping;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Configuration;

namespace ClientInfoProxy
{
    public class RetailServicePrxy : IRetailServicePrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public RetailServicePrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ClientInfo GetClientByContractId(string contractId, out OperationResult result)
        {
            PrxyClientByContractIdRequest request = new PrxyClientByContractIdRequest();
            PrxyClientByContractIdResponse response = new PrxyClientByContractIdResponse();
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/GetClientByContractId";
            request.contractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            ClientInfo clientInfo;

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientByContractIdResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                clientInfo = ClientInformationMapp.Mapp(response);

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientInfo;
        }

        public ContactInformation GetContactInformationByClientId(string clientIdentifier, out OperationResult result)
        {
            PrxyContactInformationByUserIdRequest request = new PrxyContactInformationByUserIdRequest();
            PrxyContactInformationByUserIdResponse response = new  PrxyContactInformationByUserIdResponse();
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/GetContactInformationByClientId";
            request.ClientIdentifier = clientIdentifier;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            ContactInformation contactInformation;

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContactInformationByUserIdResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contactInformation = ContactInformationMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contactInformation;
        }

        public OperationResult UpdateClientInfoNameEmail(string firstName, string lastName, string secondLastName, string email, string rfc)
        {
            UpdateClientNameAndEmailRequest request = new UpdateClientNameAndEmailRequest()
            {
                ClientData = new ClientGeneralData()
                {
                    FirstName = firstName,
                    LastName = lastName,
                    SecondLastName = secondLastName,
                    Email = email,
                    RFC = rfc
                }
            };
            UpdateClientNameAndEmailResponse response = new UpdateClientNameAndEmailResponse();
            var result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/UpdateClientNameAndEmail";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if(result.Successful)
            {
                response = JsonConvert.DeserializeObject<UpdateClientNameAndEmailResponse>(JsonResult);
                result = response.Result;

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return result;
        }
    }
}
