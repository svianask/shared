﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientInfoProxy
{
    #region ClientByContractId
    public class PrxyClientByContractIdRequest
    {
        public string contractId;
    }

    public class PrxyClientByContractIdResponse
    {
        public OperationResult Result;
        public PrxyClientInfo ClientInfo;
    }

    public class PrxyClientInfo
    {
        public string Id;
        public string Name;
        public string LastNameOne;
        public string LastNameTwo;
    }
    #endregion

    #region Contact information
    public class PrxyContactInformationByUserIdRequest
    {
        public string ClientIdentifier;
    }

    public class PrxyContactInformationByUserIdResponse
    {
        public PrxyContactInformation ContactInformation;
        public OperationResult Result;
    }

    public class PrxyContactInformation 
    {
        public string Email;
        public string MobilePhone;
        public string CountryDialCode;
        public string Name;
        public string LastName;
        public string SecondLastName;
    }

    #endregion

    #region Update Client Name Email
    public class UpdateClientNameAndEmailRequest
    {
        public ClientGeneralData ClientData;
    }

    public class UpdateClientNameAndEmailResponse
    {
        public OperationResult Result;

        public UpdateClientNameAndEmailResponse() { Result = new OperationResult(); }
    }

    public class ClientGeneralData
    {
        public ClientGeneralData()
        {

        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SecondLastName { get; set; }
        public string Email { get; set; }
        public string RFC { get; set; }
    }
    #endregion
}