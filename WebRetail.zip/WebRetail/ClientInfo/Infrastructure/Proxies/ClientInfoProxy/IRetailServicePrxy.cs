﻿using ClientInfoDomain.ClientAggregate;
using ClientInfoDomain.ContactInformationAggregate;
using Common.Domain;

namespace ClientInfoProxy
{
    public interface IRetailServicePrxy
    {
        ClientInfo GetClientByContractId(string contractId, out OperationResult result);
        ContactInformation GetContactInformationByClientId(string clientIdentifier, out OperationResult result);
        OperationResult UpdateClientInfoNameEmail(string firstName, string lastName, string secondLastName, string email, string rfc);
    }
}
