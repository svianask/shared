﻿using System;
using ClientInfoDomain.ClientAggregate;
using ClientInfoDomain.ContactInformationAggregate;

namespace ClientInfoProxy.Mapping
{
    public class ClientInformationMapp
    {
        internal static ClientInfo Mapp(PrxyClientByContractIdResponse response)
        {
            ClientInfo clientInfo = ClientInfo.Create(response.ClientInfo.Id, response.ClientInfo.Name, response.ClientInfo.LastNameOne, response.ClientInfo.LastNameTwo);
            return clientInfo;
        }
    }

    public class ContactInformationMapp
    {
        internal static ContactInformation Mapp(PrxyContactInformationByUserIdResponse response)
        {
            ContactInformation contactInformation = ContactInformation.Create(response.ContactInformation.Email, response.ContactInformation.MobilePhone, "")
                .SetName(response.ContactInformation.Name, response.ContactInformation.LastName, response.ContactInformation.SecondLastName);
            return contactInformation;
        }
    }

}
