﻿using ClientInfoDomain.ClientAggregate;
using ClientInfoDomain.ContactInformationAggregate;
using ClientInfoProxy;
using Common.Domain;
using SeriLogH;
using System;

namespace ClientInfoApplication
{
    public class ClientInfoApp : IClientInfoApp
    {
        private readonly ISeriLogHelper _log;
        public readonly IRetailServicePrxy _retailServiceProxy;

        public ClientInfoApp(ISeriLogHelper log, IRetailServicePrxy retailServiceProxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
        }

        public ClientInfo GetClientByContractId(string contractId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            ClientInfo clientInfo;
            try
            {
                _log.Info("Validando que contractId no sea nulo ni vacío.");
                if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contractId no puede ir vacío o null."); }
                _log.Debug("{cntx}", true);
                _log.Info("Obteniendo los datos del cliente del proxy RetailServicePrxy.", contractId);
                clientInfo = _retailServiceProxy.GetClientByContractId(contractId, out result);
                _log.Debug("{cntx}", new { clientInfo });

                return clientInfo;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los datos del cliente {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener los datos del cliente - " + ex.Message + "-" });
                return null;
            }
        }

        public ContactInformation GetContactInformationByClientId(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            ContactInformation contactInformation = null;
            try
            {
                if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("El argumento no puede ir vacío o null.", nameof(clientIdentifier)); }

                _log.Info("Obteniendo los datos de contacto del cliente {cntx}", clientIdentifier);
                contactInformation = _retailServiceProxy.GetContactInformationByClientId(clientIdentifier, out result);
                _log.Debug("{cntx}", new { contactInformation });
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los datos del cliente {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener los datos del cliente - " + ex.Message + "-" });
                return null;
            }

            return contactInformation;
        }

        public OperationResult UpdateClientInfoNameEmail(string firstName, string lastName, string secondLastName, string email, string rfc)
        {
            OperationResult result = new OperationResult { Successful = true };

            try
            {
                if (string.IsNullOrEmpty(firstName)) { throw new ArgumentException(nameof(firstName)); }
                if (string.IsNullOrEmpty(lastName)) { throw new ArgumentException(nameof(lastName)); }
                if (string.IsNullOrEmpty(email)) { throw new ArgumentException(nameof(email)); }
                if (string.IsNullOrEmpty(rfc)) { throw new ArgumentException(nameof(rfc)); }

                _log.Info("Actualizando los datos en SIIF");
                result = _retailServiceProxy.UpdateClientInfoNameEmail(firstName, lastName, secondLastName, email, rfc);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error alactualizar los datos del cliente {cntx}", new { rfc });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al actualizar los datos del cliente - " + ex.Message + "-" });
            }
            return result;
        }
    }
}
