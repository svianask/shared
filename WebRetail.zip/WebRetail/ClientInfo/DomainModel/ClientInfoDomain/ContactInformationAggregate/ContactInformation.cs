﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientInfoDomain.ContactInformationAggregate
{
    public class ContactInformation : ValueObject<ContactInformation>
    {
        private readonly string _email;
        private readonly string _mobilePhone;
        private readonly string _countryDialCode;
        private string _name;
        private string _lastName;
        private string _secondLastName;

        public ContactInformation(string email, string mobilePhone, string countryDialCode)
        {
            _email = email;
            _mobilePhone = mobilePhone;
            _countryDialCode = countryDialCode;
        }

        public string Email => _email;

        public string MobilePhone => _mobilePhone;

        public string CountryDialCode => _countryDialCode;
        public string Name => _name;
        public string LastName => _lastName;
        public string SecondLastName => _secondLastName;

        public static ContactInformation Create(string email, string phone, string countryDialCode)
        {
            phone = StandarizePhone(phone);
            countryDialCode = StandarizeCountryDialCode(countryDialCode);

            return new ContactInformation(email, phone, countryDialCode);
        }

        private static string StandarizeCountryDialCode(string countryDialCode)
        {
            countryDialCode = countryDialCode.Replace(" ", "").Trim();
            if (countryDialCode.Length < 1) { countryDialCode = "52"; }
            return countryDialCode;
        }

        private static string StandarizePhone(string phone)
        {
            phone = phone.Replace(" ", "").Trim();
            if (phone.Length != 10) { phone = string.Empty; }
            return phone;
        }

        public ContactInformation SetName(string name, string lastName, string secondLastName)
        {
            _name = name;
            _lastName = lastName;
            _secondLastName = secondLastName;
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Email,
                MobilePhone,
                CountryDialCode,
                Name,
                LastName,
                SecondLastName
            };
        }
    }
}
