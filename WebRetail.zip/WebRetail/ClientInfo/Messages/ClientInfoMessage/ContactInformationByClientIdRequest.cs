﻿namespace ClientInfoMessage
{
    public class ContactInformationByClientIdRequest
    {
        public string ClientIdentifier;
    }
}
