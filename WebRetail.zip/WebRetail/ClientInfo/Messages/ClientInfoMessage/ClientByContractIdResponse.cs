﻿using ClientInfoDomain.ClientAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientInfoMessage
{
    public class ClientByContractIdResponse
    {
        public OperationResult Result;
        public ClientInfo ClientInfo;

        public ClientByContractIdResponse()
        {
            Result = new OperationResult();
            ClientInfo = null;
        }

    }
}
