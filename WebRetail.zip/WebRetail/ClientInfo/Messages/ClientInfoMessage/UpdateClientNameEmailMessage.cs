﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientInfoMessage
{
    public class UpdateClientNameEmailRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SecondLastName { get; set; }
        public string Email { get; set; }
        public string RFC { get; set; }

        public UpdateClientNameEmailRequest() { }
    }

    public class UpdateClientNameEmailResponse
    {
        public OperationResult Result;

        public UpdateClientNameEmailResponse() { Result = new OperationResult(); }
    }
}
