﻿using ClientInfoDomain.ContactInformationAggregate;
using Common.Domain;

namespace ClientInfoMessage
{
    public class ContactInformationByClientIdResponse
    {
        public ContactInformation ContactInformation;
        public OperationResult Result; 
    }
}
