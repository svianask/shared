﻿

using ClientStatisticsDomain.CampaignsAggregate;
using ClientStatisticsDomain.ClientStatisticsAggregate;
using ClientStatisticsProxy;
using ClientStatisticsProxy.WebRetailServiceStatisticsMapp;
using Common.Domain;
using Common.Proxy;
using SeriLogH;
using System.Collections.Generic;
using System.Linq;

namespace ClientStatistics.Application
{
    public class ClientStatisticsApp : IClientStatisticsApp
    {
        private readonly IWebRetailStatisticsProxy _webRetailStatisticsProxy;
        private readonly ISeriLogHelper _log;
        private readonly IParametersProxy _parametersProxy;
        public ClientStatisticsApp(ISeriLogHelper log, IParametersProxy parametersProxy, 
            IWebRetailStatisticsProxy webRetailStatisticsProxy) 
        {
            _webRetailStatisticsProxy = webRetailStatisticsProxy;
            _log = log;
            _parametersProxy = parametersProxy;
                
        }

        public List<Statistic> GetStatistics(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            _log.Info("Getting  Client Statistics Information");
            rfc = rfc.ToUpper();
            _log.Info("Rfc Parameter: {cntx}", rfc);
            List<CampaignData> campaings = _webRetailStatisticsProxy.GetAllCampaingsByRFC(rfc, out result).Where(o => o.CampaignDetails.Type.Trim().ToUpper() == "CAJA_ACCION" || o.CampaignDetails.Type.Trim().ToUpper() == "CAJA_DATA").ToList();
            _log.Debug("Campaigns founds: {cntx}", campaings);

            List<Statistic> statistics = StatisticsMapp.Mapp(campaings);
            _log.Debug("Result Statistics {cntx}", statistics);
            return statistics;
        }

        public int GetStatisticsCountByClient(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            _log.Info("Getting Total  Statistics Information");
            rfc = rfc.ToUpper();
            _log.Info("Rfc Parameter: {cntx}", rfc);
            int countStatistics = _webRetailStatisticsProxy.GetAllCampaingsByRFC(rfc, out result).Where(o => o.CampaignDetails.Type.Trim().ToUpper() == "CAJA_ACCION" || o.CampaignDetails.Type.Trim().ToUpper() == "CAJA_DATA").Count();
            _log.Debug("Total Statistics: {cntx}", countStatistics);

            return countStatistics;
        }

        public void UpdateClickStatisticItemClient(string rfc, string campaignId, string responseValue, string id, bool hasClicked, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            _log.Info("Recording ClickStatisticItemClient");
            _log.Info("Rfc Parameter: {cntx}", rfc);
            _log.Info("CampaignId Parameter: {cntx}", campaignId);
            _log.Info("Response Value Parameter: {cntx}", responseValue);
            _log.Info("Id Parameter: {cntx}", id);
            _log.Info("HasClicked Parameter: {cntx}", hasClicked);

            _webRetailStatisticsProxy.RegisterEventClick($"{rfc}{campaignId}", responseValue, id, hasClicked, out result);
            _log.Info("Recording ClickStatisticItemClient  Proccessed");
        }
    }
}
