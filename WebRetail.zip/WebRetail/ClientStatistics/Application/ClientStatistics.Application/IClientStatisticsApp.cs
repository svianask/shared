﻿using ClientStatisticsDomain.ClientStatisticsAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientStatistics.Application
{
    public interface IClientStatisticsApp
    {
        List<Statistic> GetStatistics(string rfc, out OperationResult result);
        void UpdateClickStatisticItemClient(string rfc, string campaignId, string responseValue, string id, bool hasClicked, out OperationResult result);
        int GetStatisticsCountByClient(string rfc, out OperationResult result);
    }
}
