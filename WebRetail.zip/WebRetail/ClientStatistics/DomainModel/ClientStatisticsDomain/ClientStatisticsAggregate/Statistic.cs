﻿

using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClientStatisticsDomain.ClientStatisticsAggregate
{
    public class Statistic : Entity<string>
    {
        private string header;
        private string subheader;
        private string campaignId;
        private string labelButtonAction;
        private string urlRedirect;
        private List<string> options;
        private string boxType;
        private string itemType;


        private Statistic(string id, string textHeader, string textSubheader, string campaignId, string labelButtonAction, string textUrlRedirect,  List<string> options,  string boxType, string itemType)
        {
            Id = id;
            header = textHeader;
            subheader = textSubheader;
            this.campaignId = campaignId;   
            this.options = options;
            this.boxType = boxType;
            this.itemType = itemType;
            this.labelButtonAction = labelButtonAction;
            this.urlRedirect = textUrlRedirect;
        }

        public string Header=> header;
        public string SubHeader => subheader;
        public string CampaignId => campaignId;
        public string LabelButtonAction => labelButtonAction;
        public string UrlRedirect => urlRedirect;
        public List<string> Options => options;
        public string BoxType => boxType;
        public string ItemType => itemType;


        public static Statistic Create(string id, string textHeader, string textSubheader, string campaignId, string textUrlRedirect, string options, string boxType, string itemType)
        {
            if (string.IsNullOrEmpty(id)) { throw new ArgumentException("Id can't be NULL"); }
            if (string.IsNullOrEmpty(textHeader)) { throw new ArgumentException("TextHeader can't be NULL"); }
            if (string.IsNullOrEmpty(boxType)) { throw new ArgumentException("BoxType can't be NULL"); }
            if (string.IsNullOrEmpty(itemType)) { throw new ArgumentException("ItemType can't be NULL"); }
            if (string.IsNullOrEmpty(campaignId)) { throw new ArgumentException("CampaignId can't be NULL"); }

            boxType = boxType.Trim().ToUpper();
            itemType = itemType.Trim().ToUpper();   
            options = options.Trim().ToUpper();
            List<string> lobjects = new List<string>();
            if( !String.IsNullOrEmpty(options) && !boxType.Equals("CAJA_ACTION") && !itemType.Equals("TEXT") && !itemType.Equals("NO APLICA"))
            {
                var opts = options.Split(new[] { '/' }).ToList();
                lobjects.AddRange(opts);
            }

           

            return new Statistic(id, textHeader, textSubheader, campaignId, options, textUrlRedirect, lobjects, boxType, itemType);
        }

    }
}
