﻿using Common.Domain;

namespace ClientNotification.Messages
{
    public class SendFirstNotificationsResponse
    {
        public OperationResult Result;
    }
}
