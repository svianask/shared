﻿using Common.Domain;

namespace ClientNotification.Messages
{
    public class WelcomeKitProcessResponse
    {
        public OperationResult Result;
    }
}
