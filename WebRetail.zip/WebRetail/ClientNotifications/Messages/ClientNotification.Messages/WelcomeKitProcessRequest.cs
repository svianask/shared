﻿using System;

namespace ClientNotification.Messages
{
    public class WelcomeKitProcessRequest
    {
        public DateTime InitDate { get; set; }
        public DateTime EndDate { get; set; }
        public string UrlFirstPasswordSettingProcess { get; set; }
    }
}
