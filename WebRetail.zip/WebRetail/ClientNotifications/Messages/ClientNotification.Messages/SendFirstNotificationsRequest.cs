﻿using System;

namespace ClientNotification.Messages
{
    public class SendFirstNotificationsRequest
    {
        public string ClientIdentifier { get; set; }

        public string ContractId { get; set; }

        public string FirstPasswordSettingUrl { get; set; }
    }
}
