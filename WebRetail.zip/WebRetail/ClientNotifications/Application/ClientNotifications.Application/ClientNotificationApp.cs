﻿using ClientNotifications.Domain.ClientContractsAggregate;
using ClientNotifications.Domain.ClientInfoAggregate;
using ClientNotifications.Domain.ClientProfileAggregate;
using ClientNotifications.Domain.TemplateAggregate;
using ClientNotifications.Domain.UpdatedAndNewContractsAggregate;
using ClientNotifications.Domain.WKNotificationsAggregate;
using ClientNotificationsProxy;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace ClientNotifications.Application
{
    public class ClientNotificationApp : IClientNotificationApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientNotificationsPrxy _clientNotificationsPrxy;
        private readonly IRetailServiceProxy _retailServicePrxy;
        private readonly IRetailExtServicePrxy _retailExtServicePrxy;
        private readonly IParametersPrxy _parametersPrxy;
        private readonly IMxRetailAuthenticationProxy _mxRetailAuthenticationProxy;

        public ClientNotificationApp(
            ISeriLogHelper log, 
            IClientNotificationsPrxy notificationsPrxy, 
            IRetailServiceProxy retailServicePrxy, 
            IRetailExtServicePrxy retailExtServicePrxy, 
            IParametersPrxy parametersPrxy, 
            IMxRetailAuthenticationProxy mxRetailAuthenticationProxy)
        {
            _log = log;
            _clientNotificationsPrxy = notificationsPrxy;
            _retailServicePrxy = retailServicePrxy;
            _retailExtServicePrxy = retailExtServicePrxy;
            _parametersPrxy = parametersPrxy;
            _mxRetailAuthenticationProxy = mxRetailAuthenticationProxy;
        }

        private delegate void delSendNotification(string userName, string email, string phoneNumber, string otp);

        public void SendFirstNotification(string customerIdentifier, string contractId, string firstPasswordSettingUrl, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            if (string.IsNullOrEmpty(customerIdentifier)) { throw new ArgumentException("El identificador del cliente no puede ser nulo o estar vacío."); }

            List<string> toEmails;
            List<string> toCcEmails;
            string subject;
            Dictionary<string, string> templateData;
            List<AttachmentFile> attachments;
            string encodedTemplate;

            try
            {
                _log.Info("Obteniendo información del contrato.");
                ClientContracts contracts = _retailServicePrxy.GetContracts(customerIdentifier, out result);
                ContractInfo contract;

                if (string.IsNullOrEmpty(contractId))
                {
                    contract = contracts.Contracts.OrderBy(c => c.AfiliationDate).Last();
                }
                else
                {
                    contract = contracts.Contracts.First(c => c.Id == contractId);
                }
                _log.Debug("{cntx}", contract);

                var BasPlanIds = new List<short>
                {
                    contract.PlanBasId
                };

                string goalDescription = NormalizeGoalDescription(contract.GoalDescription);

                _log.Info("Obteniendo información de los planes: {cntx}", new { contract.Id, BasPlanIds });
                var plansInfo = _retailExtServicePrxy.GetPlansById(BasPlanIds, out result);
                _log.Debug("{cntx}", plansInfo);

                var Platform = contract.Platform;
                _log.Info("Estableciendo infomación del plan en el contrato {cntx}", contract.Id);
                contract.SetPlanInfo(plansInfo, Platform);

                _log.Info("Obteniendo información del cliente.");
                ClientInfo clientInfo = _retailServicePrxy.GetClientByContractId(contract.Id, out result);
                _log.Debug("{cntx}", clientInfo);

                _log.Info("Obteniendo los datos del contacto del contrato.");
                ContactData contactData = _retailServicePrxy.GetClientContactData(customerIdentifier, contract.Id, out result);
                _log.Debug("{cntx}", contactData);

                _log.Info("Obteniendo el portafolio del contrato.");
                ClientProfile clientProfile = _retailServicePrxy.GetClientProfile(contract.Id, contract.Platform, out result);
                _log.Debug("{cntx}", clientProfile);

                _log.Info("Obteniendo el número de referencia del contrato");
                string referenceNumber = _retailServicePrxy.GetReferenceNumber(contract.Id, contract.Platform, out result);
                _log.Debug("{cntx}", referenceNumber);

                _log.Info("Obteniendo la aportación y plazo de aportación del contrato.");
                ContractExtBasicInfo contractExtBasicInfo = _retailExtServicePrxy.GetContractExtBasicInfo(contract.Id, out result);
                _log.Debug("{cntx}", contractExtBasicInfo);

                _log.Info("Obteniendo el Identificador del template apropiado para el plan.");
                Template templateInfo = _retailServicePrxy.GetTemplateBody(contract.PlaId.ToString(), out result);
                _log.Debug("{cntx}", templateInfo);

                _log.Info("Obteniendo los datos del remitente.");
                PrxySenderData senderData = _parametersPrxy.GetSenderData(out result);
                _log.Debug("{cntx}", senderData);

                _log.Info("Obteniendo calidad de planes como internos o externos");
                List<string> internalPlans = _parametersPrxy.GetInternalPlans(out result);
                _log.Debug("{cntx}", internalPlans);

                _log.Info("Diagnosticando si el plan es interno.");
                string isInternFlag = internalPlans.IndexOf(contract.PlaId) >= 0 ? "interno": "externo";
                _log.Debug("{cntx}", isInternFlag);

                _log.Info("Obteniendo token para cambio de contraseña.");
                Dictionary<string, string> tokenData = BuildTokenData(customerIdentifier);
                string token = firstPasswordSettingUrl + _mxRetailAuthenticationProxy.GetEncryptedToken(tokenData, out result);
                _log.Debug("{cntx}", token);

                _log.Info("Armando notificación con data recopilada.");
                string nombreComercial = plansInfo.SingleOrDefault(pi => contract.Platform == pi.PlanClasification.Platform).ComercialInfo.ComercialName;
                toEmails = new List<string> { contactData.Email };              // el único destinatario es el cliente 
                //toEmails = new List<string> { "jherrerar@skandia.com.mx" };
                toCcEmails = null;                                              // lista nula, el envío es único para un sólo destinatario
                subject = String.Format($"Felicidades por adquirir {nombreComercial} en Skandia");
                templateData = BuildRequest(clientInfo, contract, clientProfile, referenceNumber, contractExtBasicInfo, goalDescription, isInternFlag, token);
                attachments = null;
                encodedTemplate = templateInfo.EncodedTemplate;
                _log.Debug("{cntx}", new {
                    subject,
                    senderData,
                    toEmails,
                    toCcEmails,
                    templateData,
                    encodedTemplate,
                    attachments
                });

                if (string.IsNullOrEmpty(encodedTemplate))
                {
                    throw new Exception($"No se ha encontrado plantilla para el plan {contract.PlaId} - {nombreComercial}.");
                }

                _log.Info("Enviando notificación");
                _clientNotificationsPrxy.SendNotification(subject, senderData, toEmails, toCcEmails, templateData, encodedTemplate, attachments, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al realizar el envío de la notificación: {cntx}", customerIdentifier);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error durante el envío de la notificación: " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
        }

        public void ProcessWelcomeKits(DateTime initDate, DateTime endDate, string firstPasswordSettingUrl, out OperationResult result)
        {
            DateTime initialDate = new DateTime(initDate.Year, initDate.Month, initDate.Day); 
            DateTime finalDate = new DateTime(endDate.Year, endDate.Month, endDate.Day);
            DateTime hoy = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            List<WKNotification> notifications = new List<WKNotification>();

            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo los contratos nuevos y actualizados para el periodo {cntx}", initialDate, finalDate);
                List<UpdatedAndNewContract> updatedAndNewContracts = _retailExtServicePrxy.GetUpdatedAndNewContracts(initialDate, finalDate.AddDays(1));
                _log.Debug("{cntx}", updatedAndNewContracts.Count);

                _log.Info("Filtrando duplicados");
                List<string> distinctContracts = (List<string>) updatedAndNewContracts.Select(u => u.ContractId).Distinct().ToList();
                _log.Debug("{ctnx}", distinctContracts.Count);

                _log.Info("Filtrando los que no hayan tenido WK anteriormente {cntx}", distinctContracts);
                List<string> filteredContracts = _retailExtServicePrxy.GetFilterContractsWithoutWK(distinctContracts);
                _log.Debug("{cntx}", filteredContracts.Count);

                _log.Info("Filtrando la lista de elementos completa, con userName.");
                List<UpdatedAndNewContract> filteredList = updatedAndNewContracts.Where(p => filteredContracts.Contains(p.ContractId)).ToList();
                _log.Debug("{ctnx}", filteredList.Count);

                _log.Info("Repasamos la lista notificaciones a enviar con los parámetros: {cntx}", filteredContracts.Count, firstPasswordSettingUrl);
                foreach (UpdatedAndNewContract contract in filteredList)
                {
                    WKNotification notification = new WKNotification(0, contract.UserName, contract.ContractId, contract.ContractCreateOrModify, new DateTime(1900,1,1), "", false);

                    notifications.Add(notification);
                }

                _log.Info("Insertamos la notificacion faltante. {cntx}", notifications);
                _retailExtServicePrxy.InsertNotification(notifications, out OperationResult insertionResult);
                _log.Debug("{cntx}", insertionResult);


                _log.Info("Obteniendo los registros de las notificaciones enviadas en el periodo {cntx}", initialDate, finalDate);
                List<WKNotification> wkNotificationsList = _retailExtServicePrxy.GetWKNotifications(initialDate, finalDate);
                _log.Debug("{cntx}", wkNotificationsList);

                _log.Info("Repasamos la lista notificaciones a enviar con los parámetros: {cntx}", filteredContracts.Count, firstPasswordSettingUrl);
                foreach (WKNotification notification in wkNotificationsList)
                {
                    _log.Info("Envío de la notificación. {cntx}", notification.UserName, notification.ContractId);

                    string templateId = GetTemplateId(notification.UserName, notification.ContractId, out result);
                    _log.Debug("{cntx}", notification.UserName, notification.ContractId, templateId);

                    // if no template is returned
                    if (string.IsNullOrEmpty(templateId)) continue;

                    bool applyNotificationSending = true;

                    // if template required is generic
                    if (templateId == "GENERICTPBY")
                    {
                        var prevGenericIncidences = _retailExtServicePrxy.GetWKGenericNotifications(notification.ContractId, notification.UserName);
                        
                        // then, we check if there is not a previous generic WK...
                        if (prevGenericIncidences.Count > 0)
                        {
                            applyNotificationSending = false;
                        }
                    }

                    if (applyNotificationSending)
                    {
                        SendFirstNotification(notification.UserName, notification.ContractId, firstPasswordSettingUrl, out result);
                        
                        if (result.Successful)
                        {
                            _log.Info("Actualizamos la notificación en la lista de notificaciones a enviar");
                            notification.MarkAsSent(templateId);

                            _log.Info("Actualizamos en base de datos el registro de la notificación. {cntx}", notification);
                            _retailExtServicePrxy.UpdateNotificationRecord(notification.NotificationWKId, templateId, out OperationResult updateResult);
                            _log.Debug("{cntx}", updateResult);

                            if (!updateResult.Successful)
                            {
                                _log.Error(new Exception(updateResult.SystemMessages.First().Message), "Error al realizar la actualización de la notificación para el contrato: {cntx}", notification.NotificationWKId);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al realizar el procesamiento de los welcome kits: {cntx}", initialDate, finalDate, firstPasswordSettingUrl);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error durante el envío de la notificación: " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
        }

        private string GetTemplateId(string customerIdentifier, string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            if (string.IsNullOrEmpty(customerIdentifier)) { throw new ArgumentException("El identificador del cliente no puede ser nulo o estar vacío."); }

            string usedTemplate = string.Empty;

            try
            {
                _log.Info("Obteniendo información del contrato.");
                ClientContracts contracts = _retailServicePrxy.GetContracts(customerIdentifier, out result);
                ContractInfo contract;

                contract = contracts.Contracts.First(c => c.Id == contractId);

                var basPlanIds = new List<short> { contract.PlanBasId };

                _log.Info("Obteniendo información de los planes: {cntx}", new { contract.Id, basPlanIds });
                var plansInfo = _retailExtServicePrxy.GetPlansById(basPlanIds, out result);
                _log.Debug("{cntx}", plansInfo);

                var Platform = contract.Platform;
                _log.Info("Estableciendo infomación del plan en el contrato {cntx}", contract.Id);
                contract.SetPlanInfo(plansInfo, Platform);

                _log.Info("Obteniendo el Identificador del template apropiado para el plan.");
                Template templateInfo = _retailServicePrxy.GetTemplateBody(contract.PlaId.ToString(), out result);
                usedTemplate = templateInfo.TemplateId;
                _log.Debug("{cntx}", usedTemplate);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar el template id: {cntx}", customerIdentifier, contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al consultar el template id: " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return usedTemplate;
        }

        private Dictionary<string, string> BuildRequest(
            ClientInfo clientInfo,
            ContractInfo contractInfo,
            ClientProfile clientProfile, 
            string referenceNumber, 
            ContractExtBasicInfo contractExtBasicInfo, 
            string savingTarget, 
            string isInternFlag, 
            string token)
        {
            return new Dictionary<string, string>
                {
                    { "Nombre", $"{clientInfo.Name} {clientInfo.LastNameOne} {clientInfo.LastNameTwo}"},
                    { "Contrato", contractInfo.Id },
                    { "TipoDeCliente", clientProfile.ClientType.Description },
                    { "ServicioDeInversion", clientProfile.ServiceType.Description },
                    { "NumeroDeReferencia", referenceNumber },
                    { "Aportacion", contractExtBasicInfo.CommittedAmount.ToString("N2") },
                    { "PeriodoAportacion", (contractExtBasicInfo.SavingTerm / 12).ToString("N2") + " años." },
                    { "MetaDeAhorro", savingTarget },
                    { "EsPlanInterno", isInternFlag },
                    { "LigaPrimerPassword", token }
                };
        }

        private string NormalizeGoalDescription(string originalString)
        {
            Dictionary<string, string> savingTargetExceptions = new Dictionary<string, string>
            {
                { "negocio", "negocios" },
                { "viaje", "suenos" }
            };

            byte[] tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(originalString);
            string result = System.Text.Encoding.UTF8.GetString(tempBytes).ToLower();

            if (savingTargetExceptions.ContainsKey(result))
            {
                result = savingTargetExceptions[result];
            }

            return result;
        }

        public Dictionary<string, string> BuildTokenData(string userName)
        {
            Dictionary<string, string> result = null;
            string stringPortalId = ConfigurationManager.AppSettings["Solvency:PortalId"];

            if (!string.IsNullOrEmpty(stringPortalId))
            {
                result = new Dictionary<string, string>
                {
                    { "InitialDate", DateTime
                                        .Now
                                        .ToUniversalTime()
                                        .ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'") },  // la fecha del momento
                    { "Lifetime", "-1" },                                                       // -1 porque no tiene fecha d<e caducidad
                    { "Portal", stringPortalId },                                               // obtenemos de la configuración el portalId
                    { "Profile", "-1" },                                                        // en este caso el perfil del usuario no es necesario identificarlo
                    { "UserName", userName }                                                    // el userName, llega desde el llamado de 
                };
            }

            return result;
        }
    }
}
