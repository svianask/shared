﻿using Common.Domain;
using System;

namespace ClientNotifications.Application
{
    public interface IClientNotificationApp
    {
        void SendFirstNotification(string customerIdentifier, string contractId, string firstPasswordSettingUrl, out OperationResult result);

        void ProcessWelcomeKits(DateTime initDate, DateTime endDate, string urlFirstPasswordSettingProcess, out OperationResult result);
    }
}
