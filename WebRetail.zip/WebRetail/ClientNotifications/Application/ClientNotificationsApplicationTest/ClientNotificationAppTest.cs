﻿using ClientNotifications.Application;
using ClientNotifications.Domain.ClientContractsAggregate;
using ClientNotifications.Domain.ClientInfoAggregate;
using ClientNotifications.Domain.ClientProfileAggregate;
using ClientNotifications.Domain.PlanAggregate;
using ClientNotifications.Domain.TemplateAggregate;
using ClientNotifications.Domain.UpdatedAndNewContractsAggregate;
using ClientNotificationsApplicationTest.Extensions;
using ClientNotificationsProxy;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Proxy;
using SeriLogH;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace ClientNotificationsApplicationTest
{
    [TestClass]
    public class ClientNotificationAppTest
    {
        private readonly ISeriLogHelper _seriloHelper;
        private readonly Mock<IRetailServiceProxy> _retailServiceProxy;
        private readonly Mock<IRetailExtServicePrxy> _retailExtServicePrxy;
        private readonly IClientNotificationsPrxy _notificationsProxy;
        private readonly Mock<IParametersPrxy> _parametersPrxy;
        private readonly ClientNotificationApp _clientNotification;
        private readonly ProxyEngine _proxyEngine;
        private readonly Mock<IMxRetailAuthenticationProxy> _mxRetailAuthenticationProxy;

        private string _firstPasswordSettingUrl;
        private string _clientIdentifier;
        private string _contractId;
        private short _planBasId;
        private string _planId;
        private int _platform;

        private DateTime _initDate, _endDate;

        public ClientNotificationAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = "C:\\Files\\TestWebRetail-.txt";

            // inicialización de mocks
            _seriloHelper = new SeriLogHelper();
            //_seriloHelper = new Mock<ISeriLogHelper>().Object; //Uncomment for execution without the log file otherwise log file is update
            _proxyEngine = new ProxyEngine();
            _notificationsProxy = new ClientNotificationsPrxy(_seriloHelper, _proxyEngine);
            _retailServiceProxy = new Mock<IRetailServiceProxy>();
            _retailExtServicePrxy = new Mock<IRetailExtServicePrxy>();
            _parametersPrxy = new Mock<IParametersPrxy>();
            _mxRetailAuthenticationProxy = new Mock<IMxRetailAuthenticationProxy>();

            // inicialización de módulo a testear
            _clientNotification = new ClientNotificationApp(
                _seriloHelper, 
                _notificationsProxy, 
                _retailServiceProxy.Object, 
                _retailExtServicePrxy.Object, 
                _parametersPrxy.Object, 
                _mxRetailAuthenticationProxy.Object);
        }

        [TestMethod, TestCategory("SendNotificationSuccessful")]
        public void SendNotificationSuccessful()
        {
            OperationResult result = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out result);

            Assert.IsTrue(result.Successful);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationContractsFail()
        {
            OperationResult _ = new OperationResult();

            //_ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationPlansFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            //_ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationClientInfoFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            //_ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationContactDataFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            //_ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationClientProfileFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            //_ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationContractBasicInfoFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            //_ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationTemplateFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            //_ = GetTemplate();
            _ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationSenderDataFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            //_ = GetSenderData();
            _ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendNotificationInternalPlansFail()
        {
            OperationResult _ = new OperationResult();

            _ = GetContracts();
            _ = GetPlans();
            _ = GetClientInfo();
            _ = GetClientContactData();
            _ = GetClientProfile();
            _ = GetReferenceNumber();
            _ = GetContractExtBasicInfo();
            _ = GetTemplate();
            _ = GetSenderData();
            //_ = GetInernalPlans();

            SendNotifications(out _);

            Assert.IsFalse(_.Successful);
            Assert.IsNotNull(_.SystemMessages);
            Assert.IsTrue(_.SystemMessages.Count > 0);
            Assert.IsNotNull(_.SystemMessages[0].MessageType == SystemMessageTypes.Error);
        }

        private void SendNotifications(out OperationResult result)
        {
            _clientNotification.SendFirstNotification(_clientIdentifier, "", _firstPasswordSettingUrl, out result);
        }

        [TestMethod, TestCategory("ProcessNewContractsSuccessful")]
        public void ProcessWelcomeKitsSuccessful()
        {
            OperationResult _ = new OperationResult();

            _clientNotification.ProcessWelcomeKits(_initDate, _endDate, _firstPasswordSettingUrl, out _);

            Assert.IsTrue(_.Successful);
        }

        #region Generación de mocks

        private OperationResult GetContracts()
        {
            OperationResult result = new OperationResult();
            ClientContracts contracts = ClientContracts.Create(_clientIdentifier);

            _retailServiceProxy
                    .Setup(s => s.GetContracts(_clientIdentifier, out result))
                    .Returns(contracts.AddContract(
                        ContractInfo
                            .Create(_contractId, _planBasId, _platform, 15, _contractId)
                            .SetGoalDescription("Negocio")
                    ));

            return result;
        }

        private OperationResult GetPlans()
        {
            OperationResult result = new OperationResult();
            List<short> BasPlanIds = new List<short> { _planBasId };

            // recuperación de informacióon de planes
            _retailExtServicePrxy
                .Setup(s => s.GetPlansById(BasPlanIds, out result))
                .Returns(new List<Plan> {
                    Plan
                        .Create(_planId, "Skandia Crea", "Skandia Crea", _planBasId.ToString())
                        .SetPlanClasification(_platform, 10)
                        .SetComercialInfo(535, "Skandia Crea")
                });

            return result;
        }

        private OperationResult GetClientInfo()
        {
            OperationResult result = new OperationResult();

            _retailServiceProxy
                .Setup(s => s.GetClientByContractId(_contractId, out result))
                .Returns(ClientInfo.Create(_contractId, "John Doe", "John", "Doe"));

            return result;
        }

        private OperationResult GetClientContactData()
        {
            OperationResult result = new OperationResult();

            _retailServiceProxy
                    .Setup(s => s.GetClientContactData(_clientIdentifier, _contractId, out result))
                    .Returns(new ContactData { Email = "jherrerar@skandia.com", CellPhone = "5534932219", Phone = "5534932219" });

            return result;
        }

        private OperationResult GetClientProfile()
        {
            OperationResult result = new OperationResult();

            ClientProfile clientProfile = new ClientProfile(_contractId)
                .SetClientType("3", "Cliente normal")
                .SetProductTypeId("10")
                .SetPortfolioType("10", "General portfolio")
                .SetSalesPracticeProfile("8213", "Profile description", "10", "General portfolio")
                .SetServiceType("90", "General service");

            _retailServiceProxy
                .Setup(s => s.GetClientProfile(_contractId, _platform, out result))
                .Returns(clientProfile);

            return result;
        }

        private OperationResult GetReferenceNumber()
        {
            OperationResult result = new OperationResult();

            _retailServiceProxy
                .Setup(s => s.GetReferenceNumber(_contractId, _platform, out result))
                .Returns("GenericReferenceNumber");

            return result;
        }

        private OperationResult GetContractExtBasicInfo()
        {
            OperationResult result = new OperationResult();

            _retailExtServicePrxy
                .Setup(s => s.GetContractExtBasicInfo(_contractId, out result))
                .Returns(ContractExtBasicInfo.Create(1000000, 72, 7000));

            return result;
        }

        private OperationResult GetTemplate()
        {
            OperationResult result = new OperationResult();

            _retailServiceProxy
                .Setup(s => s.GetTemplateBody(_planId, out result))
                .Returns(new Template("GENERICTPBY", Base64Encode("<html><head></head><body>generic template</body></html>")));

            return result;
        }

        private OperationResult GetSenderData()
        {
            OperationResult result = new OperationResult();

            _parametersPrxy
                .Setup(s => s.GetSenderData(out result))
                .Returns(new PrxySenderData { Name = "John Sender Doe", Email = "jherrerar@skandia.com.mx" });

            return result;
        }

        private OperationResult GetInernalPlans()
        {
            OperationResult result = new OperationResult();

            // lo hacemos un plan interno
            _parametersPrxy
                .Setup(s => s.GetInternalPlans(out result))
                .Returns(new List<string> { _planId.ToString() });

            return result;
        }

        #endregion

        [TestInitialize]
        public void Initialize()
        {
            _clientIdentifier = "CASC690117F17";
            _planBasId = 480;
            _contractId = "567953";
            _planId = "530";
            _platform = 10;

            _initDate = DateTime.Now.Date.AddMonths(-3);
            _endDate = DateTime.Now.Date;
            _firstPasswordSettingUrl = "https://localhost:8000/web/retail/setPassword?token=";

            var dummyResult = new List<UpdatedAndNewContract> { 
                    new UpdatedAndNewContract("680750", "HERA770801QJ2", "Juan Perez", _initDate),
                    new UpdatedAndNewContract("680751", "HERA561211QB1", "Johnn Doe", _endDate)
            };

            _retailExtServicePrxy
                .Setup(c => c.GetUpdatedAndNewContracts(It.IsAny<DateTime>(), It.IsAny<DateTime>()))
                .Returns(dummyResult);
        }

        #region helpers

        private string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        #endregion
    }
}
