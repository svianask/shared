﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientNotifications.Domain.ClientProfileAggregate
{
    public class PortfolioType
    {
        private readonly string _identifier;
        private readonly string _description;

        internal PortfolioType(string identifier, string description)
        {
            _identifier = identifier;

            description = description.Trim().ToLower();
            description = description.Substring(0, 1).ToUpper() + description.Substring(1);
            _description = description;
        }

        public string Identifier => _identifier;

        public string Description => _description;
    }
}
