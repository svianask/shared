﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientNotifications.Domain.ClientProfileAggregate
{
    public class SalesPracticeProfile : ValueObject<SalesPracticeProfile>
    {
        private Client _client;
        private Portfolio _portfolio;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cliProfId">client profile id of sales prectice</param>
        /// <param name="cliProfDesc">client profile description of sales prectice</param>
        /// <param name="portfProfId">portfolio profile id of sales prectice</param>
        /// <param name="portfProfDesc">portfolio profile description of sales prectice</param>
        internal SalesPracticeProfile(string cliProfId, string cliProfDesc, string portfProfId, string portfProfDesc)
        {
            SetClientProfile(cliProfId, cliProfDesc);
            SetPortfolioProfile(portfProfId, portfProfDesc);
        }

        public Client Client => _client;

        public Portfolio Portfolio => _portfolio;

        protected SalesPracticeProfile SetClientProfile(string identifier, string description)
        {
            this._client = Client.Create(identifier, description);
            return this;
        }

        protected SalesPracticeProfile SetPortfolioProfile(string identifier, string description)
        {
            this._portfolio = Portfolio.Create(identifier, description);
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                this.Client,
                this.Portfolio
            };
        }
    }

    public class Client : ValueObject<Client>
    {
        private readonly string _identifier;
        private readonly string _description;

        private Client(string identifier, string description)
        {
            _identifier = identifier;

            description = description.Trim().ToLower();
            description = description.Substring(0, 1).ToUpper() + description.Substring(1);
            _description = description;
        }

        public string Identifier => _identifier;

        public string Description => _description;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Identifier,
                Description
            };
        }

        public static Client Create(string identifier, string description)
        {
            return new Client(identifier, description);
        }
    }

    public class Portfolio : ValueObject<Portfolio>
    {
        private readonly string _identifier;
        private readonly string _description;

        private Portfolio(string identifier, string description)
        {
            _identifier = identifier;

            description = description.Trim().ToLower();
            description = description.Substring(0, 1).ToUpper() + description.Substring(1);
            _description = description;
        }

        public string Identifier => _identifier;

        public string Description => _description;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Identifier,
                Description
            };
        }

        public static Portfolio Create(string identifier, string description)
        {
            return new Portfolio(identifier, description);
        }
    }
}
