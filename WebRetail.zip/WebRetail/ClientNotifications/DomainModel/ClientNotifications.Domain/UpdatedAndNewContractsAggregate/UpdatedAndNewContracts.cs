﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientNotifications.Domain.UpdatedAndNewContractsAggregate
{
    public class UpdatedAndNewContract : ValueObject<UpdatedAndNewContract>
    {
        private readonly string _contractId;
        private readonly string _clientRFC;
        private readonly string _userName;
        private readonly DateTime _contractCreateOrModify;

        public UpdatedAndNewContract(string contractId, string clientRFC, string userName, DateTime contractCreateOrModify)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El argumento contractId no puede ser nulo o vacío"); }
            if (string.IsNullOrEmpty(clientRFC)) { throw new ArgumentException("El argumento clientRFC no puede ser nulo o vacío"); }
            if (string.IsNullOrEmpty(userName)) { throw new ArgumentException("El argumento userName no puede ser nulo o vacío"); }

            _contractId = contractId;
            _clientRFC = clientRFC;
            _userName = userName;
            _contractCreateOrModify = contractCreateOrModify;
        }
        public string ClientRFC => _clientRFC;
        public string ContractId => _contractId;
        public string UserName => _userName;
        public DateTime ContractCreateOrModify => _contractCreateOrModify;


        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}