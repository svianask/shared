﻿using Ddd;
using System.Collections.Generic;

namespace ClientNotifications.Domain.ClientContractsAggregate
{
    public class ContactData 
    {
        public string CellPhone { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
    }
}
