﻿using ClientNotifications.Domain.PlanAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClientNotifications.Domain.ClientContractsAggregate
{
    public class ContractInfo: Entity<string>
    {
        private readonly short _planBasId;
        private readonly int _platform;
        private readonly short _goalId;
        private string _goalImage;
        private int _contractType;
        private string _comercialName;
        private string _plaId;
        private string _groupingContractId;
        private string _goalDescription;
        private DateTime _afiliationDate;

        private ContractInfo(string contractId, short planBasId, int platform, short goalId, string groupingContractId)
        {
            Id = contractId;
            _planBasId = planBasId;
            _platform = platform;
            _goalId = goalId;
            _groupingContractId = groupingContractId;
        }

        public short PlanBasId => _planBasId;
        public int Platform => _platform;
        public short GoalId => _goalId;
        public int ContractType => _contractType;
        public string ComercialName => _comercialName;
        public string GoalImage => _goalImage;
        public string GoalDescription => _goalDescription;
        public string PlaId => _plaId;
        public string GroupingContractId => _groupingContractId;
        public DateTime AfiliationDate => _afiliationDate;

        public static ContractInfo Create(string contractId, short planBasId, int platform, short goalId, string groupingContractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(groupingContractId)) { throw new ArgumentException("groupingContractId no puede ser nulo ni vacío"); }
            if (planBasId < 0) { throw new ArgumentException("El valor de planId no es válido"); }
            if (platform != 5 && platform != 10) { throw new ArgumentException("El tipo de producto es inválido"); }
            if (goalId < 0) { throw new ArgumentException("el id de la meta es inválido"); }

            return new ContractInfo(contractId, planBasId, platform, goalId, groupingContractId);
        }

        private void SetContractType(int contractType)
        {
            _contractType = contractType;
        }

        public Plan SetPlanInfo(List<Plan> plansInfo, int platform)
        {
            var planInfo = plansInfo.Single(x => x.PlanClasification.Platform == Platform);

            _plaId = planInfo.Id;
            _comercialName = planInfo.ComercialInfo.ComercialName;
            var productType = planInfo.PlanClasification.ProductType;

            SetContractType(productType);
            return planInfo;
        }

        public ContractInfo SetGoalDescription(string goalDescription)
        {
            _goalDescription = goalDescription;
            return this;
        }

        public ContractInfo SetContractDate(DateTime contractDate)
        {
            this._afiliationDate = contractDate;

            return this;
        }
    }
}
