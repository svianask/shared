﻿namespace ClientNotifications.Domain
{
    public class Ennumerators
    {
        public enum ParametersType : int
        {
            /// <summary>
            /// Parámetro que guarda la data del remitente 
            /// </summary>
            FNSENDERDAT

            /// <summary>
            /// Lista de planes internos
            /// </summary>
            , FNINTERPLAN
        }
               
    }
}
