﻿using Ddd;
using System;

namespace ClientNotifications.Domain.ClientInfoAggregate
{
    public class ClientInfo : Entity<string>
    {

        private string _name;
        private string _lastNameOne;
        private string _lastNameTwo;
        private int _personTypeId;

        public ClientInfo(string contractId, string name, string lastNameOne, string lastNameTwo)
        {
            Id = contractId;
            _name = name;
            _lastNameOne = lastNameOne;
            _lastNameTwo = lastNameTwo;
        }

        public string Name => _name;
        public string LastNameOne => _lastNameOne;
        public string LastNameTwo => _lastNameTwo;
        public int PersonTypeId => _personTypeId;

        public static ClientInfo Create(string contractId, string name, string lastNameOne, string lastNameTwo)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío."); }
            if (string.IsNullOrEmpty(name)) { throw new ArgumentException("El nombre no puede ser nulo ni vacío."); }
            if (string.IsNullOrEmpty(lastNameOne)) { throw new ArgumentException("El apellido paterno no puede ser nulo ni vacío."); }
            if (string.IsNullOrEmpty(lastNameTwo)) { throw new ArgumentException("El apellido materno no puede ser nulo ni vacío."); }

            return new ClientInfo(contractId, name, lastNameOne, lastNameTwo);
        }

        public ClientInfo SetPersonalityFiscal(int personTypeId)
        {
            if (personTypeId < 1) { throw new ArgumentException("El id del tipo de persona debe ser mayor a 0."); }

            _personTypeId = personTypeId;

            return this;
        }
    }
}
