﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientNotifications.Domain.WKNotificationsAggregate
{
    public class WKNotification : ValueObject<WKNotification>
    {
        private readonly int _notificationWKId;
        private readonly string _userName;
        private readonly string _contractId;
        private readonly DateTime _fechaAlta;
        private readonly DateTime _fechaEnvio;
        private string _plantillaUtilizada;
        private bool _notificacionEnviada;

        public int NotificationWKId => _notificationWKId;
        public string UserName => _userName;
        public string ContractId => _contractId;
        public DateTime FechaAlta => _fechaAlta;
        public DateTime FechaEnvio => _fechaEnvio;
        public string PlantillaUtilizada => _plantillaUtilizada;
        public bool NotificacionEnviada => _notificacionEnviada;

        public WKNotification(int notificationWKId, string userName, string contractId, DateTime fechaAlta, DateTime fechaEnvio, string plantillaUtilizada, bool notificacionEnviada)
        {
            if (string.IsNullOrEmpty(userName)) { throw new ArgumentException("El argumento userName no puede ser nulo o vacío"); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El argumento contractId no puede ser nulo o vacío"); }

            _notificationWKId = notificationWKId;
            _userName = userName;
            _contractId = contractId;
            _plantillaUtilizada = plantillaUtilizada;
            _fechaAlta = fechaAlta;
            _fechaEnvio = fechaEnvio;
            _notificacionEnviada = notificacionEnviada;
        }

        public void MarkAsSent(string plantillaUtilizada)
        {
            this._notificacionEnviada = true;
            this._plantillaUtilizada = plantillaUtilizada;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}