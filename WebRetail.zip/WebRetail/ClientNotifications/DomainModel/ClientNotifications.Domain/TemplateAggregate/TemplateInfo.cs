﻿using Ddd;
using System.Collections.Generic;

namespace ClientNotifications.Domain.TemplateAggregate
{
    public class Template : ValueObject<Template>
    {
        private readonly string _templateId;
        private readonly string _encodedTemplate;

        public Template(string templateId, string template)
        {
            _templateId = templateId;
            _encodedTemplate = template;
        }

        public string TemplateId => _templateId;

        public string EncodedTemplate => _encodedTemplate;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                TemplateId,
                EncodedTemplate
            };
        }
    }
}
