﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientNotifications.Domain.PlanAggregate
{
    public class ComercialInfo : ValueObject<ComercialInfo>
    {
        private readonly short _comercialPlanId;
        private readonly string _comercialName;

        private ComercialInfo(short comercialPlanId, string comercialName)
        {
            _comercialPlanId = comercialPlanId;
            _comercialName = comercialName;
        }

        public short ComercialPlanId => _comercialPlanId;

        public string ComercialName => _comercialName;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ComercialPlanId,
                ComercialName
            };
        }

        internal static ComercialInfo Create(short comercialPlanId, string comercialName)
        {
            if (string.IsNullOrEmpty(comercialName)) { throw new ArgumentException(nameof(comercialName) + " no puede ser nulo ni vacío"); }
            if (comercialPlanId <= 0) { throw new ArgumentException(nameof(comercialPlanId) + " no es válido"); }

            return new ComercialInfo(comercialPlanId, comercialName);
        }
    }
}
