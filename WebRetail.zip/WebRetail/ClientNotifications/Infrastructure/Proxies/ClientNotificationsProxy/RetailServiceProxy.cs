﻿using ClientNotifications.Domain.ClientContractsAggregate;
using ClientNotifications.Domain.ClientInfoAggregate;
using ClientNotifications.Domain.ClientProfileAggregate;
using ClientNotifications.Domain.TemplateAggregate;
using ClientNotificationsProxy.RetailServiceMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Configuration;

namespace ClientNotificationsProxy
{
    public class RetailServiceProxy : IRetailServiceProxy
    {
        private readonly IProxyEngine _proxyEngine;

        public RetailServiceProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ClientContracts GetContracts(string clientIdentifier, out OperationResult result)
        {
            PrxyContractsRequest request = new PrxyContractsRequest();
            PrxyContractsResponse response = new PrxyContractsResponse();
            ClientContracts contractsOfClient = ClientContracts.Create(clientIdentifier);
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContracts";

            request.ClientIdentifier = clientIdentifier;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractsOfClient = ContractsOfClientMapp.Mapp(response, contractsOfClient);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractsOfClient;
        }

        public ClientInfo GetClientByContractId(string contractId, out OperationResult result)
        {
            PrxyClientByContractIdRequest request = new PrxyClientByContractIdRequest();
            PrxyClientByContractIdResponse response = new PrxyClientByContractIdResponse();
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/GetClientByContractId";
            request.contractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            ClientInfo clientInfo;

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientByContractIdResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                clientInfo = ClientInformationMapp.Mapp(response);

            }
            else
            {
                result.Successful = false;

                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientInfo;
        }

        public ClientProfile GetClientProfile(string contractId, int platform, out OperationResult result)
        {
            PrxyClientProfileRequest request = new PrxyClientProfileRequest();
            PrxyClientProfileResponse response = new PrxyClientProfileResponse();
            ClientProfile clientProfile;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetClientProfile";
            request.ContractId = contractId;
            request.Platform = platform;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientProfileResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                clientProfile = ContractProfileMapp.ClientContractMapp(contractId, response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientProfile;
        }

        public string GetReferenceNumber(string contractId, int platform, out OperationResult result)
        {
            PrxyReferenceNumberRequest request = new PrxyReferenceNumberRequest();
            PrxyReferenceNumberResponse response = new PrxyReferenceNumberResponse();
            string referenceNumber = string.Empty;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetReferenceNumber";
            request.ContractId = contractId;
            request.Platform = platform;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyReferenceNumberResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                referenceNumber = response.ReferenceNumber;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return referenceNumber;
        }

        public ContactData GetClientContactData(string clientIdentifier, string contractId, out OperationResult result)
        {
            PrxyClientContactDataRequest request = new PrxyClientContactDataRequest();
            PrxyClientContactDataResponse response = new PrxyClientContactDataResponse();
            ContactData contactData;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractsClient";

            request.ClientIdentifier = clientIdentifier;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientContactDataResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contactData = ContactDataMapp.Mapp(response, contractId);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contactData;
        }

        public Template GetTemplateBody(string planId, out OperationResult result)
        {
            PrxyFirstNotificationTemplateRequest request = new PrxyFirstNotificationTemplateRequest();
            PrxyFirstNotificationTemplateResponse response;
            Template templateInfo;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Notifications/GetFirstNotificationTemplate";

            request.PlanId = planId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyFirstNotificationTemplateResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                templateInfo = new Template(response.TemplateId, response.Template);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return templateInfo;
        }

        public ContractInfo GetContractInfo(string contractId, out OperationResult result)
        {
            PrxyContractInfoRequest request = new PrxyContractInfoRequest();
            PrxyContractInfoResponse response = new PrxyContractInfoResponse();
            ContractInfo contractDetail = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";
            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractInfoResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                contractDetail = ContractInfoMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractDetail;
        }

        public void UpdateClientContactData(string clientId, string email, string phone, out OperationResult result)
        {
            PrxyUpdateContactInformationRequest request = new PrxyUpdateContactInformationRequest();
            PrxyUpdateContactInformationResponse response = new PrxyUpdateContactInformationResponse();

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/UpdateContactInformation";
            request.ClientIdentifier = clientId;
            request.Email = email;
            request.Phone = phone;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyUpdateContactInformationResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
       }
    }
}
