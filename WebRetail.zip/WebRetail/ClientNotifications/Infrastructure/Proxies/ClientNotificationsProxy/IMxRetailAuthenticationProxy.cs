﻿using Common.Domain;
using System.Collections.Generic;

namespace ClientNotificationsProxy
{
    public interface IMxRetailAuthenticationProxy
    {
        string GetEncryptedToken(Dictionary<string, string> parameters, out OperationResult result);
    }
}
