﻿using ClientNotifications.Domain.UpdatedAndNewContractsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientNotificationsProxy
{
    #region Contract extended basic info

    public class PrxyContractExtBasicInfoResponse
    {
        public PrxyContractExtBasicInfo ContractExtBasicInfo;
        public OperationResult Result;
    }

    public class PrxyContractExtBasicInfoRequest
    {
        public string ContractId;
    }

    public class PrxyContractExtBasicInfo
    {
        public decimal SavingGoal;
        public int SavingTerm;
        public decimal CommittedAmount;
        public DateTime AfiliationDate;
        public DateTime EfectiveEndDate;
    }

    #endregion

    #region Welcome Kit 

    #region Query 

    public class Updated_NewContractsRequestPrxy
    {
        public DateTime InitDate;
        public DateTime EndDate;
    }

    public class Updated_NewContractsResponsePrxy
    {
        public List<UpdatedAndNewContractPrxy> UpdatedAndNewContracts;

        public OperationResult Result;
    }

    public class UpdatedAndNewContractPrxy
    {
        public string ContractId;
        public string ClientRFC;
        public string UserName;
        public DateTime ContractCreateOrModify;
    }

    #endregion

    #region Welcome Kit Notifications

    public class WKGenericNotificationsRequestPrxy
    {
        public string ContractId;
        public string UserName;
    }

    public class WKGenericNotificationsResponsePrxy
    {
        public List<WKNotificationPrxy> NotificationsList;

        public OperationResult Result;
    }

    public class WKNotificationsRequestPrxy
    {
        public DateTime InitDate;
        public DateTime EndDate;
    }

    public class WKNotificationsResponsePrxy
    {
        public List<WKNotificationPrxy> NotificationsList;

        public OperationResult Result;
    }

    public class WKNotificationPrxy
    {
        public int NotificationWKId { get; set; }
        public string UserName { get; set; }
        public string ContractId { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime FechaEnvio { get; set; }
        public String PlantillaUtilizada { get; set; }
        public bool NotificacionEnviada { get; set; }
    }

    #endregion

    #region Update record

    public class UpdateNotificationRequestPrxy
    {
        public int NotificacionWkId { get; set; }
        public string UsedTemplate { get; set; }
    }

    public class UpdateNotificationResponsePrxy
    {
        public OperationResult Result;
    }

    #endregion

    #region Insert notification

    public class InsertNotificationRequestPrxy
    {
        public InsertNotificationRequestPrxy()
        {
            Notification = new List<WKNotificationPrxy>();
        }

        public List<WKNotificationPrxy> Notification { get; set; }
    }

    public class InsertNotificationResponsePrxy
    {
        public int NotificationId { get; set; }
        public OperationResult Result { get; set; }
    }

    #endregion

    #region Filtered contracts

    public class FilterContractsWithoutWKRequestPrxy
    {
        public List<string> Contracts { get; set; }
    }

    public class FilterContractsWithoutWKResponsePrxy
    {
        public List<string> FilteredContracts { get; set; }
    
        public OperationResult Result { get; set; }
    }

    #endregion

    #endregion

    #region Plans

    public class PrxyPlansRequest
    {
        public List<short> PlanIds;
    }

    public class PrxyPlansResponse
    {
        public List<PrxyPlan> Plans;
        public OperationResult Result;
    }

    public class PrxyPlan
    {
        public string Id;
        public string Name;
        public string ShortName;
        public string BasPlanId;
        public PrxyPlanClasification PlanClasification;
        public PrxyComercialInfo ComercialInfo;
    }

    public class PrxyComercialInfo
    {
        public short ComercialPlanId;
        public string ComercialName;
    }

    public class PrxyPlanClasification
    {
        public int Platform;
        public int ProductType;
    }

    #endregion
}
