﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;

namespace ClientNotificationsProxy
{
    public class MxRetailAuthenticationProxy : IMxRetailAuthenticationProxy
    {
        private readonly IProxyEngine _proxyEngine;

        public MxRetailAuthenticationProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public string GetEncryptedToken(Dictionary<string, string> parameters, out OperationResult result)
        {
            GetEncryptedTokenRequest request = new GetEncryptedTokenRequest();
            GetEncryptedTokenResponse response = new GetEncryptedTokenResponse();
            string encryptedToken;
            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "PasswordSetting/BuildToken";

            result = new OperationResult();
            request.Parameters = parameters;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetEncryptedTokenResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0].Message); }

                encryptedToken = HttpUtility.UrlEncode(response.Token);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return encryptedToken;
        }
    }
}
