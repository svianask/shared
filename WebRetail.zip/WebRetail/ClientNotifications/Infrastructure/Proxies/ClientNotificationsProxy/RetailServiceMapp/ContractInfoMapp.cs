﻿using ClientNotifications.Domain.ClientContractsAggregate;

namespace ClientNotificationsProxy.RetailServiceMapp
{
    public class ContractInfoMapp
    {
        public static ContractInfo Mapp(PrxyContractInfoResponse prxyResponse)
        {
            string contractId = prxyResponse.ContractInfo.Id;
            short planBasId = prxyResponse.ContractInfo.PlanBasId;
            int platform = prxyResponse.ContractInfo.Platform;
            short goalId = prxyResponse.ContractInfo.GoalId;
            string groupingContractId = prxyResponse.ContractInfo.ContratoAgrupa;
            string goalDescription = prxyResponse.ContractInfo.GoalDescription;

            return ContractInfo
                .Create(contractId, planBasId, platform, goalId, groupingContractId)
                .SetGoalDescription(goalDescription);
        }
    }
}
