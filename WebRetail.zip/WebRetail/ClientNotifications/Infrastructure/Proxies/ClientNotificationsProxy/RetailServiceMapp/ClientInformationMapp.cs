﻿using ClientNotifications.Domain.ClientInfoAggregate;

namespace ClientNotificationsProxy.RetailServiceMapp
{
    public class ClientInformationMapp
    {
        internal static ClientInfo Mapp(PrxyClientByContractIdResponse response)
        {
            ClientInfo clientInfo = ClientInfo
                .Create(response.ClientInfo.Id, response.ClientInfo.Name, response.ClientInfo.LastNameOne, response.ClientInfo.LastNameTwo)
                .SetPersonalityFiscal(response.ClientInfo.PersonTypeId);
        
            return clientInfo;
        }
    }
}
