﻿using ClientNotifications.Domain.ClientContractsAggregate;

namespace ClientNotificationsProxy.RetailServiceMapp
{
    public class ContractsOfClientMapp
    {
        public static ClientContracts Mapp(PrxyContractsResponse contracts, ClientContracts contractsOfClient)
        {
            contracts
                .ContractsOfClient
                .Contracts
                .ForEach(x =>
                    contractsOfClient.AddContract(
                        ContractInfo
                            .Create(x.Id, x.PlanBasId, x.Platform, x.GoalId, x.ContratoAgrupa)
                            .SetGoalDescription(x.GoalDescription)
                            .SetContractDate(x.AfiliationDate)
                        )
                );

            return contractsOfClient;
        }
    }
}
