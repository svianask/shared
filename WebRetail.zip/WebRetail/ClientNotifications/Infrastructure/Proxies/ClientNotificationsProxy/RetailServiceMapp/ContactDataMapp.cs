﻿using ClientNotifications.Domain.ClientContractsAggregate;

namespace ClientNotificationsProxy.RetailServiceMapp
{
    public class ContactDataMapp
    {
        public static ContactData Mapp(PrxyClientContactDataResponse contracts, string contractId)
        {
            ContactData response = null;

            foreach (var contract in contracts.ContractsOfClient.Contracts)
            {
                if (contract.Id.Equals(contractId))
                {
                    response = new ContactData
                    {
                        Phone = contract.ContactData.Phone,
                        CellPhone = contract.ContactData.CellPhone,
                        Email = contract.ContactData.Email
                    };

                    break;
                }
            }

            return response;
        }
    }
}
