﻿using ClientNotifications.Domain.PlanAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientNotificationsProxy.RetailServiceMapp
{
    public class PlansMapp
    {
        public static List<Plan> Mapp(PrxyPlansResponse prxPlansResponse)
        {
            List<Plan> Plans = new List<Plan>();
            prxPlansResponse.Plans.ForEach(p =>
                Plans.Add(
                    Plan
                        .Create(p.Id, p.Name, p.ShortName, p.BasPlanId)
                        .SetComercialInfo(p.ComercialInfo.ComercialPlanId, p.ComercialInfo.ComercialName)
                        .SetPlanClasification(p.PlanClasification.Platform, p.PlanClasification.ProductType)
                )
            );
            return Plans;
        }
    }
}
