﻿using ClientNotifications.Domain.UpdatedAndNewContractsAggregate;
using ClientNotificationsProxy;
using System.Collections.Generic;

namespace ManagementOidcRetail.Proxy.Mapping
{
    public class UpdatedAndNexContractsMapping
    {
        public static List<UpdatedAndNewContract> Mapping(List<UpdatedAndNewContractPrxy> updatedAndNewContractsPrxy)
        {
            List<UpdatedAndNewContract> updatedAndNewContracts = new List<UpdatedAndNewContract>();

            updatedAndNewContractsPrxy
                .ForEach(u => updatedAndNewContracts.Add(
                    new UpdatedAndNewContract(u.ContractId, u.ClientRFC, u.UserName, u.ContractCreateOrModify)
                )
            );

            return updatedAndNewContracts;
        }
    }
}
