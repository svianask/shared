﻿using ClientNotifications.Domain.WKNotificationsAggregate;
using ClientNotificationsProxy;
using System.Collections.Generic;

namespace ManagementOidcRetail.Proxy.Mapping
{
    public class WKNotificationsMapping
    {
        public static List<WKNotification> Mapping(List<WKNotificationPrxy> updatedAndNewContractsPrxy)
        {
            List<WKNotification> wkNotifications = new List<WKNotification>();

            updatedAndNewContractsPrxy
                .ForEach(u => wkNotifications.Add(
                    new WKNotification(u.NotificationWKId, u.UserName, u.ContractId, u.FechaAlta, u.FechaEnvio, u.PlantillaUtilizada, u.NotificacionEnviada)
                )
            );

            return wkNotifications;
        }
    }
}
