﻿using ClientNotifications.Domain.ClientContractsAggregate;
using Common.Domain;
using Ddd;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;

namespace ClientNotificationsProxy
{
    #region Contracts Information

    public class PrxyContractsResponse
    {
        public ContractsOf ContractsOfClient;
        public OperationResult Result;

        public PrxyContractsResponse()
        {
            ContractsOfClient = new ContractsOf();
            Result = new OperationResult();
        }
    }

    public class PrxyContractsRequest
    {
        public string ClientIdentifier;
    }

    public class ContractsOf
    {
        public string Id;
        public List<Contr> Contracts;
    }

    public class Contr
    {
        public string Id;
        public short PlanBasId;
        public int Platform;
        public short GoalId;
        public string GoalDescription;
        public string ContratoAgrupa;
        public DateTime AfiliationDate;
    }

    #endregion

    #region ClientByContractId

    public class PrxyClientByContractIdRequest
    {
        public string contractId;
    }

    public class PrxyClientByContractIdResponse
    {
        public OperationResult Result;
        public PrxyClientInfo ClientInfo;
    }

    public class PrxyClientInfo
    {
        public string Id;
        public string Name;
        public string LastNameOne;
        public string LastNameTwo;
        public int PersonTypeId;
    }

    #endregion

    #region Client Profile

    public class PrxyClientProfileResponse
    {
        public PrxyClientProfile ClientProfile;
        public OperationResult Result;
    }
    public class PrxyClientProfileRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class PrxyClientProfile
    {
        public PrxySalesPractClientType ClientType;
        public PrxyServiceType ServiceType;
        public string ProductType;
    }

    public class PrxySalesPractClientType
    {
        public string Id;
        public string Description;
    }

    public class PrxyServiceType
    {
        public string Id;
        public string Description;
    }

    #endregion

    #region Client Portfolio Profiles

    public class PrxyPortfolioProfileResponse
    {
        public PrxySalesPractPortfolioType PortfolioType;
        public OperationResult Result;
    }

    public class PrxyPortfolioProfileRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class PrxySalesPractPortfolioType
    {
        public PrxySalesPractClientType ClientType;
        public string Id;
        public string Description;
    }

    #endregion

    #region Contract Reference Number

    public class PrxyReferenceNumberResponse
    {
        public string ReferenceNumber;
        public OperationResult Result;
    }

    public class PrxyReferenceNumberRequest
    {
        public string ContractId;
        public int Platform;
    }

    #endregion

    #region Contracts By Client

    public class PrxyClientContactDataRequest
    {
        public string ClientIdentifier;
    }

    public class PrxyClientContactDataResponse
    {
        public PrxyContractsOfClientResponse ContractsOfClient;
        public OperationResult Result;
    }

    public class PrxyContractsOfClientResponse
    {
        public List<PrxyContract> Contracts;
    }

    public class PrxyContract
    {
        public string Id;
        public PrxyContactData ContactData;
    }

    public class PrxyContactData
    { 
        public string CellPhone;
        public string Phone;
        public string Email; 
    }

    #endregion

    #region Client Notifications 

    public class PrxyClientNotificationsRequest
    {
        public string Subject { get; set; }
        public PrxySenderData SenderData { get; set; }
        public List<string> ToEmails { get; set; }
        public List<string> ToCcEmails { get; set; }
        public Dictionary<string, string> TemplateData { get; set; }
        public List<AttachmentFile> Attachments { get; set; }
        public string Template { get; set; }
    }

    public class PrxyClientNotificationsResponse
    {
        public OperationResult Result { get; set; }
    }

    public class PrxySenderData
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }

    #endregion

    #region Template Info

    public class PrxyFirstNotificationTemplateRequest
    {
        public string PlanId;
    }

    public class PrxyFirstNotificationTemplateResponse
    {
        public string TemplateId;
        public string Template;

        public OperationResult Result;
    }

    #endregion

    #region ContractInfo

    public class PrxyContractInfoResponse
    {
        public PrxyContractInfo ContractInfo;
        public OperationResult Result;

        public PrxyContractInfoResponse()
        {
            Result = new OperationResult();
        }
        public class PrxyContractInfo
        {
            public string Id;
            public short PlanBasId;
            public int Platform;
            public short GoalId;
            public string ContratoAgrupa;
            public DateTime AfiliationDate;
            public string GoalDescription;
            public int ContractType;
        }

    }

    public class PrxyContractInfoRequest
    {
        public string ContractId;
    }

    #endregion

    #region Grouper Contract

    public class PrxyGrouperContractResponse
    {
        public string GrouperContract;
        public OperationResult Result;
    }

    public class PrxyGrouperContractRequest
    {
        public string ContractId;
        public int Platform;
    }

    #endregion

    #region Saving Target

    public class PrxySavingTargetResponse
    {
        public string SavingTarget;
        public OperationResult Result;
    }

    public class PrxySavingTargetRequest
    {
        public string ContractId;
        public int Platform;
    }
    #endregion

    #region Update Client Contact Data 
    public class PrxyUpdateContactInformationRequest
    {
        public string ClientIdentifier;
        public string Email;
        public string Phone;
    }

    public class PrxyUpdateContactInformationResponse
    {
        public OperationResult Result;
    }
    #endregion Update Client Contact Data
}
