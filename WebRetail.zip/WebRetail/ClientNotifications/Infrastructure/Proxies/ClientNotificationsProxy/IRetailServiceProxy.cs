﻿using ClientNotifications.Domain.ClientContractsAggregate;
using ClientNotifications.Domain.ClientInfoAggregate;
using ClientNotifications.Domain.ClientProfileAggregate;
using ClientNotifications.Domain.TemplateAggregate;
using Common.Domain;

namespace ClientNotificationsProxy
{
    public interface IRetailServiceProxy
    {
        ClientContracts GetContracts(string clientIdentifier, out OperationResult result);

        ContactData GetClientContactData(string clientIdentifier, string contractId, out OperationResult result);

        ClientInfo GetClientByContractId(string contractId, out OperationResult result);

        ClientProfile GetClientProfile(string contractId, int platform, out OperationResult result);

        string GetReferenceNumber(string contractId, int platform, out OperationResult result);

        Template GetTemplateBody(string planId, out OperationResult result);

        ContractInfo GetContractInfo(string contractId, out OperationResult result);
        void UpdateClientContactData(string clientId, string email, string phone, out OperationResult result);
    }
}
