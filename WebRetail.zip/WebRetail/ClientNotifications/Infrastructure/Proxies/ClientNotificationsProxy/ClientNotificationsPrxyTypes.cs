﻿namespace ClientNotificationsProxy
{
    public class AttachmentFile
    {
    }
}
