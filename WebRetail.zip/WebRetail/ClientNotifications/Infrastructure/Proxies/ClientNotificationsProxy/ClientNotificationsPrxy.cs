﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientNotificationsProxy
{
    public class ClientNotificationsPrxy : IClientNotificationsPrxy
    {
        private readonly ISeriLogHelper _log;
        private readonly IProxyEngine _proxyEngine;

        public ClientNotificationsPrxy(ISeriLogHelper seriLogHelper, IProxyEngine proxyEngine)
        {
            _log = seriLogHelper;
            _proxyEngine = proxyEngine;
        }

        public void SendNotification(string subject, PrxySenderData senderData, List<string> toEmails, List<string> toCcEmails, Dictionary<string, string> templateData, string encodedTemplate, List<AttachmentFile> attachments, out OperationResult result)
        {
            PrxyClientNotificationsRequest request = new PrxyClientNotificationsRequest();
            PrxyClientNotificationsResponse response = new PrxyClientNotificationsResponse();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientNotifications/SendNotification";

            request.Subject = subject;
            request.SenderData = senderData;
            request.ToEmails = toEmails;
            request.ToCcEmails = toCcEmails;
            request.TemplateData = templateData;
            request.Template = encodedTemplate;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientNotificationsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
        }
    }
}
