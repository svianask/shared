﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using static ClientNotifications.Domain.Ennumerators;

namespace ClientNotificationsProxy
{
    public class ParametersPrxy : IParametersPrxy
    {
        IProxyEngine _proxyEngine;

        public ParametersPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<string> GetInternalPlans(out OperationResult result)
        {
            List<string> internalPlans = new List<string>();
            string parameterValue = GetStringParameter(ParametersType.FNINTERPLAN.ToString(), out result);

            if (!string.IsNullOrEmpty(parameterValue))
            {
                internalPlans = parameterValue.Split('|').ToList();
            }

            return internalPlans;
        }

        public PrxySenderData GetSenderData(out OperationResult result)
        {
            PrxySenderData paramSenderData = null;
            string parameterValue = GetStringParameter(ParametersType.FNSENDERDAT.ToString(), out result);

            if (!string.IsNullOrEmpty(parameterValue))
            {
                paramSenderData = JsonConvert.DeserializeObject<PrxySenderData>(parameterValue);
            }

            return paramSenderData;
        }

        private string GetStringParameter(string parameterId, out OperationResult result)
        {
            PrxyStringParameterResponse response;
            string templateBody;

            if (string.IsNullOrEmpty(parameterId)) throw new Exception("El identificador del parámetro no puede ser nulo.");

            string url = ConfigurationManager.AppSettings["BursinessParameters:URLService"].ToString() + "Query/GetStringParameter";

            PrxyStringParameterRequest request = new PrxyStringParameterRequest
            {
                ParameterId = parameterId,
                ContractId = "",
                PlanId = "",
                ProductType = ProductType.GlobalTrust.ToString(),
                ContractAttributeType = ContractAttributeType.Standar.ToString()
            };

            string jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyStringParameterResponse>(jsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                templateBody = response.StringParameter.Value;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return templateBody;
        }
    }
}
