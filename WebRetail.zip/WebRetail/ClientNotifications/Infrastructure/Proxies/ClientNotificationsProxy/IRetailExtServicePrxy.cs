﻿using Common.Domain;
using ClientNotifications.Domain.ClientContractsAggregate;
using ClientNotifications.Domain.PlanAggregate;
using ClientNotifications.Domain.UpdatedAndNewContractsAggregate;
using System.Collections.Generic;
using System;
using ClientNotifications.Domain.WKNotificationsAggregate;

namespace ClientNotificationsProxy
{
    public interface IRetailExtServicePrxy
    {
        ContractExtBasicInfo GetContractExtBasicInfo(string contractId, out OperationResult result);

        List<Plan> GetPlansById(List<short> basPlanIds, out OperationResult result);

        List<UpdatedAndNewContract> GetUpdatedAndNewContracts(DateTime initDate, DateTime endDate);

        List<string> GetFilterContractsWithoutWK(List<string> contracts);

        List<WKNotification> GetWKNotifications(DateTime initDate, DateTime endDate);

        List<WKNotification> GetWKGenericNotifications(string contractId, string userName);

        void UpdateNotificationRecord(int notificacionWkId, string usedTemplate, out OperationResult result);

        int InsertNotification(List<WKNotification> notification, out OperationResult result);
    }
}
