﻿using Common.Domain;
using System.Collections.Generic;

namespace ClientNotificationsProxy
{
    public class GetEncryptedTokenRequest
    {
        public Dictionary<string, string> Parameters { get; set; }
    }

    public class GetEncryptedTokenResponse
    {
        public string Token { get; set; }

        public OperationResult Result { get; set; }
    }
}
