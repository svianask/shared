﻿using Common.Domain;

namespace ClientNotificationsProxy
{

    public class PrxyStringParameterRequest
    {
        public string ParameterId { get; set; }
        public string ContractId { get; set; }
        public string PlanId { get; set; }
        public string ProductType { get; set; }
        public string ContractAttributeType { get; set; }
    }

    public class PrxyStringParameterResponse
    {
        public PrxyStringParameter StringParameter;
        public OperationResult Result;
    }

    public class PrxyStringParameter
    {
        public string Id;
        public string Value;
    }
}
