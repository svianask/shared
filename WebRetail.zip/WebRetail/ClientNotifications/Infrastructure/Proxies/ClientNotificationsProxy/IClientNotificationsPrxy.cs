﻿using Common.Domain;
using System.Collections.Generic;

namespace ClientNotificationsProxy
{
    public interface IClientNotificationsPrxy
    {
        void SendNotification(string subject, PrxySenderData senderData, List<string> toEmails, List<string> toCcEmails, Dictionary<string, string> templateDate, string encodedTemplate, List<AttachmentFile> attachments, out OperationResult result);
    }
}
