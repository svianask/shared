﻿using ClientNotifications.Domain.ClientContractsAggregate;

namespace ClientNotificationsProxy.RetailExtServiceMapp
{
    public class ContractExtBasicInfoMapp
    {
        public static ContractExtBasicInfo Mapp(PrxyContractExtBasicInfo prxyContractExtBasicInfo)
        {
            return ContractExtBasicInfo.Create(
                    prxyContractExtBasicInfo.SavingGoal,
                    prxyContractExtBasicInfo.SavingTerm,
                    prxyContractExtBasicInfo.CommittedAmount
                )
                .SetEffectiveDates(
                    prxyContractExtBasicInfo.AfiliationDate,
                    prxyContractExtBasicInfo.EfectiveEndDate
                );
        }
    }
}
