﻿using Common.Domain;
using System.Collections.Generic;

namespace ClientNotificationsProxy
{
    public interface IParametersPrxy
    {
        List<string> GetInternalPlans(out OperationResult result);

        PrxySenderData GetSenderData(out OperationResult result);
    }
}
