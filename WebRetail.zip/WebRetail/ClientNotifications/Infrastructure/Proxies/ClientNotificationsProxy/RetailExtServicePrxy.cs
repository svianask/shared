﻿using ClientNotifications.Domain.ClientContractsAggregate;
using ClientNotifications.Domain.PlanAggregate;
using ClientNotifications.Domain.UpdatedAndNewContractsAggregate;
using ClientNotifications.Domain.WKNotificationsAggregate;
using ClientNotificationsProxy.RetailExtServiceMapp;
using ClientNotificationsProxy.RetailServiceMapp;
using Common.Domain;
using ManagementOidcRetail.Proxy.Mapping;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace ClientNotificationsProxy
{
    public class RetailExtServicePrxy : IRetailExtServicePrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public RetailExtServicePrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ContractExtBasicInfo GetContractExtBasicInfo(string contractId, out OperationResult result)
        {
            PrxyContractExtBasicInfoRequest request = new PrxyContractExtBasicInfoRequest();
            PrxyContractExtBasicInfoResponse response = new PrxyContractExtBasicInfoResponse();
            ContractExtBasicInfo contractExtBasicInfo = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractExtBasicInfo"; //Controller/Action

            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractExtBasicInfoResponse>(JsonResult);
                contractExtBasicInfo = ContractExtBasicInfoMapp.Mapp(response.ContractExtBasicInfo);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return contractExtBasicInfo;
        }

        public List<Plan> GetPlansById(List<short> basPlanIds, out OperationResult result)
        {
            PrxyPlansRequest request = new PrxyPlansRequest();
            PrxyPlansResponse response = new PrxyPlansResponse();
            List<Plan> Plans = new List<Plan>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetPlansById"; //Controller/Action

            request.PlanIds = basPlanIds;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyPlansResponse>(JsonResult);
                Plans = PlansMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else
                {
                    throw new ApplicationException("Error al consumir el servicio " + url);
                }
            }

            return Plans;
        }

        public List<UpdatedAndNewContract> GetUpdatedAndNewContracts(DateTime initDate, DateTime endDate)
        {
            OperationResult result = new OperationResult();
            Updated_NewContractsRequestPrxy request = new Updated_NewContractsRequestPrxy();
            Updated_NewContractsResponsePrxy response = new Updated_NewContractsResponsePrxy();
            List<UpdatedAndNewContract> updatedAndNewContracts = null;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Contracts/GetUpdatedAndNewContracts";

            request.InitDate = initDate;
            request.EndDate = endDate;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<Updated_NewContractsResponsePrxy>(JsonResult);

                ValidateErrResult("Error al consumir el servicio " + url + " - ", response.Result);

                updatedAndNewContracts = UpdatedAndNexContractsMapping.Mapping(response.UpdatedAndNewContracts);
            }
            else { 
                ValidateErrResult("Error al consumir el servicio " + url + " - ", result); 
            }

            return updatedAndNewContracts;
        }

        public List<WKNotification> GetWKGenericNotifications(string contractId, string userName)
        {
            OperationResult result;
            WKGenericNotificationsRequestPrxy request = new WKGenericNotificationsRequestPrxy();
            WKGenericNotificationsResponsePrxy response;
            List<WKNotification> updatedAndNewContracts = null;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Notifications/GetWKGenericNotifications";

            request.ContractId = contractId;
            request.UserName = userName;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<WKGenericNotificationsResponsePrxy>(JsonResult);

                ValidateErrResult("Error al consumir el servicio " + url + " - ", response.Result);

                updatedAndNewContracts = WKNotificationsMapping.Mapping(response.NotificationsList);
            }
            else
            {
                ValidateErrResult("Error al consumir el servicio " + url + " - ", result);
            }

            return updatedAndNewContracts;
        }

        public List<WKNotification> GetWKNotifications(DateTime initDate, DateTime endDate)
        {
            OperationResult result;
            WKNotificationsRequestPrxy request = new WKNotificationsRequestPrxy();
            WKNotificationsResponsePrxy response;
            List<WKNotification> updatedAndNewContracts = null;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Notifications/GetWKNotifications";

            request.InitDate = initDate;
            request.EndDate = endDate;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<WKNotificationsResponsePrxy>(JsonResult);

                ValidateErrResult("Error al consumir el servicio " + url + " - ", response.Result);

                updatedAndNewContracts = WKNotificationsMapping.Mapping(response.NotificationsList);
            }
            else
            {
                ValidateErrResult("Error al consumir el servicio " + url + " - ", result);
            }

            return updatedAndNewContracts;
        }

        public List<string> GetFilterContractsWithoutWK(List<string> contracts)
        {
            OperationResult result = new OperationResult();
            FilterContractsWithoutWKRequestPrxy request = new FilterContractsWithoutWKRequestPrxy();
            FilterContractsWithoutWKResponsePrxy response = new FilterContractsWithoutWKResponsePrxy();
            List<string> filteredContracts = new List<string>();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Notifications/GetFilterContractsWithoutWK";

            request.Contracts = contracts;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<FilterContractsWithoutWKResponsePrxy>(JsonResult);
                ValidateErrResult("Error al consumir el servicio " + url + " - ", response.Result);
                filteredContracts = response.FilteredContracts;
            }
            else { ValidateErrResult("Error al consumir el servicio " + url + " - ", result); }

            return filteredContracts;
        }

        public int InsertNotification(List<WKNotification> notifications, out OperationResult result)
        {
            InsertNotificationRequestPrxy request = new InsertNotificationRequestPrxy();
            InsertNotificationResponsePrxy response = new InsertNotificationResponsePrxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Notifications/InsertNotification";
            int notificationId = 0;

            foreach (WKNotification wkNotifications in notifications)
            {
                request.Notification.Add( new WKNotificationPrxy
                {
                    ContractId = wkNotifications.ContractId,
                    UserName = wkNotifications.UserName,
                    FechaAlta = wkNotifications.FechaAlta,
                    FechaEnvio = wkNotifications.FechaEnvio,
                    PlantillaUtilizada = wkNotifications.PlantillaUtilizada,
                    NotificacionEnviada = wkNotifications.NotificacionEnviada
                });
            }
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<InsertNotificationResponsePrxy>(JsonResult);

                notificationId = response.NotificationId;

                ValidateErrResult("Error al consumir el servicio " + url + " - ", response.Result);
            }
            else
            {
                ValidateErrResult("Error al consumir el servicio " + url + " - ", result);
            }

            return notificationId;
        }

        public void UpdateNotificationRecord(int notificacionWkId, string plantillaUtilizada, out OperationResult result)
        {
            UpdateNotificationRequestPrxy request = new UpdateNotificationRequestPrxy();
            UpdateNotificationResponsePrxy response = new UpdateNotificationResponsePrxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Notifications/UpdateNotificationRecord";

            request.NotificacionWkId = notificacionWkId;
            request.UsedTemplate = plantillaUtilizada;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<UpdateNotificationResponsePrxy>(JsonResult);

                result = response.Result;

                ValidateErrResult("Error al consumir el servicio " + url + " - ", response.Result);
            }
            else
            {
                ValidateErrResult("Error al consumir el servicio " + url + " - ", result);
            }
        }

        private void ValidateErrResult(string errorDescription, OperationResult result)
        {
            var errMessages = new StringBuilder();
            result.SystemMessages.ForEach(x => errMessages.Append(x.Message + " - "));
            if (!result.Successful) { throw new Exception(errMessages.ToString()); }
        }
    }
}
