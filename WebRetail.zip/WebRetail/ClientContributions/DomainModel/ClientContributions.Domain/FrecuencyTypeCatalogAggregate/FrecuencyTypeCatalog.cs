﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContributions.Domain.FrecuencyTypeCatalogAggregate
{
    public class FrecuencyTypeCatalog : ValueObject<FrecuencyTypeCatalog>
    {
        private FrecuencyTypeCatalog(short frecuencyTypeId, string frecuencyType, string frecuencyTypeShort)
        {
            Id = frecuencyTypeId;
            Description = frecuencyType;
            DescriptionShort = frecuencyTypeShort;
        }

        public short Id { get; }
        public string Description { get; }
        public string DescriptionShort { get; }

        public static FrecuencyTypeCatalog Create(short frecuencyTypeId, string frecuencyType, string frecuencyTypeShort)
        {
            if (frecuencyTypeId == 0) { throw new ArgumentException("El identificador de la frecuencia no puede ser nulo."); }
            if (string.IsNullOrEmpty(frecuencyType)) { throw new ArgumentException("La descripcion de la frecuencia no pueder ir vacia."); }
            if (string.IsNullOrEmpty(frecuencyTypeShort)) { throw new ArgumentException("La descripcion corta de la frecuencia no pueder ir vacia."); }

            return new FrecuencyTypeCatalog(frecuencyTypeId, frecuencyType, frecuencyTypeShort);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Id,
                Description,
                DescriptionShort
            };
        }
    }
}
