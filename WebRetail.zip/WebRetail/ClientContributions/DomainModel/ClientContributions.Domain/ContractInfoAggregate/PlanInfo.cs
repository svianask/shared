﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContributions.Domain.ContractInfoAggregate
{
    public class PlanInfo : ValueObject<ContractInfo>
    {
        private PlanInfo(string id, string name, string shortName, string basPlanId)
        {
            Id = id;
            Name = name;
            ShortName = shortName;
            BasPlanId = basPlanId;
        }

        public string Id { get; }
        public string Name { get; }
        public string ShortName { get; }
        public string BasPlanId { get; }

        public PlanClasification PlanClasification { get; private set; }
        public ComercialInfo ComercialInfo { get; private set; }


        public static PlanInfo Create(string id, string name, string shortName, string basPlanId)
        {
            if (string.IsNullOrEmpty(name)) { throw new ArgumentException(nameof(name) + " no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(shortName)) { throw new ArgumentException(nameof(shortName) + " no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(basPlanId)) { throw new ArgumentException(nameof(basPlanId) + " no puede ser nulo ni vacío"); }

            return new PlanInfo(id, name, shortName, basPlanId);
        }

        public PlanInfo SetPlanClasification(int platform, int productType)
        {
            PlanClasification = PlanClasification.Create(platform, productType);
            return this;
        }

        public PlanInfo SetComercialInfo(short comercialPlanId, string comercialName)
        {
            ComercialInfo = ComercialInfo.Create(comercialPlanId, comercialName);
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Id,
                BasPlanId
            };
        }
    }

    public class ComercialInfo : ValueObject<ComercialInfo>
    {
        public short ComercialPlanId { get; }
        public string ComercialName { get; }
        private ComercialInfo(short comercialPlanId, string comercialName)
        {
            ComercialPlanId = comercialPlanId;
            ComercialName = comercialName;
        }

        internal static ComercialInfo Create(short comercialPlanId, string comercialName)
        {
            if (string.IsNullOrEmpty(comercialName)) { throw new ArgumentException(nameof(comercialName) + " no puede ser nulo ni vacío"); }
            if (comercialPlanId <= 0) { throw new ArgumentException(nameof(comercialPlanId) + " no es válido"); }
            return new ComercialInfo(comercialPlanId, comercialName);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ComercialPlanId,
                ComercialName
            };
        }
    }

    public class PlanClasification : ValueObject<PlanClasification>
    {
        public int Platform { get; }
        public int ProductType { get; }
        private PlanClasification(int platform, int productType)
        {
            Platform = platform;
            ProductType = productType;
        }

        internal static PlanClasification Create(int platform, int productType)
        {
            return new PlanClasification(platform, productType);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Platform,
                ProductType
            };
        }
    }

}
