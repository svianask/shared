﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContributions.Domain.ContractInfoAggregate
{
    public class ContractInfo : ValueObject<ContractInfo>
    {
        private ContractInfo(string contractId, short planBasId, int platform, string contratoAgrupa, DateTime afiliationDate)
        {
            ContractId = contractId;
            PlanBasId = planBasId;
            Platform = platform;
            ContratoAgrupa = contratoAgrupa;
            AfiliationDate = afiliationDate;
        }

        public string ContractId { get; }
        public short PlanBasId { get; }
        public int Platform { get; }
        public string ContratoAgrupa { get; }
        public DateTime AfiliationDate { get; }

        public static ContractInfo Create(string contractId, short planBasId, int platform, string contratoAgrupa, DateTime afiliationDate)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El identificador de la contrato no puede ser nulo."); }

            return new ContractInfo(contractId, planBasId, platform, contratoAgrupa, afiliationDate);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                PlanBasId,
                Platform,
                ContratoAgrupa
            };
        }
    }
}
