﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContributions.Domain.ClientContributionsValidateAggregate
{
    public class ClientContributionsValidate : ValueObject<ClientContributionsValidate>
    {
        private bool _isContributionValidate;
        private string _messageMotive;
        private string _planId;

        private List<string> _applyPlans;
        private List<ClientBankAccountsContributions> _clientBanckAccounts;
        private string _initSchedule;
        private string _endSchedule;
        private bool _applySchedule;


        private bool _isDomiciliationValidate;
        private List<string> _applyDomiciliationsPlans;
        private ClientContributionsValidate(string planId)
        {
            _planId = planId;
        }

        public bool IsContributionValidate => _isContributionValidate;

        public bool IsDomiciliationValidate => _isDomiciliationValidate;

        public string MessageMotive => _messageMotive;

        public static ClientContributionsValidate Create(string planId)
        {
            return new ClientContributionsValidate(planId);
        }

        public ClientContributionsValidate SetApplyPlans(List<string> applyPlans)
        {
            _applyPlans = applyPlans;
            return this;
        }

        public ClientContributionsValidate SetBankAccounts(List<ClientBankAccountsContributions> clientBankAccounts)
        {
            _clientBanckAccounts = clientBankAccounts;
            return this;
        }

        public ClientContributionsValidate SetEnabledSchedule(string initSchedule, string endSchedule, bool applySchedule)
        {
            _initSchedule = initSchedule;
            _endSchedule = endSchedule;
            _applySchedule = applySchedule;
            return this;
        }

        public ClientContributionsValidate ValidateApplyContributions()
        {
            int motiveId = 0;
            _isContributionValidate = false;

            if (!_applyPlans.Contains(_planId))
            {
                motiveId = 1;
            }
            else if (_clientBanckAccounts is null || _clientBanckAccounts.Count <= 0)
            {
                motiveId = 2;
            }
            else if (!_applySchedule)
            {
                motiveId = 3;
            }
            else
            {
                _isContributionValidate = true;
            }

            SetMessage(motiveId);
            return this;
        }

        private void SetMessage(int typeMotive)
        {
            switch (typeMotive)
            {
                case 1: //El plan no aplica
                    _messageMotive = "Tu plan no permite realizar aportaciones a través del portal. Conoce como hacerlo en el siguiente link";
                    break;
                case 2://El contrato no tiene cuentas bancarias asociadas.
                    _messageMotive = "No tienes cuenta registrada en este momento. Podrás inscribir la cuenta a través de la aplicación móvil o llamando a nuestro teléfono de servicio al cliente.";
                    break;
                case 3:
                    _messageMotive =
                        string.Format("El servicio de aportaciones no está disponible. El horario para solicitar aportaciones es de las {0}hrs a las {1}hrs", _initSchedule, _endSchedule);
                    break;
                default:
                    _messageMotive = "";
                    break;

            }
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }

        public ClientContributionsValidate SetApplyDomiciliationsPlans(List<string> applyPlansForDomiciliation)
        {
            _applyDomiciliationsPlans = applyPlansForDomiciliation;
            return this;
        }

        public ClientContributionsValidate ValidateApplyDomiciliations()
        {
            _isDomiciliationValidate = _applyDomiciliationsPlans.Contains(_planId) && _isContributionValidate;
            return this;
        }
    }
}
