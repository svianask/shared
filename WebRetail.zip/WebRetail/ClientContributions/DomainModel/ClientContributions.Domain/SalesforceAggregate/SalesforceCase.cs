﻿using Ddd;
using System.Collections.Generic;

namespace ClientContributions.Domain.SalesforceAggregate
{
    public sealed class SalesforceCase : ValueObject<SalesforceCase>
    {
        public string ContractId { get; }
        public string CaseNumber { get; }


        private SalesforceCase(string contractId, string caseNumber)
        {
            ContractId = contractId;
            CaseNumber = caseNumber;
        }

        public static SalesforceCase Create(string contractId, string caseNumber)
        {
            return new SalesforceCase(contractId, caseNumber);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                CaseNumber
            };
        }
    }

    public sealed class SalesforceCaseRequest : ValueObject<SalesforceCase>
    {
        public string ClientIdentifier { get; set; }
        public string ContractId { get; set; }
        public string Issue { get; private set; } = string.Empty;
        public string OriginCase { get; private set; } = string.Empty;
        public string Category { get; private set; } = string.Empty;
        public string OriginType { get; private set; } = string.Empty;
        public string CaseType { get; private set; } = string.Empty;
        public string SubType { get; private set; } = string.Empty;
        public string Tracing { get; private set; } = string.Empty;

        private SalesforceCaseRequest(string contractId, string clientIdentifier)
        {
            ContractId = contractId;
            ClientIdentifier = clientIdentifier;
        }

        public static SalesforceCaseRequest Create(string contractId, string clientIdentifier)
        {
            return new SalesforceCaseRequest(contractId, clientIdentifier);
        }

        public SalesforceCaseRequest SetDetail(string issue, string originCase, string category)
        {
            Issue = issue;
            OriginCase = originCase;
            Category = category;
            return this;
        }

        public SalesforceCaseRequest SetInfo(string originType, string caseType, string subType, string tracing)
        {
            OriginType = originType;
            CaseType = caseType;
            SubType = subType;
            Tracing = tracing;
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                ClientIdentifier
            };
        }
    }
}
