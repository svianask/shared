﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionContactClientAggregate
{
    public class ContributionContactClient : ValueObject<ContributionContactClient>
    {
        private readonly string _email;
        private readonly string _name;
        private readonly string _lastName;

        private ContributionContactClient(string email, string name, string lastName)
        {
            _email = email;
            _name = name;
            _lastName = lastName;
        }

        public string Email => _email;
        public string Name => _name;
        public string LastName => _lastName;

        public static ContributionContactClient Create(string email, string name, string lastName)
        {
            if (string.IsNullOrEmpty(email)) { throw new ArgumentNullException(nameof(email)); }
            if(string.IsNullOrEmpty(name)) { throw new ArgumentNullException(nameof(name)); }

            return new ContributionContactClient(email, name, lastName);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
