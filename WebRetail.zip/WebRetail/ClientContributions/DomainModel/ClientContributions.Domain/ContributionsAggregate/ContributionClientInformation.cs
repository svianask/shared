﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionClientInformation : ValueObject<ContributionClientInformation>
    {
        private string _contractId;
        private string _contractMasterId;
        private double _amount;
        private int _bankAccountTypeId;
        private int _bankClientId;
        private string _accountClient;
        private DateTime _dateContribution;
        private string _typeContribution;
        private string _userId;
        private int _domiciliationTypeId;

        private ContributionClientInformation(string contractId)
        {
            _contractId = contractId;
        }

        public static ContributionClientInformation Create(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }
            return new ContributionClientInformation(contractId);
        }

        public ContributionClientInformation SetAmountDateInfo(double amount, DateTime dateContribution)
        {
            if (amount <= 0) { throw new ArgumentException(nameof(amount)); }

            _amount = amount;
            _dateContribution = dateContribution;
            return this;
        }

        public ContributionClientInformation SetBankInfo(int bankAccountTypeId, int bankClientId, string accountClient)
        {
            if (string.IsNullOrEmpty(accountClient)) { throw new ArgumentException(nameof(accountClient)); }

            _bankAccountTypeId = bankAccountTypeId;
            _bankClientId = bankClientId;
            _accountClient = accountClient;
            return this;
        }

        public ContributionClientInformation SetAdditionalInfo(string typeContribution, string userId)
        {
            _typeContribution = typeContribution;
            _userId = userId;
            return this;
        }

        public ContributionClientInformation SetDomiciliationType( int domiciliationTypeId)
        {
            _domiciliationTypeId = domiciliationTypeId;
            return this;
        }

        public ContributionClientInformation SetContractMaster( string contractMasterId)
        {
            _contractMasterId = contractMasterId;
            return this;
        }

        public string ContractId => _contractId;
        public string ContractMasterId => _contractMasterId;
        public double Amount => _amount;
        public int BankAccountTypeId => _bankAccountTypeId;
        public int BankClientId => _bankClientId;
        public string AccountClient => _accountClient;
        public DateTime DateContribution => _dateContribution;
        public string TypeContribution => _typeContribution;
        public string UserId => _userId;
        public int DomiciliationTypeId => _domiciliationTypeId;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                Amount,
                BankAccountTypeId,
                BankClientId,
                AccountClient
            };
        }
    }
}
