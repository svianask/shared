﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionAmountDue : ValueObject<ContributionAmountDue>
    {
        private bool _applyAmountDue;
        private decimal _amountDue;

        private ContributionAmountDue(bool applyAmountDue, decimal amountDue)
        {
            _applyAmountDue = applyAmountDue;
            _amountDue = amountDue;
        }

        public bool ApplyAmountDue => _applyAmountDue;
        public decimal AmountDue => _amountDue;

        public static ContributionAmountDue Create(decimal amountDue)
        {
            var isApply = amountDue > 0;
            return new ContributionAmountDue(isApply, amountDue);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
