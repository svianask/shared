﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionConfig : Entity<string>
    {
        private string _productName;
        private int _segmentType;

        private ContributionComission _commision;
        private ContributionMinMaxAmount _allowAmounts;
        private ContributionCommitedAmount _commitedAmount;
        private ContributionAmountDue _amountDue;
        private ContributionaAdditionalContracts _additionalContracts;
        private List<ClientBankAccountsContributions> _bankAccounts;
        private ContributionBusinessDays _businessDays;

        private int _maxContributionHour;

        private ContributionConfig(string contractId, int segment, string prodcutName)
        {
            _segmentType = segment;
            _productName = prodcutName;
            Id = contractId;
        }

        public int SegmentType => _segmentType;
        public string ProductName => _productName;
        public ContributionMinMaxAmount AllowAmounts => _allowAmounts;
        public ContributionComission Comission => _commision;
        public ContributionCommitedAmount CommitedAmount => _commitedAmount;
        public ContributionAmountDue AmountDue => _amountDue;
        public ContributionaAdditionalContracts AdditionalContracts => _additionalContracts;
        public List<ClientBankAccountsContributions> BankAccounts => _bankAccounts;
        public ContributionBusinessDays BusinessDays => _businessDays;
        public int MaxContributionHour => _maxContributionHour;

        public static ContributionConfig Create(string contractId, int segment, string prodcutName)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            return new ContributionConfig(contractId, segment, prodcutName);
        }

        public ContributionConfig SetAllowsAmounts(ContributionMinMaxAmount allowsAmounts)
        {
            _allowAmounts = allowsAmounts;
            return this;
        }

        public ContributionConfig SetCommision(ContributionComission comission)
        {
            _commision = comission;
            return this;
        }

        public ContributionConfig SetCommiteAmount(ContributionCommitedAmount commitedAmount)
        {
            _commitedAmount = commitedAmount;
            return this;
        }

        public ContributionConfig SetAmountDue(ContributionAmountDue amountDue)
        {
            _amountDue = amountDue;
            return this;
        }

        public ContributionConfig SetAddittionalContracts(ContributionaAdditionalContracts additionalContracts)
        {
            _additionalContracts = additionalContracts;
            return this;
        }

        public ContributionConfig SetBankAccounts(List<ClientBankAccountsContributions> clientBankAccounts)
        {
            _bankAccounts = clientBankAccounts;
            return this;
        }

        public ContributionConfig SetBussinesDays(ContributionBusinessDays businessDays)
        {
            _businessDays = businessDays;
            return this;
        }
        
        public ContributionConfig SetMaxContributionHour(int maxContributionHour)
        {
            _maxContributionHour = maxContributionHour;
            return this;
        }
    }
}
