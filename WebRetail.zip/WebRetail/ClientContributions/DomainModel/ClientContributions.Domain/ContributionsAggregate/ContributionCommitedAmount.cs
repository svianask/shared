﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionCommitedAmount : ValueObject<ContributionCommitedAmount>
    {
        private bool _isApplyCommitedAmount;
        private decimal _commitedAmount;

        private ContributionCommitedAmount(bool apply, decimal commitedAmount)
        {
            _isApplyCommitedAmount = apply;
            _commitedAmount = commitedAmount;
        }

        public static ContributionCommitedAmount Create(decimal commitedAmount)
        {
            var apply = commitedAmount > 0;
            return new ContributionCommitedAmount(apply, commitedAmount);
        }

        public bool IsApplyCommitedAmount => _isApplyCommitedAmount;
        public decimal CommitedAmount => _commitedAmount;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
