﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionComission : ValueObject<ContributionComission>
    {
        private bool _isApplyComission;
        private decimal _comissionPorcentage;

        private ContributionComission(bool isApplyComission, decimal comissionPorcentage)
        {
            _isApplyComission = isApplyComission;
            _comissionPorcentage = comissionPorcentage;
        }

        public bool IsApplyComission => _isApplyComission;
        public decimal ComissionPorcentage => _comissionPorcentage;

        public static ContributionComission Create(decimal comission)
        {
            var applyComission = comission > 0; 
            return new ContributionComission(applyComission, comission);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
