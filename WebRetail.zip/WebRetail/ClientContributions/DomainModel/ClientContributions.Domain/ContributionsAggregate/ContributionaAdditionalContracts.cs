﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionaAdditionalContracts : ValueObject<ContributionaAdditionalContracts>
    {
        private bool _applyAdditionalContract;
        private string _contractAdditionalId;
        private string _contributionContractId;

        private ContributionaAdditionalContracts(bool applyAdditionalContract, string contractAdditional, string contributionContractId)
        {
            _applyAdditionalContract = applyAdditionalContract;
            _contractAdditionalId = contractAdditional;
            _contributionContractId = contributionContractId;
        }

        public bool ApplyAdditionalContract => _applyAdditionalContract;
        public string ContractAdditionalId => _contractAdditionalId;
        public string ContributionContractId => _contributionContractId;

        public static ContributionaAdditionalContracts Create(string contractAdditional, string contributionContractId)
        {
            var applyAdditionalContract = !string.IsNullOrEmpty(contractAdditional);

            return new ContributionaAdditionalContracts(applyAdditionalContract, contractAdditional, contributionContractId);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
