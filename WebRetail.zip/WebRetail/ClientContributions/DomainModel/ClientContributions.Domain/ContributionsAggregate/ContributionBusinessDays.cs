﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionBusinessDays : ValueObject<ContributionBusinessDays>
    {
        private List<BussinesDay> _bussinessDays;

        private ContributionBusinessDays()
        {
            _bussinessDays = new List<BussinesDay>();
        }

        public List<BussinesDay> BussinessDays => _bussinessDays;

        public static ContributionBusinessDays Create()
        {
            return new ContributionBusinessDays();
        }

        public ContributionBusinessDays AddDate(BussinesDay day)
        {
            _bussinessDays.Add(day);
            return this;
        }
        
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }

    public class BussinesDay : ValueObject<BussinesDay>
    {
        private DateTime _bussinesDate;
        private bool _isEnabled;
        private BussinesDay(DateTime day, bool isEnabled)
        {
            _bussinesDate = day;
            _isEnabled = isEnabled;
        }

        public DateTime BussinesDate => _bussinesDate;
        public bool IsEnabled => _isEnabled;

        public static BussinesDay Create(DateTime date, bool isEnabled)
        {
            return new BussinesDay(date, isEnabled);
        }
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
