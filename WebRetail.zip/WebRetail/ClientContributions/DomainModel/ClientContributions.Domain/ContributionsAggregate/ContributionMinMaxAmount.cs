﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionsAggregate
{
    public class ContributionMinMaxAmount : ValueObject<ContributionMinMaxAmount>
    {
        private decimal _amountMimimun;
        private decimal _amounteMaximun;

        private ContributionMinMaxAmount(decimal amountMimimun, decimal amounteMaximun)
        {
            _amountMimimun = amountMimimun;
            _amounteMaximun = amounteMaximun;
        }

        public static ContributionMinMaxAmount Create(decimal amountMin, decimal amountMax)
        {
            return new ContributionMinMaxAmount(amountMin, amountMax);
        }

        public decimal AmountMinimun => _amountMimimun;
        public decimal AmountMaximun => _amounteMaximun;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<Object>()
            {
                AmountMinimun,
                AmountMaximun
            };
        }
    }
}
