﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ClientBankAccountsContributionsAggregate
{
    public class ClientBankAccountsContributions : Entity<string>
    {
        private int _accountId;
        private int _bankId;
        private int _bankAccountTypeId;
        private string _accountNumber;
        private string _accountBankName;
        private int _accountUseTypeId;

        private ClientBankAccountsContributions(string contractId)
        {
            Id = contractId;
        }

        public int BankId => _bankId;
        public int BankAccountTypeId => _bankAccountTypeId;
        public int AccountId => _accountId;
        public string AccountNumber => _accountNumber;
        public string AccountBankName => _accountBankName;
        public int AccountUseTypeId => _accountUseTypeId;

        public static ClientBankAccountsContributions Create(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío."); }
            return new ClientBankAccountsContributions(contractId);
        }

        public ClientBankAccountsContributions SetBankData(int bankId, string accountBankName, int bankAccountTypeId)
        {
            _bankId = bankId;
            _accountBankName = accountBankName;
            _bankAccountTypeId = bankAccountTypeId;
            return this;
        }

        public ClientBankAccountsContributions SetAccountData(int accountId, string accountNumber, int accountUseTypeId)
        {
            _accountId = accountId;
            _accountNumber = accountNumber;
            _accountUseTypeId = accountUseTypeId;
            return this;
        }
    }
}
