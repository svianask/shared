﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionProductInfoAggregate
{
    public class ContributionProductInfo : Entity<int>
    {
        private readonly short _planBasId;
        private readonly int _platform;
        private string _comercialName;

        private ContributionProductInfo(short planBasId, int platform, string comercialName, int planId)
        {
            _planBasId = planBasId;
            _platform = platform;
            _comercialName = comercialName;
            Id = planId;
        }

        public static ContributionProductInfo Create(short planBasId, int platform, string comercialName, int planId)
        {
            return new ContributionProductInfo(planBasId, platform, comercialName, planId);
        }

        public short PlanBasId => _planBasId;
        public int Platform => _platform;
        public string ComercialName => _comercialName;
    }
}
