﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionNotificationAggregate
{
    public class ContributionEmailInfo
    {
        public string Name;
        public string EmailAddress;
    }
}
