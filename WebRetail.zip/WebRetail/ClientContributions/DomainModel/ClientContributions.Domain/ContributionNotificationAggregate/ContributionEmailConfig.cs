﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionNotificationAggregate
{
    public class ContributionEmailConfig
    {
        public string Provider;
        public string Subject;
        public string Configuration;
        public string TemplateId;
        public ContributionEmailInfo Sender;
        public List<ContributionEmailInfo> Cc;
        public List<ContributionEmailInfo> Bcc;
    }
}
