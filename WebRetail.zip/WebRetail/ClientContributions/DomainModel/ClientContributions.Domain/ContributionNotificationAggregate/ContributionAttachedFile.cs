﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Domain.ContributionNotificationAggregate
{
    public class ContributionAttachedFile
    {
        public string Name;
        public byte[] ContentByte;
        public byte[] ContentBase64;
        public string Url;
    }
}
