﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Messages
{
    public class HasProgrammedPaymentRequest
    {
        public string ClientId { get; set; }
        public string ContractId { get; set; }
    }

    public class HasProgrammedPaymentResponse
    {
        public Boolean HasProgrammedPayment;
        public OperationResult Result;
    }
}
