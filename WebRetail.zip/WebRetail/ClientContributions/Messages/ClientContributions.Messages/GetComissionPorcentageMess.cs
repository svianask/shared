﻿using ClientContributions.Domain.ContributionsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Messages
{
    public class GetComissionPorcentageResponse
    {
        public ContributionComission ComissionContribution;
        public OperationResult Result;
    }

    public class GetComissionPorcentageRequest
    {
        public string ContractId;
    }
}
