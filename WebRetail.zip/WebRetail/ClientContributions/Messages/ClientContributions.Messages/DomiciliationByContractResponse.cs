﻿using ClientContributions.Domain.ClientDomiciliationAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Messages
{
    public class DomiciliationsByContractResponse
    {
        public List<ClientDomiciliation> Domiciliation { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }
}
