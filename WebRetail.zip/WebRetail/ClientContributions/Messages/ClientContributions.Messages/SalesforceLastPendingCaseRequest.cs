﻿namespace ClientContributions.Messages
{
    public class SalesforceLastPendingCaseRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
        public string Issue { get; set; } = string.Empty;
        public string OriginCase { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string OriginType { get; set; } = string.Empty;
        public string CaseType { get; set; } = string.Empty;
        public string SubType { get; set; } = string.Empty;
        public string Tracing { get; set; } = string.Empty;
    }
}
