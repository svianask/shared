﻿using ClientContributions.Domain.ContributionsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Messages
{
    public class GetAmountMinMaxAllowsResponse
    {
        public OperationResult Result;
        public ContributionMinMaxAmount ContributionMinMaxAmountAllow;
    }

    public class GetAmountMinMaxAllowsRequest
    {
        public string ContractId;
    }
}
