﻿using ClientContributions.Domain.ContributionsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Messages
{
    public class GeneraContributionResponse
    {
        public OperationResult Result;
    }

    public class GeneraContributionRequest
    {
        public ContributionClientPrxyInfo ContributionInformation;
    }

    public class ContributionClientPrxyInfo
    {
        public string ContractMaster;
        public string ContractId;
        public double Amount;
        public int BankAccountTypeId;
        public int BankClientId;
        public string AccountClient;
        public DateTime DateContribution;
        public string TypeContribution;
        public string UserId;
    }
}
