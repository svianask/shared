﻿using ClientContributions.Domain.SalesforceAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Messages
{
    public class SalesforceLastPendingCaseResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();

        public List<SalesforceCase> SalesforceCases { get; set; } = new List<SalesforceCase>();
    }
}
