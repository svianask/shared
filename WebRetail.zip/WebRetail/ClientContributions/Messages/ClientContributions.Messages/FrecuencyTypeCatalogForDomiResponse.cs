﻿using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Messages
{
    public class FrecuencyTypeCatalogForDomiResponse
    {
        public List<FrecuencyTypeCatalog> FrecuencyTypes { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }
}
