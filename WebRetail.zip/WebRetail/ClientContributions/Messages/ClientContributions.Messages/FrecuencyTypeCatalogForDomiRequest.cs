﻿namespace ClientContributions.Messages
{
    public class FrecuencyTypeCatalogForDomiRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
    }
}
