﻿namespace ClientContributions.Messages
{
    public class DomiciliationsByContractRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; }
        public bool MaskSensitiveInfo { get; set; } = true;
    }
}
