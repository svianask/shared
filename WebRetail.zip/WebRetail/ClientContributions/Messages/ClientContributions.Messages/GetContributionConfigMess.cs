﻿using ClientContributions.Domain.ContributionsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Messages
{
    public class GetContributionConfigResponse
    {
        public OperationResult Result;
        public ContributionConfig ContributionConfiguration;
    }

    public class GetContributionConfigRequest
    {
        public string ContractId;
    }
}
