﻿using ClientContributions.Domain.ClientContributionsValidateAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Messages
{
    public class ValidateApplyContributionResponse
    {
        public OperationResult Result;
        public ClientContributionsValidate ContributionsValidate;
    }

    public class ValidateApplyContributioRequest
    {
        public string ContractId;
    }
}
