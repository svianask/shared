﻿using ClientContributions.Application;
using ClientContributions.Application.ProductsImplementacion;
using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContractInfoAggregate;
using ClientContributions.Domain.ContributionContactClientAggregate;
using ClientContributions.Domain.ContributionProductInfoAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using ClientContributions.Domain.SalesforceAggregate;
using ClientContributions.Messages;
using ClientContributions.Proxies;
using Common.Domain;
using Common.Proxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientContributions.ApplicationTest
{
    /// <summary>
    /// Summary description for ClientContributionsAppTest
    /// </summary>
    [TestClass]
    public class ClientContributionsAppTest
    {
        private readonly ISeriLogHelper _log;
        private readonly Mock<IClientContributionsRetailExtPrxy> _retailExtPrxy;
        private readonly Mock<IClientContributionWebRetailPrxy> _webRetailPrxy;
        private readonly Mock<IClientContributionRetailPrxy> _retailProxy;
        private readonly IContributionImplementacionSolve[] _blContributions;
        private readonly Mock<IParametersProxy> _parametersProxy;
        private readonly Mock<IClientContributionNotificationPrxy> _notificationPrxy;
        private readonly Mock<IClientContributionMxAuthPrxy> _mxAuthPrxy;

        private readonly Mock<IClientContributionParametersPrxy> _contributionParameters;
        private readonly ClientContributionsApp _contributionsApp;

        private string _contractId;
        private string _emtyContractId;
        public ClientContributionsAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = "C:\\Files\\TestWebRetail-.txt";

            _log = new SeriLogHelper();

            _retailExtPrxy = new Mock<IClientContributionsRetailExtPrxy>();
            _webRetailPrxy = new Mock<IClientContributionWebRetailPrxy>();
            _retailProxy = new Mock<IClientContributionRetailPrxy>();
            _contributionParameters = new Mock<IClientContributionParametersPrxy>();

            //Se agregan las implementaciones al array de la interface.
            _blContributions = new IContributionImplementacionSolve[7];
            IContributionImplementacionSolve capital = new CapitalPlusCntbn(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);
            IContributionImplementacionSolve capitalSeguro = new CapitalSeguroCntbn(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);
            IContributionImplementacionSolve skCapital = new SKCapitalSeguroCntbn(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);
            IContributionImplementacionSolve skCrea = new SkCreaCntbn(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);
            IContributionImplementacionSolve skVision = new SKVisionFlexCntbn(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);
            IContributionImplementacionSolve multitrust = new MultitrustCntbn(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);

            IContributionImplementacionSolve defaultContribution = new DefaultContribution(_log, _retailProxy.Object, _contributionParameters.Object, _webRetailPrxy.Object, _retailExtPrxy.Object);
            _blContributions[0] = capital;
            _blContributions[1] = capitalSeguro;
            _blContributions[2] = skCapital;
            _blContributions[3] = skCrea;
            _blContributions[4] = skVision;
            _blContributions[5] = multitrust;
            _blContributions[6] = defaultContribution;

            _parametersProxy = new Mock<IParametersProxy>();
            _notificationPrxy = new Mock<IClientContributionNotificationPrxy>();
            _mxAuthPrxy = new Mock<IClientContributionMxAuthPrxy>();

            _contributionsApp = new ClientContributionsApp(_blContributions, _log, _retailExtPrxy.Object, _webRetailPrxy.Object, _retailProxy.Object,
                _parametersProxy.Object, _notificationPrxy.Object, _mxAuthPrxy.Object, _contributionParameters.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            _contractId = "562969";
            _emtyContractId = "";
        }

        #region ValidateApplyContributions Method
        [TestMethod, TestCategory("ValidateApplyContributions")]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateApplyContributionsEmptyContractId()
        {
            var resultValidate = _contributionsApp.ValidateApplyContributions(_emtyContractId, out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("ValidateApplyContributions")]
        public void ValidateApplyContributionsSuccessScheduleTrue()
        {
            GetSegmentByContractId(0); //por default, este metodo es generico para todos y no es necesario hacer pruebas en todas las implementaciones
            GetPlanIdByContractId();
            GetApplyPlans();
            GetApplyDomiciliationPlans();
            GetClientBankAccounts();
            ValidateContributionScheduleTrue();

            var resultValidate = _contributionsApp.ValidateApplyContributions(_contractId, out OperationResult result);
            Assert.IsNotNull(resultValidate);
            Assert.IsTrue(resultValidate.IsContributionValidate);
            Assert.IsTrue(result.Successful);
        }


        [TestMethod, TestCategory("ValidateApplyContributions")]
        public void ValidateApplyContributionsSuccessScheduleFalse()
        {
            GetSegmentByContractId(0); //por default, este metodo es generico para todos y no es necesario hacer pruebas en todas las implementaciones
            GetPlanIdByContractId();
            GetApplyPlans();
            GetApplyDomiciliationPlans();
            GetClientBankAccounts();
            ValidateContributionScheduleFalse();

            var resultValidate = _contributionsApp.ValidateApplyContributions(_contractId, out OperationResult result);
            Assert.IsNotNull(resultValidate);
            Assert.IsFalse(resultValidate.IsContributionValidate);
            Assert.IsFalse(string.IsNullOrEmpty(resultValidate.MessageMotive));
            Assert.IsTrue(result.Successful);
        }


        [TestMethod, TestCategory("ValidateApplyDomiciliations")]
        public void ValidateApplyDomiciliationsuccessScheduleTrue()
        {
            GetSegmentByContractId(0); //por default, este metodo es generico para todos y no es necesario hacer pruebas en todas las implementaciones
            GetPlanIdByContractId();
            GetApplyPlans();
            GetApplyDomiciliationPlans();
            GetClientBankAccounts();
            ValidateContributionScheduleTrue();

            var resultValidate = _contributionsApp.ValidateApplyContributions(_contractId, out OperationResult result);
            Assert.IsNotNull(resultValidate);
            Assert.IsTrue(resultValidate.IsContributionValidate);
            Assert.IsTrue(resultValidate.IsDomiciliationValidate);
            Assert.IsTrue(result.Successful);
        }


        [TestMethod, TestCategory("ValidateApplyDomiciliations")]
        public void ValidateApplyDomiciliationsSuccessScheduleFalse()
        {
            GetSegmentByContractId(0); //por default, este metodo es generico para todos y no es necesario hacer pruebas en todas las implementaciones
            GetPlanIdByContractId();
            GetApplyPlans();
            GetApplyDomiciliationPlans();
            GetClientBankAccounts();
            ValidateContributionScheduleFalse();

            var resultValidate = _contributionsApp.ValidateApplyContributions(_contractId, out var result);
            Assert.IsNotNull(resultValidate);
            Assert.IsFalse(resultValidate.IsContributionValidate);
            Assert.IsFalse(resultValidate.IsDomiciliationValidate);
            Assert.IsFalse(string.IsNullOrEmpty(resultValidate.MessageMotive));
            Assert.IsTrue(result.Successful);
        }

        #endregion

        #region GetContributionConfig Method
        [TestMethod, TestCategory("GetContributionConfig")]
        [ExpectedException(typeof(ArgumentException))]
        public void GetContributionConfigEmtyContractFail()
        {
            var resultConfig = _contributionsApp.GetContributionConfig(_emtyContractId, out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("GetContributionConfig")]
        [DataRow(0)]
        [DataRow(109)]
        [DataRow(8)]
        [DataRow(11)]
        [DataRow(14)]
        [DataRow(15)]
        [DataRow(22)]
        public void GetContributionConfigSuccess(int segmentType)
        {
            GetSegmentByContractId(segmentType);
            GetPlanIdByContractId();
            GetContractContribution();
            GetAllowAmounts();
            GetComissionByContractId();
            GetCommitedAmount();
            GetAmountDue();
            GetClientBankAccounts();
            GetDaysCalendar();

            var resultConfig = _contributionsApp.GetContributionConfig(_contractId, out OperationResult result);
            Assert.IsNotNull(resultConfig);
            Assert.IsTrue(result.Successful);
        }
        #endregion

        #region GeneraContribution
        [TestMethod, TestCategory("GeneraContribution")]
        [DataRow("", 2500, "01232654125")]
        [DataRow("562969", 0, "01232654125")]
        [DataRow("562969", 2500, "")]
        //[ExpectedException(typeof(ArgumentException))]
        public void GeneraContributionFailEmptyParameters(string contractId, double amount, string accountClient)
        {
            ContributionClientPrxyInfo contribution = new ContributionClientPrxyInfo()
            {
                ContractId = contractId,
                Amount = amount,
                AccountClient = accountClient,
                DateContribution = DateTime.Now,
                BankAccountTypeId = 15,
                BankClientId = 10,
                TypeContribution = "",
                UserId = ""
            };
            var resultGeneraContribution = _contributionsApp.GeneraContribution(contribution);

            Assert.IsFalse(resultGeneraContribution.Successful);
            Assert.IsNotNull(resultGeneraContribution.SystemMessages);
        }

        [TestMethod, TestCategory("GeneraContribution")]
        public void GeneraContributionFailProxy()
        {
            ContributionClientPrxyInfo contribution = new ContributionClientPrxyInfo()
            {
                ContractId = _contractId,
                Amount = 2500,
                AccountClient = "01232654125",
                DateContribution = DateTime.Today,
                BankAccountTypeId = 15,
                BankClientId = 10,
                TypeContribution = "Ahorro Adicional",
                UserId = "DORJ860703D32"
            };

            GeneraContributionFail();

            var resultGeneraContribution = _contributionsApp.GeneraContribution(contribution);

            Assert.IsFalse(resultGeneraContribution.Successful);
        }

        [TestMethod, TestCategory("GeneraContribution")]
        public void GeneraContributionSuccess()
        {
            ContributionClientPrxyInfo contribution = new ContributionClientPrxyInfo()
            {
                ContractId = _contractId,
                Amount = 2500,
                AccountClient = "01232654125",
                DateContribution = DateTime.Now,
                BankAccountTypeId = 15,
                BankClientId = 10,
                TypeContribution = "Ahorro Adicional",
                UserId = "DORJ860703D32"
            };

            ContributionClientInformation information =
                ContributionClientInformation.Create(_contractId)
                .SetAmountDateInfo(2500, DateTime.Now)
                .SetBankInfo(15, 10, "01232654125")
                .SetAdditionalInfo("Ahorro Adicional", "DORJ860703D32");

            InsertLog();
            GeneraContribution(information);
            GetClientInfo();
            GetBinaryParameter();
            GetStringParameter();
            SendNotificationsAppSync();
            var resultGeneraContribution = _contributionsApp.GeneraContribution(contribution);

            Assert.IsTrue(resultGeneraContribution.Successful);
        }
        #endregion

        #region DomiciliationsClient

        [TestMethod, TestCategory("Domiciliations")]
        public void GetDomiciliationsByContract()
        {
            var result = new OperationResult() { Successful = true };
            _retailProxy.Setup(c => c.GetDomiciliationsByContract(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), out result)).Returns(Mock.Of<List<ClientDomiciliation>>());
            _retailProxy.Setup(c => c.GetBankCatalog(out result)).Returns(Mock.Of<List<BankCatalogPrxy>>());
            _retailExtPrxy.Setup(c => c.GetDomiciliationsHsbcByContract(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), out result)).Returns(Mock.Of<List<ClientDomiciliation>>());
            _retailExtPrxy.Setup(c => c.GetDomiciliationsSantanderByContract(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), out result)).Returns(Mock.Of<List<ClientDomiciliation>>());
            var clientDomiciliations = _contributionsApp.GetDomiciliationsByContract("897071", "BEEJ930917SW1", true, out result);
            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(clientDomiciliations);
        }

        [TestMethod, TestCategory("Domiciliations")]
        public void GetAllFrecuencyTypeCatalogForDomi()
        {
            var result = new OperationResult() { Successful = true };
            const string clientIdentifier = "BEEJ930917SW1";
            const string contractId = "727599";
            const short planId = 690;
            const short planBasId = 690;
            var contractInfo = ContractInfo.Create(contractId, planBasId, 10, "727600", DateTime.Today);
            var planBasIds = new List<short>() { contractInfo.PlanBasId };
            var planInfo = PlanInfo
                .Create(planId.ToString(), "MAESTRA CEA SKANDIA CREA 2", "SKCREA CEA-MT 2", planBasId.ToString())
                .SetComercialInfo(15, "SKANDIA CREA")
                .SetPlanClasification(10, 1);
            var frecuencyTypeCatalogs = new List<FrecuencyTypeCatalog>()
            {
                FrecuencyTypeCatalog.Create(10, "Frecuencia Mensual", "Mensual")
                , FrecuencyTypeCatalog.Create(30, "Frecuencia Semestral", "Semestral")
                , FrecuencyTypeCatalog.Create(40, "Frecuencia Trimestral", "Trimestral")
                , FrecuencyTypeCatalog.Create(45, "Frecuencia Anual", "Anual")
            };

            var applyPlanFrecuencyTypes = new List<DomiFrecuencyTypesPlansParameter>()
            {
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 10, Plans = new List<string>(){ "645", "750"}},
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 30},
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 40},
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 45}
            };



            _retailProxy.Setup(c => c.GetContractInfo(contractId, clientIdentifier, out result)).Returns(contractInfo);
            _retailExtPrxy.Setup(c => c.GetPlansById(planBasIds, out result)).Returns(new List<PlanInfo>() { planInfo });
            _retailProxy.Setup(c => c.GetFrecuencyTypeCatalogForDomi(out result)).Returns(frecuencyTypeCatalogs);
            _contributionParameters.Setup(c => c.GetApplyPlanFrecuencyTypes()).Returns(applyPlanFrecuencyTypes);

            var response = _contributionsApp.GetFrecuencyTypeCatalogForDomi(contractId, clientIdentifier, out var resultValidation);
            Assert.IsTrue(resultValidation.Successful);
            Assert.IsNotNull(response);
        }

        [TestMethod, TestCategory("Domiciliations")]
        public void GetCustomFrecuencyTypeCatalogForDomi()
        {
            var result = new OperationResult() { Successful = true };
            const string clientIdentifier = "BEEJ930917SW1";
            const string contractId = "727599";
            const short planId = 750;
            const short planBasId = 750;
            var contractInfo = ContractInfo.Create(contractId, planBasId, 10, "727600", DateTime.Today);
            var planBasIds = new List<short>() { contractInfo.PlanBasId };
            var planInfo = PlanInfo
                .Create(planId.ToString(), "MAESTRA CEA SKANDIA CREA 2", "SKCREA CEA-MT 2", planBasId.ToString())
                .SetComercialInfo(15, "SKANDIA CREA")
                .SetPlanClasification(10, 1);
            var frecuencyTypeCatalogs = new List<FrecuencyTypeCatalog>()
            {
                FrecuencyTypeCatalog.Create(10, "Frecuencia Mensual", "Mensual")
                , FrecuencyTypeCatalog.Create(30, "Frecuencia Semestral", "Semestral")
                , FrecuencyTypeCatalog.Create(40, "Frecuencia Trimestral", "Trimestral")
                , FrecuencyTypeCatalog.Create(45, "Frecuencia Anual", "Anual")
            };

            var applyPlanFrecuencyTypes = new List<DomiFrecuencyTypesPlansParameter>()
            {
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 10, Plans = new List<string>(){ "645", "750"}},
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 30},
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 40},
                new DomiFrecuencyTypesPlansParameter{FrecuencyTypeId = 45}
            };

            _retailProxy.Setup(c => c.GetContractInfo(contractId, clientIdentifier, out result)).Returns(contractInfo);
            _retailExtPrxy.Setup(c => c.GetPlansById(planBasIds, out result)).Returns(new List<PlanInfo>() { planInfo });
            _retailProxy.Setup(c => c.GetFrecuencyTypeCatalogForDomi(out result)).Returns(frecuencyTypeCatalogs);
            _contributionParameters.Setup(c => c.GetApplyPlanFrecuencyTypes()).Returns(applyPlanFrecuencyTypes);

            var response = _contributionsApp.GetFrecuencyTypeCatalogForDomi(contractId, clientIdentifier, out var resultValidation);
            Assert.IsTrue(resultValidation.Successful);
            Assert.IsNotNull(response);
        }



        [TestMethod, TestCategory("Domiciliations")]
        public void GetSalesforceLastPendingCase()
        {
            var result = new OperationResult() { Successful = true };
            var sfLastPendingR = new SalesforceLastPendingCaseRequest
            {
                ContractId = "727599",
                ClientIdentifier = "BEEJ930917SW1",
                Issue = "BAJA DOMI/727599",
                OriginCase = "Skandianet",
                Category = "Cliente",
                OriginType = "Solicitudes - Web / email",
                CaseType = "Instrucciones",
                SubType = "Cambio de domiciliación",
                Tracing = "Contratos"
            };

            _retailExtPrxy.Setup(c => c.GetSalesforceLastPendingCase(It.IsAny<SalesforceCaseRequest>(), out result)).Returns(Mock.Of<List<SalesforceCase>>());
            var frecuencyTypeCatalogs = _contributionsApp.GetSalesforceLastPendingCase(sfLastPendingR, out var resultValidation);
            Assert.IsTrue(resultValidation.Successful);
            Assert.IsNotNull(frecuencyTypeCatalogs);
        }

        #endregion

        #region Mocks
        public void GetSegmentByContractId(int segmentImplementation)
        {
            _retailExtPrxy.Setup(x => x.GetSegmentByContractId(_contractId))
                .Returns(segmentImplementation);
        }

        public void GetPlanIdByContractId()
        {
            ContributionProductInfo productInfo = ContributionProductInfo.Create(480, 10, "Capital Plus", 480);
            _webRetailPrxy.Setup(x => x.GetPlanIdByContractId(_contractId))
                .Returns(productInfo);
        }

        public void GetApplyPlans()
        {
            _contributionParameters.Setup(x => x.GetApplyPlans())
                .Returns(new List<string> { "480", "527", "785" });
        }

        private void GetClientBankAccounts()
        {
            ClientBankAccountsContributions clientBank =
                ClientBankAccountsContributions.Create(_contractId)
                    .SetAccountData(15, "01236254125", 10);
            List<ClientBankAccountsContributions> clientBanks = new List<ClientBankAccountsContributions> { clientBank };
            _retailProxy.Setup(x => x.GetClientBankAccounts(_contractId))
                .Returns(clientBanks);
        }

        private void GetContractContribution()
        {
            string contractAdditional = string.Empty;
            _retailProxy.Setup(x => x.GetContractContribution(_contractId, 10, out contractAdditional))
                .Callback(() => contractAdditional = "569563")
                .Returns(_contractId);
        }

        private void GetAllowAmounts()
        {
            ContributionMinMaxAmount amount = ContributionMinMaxAmount.Create(1500, 50000);
            _retailProxy.Setup(x => x.GetAllowAmounts())
                .Returns(amount);
        }

        private void GetComissionByContractId()
        {
            _retailProxy.Setup(x => x.GetComissionByContractId(_contractId))
                .Returns(2);
        }

        private void GetCommitedAmount()
        {
            _retailProxy.Setup(x => x.GetCommitedAmount(_contractId))
                .Returns(2);
        }

        private void GetAmountDue()
        {
            _retailProxy.Setup(x => x.GetAmountDue(_contractId))
                .Returns(2);
        }

        private void GetDaysCalendar()
        {
            string days = "01111100111110011111001111100111110001111001111100111110011111001111100111110001111001111100111000011111001111100111110001111001111100111110011111001111100111110011111001111100111110011111001111100111110011111001111100111110011111001111100111110011111001111100111110011111001111100111110011111001111100111010011111001111100011110011111001111100101110011111000111100";
            _retailProxy.Setup(x => x.GetDaysCalendar(DateTime.Today.Year))
                .Returns(days);
        }

        private void GeneraContributionFail()
        {
            OperationResult result = new OperationResult();
            _retailProxy.Setup(x => x.GeneraContribution(It.IsAny<ContributionClientInformation>(), out result))
                .Callback(() => { result.Successful = false; })
                .Returns(string.Empty);
        }

        private void GeneraContribution(ContributionClientInformation clientInformation)
        {
            OperationResult result = new OperationResult();
            _retailProxy.Setup(x => x.GeneraContribution(clientInformation, out result))
                .Callback(() => { result.Successful = true; })
                .Returns("<DomiciliationOnDemandLogRequest></DomiciliationOnDemandLogRequest>");
        }

        private void InsertLog()
        {
            OperationResult result = new OperationResult() { Successful = true };
            _retailProxy.Setup(x => x.InsertLog(""))
                .Returns(result);
        }

        private void GetClientInfo()
        {
            ContributionContactClient contactClient = ContributionContactClient.Create("correo@skandia.com.mx", "Nombre", "Apellido");
            _mxAuthPrxy.Setup(x => x.GetClientInfo(_contractId))
                .Returns(contactClient);
        }

        private void GetBinaryParameter()
        {
            OperationResult result = new OperationResult() { Successful = true };
            _parametersProxy.Setup(x => x.GetBinaryParameter("APORTEPL", "", "", "Retail", "Standar", out result))
                .Returns("pametro binario");
        }

        private void GetStringParameter()
        {
            OperationResult result = new OperationResult() { Successful = true };
            _parametersProxy.Setup(x => x.GetStringParameter("APORTECNFG", "", "", "Retail", "Standar", out result))
                .Returns("string");
        }

        private void SendNotificationsAppSync()
        {
            OperationResult result = new OperationResult() { Successful = true };
            var request = new Dictionary<string, object>(){
                { "emailConfig", "configuracion email"},
                { "htmlTemplate", "htmlTemplate" },
                { "email", "email@skandia.com.mx" },
                { "templateData", "parametros template" }
            };
            _notificationPrxy.Setup(x => x.SendNotificationsAppSync(request))
                .Returns(result);
        }

        private void ValidateContributionScheduleTrue()
        {
            string initSchedule = "8:00", endEchedule = "22:00";
            _retailExtPrxy.Setup(x => x.ValidateContributionSchedule(out initSchedule, out endEchedule))
                .Callback(() => { initSchedule = "8:00"; endEchedule = "22:00"; })
                .Returns(true);
        }

        private void ValidateContributionScheduleFalse()
        {
            string initSchedule = "8:00", endEchedule = "22:00";
            _retailExtPrxy.Setup(x => x.ValidateContributionSchedule(out initSchedule, out endEchedule))
                .Callback(() => { initSchedule = "8:00"; endEchedule = "22:00"; })
                .Returns(false);
        }

        public void GetApplyDomiciliationPlans()
        {
            _contributionParameters.Setup(x => x.GetApplyDomiciliationsPlans())
                .Returns(new List<string> { "480", "527", "785" });
        }

        #endregion
    }
}
