﻿using ClientContributions.Proxies;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Application.ProductsImplementacion
{
    public class DefaultContribution : ContributionImplementacionSolve
    {
        public readonly int _contractSegment = 0;

        private readonly IClientContributionRetailPrxy _retailPrxy;
        private readonly ISeriLogHelper _log;
        private readonly IClientContributionParametersPrxy _parametersPrxy;
        private readonly IClientContributionWebRetailPrxy _webRetailPrxy;
        private readonly IClientContributionsRetailExtPrxy retailExtPrxy;

        public DefaultContribution(ISeriLogHelper log, IClientContributionRetailPrxy retailProxy, IClientContributionParametersPrxy parametersProxy, 
            IClientContributionWebRetailPrxy webRetailProxy, IClientContributionsRetailExtPrxy retailExtPrxy)
            : base(log, retailProxy, parametersProxy, webRetailProxy, retailExtPrxy)
        {
            _log = log;
            _retailPrxy = retailProxy;
            _parametersPrxy = parametersProxy;
            _webRetailPrxy = webRetailProxy;
            this.retailExtPrxy = retailExtPrxy;
        }

        public override bool AppliesTo(int contractSegment)
        {
            return true;
        }
    }
}
