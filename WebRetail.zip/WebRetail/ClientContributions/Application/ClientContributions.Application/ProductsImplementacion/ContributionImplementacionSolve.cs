﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ClientContributionsValidateAggregate;
using ClientContributions.Domain.ContributionProductInfoAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Proxies;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;

namespace ClientContributions.Application
{
    public abstract class ContributionImplementacionSolve : IContributionImplementacionSolve
    {
        private readonly IClientContributionRetailPrxy _retailPrxy;
        private readonly ISeriLogHelper _log;
        private readonly IClientContributionParametersPrxy _parametersPrxy;
        private readonly IClientContributionWebRetailPrxy _webRetailPrxy;
        private readonly IClientContributionsRetailExtPrxy _retailExtPrxy;

        public ContributionImplementacionSolve(ISeriLogHelper seriLog, IClientContributionRetailPrxy retailPrxy, IClientContributionParametersPrxy parametersPrxy,
            IClientContributionWebRetailPrxy webRetailPrxy, IClientContributionsRetailExtPrxy retailExtPrxy)
        {
            _log = seriLog;
            _retailPrxy = retailPrxy;
            _parametersPrxy = parametersPrxy;
            _webRetailPrxy = webRetailPrxy;
            _retailExtPrxy = retailExtPrxy;
        }

        public abstract bool AppliesTo(int contractSegment);

        private delegate List<ClientBankAccountsContributions> delGetBanksAccounts(string contractId);
        private delegate List<string> delGetApplyContributionsPlans();
        private delegate ContributionProductInfo delGetPlanIdByContract(string contractId);
        private delegate bool delValidateSchedule(out string initSchedule, out string endSchedule);

        private delegate List<string> delGetApplyDomiciliationsPlans();
        public ClientContributionsValidate ValidateApplyContributions(string contractId, out OperationResult result)
        {
            ClientContributionsValidate contributionsValidate = null;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo el ID del plan");
                delGetPlanIdByContract delGetPlanIdByContract = _webRetailPrxy.GetPlanIdByContractId;
                IAsyncResult asyncGetPlanId = delGetPlanIdByContract.BeginInvoke(contractId, null, null);

                _log.Info("Obteniendo los planes que aplican para realizar contribuciones.");
                delGetApplyContributionsPlans delGetApplyContributionsPlans = _parametersPrxy.GetApplyPlans;
                IAsyncResult asyncGetApplyPlans = delGetApplyContributionsPlans.BeginInvoke(null, null);

                _log.Info("Obteniendo las cuentas bancarias asociadas al contrato.");
                delGetBanksAccounts delGetBanksAccounts = _retailPrxy.GetClientBankAccounts;
                IAsyncResult asyncGetBanksAccounts = delGetBanksAccounts.BeginInvoke(contractId, null, null);

                _log.Info("Validando el horario para la aportacion");
                delValidateSchedule delValidateSchedule = _retailExtPrxy.ValidateContributionSchedule;
                IAsyncResult asyncValidateSchedule = delValidateSchedule.BeginInvoke(out string initSchedule, out string endEchedule, null, null);

                while (!asyncGetBanksAccounts.IsCompleted || !asyncGetApplyPlans.IsCompleted
                    || !asyncGetPlanId.IsCompleted || !asyncValidateSchedule.IsCompleted) { Thread.Sleep(20); }

                var planInfo = delGetPlanIdByContract.EndInvoke(asyncGetPlanId);
                _log.Debug("Id plan: {cntx}", planInfo);

                var plansApplyContribution = delGetApplyContributionsPlans.EndInvoke(asyncGetApplyPlans);
                _log.Debug("Planes aplican contribucion: {cntx}", plansApplyContribution);

                var banksAccounts = delGetBanksAccounts.EndInvoke(asyncGetBanksAccounts);
                _log.Debug("Cuentas bancarias asociadas: {cntx}", banksAccounts);

                var applySchecule = delValidateSchedule.EndInvoke(out initSchedule, out endEchedule, asyncValidateSchedule);
                _log.Debug("Aplica horario {cntx}", applySchecule);

                _log.Info("Obteniendo los planes que aplican para realizar contribuciones.");
                delGetApplyDomiciliationsPlans delGetApplyDomiciliationsPlans = _parametersPrxy.GetApplyDomiciliationsPlans;
                var asyncGetApplyDomiciliationsPlans = delGetApplyDomiciliationsPlans.BeginInvoke(null, null);
                while (!asyncGetApplyDomiciliationsPlans.IsCompleted) { Thread.Sleep(20); }
                var plansApplyForDomiciliations = delGetApplyDomiciliationsPlans.EndInvoke(asyncGetApplyDomiciliationsPlans);
                _log.Debug("Planes aplican domiciliacion: {cntx}", plansApplyForDomiciliations);

                contributionsValidate = ClientContributionsValidate.Create(planInfo.Id.ToString())
                    .SetApplyPlans(plansApplyContribution)
                    .SetApplyDomiciliationsPlans(plansApplyForDomiciliations)
                    .SetBankAccounts(banksAccounts)
                    .SetEnabledSchedule(initSchedule, endEchedule, applySchecule)
                    .ValidateApplyContributions()
                    .ValidateApplyDomiciliations();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al valir contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return contributionsValidate;
        }

        public ContributionMinMaxAmount GetContributionMinMaxAmount(out OperationResult result)
        {
            ContributionMinMaxAmount contributionMinMax = null;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo montos minimo y maximo permitidos.");
                contributionMinMax = _retailPrxy.GetAllowAmounts();
                _log.Debug("Montos permitidos {ctnx}", contributionMinMax);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los montos permitidos para aportacion");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return contributionMinMax;
        }

        public virtual ContributionComission GetContributionComission(string contractId, out OperationResult result)
        {
            ContributionComission contributionComission = null;
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Creando objeto con los datos, ya que esta implementacion no implica tener comision.");
                contributionComission = ContributionComission.Create(0);
                _log.Debug("comision: {cntx}", contributionComission);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la comision para el contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return contributionComission;
        }

        public virtual ContributionCommitedAmount GetCommitedAmount(string contractContributionId, string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            return ContributionCommitedAmount.Create(0);
        }

        public virtual ContributionAmountDue GetAmountDue(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            return ContributionAmountDue.Create(0);
        }

        public virtual int GetDomiciliationType(out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Buscando en configuración el tipo de domiciliación, default implementation");
                int domiciliationTypeId = int.Parse(string.Format("{0}", ConfigurationManager.AppSettings["DomiciliationTypeMonthly"]));
                _log.Info("Tipo de domiciliación: {cntx}", domiciliationTypeId);
                return domiciliationTypeId;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el tipo de domiciliación para la implementación por default");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
                throw ex;
            }
        }
    }
}
