﻿using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Proxies;
using Common.Domain;
using SeriLogH;
using System;
using System.Configuration;

namespace ClientContributions.Application.ProductsImplementacion
{
    public class SkCreaMetasCntbn : ContributionImplementacionSolve
    {
        public readonly int _contractSegment = 227;
        private readonly IClientContributionRetailPrxy _retailPrxy;
        private readonly ISeriLogHelper _log;
        private readonly IClientContributionParametersPrxy _parametersPrxy;
        private readonly IClientContributionWebRetailPrxy _webRetailPrxy;
        private readonly IClientContributionsRetailExtPrxy retailExtPrxy;

        public SkCreaMetasCntbn(ISeriLogHelper log, IClientContributionRetailPrxy retailProxy, IClientContributionParametersPrxy parametersProxy,
            IClientContributionWebRetailPrxy webRetailProxy, IClientContributionsRetailExtPrxy retailExtPrxy)
            : base(log, retailProxy, parametersProxy, webRetailProxy, retailExtPrxy)
        {
            _log = log;
            _retailPrxy = retailProxy;
            _parametersPrxy = parametersProxy;
            _webRetailPrxy = webRetailProxy;
            this.retailExtPrxy = retailExtPrxy;
        }

        public override bool AppliesTo(int contractSegment)
        {
            return _contractSegment.Equals(contractSegment);
        }

        public override ContributionCommitedAmount GetCommitedAmount(string contractContributionId, string contractId, out OperationResult result)
        {
            ContributionCommitedAmount commitedAmount = null;
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo el monto comprometido");
                var amount = _retailPrxy.GetCommitedAmount(contractContributionId);
                _log.Debug("monto comprometido: {cntx}", amount);

                commitedAmount = ContributionCommitedAmount.Create(amount);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto comprometido del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return commitedAmount;
        }

        public override int GetDomiciliationType(out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Buscando en configuración el tipo de domiciliación");
                int domiciliationTypeId = int.Parse(string.Format("{0}", ConfigurationManager.AppSettings["DomiciliationTypeReserves"]));
                _log.Info("Tipo de domiciliación: {cntx}", domiciliationTypeId);
                return domiciliationTypeId;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el tipo de domiciliación para la implementación {implementation}", new { this._contractSegment });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
                throw ex;
            }
        }
    }
}
