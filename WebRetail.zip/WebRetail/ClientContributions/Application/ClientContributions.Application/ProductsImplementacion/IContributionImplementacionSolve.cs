﻿using ClientContributions.Domain.ClientContributionsValidateAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using Common.Domain;

namespace ClientContributions.Application
{
    public interface IContributionImplementacionSolve
    {
        bool AppliesTo(int contractSegment);
        ClientContributionsValidate ValidateApplyContributions(string contractId, out OperationResult result);
        ContributionMinMaxAmount GetContributionMinMaxAmount(out OperationResult result);
        ContributionComission GetContributionComission(string contractId, out OperationResult result);
        ContributionCommitedAmount GetCommitedAmount(string contractContributionId, string contractId, out OperationResult result);
        ContributionAmountDue GetAmountDue(string contractId, out OperationResult result);
        int GetDomiciliationType( out OperationResult result);
    }
}
