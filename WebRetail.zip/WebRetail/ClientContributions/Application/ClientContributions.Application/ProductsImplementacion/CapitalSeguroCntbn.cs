﻿using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Proxies;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Application.ProductsImplementacion
{
    public class CapitalSeguroCntbn : ContributionImplementacionSolve
    {
        public readonly int _contractSegment = 8;
        private readonly IClientContributionRetailPrxy _retailPrxy;
        private readonly ISeriLogHelper _log;
        private readonly IClientContributionParametersPrxy _parametersPrxy;
        private readonly IClientContributionWebRetailPrxy _webRetailPrxy;
        private readonly IClientContributionsRetailExtPrxy retailExtPrxy;

        public CapitalSeguroCntbn(ISeriLogHelper log, IClientContributionRetailPrxy retailProxy, IClientContributionParametersPrxy parametersProxy, 
            IClientContributionWebRetailPrxy webRetailProxy, IClientContributionsRetailExtPrxy retailExtPrxy)
            : base(log, retailProxy, parametersProxy, webRetailProxy, retailExtPrxy)
        {
            _log = log;
            _retailPrxy = retailProxy;
            _parametersPrxy = parametersProxy;
            _webRetailPrxy = webRetailProxy;
            this.retailExtPrxy = retailExtPrxy;
        }

        public override bool AppliesTo(int contractSegment)
        {
            return _contractSegment.Equals(contractSegment);
        }

        public override ContributionComission GetContributionComission(string contractId, out OperationResult result)
        {
            ContributionComission contributionComission = null;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo la comision del contrato: {cntx}", contractId);
                var comission = _retailPrxy.GetComissionByContractId(contractId);
                _log.Debug("comision: {cntx}", comission);
                contributionComission = ContributionComission.Create(comission);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al obtener la comision del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }
            return contributionComission;
        }
    }
}
