﻿using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Proxies;
using Common.Domain;
using SeriLogH;
using System;

namespace ClientContributions.Application.ProductsImplementacion
{
    public class SKVisionFlexCntbn : ContributionImplementacionSolve
    {
        public readonly int _contractSegment = 22;
        private readonly IClientContributionRetailPrxy _retailPrxy;
        private readonly ISeriLogHelper _log;
        private readonly IClientContributionParametersPrxy _parametersPrxy;
        private readonly IClientContributionWebRetailPrxy _webRetailPrxy;
        private readonly IClientContributionsRetailExtPrxy retailExtPrxy;

        public SKVisionFlexCntbn(ISeriLogHelper log, IClientContributionRetailPrxy retailProxy, IClientContributionParametersPrxy parametersProxy,
            IClientContributionWebRetailPrxy webRetailProxy, IClientContributionsRetailExtPrxy retailExtPrxy)
            : base(log, retailProxy, parametersProxy, webRetailProxy, retailExtPrxy)
        {
            _log = log;
            _retailPrxy = retailProxy;
            _parametersPrxy = parametersProxy;
            _webRetailPrxy = webRetailProxy;
            this.retailExtPrxy = retailExtPrxy;
        }

        public override bool AppliesTo(int contractSegment)
        {
            return _contractSegment.Equals(contractSegment);
        }

        public override ContributionCommitedAmount GetCommitedAmount(string contractContributionId, string contractId, out OperationResult result)
        {
            ContributionCommitedAmount commitedAmount = null;
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo el monto comprometido");
                var amount = retailExtPrxy.GetCommitedAmount(contractId, out result);
                _log.Debug("monto comprometido: {cntx}", amount);

                commitedAmount = ContributionCommitedAmount.Create(amount);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto comprometido del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return commitedAmount;
        }

        public override ContributionAmountDue GetAmountDue(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            ContributionAmountDue amountDue = null;

            try
            {
                _log.Info("Obteniendo el montos de las aportaciones vencidas");
                var amount = _retailPrxy.GetAmountDue(contractId);
                _log.Debug("Monto vencido: {cntx}", amount);

                amountDue = ContributionAmountDue.Create(amount);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto vencido del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return amountDue;
        }

    }
}
