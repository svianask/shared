﻿using ClientContributions.Domain.ClientContributionsValidateAggregate;
using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using ClientContributions.Domain.SalesforceAggregate;
using ClientContributions.Messages;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Application
{
    public interface IClientContributionsApp
    {
        ClientContributionsValidate ValidateApplyContributions(string contractId, out OperationResult result);
        ContributionConfig GetContributionConfig(string contractId, out OperationResult result);
        OperationResult GeneraContribution(ContributionClientPrxyInfo clientInformation);
        bool HasProgrammedPayment(string clientId, string contractId, out OperationResult result);
        List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result);
        List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi(string contractId, string clientIdentifier, out OperationResult result);
        List<SalesforceCase> GetSalesforceLastPendingCase(SalesforceLastPendingCaseRequest request, out OperationResult result);
    }
}
