﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ClientContributionsValidateAggregate;
using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContributionContactClientAggregate;
using ClientContributions.Domain.ContributionNotificationAggregate;
using ClientContributions.Domain.ContributionProductInfoAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using ClientContributions.Domain.SalesforceAggregate;
using ClientContributions.Messages;
using ClientContributions.Proxies;
using Common.Domain;
using Common.Proxy;
using Newtonsoft.Json;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace ClientContributions.Application
{
    public class ClientContributionsApp : IClientContributionsApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientContributionsRetailExtPrxy _retailExtPrxy;
        private readonly IClientContributionWebRetailPrxy _webRetailPrxy;
        private readonly IClientContributionRetailPrxy _retailProxy;
        private readonly IContributionImplementacionSolve[] _blContributions;
        private readonly IParametersProxy _parametersProxy;
        private readonly IClientContributionNotificationPrxy _notificationPrxy;
        private readonly IClientContributionMxAuthPrxy _mxAuthPrxy;
        private readonly IClientContributionParametersPrxy _clientContributionParametersPrxy;
        public ClientContributionsApp(IContributionImplementacionSolve[] implementacionSolve, ISeriLogHelper log, IClientContributionsRetailExtPrxy retailExtPrxy,
            IClientContributionWebRetailPrxy webRetailPrxy, IClientContributionRetailPrxy retailPrxy, IParametersProxy parametersProxy,
            IClientContributionNotificationPrxy notificationPrxy, IClientContributionMxAuthPrxy mxAuthPrxy,
            IClientContributionParametersPrxy clientContributionParametersPrxy)
        {
            _blContributions = implementacionSolve;
            _log = log;
            _retailExtPrxy = retailExtPrxy;
            _webRetailPrxy = webRetailPrxy;
            _retailProxy = retailPrxy;
            _parametersProxy = parametersProxy;
            _notificationPrxy = notificationPrxy;
            _mxAuthPrxy = mxAuthPrxy;
            _clientContributionParametersPrxy = clientContributionParametersPrxy;
        }

        public ClientContributionsValidate ValidateApplyContributions(string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            ClientContributionsValidate contributionsValidate = null;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo el segmento del contrato");
                var segmentType = _retailExtPrxy.GetSegmentByContractId(contractId);
                _log.Debug("Segmento: {ctnx}", segmentType);

                _log.Info("Obteniendo la implementacion de acuerdo al segmento");
                IContributionImplementacionSolve implementacionSolve = _blContributions.FirstOrDefault(x => x.AppliesTo(segmentType));
                _log.Debug("{ctnx}", implementacionSolve);

                contributionsValidate = implementacionSolve.ValidateApplyContributions(contractId, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al encontrar la implementacion correspondiente al contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return contributionsValidate;
        }

        private delegate int delGetSegmentByContractId(string contractId);
        private delegate ContributionProductInfo delGetPlanIdByContract(string contractId);
        private delegate ContributionComission delGetContributionComission(string contractId, out OperationResult result);
        private delegate ContributionMinMaxAmount delGetContributionMinMaxAmount(out OperationResult result);
        private delegate ContributionCommitedAmount delGetCommitedAmount(string contractContributionId, string contractId, out OperationResult result);
        private delegate ContributionAmountDue delGetAmountDue(string contractId, out OperationResult result);
        private delegate List<ClientBankAccountsContributions> delGetClientBankAccounts(string contractId);
        private delegate string delGetDaysCalendar(int year);
        private delegate int delGetMaxContributionHour();
        public ContributionConfig GetContributionConfig(string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            result = new OperationResult() { Successful = true };
            ContributionConfig config = null;
            try
            {
                _log.Info("Obteniendo el segmento del contrato");
                delGetSegmentByContractId delGetSegmentByContractId = _retailExtPrxy.GetSegmentByContractId;
                IAsyncResult asyncGetSegmentByContractId = delGetSegmentByContractId.BeginInvoke(contractId, null, null);

                _log.Info("Obteniendo la informacion del producto");
                delGetPlanIdByContract delGetPlanIdByContract = _webRetailPrxy.GetPlanIdByContractId;
                IAsyncResult asyncGetPlanIdByContract = delGetPlanIdByContract.BeginInvoke(contractId, null, null);

                while (!asyncGetSegmentByContractId.IsCompleted || !asyncGetPlanIdByContract.IsCompleted) { Thread.Sleep(20); }

                var segmentType = delGetSegmentByContractId.EndInvoke(asyncGetSegmentByContractId);
                var productInfo = delGetPlanIdByContract.EndInvoke(asyncGetPlanIdByContract);

                _log.Info("Obteniendo el contratp de aportaciones y el adicional");
                string contractContributionId = _retailProxy.GetContractContribution(contractId, productInfo.Platform, out string contractAdditional);

                _log.Info("Obteniendo la implementacion de acuerdo al segmento");
                IContributionImplementacionSolve implementacionSolve = _blContributions.FirstOrDefault(x => x.AppliesTo(segmentType));
                _log.Debug("{ctnx}", implementacionSolve);

                _log.Info("Obteniendo los datos para aportaciones.");
                delGetContributionMinMaxAmount delGetContributionMinMaxAmount = implementacionSolve.GetContributionMinMaxAmount;
                IAsyncResult asyncGetContributionMinMaxAmount = delGetContributionMinMaxAmount.BeginInvoke(out OperationResult resultAmountsMinMax, null, null);

                _log.Info("Obteniendo la comision.");
                delGetContributionComission delGetContributionComission = implementacionSolve.GetContributionComission;
                IAsyncResult asyncGetContributionComission = delGetContributionComission.BeginInvoke(contractId, out OperationResult resultComission, null, null);

                _log.Info("Obteniendo el monto comprometido");
                delGetCommitedAmount delGetCommitedAmount = implementacionSolve.GetCommitedAmount;
                IAsyncResult asyncGetCommitedAmount = delGetCommitedAmount.BeginInvoke(contractContributionId, contractId, out OperationResult resultCommitedAmount, null, null);

                _log.Info("Obteniendo el monto vencido.");
                delGetAmountDue delGetAmountDue = (string contractId1, out OperationResult result1) => implementacionSolve.GetAmountDue(contractId1, out result1);
                IAsyncResult asyncGetAmountDue = delGetAmountDue.BeginInvoke(contractContributionId, out OperationResult resultAmountDue, null, null);

                _log.Info("Obtiene las cuentas bancarias asociadas al contrato");
                delGetClientBankAccounts delGetClientBankAccounts = _retailProxy.GetClientBankAccounts;
                IAsyncResult asyncGetClientBankAccounts = delGetClientBankAccounts.BeginInvoke(contractId, null, null);

                delGetDaysCalendar delGetDaysCalendar = _retailProxy.GetDaysCalendar;
                IAsyncResult asyncGetDaysCalendar = delGetDaysCalendar.BeginInvoke(DateTime.Now.Year, null, null);

                delGetMaxContributionHour delGetMaxContributionHour = _clientContributionParametersPrxy.GetMaxContributionHour;
                IAsyncResult asyncGetMaxContributionHour = delGetMaxContributionHour.BeginInvoke(null, null);

                while (!asyncGetContributionMinMaxAmount.IsCompleted || !asyncGetContributionComission.IsCompleted
                    || !asyncGetCommitedAmount.IsCompleted || !asyncGetAmountDue.IsCompleted
                    || !asyncGetClientBankAccounts.IsCompleted || !asyncGetDaysCalendar.IsCompleted
                    || !asyncGetMaxContributionHour.IsCompleted) { Thread.Sleep(10); }




                var amountsMinMax = delGetContributionMinMaxAmount.EndInvoke(out resultAmountsMinMax, asyncGetContributionMinMaxAmount);
                _log.Debug("Montos minimos y maximos {cntx}", amountsMinMax);
                var comission = delGetContributionComission.EndInvoke(out resultComission, asyncGetContributionComission);
                _log.Debug("Comision {cntx}", comission);
                var commitedAmount = delGetCommitedAmount.EndInvoke(out resultCommitedAmount, asyncGetCommitedAmount);
                _log.Debug("Monto comprometido: {cntx}", commitedAmount);
                var amountDue = delGetAmountDue.EndInvoke(out resultAmountDue, asyncGetAmountDue);
                _log.Debug("Monto vensido: {cntx}", amountDue);

                var bankAccounts = delGetClientBankAccounts.EndInvoke(asyncGetClientBankAccounts);
                _log.Debug("Cuentas bancarias: {cntx}", bankAccounts);
                var stringCalendar = delGetDaysCalendar.EndInvoke(asyncGetDaysCalendar);
                _log.Debug("Calendario {cntx}", stringCalendar);
                var bussinesDays = CalendarAdjust(stringCalendar, DateTime.Now.Year);

                var maxContributionHour = delGetMaxContributionHour.EndInvoke(asyncGetMaxContributionHour);
                _log.Debug("Maximo horario de aportación {cntx}", maxContributionHour);

                config = ContributionConfig.Create(contractId, segmentType, productInfo.ComercialName)
                    .SetAllowsAmounts(amountsMinMax)
                    .SetCommision(comission)
                    .SetCommiteAmount(commitedAmount)
                    .SetAmountDue(amountDue)
                    .SetBankAccounts(bankAccounts)
                    .SetAddittionalContracts(ContributionaAdditionalContracts.Create(contractAdditional, contractContributionId))
                    .SetBussinesDays(bussinesDays)
                    .SetMaxContributionHour(maxContributionHour);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los datos para la aportacion  del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return config;
        }

        private ContributionBusinessDays CalendarAdjust(string calendar, int year)
        {
            var lstDays = calendar.Select(c => c.ToString()).ToArray();
            var lstDates = ContributionBusinessDays.Create();
            for (int i = 0; i < lstDays.Length; i++)
            {

                var day = new DateTime(year, 1, 1).AddDays(i);
                var isEnabled = Convert.ToBoolean(int.Parse(lstDays[i]));
                var bussinesDay = BussinesDay.Create(day, isEnabled);
                lstDates.AddDate(bussinesDay);
            }

            return lstDates;
        }

        private delegate OperationResult delInsertLog(string resultContribution);
        private delegate void delSendNotificationContribution(ContributionClientInformation clientInformation);
        public OperationResult GeneraContribution(ContributionClientPrxyInfo info)
        {
            if (info is null) { throw new ArgumentException("La informacion de la aportacion no puede ser nula."); }

            OperationResult result = new OperationResult() { Successful = true };
            delInsertLog delInsertLog = _retailProxy.InsertLog;

            try
            {
                /*Buscando implmentación para obtener el tipo de domiciliación del contrato y buscar su implementación*/

                string contractMasterId = info.ContractMaster;/*Siempre deberá buscar el segmento con el contrato Master*/
               
                _log.Info("Obteniendo el segmento del contrato");
                var segmentType = _retailExtPrxy.GetSegmentByContractId(contractMasterId);
                _log.Debug("Segmento: {ctnx}", segmentType);

                _log.Info("Obteniendo la implementacion de acuerdo al segmento");
                IContributionImplementacionSolve implementacionSolve = _blContributions.FirstOrDefault(x => x.AppliesTo(segmentType));
                _log.Debug("{ctnx}", implementacionSolve);

                int domiciliationTypeId = implementacionSolve.GetDomiciliationType(out result);

                ContributionClientInformation contributionClient =
                    ContributionClientInformation.Create(info.ContractId)
                    .SetAmountDateInfo(info.Amount, info.DateContribution)
                    .SetBankInfo(info.BankAccountTypeId, info.BankClientId, info.AccountClient)
                    .SetAdditionalInfo(info.TypeContribution, info.UserId)
                    .SetDomiciliationType(domiciliationTypeId)
                    .SetContractMaster(info.ContractMaster);

                

                delSendNotificationContribution delSendNotification = SendNotificationContribution;
                var resultContribution = _retailProxy.GeneraContribution(contributionClient, out result);
                if (!string.IsNullOrEmpty(resultContribution)) { delInsertLog.BeginInvoke(resultContribution, null, null); }
                if (result.Successful) { delSendNotification.BeginInvoke(contributionClient, null, null); }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al generar la aportacion con los datos: {cntx}", new { info });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return result;
        }

        private delegate ContributionContactClient delGetContactInformation(string userId);
        private delegate string delGetBinaryParameter(string parameterId, string contractId, string planId, string productType, string contractAttributeType, out OperationResult result);
        private delegate string delGetStringParameter(string parameterId, string contractId, string planId, string productType, string contractAttributeType, out OperationResult result);
        private void SendNotificationContribution(ContributionClientInformation clientInformation)
        {
            var result = new OperationResult { Successful = true };

            delGetContactInformation delGetContactInformation = _mxAuthPrxy.GetClientInfo;
            delGetBinaryParameter delGetBinaryParameter = _parametersProxy.GetBinaryParameter;
            delGetStringParameter delGetStringParameter = _parametersProxy.GetStringParameter;

            _log.Info("Obteniendo los datos de contacto del usuario");
            IAsyncResult asyncGetContactInformation = delGetContactInformation.BeginInvoke(clientInformation.UserId, null, null);
            _log.Info("Obteniendo la plantaillo del email");
            IAsyncResult asyncGetBinaryParameter = delGetBinaryParameter.BeginInvoke("APORTEPL", "", "", "Retail", "Standar", out OperationResult resTemplateParam, null, null);
            _log.Info("Obteniendo la configuracion del email");
            IAsyncResult asyncGetStringParameter = delGetStringParameter.BeginInvoke("APORTECNFG", "", "", "Retail", "Standar", out OperationResult resConfigurationParam, null, null);
            //string htmlTemplateToken = _parametersProxy.GetBinaryParameter("APORTEPL", "", "", "Retail", "Standar", out OperationResult resTemplateParam);
            //string configurationToken = _parametersProxy.GetStringParameter("APORTECNFG", "", "", "Retail", "Standar", out OperationResult resConfigurationParam);

            while (!asyncGetContactInformation.IsCompleted || !asyncGetBinaryParameter.IsCompleted || !asyncGetStringParameter.IsCompleted) { Thread.Sleep(10); }

            var htmlTemplate = delGetBinaryParameter.EndInvoke(out _, asyncGetBinaryParameter);
            _log.Debug("plantilla email: {cntx}", htmlTemplate);
            var configurationEmail = delGetStringParameter.EndInvoke(out _, asyncGetStringParameter);
            _log.Debug("Configuracion email:{cntx}", configurationEmail);
            var contactClient = delGetContactInformation.EndInvoke(asyncGetContactInformation);
            _log.Debug("Datos de contacto: {cntx}", contactClient);

            Dictionary<string, string> paramsEmail =
                new Dictionary<string, string>(){
                    {"nombrecliente",contactClient.Name },
                    {"fechacobro", clientInformation.DateContribution.Day.ToString() + " de " + clientInformation.DateContribution.ToString("MMMM", new CultureInfo("es-ES")) },
                    {"tipoahorro", clientInformation.TypeContribution },
                    {"contratoId", clientInformation.ContractMasterId }
                };

            var emailConfig = JsonConvert.DeserializeObject<ContributionEmailConfig>(configurationEmail);
            var request = new Dictionary<string, object>(){
                { "emailConfig", emailConfig},
                { "htmlTemplate", htmlTemplate },
                { "email", contactClient.Email },
                { "templateData", paramsEmail }
            };

            _log.Info("Enviando notificacion por correo");
            var resultNotification = _notificationPrxy.SendNotificationsAppSync(request);
            _log.Debug("Se envio notificacion: {cntx}", resultNotification);
        }

        public bool HasProgrammedPayment(string clientId, string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(clientId)) { throw new ArgumentException(nameof(clientId)); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            Boolean hasProgrammedPayment = false;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Verificando si el cliente tiene un pago programado");
                hasProgrammedPayment = _retailProxy.HasProgrammedPaymentContribution(clientId, contractId, out result);
                _log.Debug("HasProgrammedPayment: {ctnx}", hasProgrammedPayment);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al encontrar la implementacion correspondiente al contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return hasProgrammedPayment;
        }

        public List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException(nameof(clientIdentifier)); }

            result = new OperationResult() { Successful = true };
            var response = new List<ClientDomiciliation>();
            try
            {
                var clientDomiciliation = _retailProxy.GetDomiciliationsByContract(contractId, clientIdentifier, maskSensitiveInfo, out var resultOfClientDomiciliation);
                if (!resultOfClientDomiciliation.Successful)
                    result.SystemMessages.AddRange(resultOfClientDomiciliation.SystemMessages);

                var bankCatalogs = _retailProxy.GetBankCatalog(out var resultOfBankCatalog);
                if (!resultOfBankCatalog.Successful)
                    result.SystemMessages.AddRange(resultOfBankCatalog.SystemMessages);

                var clientDomiciliationHsbc = _retailExtPrxy.GetDomiciliationsHsbcByContract(contractId, clientIdentifier, maskSensitiveInfo, out var resultOfClientDomiciliationHsbc);
                if (!resultOfClientDomiciliationHsbc.Successful)
                    result.SystemMessages.AddRange(resultOfClientDomiciliationHsbc.SystemMessages);

                foreach (var domiciliationHsbc in clientDomiciliationHsbc)
                {
                    var bankName = bankCatalogs.Exists(f => f.Id == domiciliationHsbc.BankId) ? bankCatalogs.Find(f => f.Id == domiciliationHsbc.BankId).DescriptionShort : domiciliationHsbc.BankName;
                    domiciliationHsbc.UpdateBankName(bankName);
                }

                var clientDomiciliationSantander = _retailExtPrxy.GetDomiciliationsSantanderByContract(contractId, clientIdentifier, maskSensitiveInfo, out var resultOfClientDomiciliationSantander);
                if (!resultOfClientDomiciliationSantander.Successful)
                    result.SystemMessages.AddRange(resultOfClientDomiciliationSantander.SystemMessages);

                foreach (var domiciliationSantander in clientDomiciliationSantander)
                {
                    var bankName = bankCatalogs.Exists(f => f.Id == domiciliationSantander.BankId) ? bankCatalogs.Find(f => f.Id == domiciliationSantander.BankId).DescriptionShort : domiciliationSantander.BankName;
                    domiciliationSantander.UpdateBankName(bankName);
                }

                response.AddRange(clientDomiciliation);
                response.AddRange(clientDomiciliationHsbc);
                response.AddRange(clientDomiciliationSantander);
                result.Successful = resultOfClientDomiciliation.Successful || resultOfClientDomiciliationHsbc.Successful || resultOfClientDomiciliationSantander.Successful;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al encontrar las domiciliaciones correspondiente al contrato: {ClientIdentifier}-{ContractId}", clientIdentifier, contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return response;
        }

        public List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi(string contractId, string clientIdentifier, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException(nameof(clientIdentifier)); }

            result = new OperationResult() { Successful = true };
            var response = new List<FrecuencyTypeCatalog>();
            try
            {
                var contractInfo = _retailProxy.GetContractInfo(contractId, clientIdentifier, out result);
                var listPlans = _retailExtPrxy.GetPlansById(new List<short>() { contractInfo.PlanBasId }, out result);
                var planInfo = listPlans.Single(x => x.PlanClasification.Platform == contractInfo.Platform);
                var frecuencyTypeCatalogs = _retailProxy.GetFrecuencyTypeCatalogForDomi(out result);
                var applyPlanFrecuencyTypes = _clientContributionParametersPrxy.GetApplyPlanFrecuencyTypes();

                if (applyPlanFrecuencyTypes.Exists(e => e.Plans.Exists(p => p == planInfo.Id)))
                {
                    var frecuencyTypeIds = applyPlanFrecuencyTypes.FindAll(e => e.Plans.Exists(p => p == planInfo.Id))
                        .Select(s => s.FrecuencyTypeId);

                    response.AddRange(frecuencyTypeCatalogs.Where(w => frecuencyTypeIds.Contains(w.Id)));
                }
                else response.AddRange(frecuencyTypeCatalogs);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar el catalogo de frecuencias para domiciliaciones al contrato: {ClientIdentifier}-{ContractId}", clientIdentifier, contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return response;
        }

        public List<SalesforceCase> GetSalesforceLastPendingCase(SalesforceLastPendingCaseRequest request, out OperationResult result)
        {
            if (string.IsNullOrEmpty(request.ContractId)) { throw new ArgumentException(nameof(request.ContractId)); }
            if (string.IsNullOrEmpty(request.ClientIdentifier)) { throw new ArgumentException(nameof(request.ClientIdentifier)); }

            result = new OperationResult() { Successful = true };
            var response = new List<SalesforceCase>();
            try
            {
                var salesforceCaseRequest = SalesforceCaseRequest.Create(request.ContractId, request.ClientIdentifier)
                    .SetDetail(request.Issue, request.OriginCase, request.Category)
                    .SetInfo(request.OriginType, request.CaseType, request.SubType, request.Tracing);

                response = _retailExtPrxy.GetSalesforceLastPendingCase(salesforceCaseRequest, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al encontrar las domiciliaciones correspondiente al contrato: {ClientIdentifier}-{ContractId}", request.ClientIdentifier, request.ContractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return response;
        }

    }
}
