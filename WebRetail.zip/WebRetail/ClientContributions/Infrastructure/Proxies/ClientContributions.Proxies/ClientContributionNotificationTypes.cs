﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    public class PrxyRequestSendMail
    {
        public string Provider;
        public string Asunto;
        public string Configuracion;
        public string IdPlantilla;
        public string Plantillahtml;
        public PrxyDestinatarioEmail Sender;
        public List<PrxyDestinatarioEmail> Destinatarios;
        public List<PrxyDestinatarioEmail> CC;
        public List<PrxyDestinatarioEmail> BCC;
        public List<PrxyAttachedFile> AttachedFiles;
    }

    public class PrxyResponseOperationResult
    {
        public bool successful;
        public string MessageId;
        public string systemMessages;
    }

    public class PrxyDestinatarioEmail
    {
        public string Name;
        public string Email;
        public Dictionary<string, string> AtributosPlantillaHTML;
        public List<byte> Files;
    }

    public class PrxyAttachedFile
    {
        public string Name;
        public byte[] ContentByte;
        public byte[] ContentBase64;
        public string Url;
    }
}
