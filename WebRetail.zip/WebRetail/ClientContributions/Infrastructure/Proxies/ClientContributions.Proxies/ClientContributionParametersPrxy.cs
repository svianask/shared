﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace ClientContributions.Proxies
{
    public class ClientContributionParametersPrxy : IClientContributionParametersPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientContributionParametersPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<string> GetApplyPlans()
        {
            ParametersStringResponsePrxy response;
            List<string> lstPlans = new List<string>();

            string url = ConfigurationManager.AppSettings["BursinessParameters:URLService"].ToString() + "Query/GetStringParameter";

            ParametersStringRequestPrxy request = new ParametersStringRequestPrxy
            {
                ParameterId = "PLNSAPORTES",
                ContractId = "",
                PlanId = "",
                ProductType = "Retail",
                ContractAttributeType = "Standar"
            };

            string jsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ParametersStringResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                var templateBody = response.StringParameter.Value;
                lstPlans = templateBody.Split(',').ToList();
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return lstPlans;
        }

        public int GetMaxContributionHour()
        {
            ParametersStringResponsePrxy response;
            int maxContributionHours = 0;

            string url = ConfigurationManager.AppSettings["BursinessParameters:URLService"].ToString() + "Query/GetStringParameter";

            ParametersStringRequestPrxy request = new ParametersStringRequestPrxy
            {
                ParameterId = "APORTEMAXHR",
                ContractId = "",
                PlanId = "",
                ProductType = "Retail",
                ContractAttributeType = "Standar"
            };

            string jsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ParametersStringResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                maxContributionHours = Convert.ToInt32(response.StringParameter.Value);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return maxContributionHours;
        }

        public List<string> GetApplyDomiciliationsPlans()
        {
            var lstPlans = new List<string>();

            var url = ConfigurationManager.AppSettings["BursinessParameters:URLService"] + "Query/GetStringParameter";

            var request = new ParametersStringRequestPrxy
            {
                ParameterId = "PLNSDOMIS",
                ContractId = "",
                PlanId = "",
                ProductType = "Retail",
                ContractAttributeType = "Standar"
            };

            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out var result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ParametersStringResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                var templateBody = response.StringParameter.Value;
                lstPlans = templateBody.Split(',').ToList();
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return lstPlans;
        }

        public List<DomiFrecuencyTypesPlansParameter> GetApplyPlanFrecuencyTypes()
        {
            var listPlansByFrecuencyTypes = new List<DomiFrecuencyTypesPlansParameter>();
            var url = ConfigurationManager.AppSettings["BursinessParameters:URLService"] + "Query/GetStringParameter";
            var request = new ParametersStringRequestPrxy
            {
                ParameterId = "DOMITFPLNS",
                ContractId = "",
                PlanId = "",
                ProductType = "Retail",
                ContractAttributeType = "Standar"
            };

            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out var result);
            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ParametersStringResponsePrxy>(jsonResult);
                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                var templateBody = response.StringParameter.Value;
                listPlansByFrecuencyTypes = JsonConvert.DeserializeObject<List<DomiFrecuencyTypesPlansParameter>>(templateBody);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return listPlansByFrecuencyTypes;
        }
    }
}
