﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ContributionContactClientAggregate;
using ClientContributions.Proxies.ClientContributionRetailMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    public class ClientContributionMxAuthPrxy : IClientContributionMxAuthPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientContributionMxAuthPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ContributionContactClient GetClientInfo(string userId)
        {
            UserInformationRequestPrxy request = new UserInformationRequestPrxy()
            {
                UserName = userId,
                PortalId = int.Parse(ConfigurationManager.AppSettings["Solvency:PortalId"])
            };
            UserInformationResponsePrxy response = new UserInformationResponsePrxy();
            ContributionContactClient userInformation = null;

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "Solvency/GetUserInformation";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<UserInformationResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                userInformation = ContributionContactClient.Create(response.UserInformation.Email, response.UserInformation.FirstName, response.UserInformation.LastNameOne);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return userInformation;
        }
    }
}
