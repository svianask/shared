﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClientContributions.Proxies
{
    #region GetProductInfo
    public class ProductInfoResponsePrxy
    {
        public OperationResult Result;
        public ContractProductInfoPrxy ProductInfo;
    }

    public class ContractProductInfoPrxy
    {
        public short PlanBasId;
        public int PlanId;
        public int Platform;
        public string ComercialName;
    }

    public class ProductInfoRequestPrxy
    {
        public string ContractId;
    }
    #endregion

    #region Contact information
    public class ContactInformationRequestPrxy
    {
        public string ClientIdentifier;
    }

    public class ContactInformationResponsePrxy
    {
        public ContactInformationPrxy ContactInformation;
        public OperationResult Result;
    }

    public class ContactInformationPrxy
    {
        public string Email;
        public string Name;
        public string LastName;
    }
    #endregion
}
