﻿using System.Collections.Generic;

namespace ClientContributions.Proxies
{
    public interface IClientContributionParametersPrxy
    {
        List<string> GetApplyPlans();
        int GetMaxContributionHour();

        List<string> GetApplyDomiciliationsPlans();
        List<DomiFrecuencyTypesPlansParameter> GetApplyPlanFrecuencyTypes();
    }
}
