﻿using ClientContributions.Domain.ContributionNotificationAggregate;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    public class ClientContributionNotificationPrxy : IClientContributionNotificationPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientContributionNotificationPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public OperationResult SendNotificationsAppSync(Dictionary<string, object> request)
        {
            OperationResult result = new OperationResult { Successful = true };
            ContributionEmailConfig emailConfig = null;
            List<ContributionAttachedFile> attachedFiles = null;
            Dictionary<string, string> templateData = null;
            string htmlTemplate = string.Empty;
            string email = string.Empty;


            if (!request.TryGetValue("emailConfig", out object objEmailConfig)) { throw new ArgumentException("El argumento no puede ser nulo.", nameof(emailConfig)); }
            emailConfig = (ContributionEmailConfig)objEmailConfig;

            if (!request.TryGetValue("email", out object objEmail)) { throw new ArgumentException("El argumento no puede ser nulo", nameof(email)); }
            email = (string)objEmail;

            if (request.TryGetValue("templateData", out object objTemplateData))
            {
                templateData = (Dictionary<string, string>)objTemplateData;
            }

            if (request.TryGetValue("htmlTemplate", out object objHtmlTemplate))
            {
                htmlTemplate = (string)objHtmlTemplate;
                byte[] bytesHtmlTemplate = Convert.FromBase64String(htmlTemplate);
                htmlTemplate = Encoding.UTF8.GetString(bytesHtmlTemplate);
            }

            htmlTemplate = ReplaceDataOnTemplate(htmlTemplate, templateData);

            if (request.TryGetValue("attachedFiles", out object objAttachedFiles))
            {
                attachedFiles = (List<ContributionAttachedFile>)objAttachedFiles;
            }

            string url = ConfigurationManager.AppSettings["ServiceNotificationApi:URLService"].ToString() + "SendMailExpress";

            PrxyRequestSendMail reqSendMail = new PrxyRequestSendMail()
            {
                Provider = emailConfig.Provider,
                Asunto = emailConfig.Subject,
                Configuracion = emailConfig.Configuration,
                IdPlantilla = emailConfig.TemplateId,
                Plantillahtml = htmlTemplate,
                Sender = new PrxyDestinatarioEmail
                {
                    Email = emailConfig.Sender.EmailAddress,
                    Name = emailConfig.Sender.Name
                },
                Destinatarios = new List<PrxyDestinatarioEmail> { new PrxyDestinatarioEmail { Email = email } },
                CC = new List<PrxyDestinatarioEmail>(),
                BCC = new List<PrxyDestinatarioEmail>(),
                AttachedFiles = new List<PrxyAttachedFile>()
            };
            if (emailConfig.Cc != null) { emailConfig.Cc.ForEach(cc => reqSendMail.CC.Add(new PrxyDestinatarioEmail { Email = cc.EmailAddress })); }
            if (emailConfig.Bcc != null) { emailConfig.Bcc.ForEach(bcc => reqSendMail.BCC.Add(new PrxyDestinatarioEmail { Email = bcc.EmailAddress })); }
            if (attachedFiles != null)
            {
                attachedFiles.ForEach(att => reqSendMail.AttachedFiles.Add(
                    new PrxyAttachedFile
                    {
                        ContentBase64 = att.ContentBase64,
                        ContentByte = att.ContentByte,
                        Name = att.Name,
                        Url = att.Url
                    }));
            }

            string JsonResult = _proxyEngine.SendMSRequestJson(url, reqSendMail, out result);

            if (result.Successful)
            {
                PrxyResponseOperationResult response = JsonConvert.DeserializeObject<PrxyResponseOperationResult>(JsonResult);

                if (!response.successful) { throw new Exception("Error al consumir el servicio de envío de notificaciones: " + url + " - " + response.systemMessages); }
            }
            else
            {
                result.Successful = false;

                throw new Exception("Error al consumir el servicio de envío de notificaciones: " + url + " - " + result.SystemMessages[0]);
            }
            return result;
        }

        private string ReplaceDataOnTemplate(string htmlTemplate, Dictionary<string, string> templateData)
        {
            if (htmlTemplate.Length > 0 && templateData != null && templateData.Count > 0)
            {
                templateData.ToList().ForEach(kv => { htmlTemplate = htmlTemplate.Replace("{" + kv.Key + "}", kv.Value); });
            }

            return htmlTemplate;
        }
    }
}
