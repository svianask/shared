﻿using ClientContributions.Domain.ContributionContactClientAggregate;
using ClientContributions.Domain.ContributionProductInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    public interface IClientContributionWebRetailPrxy
    {
        ContributionProductInfo GetPlanIdByContractId(string contractId);
    }
}
