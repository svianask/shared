﻿using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContractInfoAggregate;
using ClientContributions.Domain.SalesforceAggregate;
using ClientContributions.Proxies.ClientContributionRetailMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientContributions.Proxies
{
    public class ClientContributionsRetailExtPrxy : IClientContributionsRetailExtPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientContributionsRetailExtPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }
        public int GetSegmentByContractId(string contractId)
        {
            int segmentType = 0;
            ContractSegmentTypeResponsePrxy response = new ContractSegmentTypeResponsePrxy();
            ContractSegmentTypeRequestPrcy request = new ContractSegmentTypeRequestPrcy()
            {
                ContractId = contractId
            };

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"] + "ClientContracts/GetContractSegmentType";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ContractSegmentTypeResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                segmentType = response.SegmentOfContractType;

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return segmentType;
        }

        public bool ValidateContributionSchedule(out string initSchedule, out string endSchedule)
        {
            initSchedule = string.Empty;
            endSchedule = string.Empty;
            var response = new ValidateScheduleContributionResponsePxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"] + "Products/ValidateScheduleContribution";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, "", out OperationResult result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ValidateScheduleContributionResponsePxy>(JsonResult);
                initSchedule = response.ContributionSchedule.InitSchedule;
                endSchedule = response.ContributionSchedule.EndSchedule;
            }

            return response.Result.Successful;
        }

        public List<ClientDomiciliation> GetDomiciliationsHsbcByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result)
        {
            var request = new DomiciliationByContractRequestPrxy { ContractId = contractId, ClientIdentifier = clientIdentifier };
            result = new OperationResult() { Successful = true };
            List<ClientDomiciliation> listClientDomiciliations;

            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"] + "ClientDomiciliation/GetDomiciliationsHsbcByContract";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<DomiciliationHsbcByContractResponsePrxy>(jsonResult);

                result = response.Result;

                if (!response.Result.Successful) { throw new Exception($"Error al consumir el servicio {url} - {response.Result.SystemMessages[0]}"); }

                listClientDomiciliations = ClientDomiciliationMapp.Mapp(response.Domiciliation, contractId, maskSensitiveInfo);
            }
            else
            {
                result.Successful = false;
                throw new Exception($"Error al consumir el servicio {url} - {result.SystemMessages[0]}");
            }
            return listClientDomiciliations;
        }

        public List<ClientDomiciliation> GetDomiciliationsSantanderByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result)
        {
            var request = new DomiciliationByContractRequestPrxy { ContractId = contractId, ClientIdentifier = clientIdentifier };
            result = new OperationResult() { Successful = true };
            List<ClientDomiciliation> listClientDomiciliations;

            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"] + "ClientDomiciliation/GetDomiciliationsSantanderByContract";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<DomiciliationSantanderByContractResponsePrxy>(jsonResult);
                result = response.Result;
                if (!response.Result.Successful) { throw new Exception($"Error al consumir el servicio {url} - {response.Result.SystemMessages[0]}"); }
                listClientDomiciliations = ClientDomiciliationMapp.Mapp(response.Domiciliation, contractId, maskSensitiveInfo);
            }
            else
            {
                result.Successful = false;
                throw new Exception($"Error al consumir el servicio {url} - {result.SystemMessages[0]}");
            }
            return listClientDomiciliations;
        }

        public List<PlanInfo> GetPlansById(List<short> listPlanBasId, out OperationResult result)
        {
            var request = new PlanInfoRequestPrxy { PlanIds = listPlanBasId };
            result = new OperationResult() { Successful = true };
            List<PlanInfo> listPlanInfo;

            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"] + "Products/GetPlansById";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PlanInfoResponsePrxy>(jsonResult);
                listPlanInfo = PlanInfoMapp.Mapp(response.Plans);
            }
            else
            {
                result.Successful = false;
                throw new Exception($"Error al consumir el servicio {url} - {result.SystemMessages[0]}");
            }

            return listPlanInfo;
        }

        public List<SalesforceCase> GetSalesforceLastPendingCase(SalesforceCaseRequest sfCaseRequest, out OperationResult result)
        {
            var request = new SalesforceCaseRequestPrxy { ContractId = sfCaseRequest.ContractId, ClientIdentifier = sfCaseRequest.ClientIdentifier, Issue = sfCaseRequest.Issue, OriginCase = sfCaseRequest.OriginCase, Category = sfCaseRequest.Category, OriginType = sfCaseRequest.OriginType, CaseType = sfCaseRequest.CaseType, SubType = sfCaseRequest.SubType, Tracing = sfCaseRequest.Tracing };
            result = new OperationResult() { Successful = true };
            List<SalesforceCase> salesforceCases;

            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"] + "ClientDomiciliation/GetSalesforceLastPendingCase";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<SalesforceCaseResponsePrxy>(jsonResult);
                result = response.Result;
                if (!response.Result.Successful) { throw new Exception($"Error al consumir el servicio {url} - {response.Result.SystemMessages[0]}"); }
                salesforceCases = SalesforceCaseMapp.Mapp(response.SalesforceCases, sfCaseRequest.ContractId);
            }
            else
            {
                result.Successful = false;
                throw new Exception($"Error al consumir el servicio {url} - {result.SystemMessages[0]}");
            }
            return salesforceCases;
        }


        public decimal GetCommitedAmount(string contractId, out OperationResult result)
        {
            var request = new ContractExtBasicInfoRequestPrxy() { ContractId = contractId };
            decimal commitedAmount = 0;
            result = new OperationResult() { Successful = true };

            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractExtBasicInfo";

            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ContractExtBasicInfoResponsePrxy>(jsonResult);
                commitedAmount = response.ContractExtBasicInfo.CommittedAmount;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return commitedAmount;
        }
    }
}
