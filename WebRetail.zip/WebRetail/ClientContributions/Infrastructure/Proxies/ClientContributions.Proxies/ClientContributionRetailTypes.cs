﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using static System.Linq.Enumerable;

namespace ClientContributions.Proxies
{
    #region ContractBankAccounts
    public class PrxyContractBankAccountsRequest
    {
        public string ContractId;
    }

    public class PrxyContractBankAccountsResponse
    {
        public List<PrxyContractBankAccount> ContractBankAccounts;
        public OperationResult Result;
    }

    public class PrxyContractBankAccount
    {
        public int AccountId;
        public int BankId;
        public int BankAccountTypeId;
        public string AccountNumber;
        public string AccountBankName;
        public int AccountUseTypeId;
    }

    #endregion

    #region Amounts Min Max Allows
    public class PrxyContributionAllowAmountsResponse
    {
        public OperationResult Result;
        public PrxyDomiciliationAllowAmounts AllowAmounts;
    }

    public class PrxyDomiciliationAllowAmounts
    {
        public decimal AmountMinimun;
        public decimal AmountMaximun;
    }

    public class PrxyContributionAllowAmountsRequest
    {
        public int DomiciliationType;
    }
    #endregion

    #region Commision Porcentage
    public class GetPorcentageComissionResponsePrxy
    {
        public decimal PorcentageCommision;
        public OperationResult Result;
    }

    public class GetPorcentageComissionRequestPrxy
    {
        public string ContractId;
    }
    #endregion

    #region Contracts Grouping
    public class GroupingContractPrxy
    {
        public int ProductId;
        public string GrouperContractIdentifier;
        public int GrouperPlanId;
        public string ContributionContractId;
        public string AdditionalContractId;
        public string WarningMessage;
    }

    public class GetGroupingContractResponsePrxy
    {
        public OperationResult Result;
        public GroupingContractPrxy ContractsGrouping;
    }
    public class GetGroupingContractRequestPrxy
    {
        public string ContractId;
        public int Platform;
    }

    #endregion

    #region ContractCommittedAmount
    public class ContractCommittedAmountRequestPrxy
    {
        public string ContractId;
    }
    public class ContractCommittedAmountResponsePrxy
    {
        public decimal CommittedAmount;
        public OperationResult Result;
    }
    #endregion

    #region Amount Due
    public class GetAmountDueResponsePrxy
    {
        public decimal AmountDue;
        public OperationResult Result;
    }

    public class GetAmountDueRequestPrxy
    {
        public string ContractId;
    }
    #endregion

    #region Get days calendar
    public class GetDaysCalendarResponsePrxy
    {
        public string DaysCalendar;
        public OperationResult Result;
    }

    public class GetDaysCalendarRequestPrxy
    {
        public int YearConsult;
    }
    #endregion

    #region Genera Aportacion
    public class DomiciliationOnDemandRequestPrxy
    {
        public DomiciliationOnDemandPrxy DomiciliationInfo;

        public DomiciliationOnDemandRequestPrxy() { DomiciliationInfo = new DomiciliationOnDemandPrxy(); }

    }

    public class DomiciliationOnDemandPrxy
    {
        public string ContractId;
        public int DomiciliationType;
        public double Amount;
        public DateTime PaymentDate;
        public int BankAccountTypeId;
        public int BankClientId;
        public string AccountClient;
        public bool CoverContribution;
        public bool ExistDomiciliation;
        public string UserId;
    }

    public class DomiciliationOnDemandResponsePrxy
    {
        public OperationResult Result { get; set; }
        public string XmlResult { get; set; }
        public DomiciliationOnDemandResponsePrxy() { Result = new OperationResult(); }
    }
    #endregion

    #region Insert Log Contribution
    public class LogConnetorDomiProxyRequestPrxy
    {
        public string XMLQuery;
    }
    public class LogConnetorDomiProxyResponsePrxy
    {
        public OperationResult Result { get; set; }

        public LogConnetorDomiProxyResponsePrxy() { Result = new OperationResult(); }
    }
    #endregion

    #region HasProgrammed Contribution
    public class PrxyHasProgrammedContributionRequest
    {
        public string ClientID;
        public string ContractId;
    }

    public class PrxyHasProgrammedContributionResponse
    {
        public Boolean HasProgrammedPaymentContribution;
        public OperationResult Result;
    }
    #endregion

    #region Domiciliation Contract

    public enum FrecuencyTypeDomiciliation
    {
        Mensual = 10
    }

    public abstract class BaseRequestPrxy
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;

    }

    public class DomiciliationByContractRequestPrxy : BaseRequestPrxy
    {
    }

    public class BaseResponsePrxy
    {
        public OperationResult Result { get; set; }

    }

    public class DomiciliationByContractResponsePrxy : BaseResponsePrxy
    {
        public List<ClientDomiciliationPrxy> Domiciliation { get; set; } = new List<ClientDomiciliationPrxy>();
    }

    public abstract class BaseClientDomiciliationPrxy
    {
        public string ContractId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime NextPaymentDate { get; set; }
        public short AccountTypeId { get; set; }
        public string AccountType { get; set; }
        public short BankId { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public decimal Amount { get; set; }
        public short Payday { get; set; }
    }

    public class ClientDomiciliationPrxy : BaseClientDomiciliationPrxy
    {
        public int DomiciliationId { get; set; }
        public short FrequencyTypeId { get; set; }
        public string FrequencyType { get; set; }
    }

    public class BanksCatalogResponsePrxy
    {
        public OperationResult Result { get; set; } = new OperationResult();
        public List<BankCatalogPrxy> Banks { get; set; } = new List<BankCatalogPrxy>();
    }

    public class BankCatalogPrxy
    {
        public short Id { get; set; }
        public string Description { get; set; }
        public string DescriptionShort { get; set; }
    }

    public class FrecuencyTypeCatalogForDomiResponsePrxy
    {
        public List<FrecuencyTypeCatalogForDomiPrxy> FrecuencyTypes { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class FrecuencyTypeCatalogForDomiPrxy
    {
        public short Id { get; set; }
        public string Description { get; set; }
        public string DescriptionShort { get; set; }
    }

    public class ContractInfoRequestPrxy : BaseRequestPrxy
    {
    }

    public class ContractInfoResponsePrxy : BaseResponsePrxy
    {
        public ContractInfoPrxy ContractInfo { get; set; }
    }

    public class ContractInfoPrxy
    {
        public string Id { get; set; }
        public short PlanBasId { get; set; }
        public int Platform { get; set; }
        public string ContratoAgrupa { get; set; }
        public DateTime AfiliationDate { get; set; }
    }


    public class PlanInfoRequestPrxy
    {
        public List<short> PlanIds { get; set; }
    }

    public class PlanInfoResponsePrxy : BaseResponsePrxy
    {
        public List<PlanInfoPrxy> Plans = Empty<PlanInfoPrxy>().ToList();
    }

    public class PlanInfoPrxy
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string BasPlanId { get; set; }

        public PlanClasificationPrxy PlanClasification { get; set; } = new PlanClasificationPrxy();
        public ComercialInfoPrxy ComercialInfo { get; set; } = new ComercialInfoPrxy();
    }
    public class ComercialInfoPrxy
    {
        public short ComercialPlanId { get; set; }
        public string ComercialName { get; set; }
    }

    public class PlanClasificationPrxy
    {
        public int Platform { get; set; }
        public int ProductType { get; set; }
    }

    public class SalesforceCaseRequestPrxy : BaseRequestPrxy
    {
        public string Issue { get; set; } = string.Empty;
        public string OriginCase { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string OriginType { get; set; } = string.Empty;
        public string CaseType { get; set; } = string.Empty;
        public string SubType { get; set; } = string.Empty;
        public string Tracing { get; set; } = string.Empty;
    }

    public class SalesforceCaseResponsePrxy : BaseResponsePrxy
    {
        public List<SalesforceCasePrxy> SalesforceCases { get; set; }
    }

    public class SalesforceCasePrxy
    {
        public string ContractId { get; set; }
        public string CaseNumber { get; set; }
    }

    #endregion
}
