﻿using ClientContributions.Domain.ContributionProductInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies.ClientContributionWebRetailMap
{
    public class ContributionProductInfoMap
    {
        public static ContributionProductInfo Mapp(ContractProductInfoPrxy productInfoPrxy)
        {
            ContributionProductInfo productInfo = null;
            if(productInfoPrxy != null)
            {
                productInfo = ContributionProductInfo.Create(productInfoPrxy.PlanBasId, productInfoPrxy.Platform, productInfoPrxy.ComercialName, productInfoPrxy.PlanId);
            }

            return productInfo;
        }
    }
}
