﻿using ClientContributions.Domain.ContributionContactClientAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    public interface IClientContributionMxAuthPrxy
    {
        ContributionContactClient GetClientInfo(string userId);
    }
}
