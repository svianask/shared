﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies.ClientContributionRetailMapp
{
    public class BankAccountsContributionsMapp
    {
        public static List<ClientBankAccountsContributions> Mapp(List<PrxyContractBankAccount> prxyContractBankAccounts, string contractId)
        {
            List<ClientBankAccountsContributions> clientBankAccounts = new List<ClientBankAccountsContributions>();

            prxyContractBankAccounts.ForEach(account => { 
                if(account.AccountUseTypeId == 10 || account.AccountUseTypeId == 15)
                {
                    clientBankAccounts.Add(ClientBankAccountsContributions.Create(contractId)
                        .SetBankData(account.BankId, account.AccountBankName, account.BankAccountTypeId)
                        .SetAccountData(account.AccountId, account.AccountNumber, account.AccountUseTypeId));
                }
            });

            return clientBankAccounts;
        }
    }
}
