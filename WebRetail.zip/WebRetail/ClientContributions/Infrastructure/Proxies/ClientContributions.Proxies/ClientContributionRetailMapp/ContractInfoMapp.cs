﻿using ClientContributions.Domain.ContractInfoAggregate;

namespace ClientContributions.Proxies.ClientContributionRetailMapp
{
    public static class ContractInfoMapp
    {
        public static ContractInfo Mapp(ContractInfoPrxy contractInfoPrxy)
        {
            return ContractInfo.Create(contractInfoPrxy.Id, contractInfoPrxy.PlanBasId, contractInfoPrxy.Platform, contractInfoPrxy.ContratoAgrupa, contractInfoPrxy.AfiliationDate);
        }
    }
}
