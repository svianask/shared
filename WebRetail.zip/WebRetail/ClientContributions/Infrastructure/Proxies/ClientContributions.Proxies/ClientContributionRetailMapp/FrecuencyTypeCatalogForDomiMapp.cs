﻿using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using System.Collections.Generic;

namespace ClientContributions.Proxies.ClientContributionRetailMapp
{
    public static class FrecuencyTypeCatalogForDomiMapp
    {
        public static List<FrecuencyTypeCatalog> Mapp(List<FrecuencyTypeCatalogForDomiPrxy> frecuencyTypeCatalogForDomi)
        {
            var bankAccountsAllowDomis = new List<FrecuencyTypeCatalog>();

            frecuencyTypeCatalogForDomi.ForEach(f =>
                bankAccountsAllowDomis.Add(FrecuencyTypeCatalog
                    .Create(f.Id, f.Description, f.DescriptionShort)
                )
            );

            return bankAccountsAllowDomis;
        }
    }
}
