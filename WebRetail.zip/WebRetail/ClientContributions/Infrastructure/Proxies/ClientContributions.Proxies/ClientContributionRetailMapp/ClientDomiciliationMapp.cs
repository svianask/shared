﻿using ClientContributions.Domain.ClientDomiciliationAggregate;
using System.Collections.Generic;

namespace ClientContributions.Proxies.ClientContributionRetailMapp
{
    public static class ClientDomiciliationMapp
    {
        public static List<ClientDomiciliation> Mapp<T>(List<T> clientDomiciliationPrxies, string contractId, bool maskSensitiveInfo) where T : BaseClientDomiciliationPrxy
        {
            var clientDomiciliations = new List<ClientDomiciliation>();
            var countDomiId = 1;
            foreach (var cDomi in clientDomiciliationPrxies)
            {
                clientDomiciliations.Add(ClientDomiciliation.Create(countDomiId, cDomi.ContractId)
                                        .SetBankAccountInfo(cDomi.BankId, cDomi.BankName, cDomi.AccountTypeId, cDomi.AccountType, cDomi.AccountNumber)
                                        .SetConfigInfo(cDomi.StartDate, cDomi.Amount, cDomi.Payday, (short)FrecuencyTypeDomiciliation.Mensual, nameof(FrecuencyTypeDomiciliation.Mensual), cDomi.NextPaymentDate)
                                        .MaskSensitiveInfo(maskSensitiveInfo));
                countDomiId++;
            }
            return clientDomiciliations;
        }

        public static List<ClientDomiciliation> Mapp(List<ClientDomiciliationPrxy> clientDomiciliationPrxies, string contractId, bool maskSensitiveInfo)
        {
            var clientDomiciliations = new List<ClientDomiciliation>();
            clientDomiciliationPrxies.ForEach(cDomi =>
                clientDomiciliations.Add(ClientDomiciliation.Create(cDomi.DomiciliationId, cDomi.ContractId)
                    .SetBankAccountInfo(cDomi.BankId, cDomi.BankName, cDomi.AccountTypeId, cDomi.AccountType, cDomi.AccountNumber)
                    .SetConfigInfo(cDomi.StartDate, cDomi.Amount, cDomi.Payday, cDomi.FrequencyTypeId, cDomi.FrequencyType, cDomi.NextPaymentDate)
                    .MaskSensitiveInfo(maskSensitiveInfo)
                )
            );
            return clientDomiciliations;
        }
    }
}
