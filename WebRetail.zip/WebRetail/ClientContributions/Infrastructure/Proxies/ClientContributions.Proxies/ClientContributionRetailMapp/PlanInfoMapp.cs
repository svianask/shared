﻿using ClientContributions.Domain.ContractInfoAggregate;
using System.Collections.Generic;

namespace ClientContributions.Proxies.ClientContributionRetailMapp
{
    public static class PlanInfoMapp
    {
        public static List<PlanInfo> Mapp(List<PlanInfoPrxy> planInfoPrxies)
        {
            var planInfos = new List<PlanInfo>();
            planInfoPrxies.ForEach(p =>
                planInfos.Add(PlanInfo
                    .Create(p.Id, p.Name, p.ShortName, p.BasPlanId)
                    .SetComercialInfo(p.ComercialInfo.ComercialPlanId, p.ComercialInfo.ComercialName)
                    .SetPlanClasification(p.PlanClasification.Platform, p.PlanClasification.ProductType))
                );

            return planInfos;
        }
    }
}
