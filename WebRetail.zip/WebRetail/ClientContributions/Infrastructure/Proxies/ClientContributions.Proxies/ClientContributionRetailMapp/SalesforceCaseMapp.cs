﻿using ClientContributions.Domain.SalesforceAggregate;
using System.Collections.Generic;


namespace ClientContributions.Proxies.ClientContributionRetailMapp
{
    public static class SalesforceCaseMapp
    {
        public static List<SalesforceCase> Mapp(List<SalesforceCasePrxy> salesforceCasePrxies, string contractId)
        {
            var salesforceCases = new List<SalesforceCase>();
            salesforceCasePrxies.ForEach(f =>
                salesforceCases.Add(SalesforceCase.Create(contractId, f.CaseNumber))
            );
            return salesforceCases;
        }
    }
}
