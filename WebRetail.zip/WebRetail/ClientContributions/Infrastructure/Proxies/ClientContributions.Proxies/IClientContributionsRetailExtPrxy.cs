﻿using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContractInfoAggregate;
using ClientContributions.Domain.SalesforceAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Proxies
{
    public interface IClientContributionsRetailExtPrxy
    {
        int GetSegmentByContractId(string contractId);
        bool ValidateContributionSchedule(out string initSchedule, out string endSchedule);
        List<ClientDomiciliation> GetDomiciliationsHsbcByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result);
        List<ClientDomiciliation> GetDomiciliationsSantanderByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result);
        List<PlanInfo> GetPlansById(List<short> listPlanBasId, out OperationResult result);
        List<SalesforceCase> GetSalesforceLastPendingCase(SalesforceCaseRequest sfCaseRequest, out OperationResult result);

        decimal GetCommitedAmount(string contractId, out OperationResult result);
    }
}
