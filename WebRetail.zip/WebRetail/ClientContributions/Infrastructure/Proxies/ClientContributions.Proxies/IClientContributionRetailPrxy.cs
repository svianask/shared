﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContractInfoAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Proxies
{
    public interface IClientContributionRetailPrxy
    {
        List<ClientBankAccountsContributions> GetClientBankAccounts(string contractId);
        ContributionMinMaxAmount GetAllowAmounts();
        decimal GetComissionByContractId(string contractID);
        string GetContractContribution(string contractId, int platform, out string contractAdictionalId);
        decimal GetCommitedAmount(string contractId);
        decimal GetAmountDue(string contractId);
        string GetDaysCalendar(int year);
        string GeneraContribution(ContributionClientInformation clientInformation, out OperationResult result);
        OperationResult InsertLog(string xmlQuery);
        bool HasProgrammedPaymentContribution(string clientId, string contractId, out OperationResult result);
        List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result);
        List<BankCatalogPrxy> GetBankCatalog(out OperationResult result);
        List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi(out OperationResult result);
        ContractInfo GetContractInfo(string contractId, string clientIdentifier, out OperationResult result);
    }
}
