﻿using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Proxies
{
    #region Parameters String
    public class ParametersStringRequestPrxy
    {
        public string ParameterId { get; set; }
        public string ContractId { get; set; }
        public string PlanId { get; set; }
        public string ProductType { get; set; }
        public string ContractAttributeType { get; set; }
    }

    public class ParametersStringResponsePrxy
    {
        public ParametersStringPrxy StringParameter;
        public OperationResult Result;
    }

    public class ParametersStringPrxy
    {
        public string Id;
        public string Value;
    }
    #endregion

    #region Domiciliacion Parameters

    public class DomiFrecuencyTypesPlansParameter
    {
        public short FrecuencyTypeId { get; set; }
        public List<string> Plans { get; set; } = new List<string>();
    }
    #endregion

}
