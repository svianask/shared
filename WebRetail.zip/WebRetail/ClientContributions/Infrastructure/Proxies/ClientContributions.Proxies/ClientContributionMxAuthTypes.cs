﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    #region Get Information
    public class UserInformationRequestPrxy
    {
        public string UserName;
        public int PortalId;
    }

    public class UserInformationResponsePrxy
    {
        public OperationResult Result;
        public UserInformationPrxy UserInformation;
    }

    public class UserInformationPrxy
    {
        public string FirstName;
        public string LastNameOne;
        public string LastNameTwo;
        public string Alias;
        public string Email;
    }
    #endregion
}
