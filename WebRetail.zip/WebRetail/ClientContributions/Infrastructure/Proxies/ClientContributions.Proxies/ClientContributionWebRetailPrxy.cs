﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ContributionContactClientAggregate;
using ClientContributions.Domain.ContributionProductInfoAggregate;
using ClientContributions.Proxies.ClientContributionRetailMapp;
using ClientContributions.Proxies.ClientContributionWebRetailMap;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContributions.Proxies
{
    public class ClientContributionWebRetailPrxy : IClientContributionWebRetailPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientContributionWebRetailPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ContributionProductInfo GetPlanIdByContractId(string contractId)
        {
            ProductInfoRequestPrxy request = new ProductInfoRequestPrxy();
            ProductInfoResponsePrxy response = new ProductInfoResponsePrxy();
            ContributionProductInfo productInfo = null;

            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientContracts/GetProductInfoByContractId";

            request.ContractId = contractId;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ProductInfoResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                productInfo = ContributionProductInfoMap.Mapp(response.ProductInfo);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return productInfo;
        }
    }
}
