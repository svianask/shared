﻿using ClientContributions.Domain.ClientBankAccountsContributionsAggregate;
using ClientContributions.Domain.ClientDomiciliationAggregate;
using ClientContributions.Domain.ContractInfoAggregate;
using ClientContributions.Domain.ContributionsAggregate;
using ClientContributions.Domain.FrecuencyTypeCatalogAggregate;
using ClientContributions.Proxies.ClientContributionRetailMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientContributions.Proxies
{
    public class ClientContributionRetailPrxy : IClientContributionRetailPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientContributionRetailPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<ClientBankAccountsContributions> GetClientBankAccounts(string contractId)
        {
            PrxyContractBankAccountsRequest request = new PrxyContractBankAccountsRequest();
            PrxyContractBankAccountsResponse response = new PrxyContractBankAccountsResponse();
            List<ClientBankAccountsContributions> bankAccounts = null;
            OperationResult result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBankAccounts";

            request.ContractId = contractId;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractBankAccountsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                bankAccounts = BankAccountsContributionsMapp.Mapp(response.ContractBankAccounts, contractId);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return bankAccounts;
        }

        public ContributionMinMaxAmount GetAllowAmounts()
        {
            ContributionMinMaxAmount amountsAllows = null;
            PrxyContributionAllowAmountsResponse response = new PrxyContributionAllowAmountsResponse();
            PrxyContributionAllowAmountsRequest request = new PrxyContributionAllowAmountsRequest()
            {
                DomiciliationType = int.Parse(ConfigurationManager.AppSettings["DomiciliationTypeMonthly"].ToString())
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/GetAllowAmountsMinMax";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContributionAllowAmountsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                amountsAllows = ContributionMinMaxAmount.Create(response.AllowAmounts.AmountMinimun, response.AllowAmounts.AmountMaximun);

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return amountsAllows;
        }

        public decimal GetComissionByContractId(string contractID)
        {
            decimal comission = 0;
            GetPorcentageComissionResponsePrxy response = new GetPorcentageComissionResponsePrxy();
            GetPorcentageComissionRequestPrxy request = new GetPorcentageComissionRequestPrxy()
            {
                ContractId = contractID
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/GetPorcentageComission";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetPorcentageComissionResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                comission = response.PorcentageCommision;

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return comission;
        }

        public string GetContractContribution(string contractId, int platform, out string contractAdictionalId)
        {
            string contractContributionId = string.Empty;
            contractAdictionalId = string.Empty;
            GetGroupingContractResponsePrxy response = new GetGroupingContractResponsePrxy();
            GetGroupingContractRequestPrxy request = new GetGroupingContractRequestPrxy()
            {
                ContractId = contractId,
                Platform = platform,
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/GetGroupingContract";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetGroupingContractResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                if (response.ContractsGrouping != null)
                {
                    contractContributionId = response.ContractsGrouping.ContributionContractId;
                    contractAdictionalId = response.ContractsGrouping.AdditionalContractId;
                }

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractContributionId;
        }

        public decimal GetCommitedAmount(string contractId)
        {
            var request = new ContractCommittedAmountRequestPrxy() { ContractId = contractId };
            decimal commitedAmount = 0;

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractCommittedAmount";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ContractCommittedAmountResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                commitedAmount = response.CommittedAmount;

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return commitedAmount;
        }

        public decimal GetAmountDue(string contractId)
        {
            var request = new GetAmountDueRequestPrxy() { ContractId = contractId };
            decimal amountDue = 0;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/GetAmountDue";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GetAmountDueResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                amountDue = response.AmountDue;

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return amountDue;
        }

        public string GetDaysCalendar(int year)
        {
            var request = new GetDaysCalendarRequestPrxy() { YearConsult = year };
            string days = string.Empty;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/GetDaysCalendar";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GetDaysCalendarResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                days = response.DaysCalendar;

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return days;
        }

        public string GeneraContribution(ContributionClientInformation clientInformation, out OperationResult result)
        {
            var informationToContribution = new DomiciliationOnDemandPrxy()
            {
                ContractId = clientInformation.ContractId,
                Amount = clientInformation.Amount,
                PaymentDate = clientInformation.DateContribution,
                BankAccountTypeId = clientInformation.BankAccountTypeId,
                BankClientId = clientInformation.BankClientId,
                AccountClient = clientInformation.AccountClient,
                DomiciliationType =  clientInformation.DomiciliationTypeId,
                CoverContribution = Convert.ToBoolean(ConfigurationManager.AppSettings["CoverContribution"]),
                ExistDomiciliation = Convert.ToBoolean(ConfigurationManager.AppSettings["ContributionExist"]),
                UserId = ConfigurationManager.AppSettings["ContributionUser"]
            };
            var request = new DomiciliationOnDemandRequestPrxy() { DomiciliationInfo = informationToContribution };
            string resultInf = string.Empty;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/GenerateDomiciliationOnDemand";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<DomiciliationOnDemandResponsePrxy>(JsonResult);
                result = response.Result;
                resultInf = response.XmlResult;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return resultInf;
        }

        public OperationResult InsertLog(string xmlQuery)
        {
            var request = new LogConnetorDomiProxyRequestPrxy() { XMLQuery = xmlQuery };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/RegisterLogDomiciliation";
            var result = new OperationResult();
            var response = new LogConnetorDomiProxyResponsePrxy();
            string JsonResult = string.Empty;

            try
            {
                JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
                if (result.Successful)
                {
                    response = JsonConvert.DeserializeObject<LogConnetorDomiProxyResponsePrxy>(JsonResult);
                }
                else
                {
                    response.Result = result;
                }
            }
            catch (Exception ex)
            {
                SystemMessage systemMessage = new SystemMessage
                {
                    MessageType = SystemMessageTypes.Error,
                    Message = "Error al insertar el log de aportaciones - BL" + ex.Message
                };

                response.Result.Successful = false;
                response.Result.SystemMessages.Add(systemMessage);
            }

            return response.Result;
        }

        public bool HasProgrammedPaymentContribution(string clientId, string contractId, out OperationResult result)
        {
            var request = new PrxyHasProgrammedContributionRequest() { ClientID = clientId, ContractId = contractId };

            result = new OperationResult() { Successful = true };

            Boolean HasProgrammedPayment = false;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "DomiciliationContract/HasProgrammedPayment";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyHasProgrammedContributionResponse>(JsonResult);

                result = response.Result;

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                HasProgrammedPayment = response.HasProgrammedPaymentContribution;

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return HasProgrammedPayment;
        }

        public List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result)
        {
            var request = new DomiciliationByContractRequestPrxy { ContractId = contractId, ClientIdentifier = clientIdentifier };
            result = new OperationResult() { Successful = true };
            List<ClientDomiciliation> listClientDomiciliations;

            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "DomiciliationContract/GetDomiciliationsByContract";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<DomiciliationByContractResponsePrxy>(jsonResult);

                result = response.Result;

                if (!response.Result.Successful) { throw new Exception($"Error al consumir el servicio {url} - {response.Result.SystemMessages[0]}"); }

                listClientDomiciliations = ClientDomiciliationMapp.Mapp(response.Domiciliation, contractId, maskSensitiveInfo);
            }
            else
            {
                result.Successful = false;
                throw new Exception($"Error al consumir el servicio {url} - {result.SystemMessages[0]}");
            }
            return listClientDomiciliations;
        }

        public List<BankCatalogPrxy> GetBankCatalog(out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            List<BankCatalogPrxy> listBankCatalogs;

            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "DomiciliationContract/GetBankCatalog";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, out result, "GET");

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<BanksCatalogResponsePrxy>(jsonResult);

                result = response.Result;

                if (!response.Result.Successful) { throw new Exception($"Error al consumir el servicio {url} - {response.Result.SystemMessages[0]}"); }

                listBankCatalogs = response.Banks;
            }
            else
            {
                result.Successful = false;
                throw new Exception($"Error al consumir el servicio {url} - {result.SystemMessages[0]}");
            }
            return listBankCatalogs;
        }

        public List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi(out OperationResult result)
        {
            List<FrecuencyTypeCatalog> frecuencyTypeCatalogs;
            result = new OperationResult();
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "ClientContracts/GetFrecuencyTypeCatalogForDomi";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, out result, "GET");

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FrecuencyTypeCatalogForDomiResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                frecuencyTypeCatalogs = FrecuencyTypeCatalogForDomiMapp.Mapp(response.FrecuencyTypes);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return frecuencyTypeCatalogs;
        }

        public ContractInfo GetContractInfo(string contractId, string clientIdentifier, out OperationResult result)
        {
            var request = new ContractInfoRequestPrxy { ContractId = contractId, ClientIdentifier = clientIdentifier };
            result = new OperationResult() { Successful = true };
            ContractInfo contractInfo;

            var url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";

            request.ContractId = contractId;
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ContractInfoResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                contractInfo = ContractInfoMapp.Mapp(response.ContractInfo);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractInfo;
        }
    }
}
