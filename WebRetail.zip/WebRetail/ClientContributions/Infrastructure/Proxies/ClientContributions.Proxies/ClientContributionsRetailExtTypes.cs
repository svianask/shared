﻿using Common.Domain;
using System.Collections.Generic;

namespace ClientContributions.Proxies
{
    #region Get Segment Type
    public class ContractSegmentTypeRequestPrcy
    {
        public string ContractId;
    }

    public class ContractSegmentTypeResponsePrxy
    {
        public int SegmentOfContractType;
        public OperationResult Result;
    }
    #endregion

    #region Schedule Transfers
    public class ValidateScheduleContributionResponsePxy
    {
        public OperationResult Result;
        public ScheduleOperationPrxy ContributionSchedule;
    }
    public class ScheduleOperationPrxy
    {
        public string InitSchedule;
        public string EndSchedule;
    }
    #endregion

    #region Domiciliation Contract

    public class DomiciliationHsbcByContractResponsePrxy : BaseResponsePrxy
    {
        public List<ClientDomiciliationHsbcPrxy> Domiciliation { get; set; }
    }

    public class DomiciliationSantanderByContractResponsePrxy : BaseResponsePrxy
    {
        public List<ClientDomiciliationSantanderPrxy> Domiciliation { get; set; }
    }

    public class ClientDomiciliationHsbcPrxy : BaseClientDomiciliationPrxy { }

    public class ClientDomiciliationSantanderPrxy : BaseClientDomiciliationPrxy { }


    public class ContractExtBasicInfoRequestPrxy : BaseRequestPrxy { }
    public class ContractExtBasicInfoResponsePrxy : BaseResponsePrxy
    {
        public ContractExtBasicInfoPrxy ContractExtBasicInfo;
    }

    public class ContractExtBasicInfoPrxy
    {
        public decimal CommittedAmount;
    }

    #endregion
}
