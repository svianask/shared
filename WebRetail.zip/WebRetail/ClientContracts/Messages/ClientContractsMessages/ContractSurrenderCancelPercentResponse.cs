﻿

using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractSurrenderCancelPercentResponse
    {
        public OperationResult Result;
        public decimal Charge;

        public ContractSurrenderCancelPercentResponse()
        {
            Result = new OperationResult();
        }
    }
}
