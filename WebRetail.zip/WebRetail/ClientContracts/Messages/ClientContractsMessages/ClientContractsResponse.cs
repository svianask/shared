﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ClientContractsResponse
    {
        private OperationResult _result;
        private ClientContracts _clientContracts;

        public ClientContractsResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public ClientContracts ClientContracts { get => _clientContracts; set => _clientContracts = value; }
    }
}
