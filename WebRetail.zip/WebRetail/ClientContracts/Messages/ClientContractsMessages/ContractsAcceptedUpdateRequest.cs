﻿namespace ClientContractsMessages
{
    public class ContractsAcceptedUpdateRequest
    {
        public string RFC { get; set; }
        public string ContractId { get; set; }
        public bool IsCommited { get; set; }
    }
}
