﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ClientContractsByFPResponse
    {
        private OperationResult _result;
        private ClientContracts _clientContracts;

        public ClientContractsByFPResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public ClientContracts ClientContracts { get => _clientContracts; set => _clientContracts = value; }
    }
}
