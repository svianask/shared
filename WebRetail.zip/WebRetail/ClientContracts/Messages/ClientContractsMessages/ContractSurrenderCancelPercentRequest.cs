﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class ContractSurrenderCancelPercentRequest
    {
        public int ContractObjectiveNumContributions { get; set; }
        public decimal ContractMonthsOnPlan { get; set; }
        public int PlanIdentifier { get; set; }
    }
}
