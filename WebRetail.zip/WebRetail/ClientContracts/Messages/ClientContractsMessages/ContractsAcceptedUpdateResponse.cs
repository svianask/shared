﻿

using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContractsMessages
{
    public class ContractsAcceptedUpdateResponse
    {
        private OperationResult _result;
        public ContractsAcceptedUpdateResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
    }
}
