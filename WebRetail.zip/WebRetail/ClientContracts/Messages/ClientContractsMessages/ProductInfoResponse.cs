﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;
using ClientContractsDomain.ClienContractsAggregate;
namespace ClientContractsMessages
{
    public class ProductInfoResponse
    {
        public OperationResult Result;
        public ContractProductInfo ProductInfo;
    }
}
