﻿using System;
using System.Collections.Generic;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsMessages
{
    public class ContractMovementsPendingRequest
    {
        private List<AssociatedContractMess> _associatedContracts;
        private DateTime _initialDate;
        private DateTime _finalDate;
        private int _platform;
        
        public ContractMovementsPendingRequest()
        {
            AssociatedContracts = new List<AssociatedContractMess>();
        }

        public List<AssociatedContractMess> AssociatedContracts { get => _associatedContracts; set => _associatedContracts = value; }
        public DateTime InitialDate { get => _initialDate; set => _initialDate = value; }
        public DateTime FinalDate { get => _finalDate; set => _finalDate = value; }
        public int Platform { get => _platform; set => _platform = value; }
    }
}
