﻿using System;
using System.Collections.Generic;
using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractMovementsPendingResponse
    {
        private OperationResult _result;
        private List<ContractMovementDetail> _contractMovementPendingDetails;

        public ContractMovementsPendingResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<ContractMovementDetail> ContractMovementPendingDetails { get => _contractMovementPendingDetails; set => _contractMovementPendingDetails = value; }
    }
}
