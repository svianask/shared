﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class GetContractDetailByContractIdRequest
    {
        public string ContractId { get; set; }
        public string ClientIdentifier { get; set; }
    }

    public class GetContractDetailByContractIdResponse
    {
        public OperationResult Result;
        public ContractInfo ContractInfo;
    }
}
