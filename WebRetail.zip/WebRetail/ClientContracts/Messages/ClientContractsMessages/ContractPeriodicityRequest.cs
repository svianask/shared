﻿using System;

namespace ClientContractsMessages
{
    public class ContractPeriodicityRequest
    {
        public String ContractMaster { get; set; }
    }
}
