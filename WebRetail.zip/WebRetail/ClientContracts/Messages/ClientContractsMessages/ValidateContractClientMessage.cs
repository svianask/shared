﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class ValidateContractClientResponse
    {
        public bool IsContractClient { get; set; }
        public OperationResult Result { get; set; }

        public ValidateContractClientResponse() { Result = new OperationResult(); }
    }

    public class ValidateContractClientRequest
    {
        public string ClientIdentifier { get; set; }
        public string ContractId { get; set; }
    }
}
