﻿namespace ClientContractsMessages
{
    public class ContractExtBasicInfoRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
    }
}
