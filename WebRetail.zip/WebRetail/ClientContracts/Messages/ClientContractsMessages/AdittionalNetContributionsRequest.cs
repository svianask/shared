﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class AdittionalNetContributionsRequest
    {
        public AdittionalNetContributionsRequest()
        {
            AssociatedContracts = new List<AssociatedContractMess>();
        }
        
        public List<AssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
    }
}
