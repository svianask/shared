﻿namespace ClientContractsMessages
{
    public class ContractBalanceDetailRequest
    {
        public string ContractId;
    }
}
