﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class GetClientContractsBasicInfoByContractIdResponse
    {
        public ClientContracts ClientContracts { get; set; }
        public OperationResult Result { get; set; }
    }

    public class GetClientContractsBasicInfoByContractIdRequest
    {
        public string ContractId;
        public string EmailFP;
    }
}
