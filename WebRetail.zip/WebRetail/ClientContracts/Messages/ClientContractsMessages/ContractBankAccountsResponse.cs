﻿using System;
using System.Collections.Generic;
using ClientContractsDomain.BankAccountAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractBankAccountsResponse
    {
        public OperationResult Result { get; set; }

        public List<ContractBankAccount> ContractBankAccounts { get; set; }

        public ContractBankAccountsResponse()
        {
            Result = new OperationResult();
        }
    }
}
