﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class GetUrlMovementsResponse
    {
        public OperationResult Result;
        public Dictionary<string, string> MovementsData;

        public GetUrlMovementsResponse() { Result = new OperationResult(); }
    }

    public class GetUrlMovementsRequest
    {
        public string ContractId { get; set; }
    }

    public class GetDecryptStringResponse
    {
        public OperationResult Result;
        public string DecrytpResult;
        public GetDecryptStringResponse() { Result = new OperationResult(); }
    }

    public class GetDecryptStringRequest
    {
        public string DecryptString;
    }
}
