﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class GetContractsBasicInfoClientResponse
    {
        public ClientContracts ClientContracts { get; set; }
        public OperationResult Result { get; set; }
    }

    public class GetContractsBasicInfoClientRequest
    {
        public string ClientIdentifier;
    }
}
