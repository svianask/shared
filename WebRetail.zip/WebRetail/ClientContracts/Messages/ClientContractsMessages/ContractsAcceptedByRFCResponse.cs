﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;
using System.Collections.Generic;


namespace ClientContractsMessages
{
    public class ContractsAcceptedByRFCResponse
    {
        private OperationResult _result;
        private List<ContractAccepted> contracts;
        public ContractsAcceptedByRFCResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<ContractAccepted> Contracts { get => contracts; set => contracts = value; }
    }
}
