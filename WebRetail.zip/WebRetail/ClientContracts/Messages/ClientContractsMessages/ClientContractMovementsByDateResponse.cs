﻿using System;
using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ClientContractMovementsByDateResponse
    {
        private OperationResult _result;
        private ContractMovementsInfo _contractMovementsInfo;

        public ClientContractMovementsByDateResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public ContractMovementsInfo ContractMovementsInfo { get => _contractMovementsInfo; set => _contractMovementsInfo = value; }

    }
}
