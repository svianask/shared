﻿using ClientContractsDomain.ClienContractsAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractExtBasicInfoResponse
    {
        public ContractExtBasicInfo ContractExtBasicInfo { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }
}
