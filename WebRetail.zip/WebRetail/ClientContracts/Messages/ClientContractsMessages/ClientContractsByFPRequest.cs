﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class ClientContractsByFPRequest
    {
        private string _contractId;
        private string _fpEmail;

        public ClientContractsByFPRequest()
        {
        }

        public string ContractId { get => _contractId; set => _contractId = value; }
        public string FpEmail { get => _fpEmail; set => _fpEmail = value; }
    }
}
