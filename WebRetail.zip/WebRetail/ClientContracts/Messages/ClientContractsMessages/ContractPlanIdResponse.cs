﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractPlanIdResponse
    {
        public OperationResult Result;
        public int PlanId;
    }
}
