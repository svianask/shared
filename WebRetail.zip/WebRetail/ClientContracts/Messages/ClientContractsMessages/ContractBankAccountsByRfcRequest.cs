﻿namespace ClientContractsMessages
{
    public class ContractBankAccountsByRfcRequest
    {
        public string RFC { get; set; }
    }
}
