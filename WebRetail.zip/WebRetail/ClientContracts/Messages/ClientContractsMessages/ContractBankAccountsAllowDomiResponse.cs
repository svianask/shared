﻿using ClientContractsDomain.ContractBankAccountAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContractsMessages
{
    public class ContractBankAccountsAllowDomiResponse
    {
        public List<ContractBankAccountAllowDomi> ContractBankAccountAllowDomis { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }
}
