﻿using ClientContractsDomain.InvestmentsAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractBalanceDetailResponse
    {
        public Investments Investments;
        public OperationResult Result;
    }
}
