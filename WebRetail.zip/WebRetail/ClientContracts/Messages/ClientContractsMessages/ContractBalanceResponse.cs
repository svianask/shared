﻿using ClientContractsDomain.BalanceAggregate;
using Common.Domain;

namespace ClientContractsMessages
{
    public class ContractBalanceResponse
    {
        public ContractBalance ContractBalance;
        public OperationResult Result;
    }

  
}
