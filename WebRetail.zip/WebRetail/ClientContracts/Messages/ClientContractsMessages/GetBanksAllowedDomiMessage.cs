﻿using ClientContractsDomain.BankAccountAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContractsMessages
{
    public class GetBanksAllowedDomiResponse
    {
        public List<Bank> Banks { get; set; }
        public OperationResult Result { get; set; }
        
        public GetBanksAllowedDomiResponse(List<Bank> banks, OperationResult result)
        {
            Banks = banks;
            Result = result;            
        }
    }
}
