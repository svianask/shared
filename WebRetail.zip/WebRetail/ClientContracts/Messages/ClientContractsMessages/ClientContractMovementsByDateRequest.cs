﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class ClientContractMovementsByDateRequest
    {
        private string _contractId;
        private string _initialDate;
        private string _finalDate;
        public ClientContractMovementsByDateRequest() { }

        public string ContractId { get => _contractId; set => _contractId = value; }
        public string InitialDate { get => _initialDate; set => _initialDate = value; }
        public string FinalDate { get => _finalDate; set => _finalDate = value; }
    }
}
