﻿
namespace ClientContractsMessages
{
    public class ContractsAcceptedByRFCRequest
    {
        public string Rfc { get; set; }
    }
}
