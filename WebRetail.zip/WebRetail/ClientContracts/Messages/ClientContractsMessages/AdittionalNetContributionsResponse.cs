﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsMessages
{
    public class AdittionalNetContributionsResponse
    {
        private decimal _adittionalNetContributions;
        private OperationResult _result;

        public AdittionalNetContributionsResponse()
        {
            _result = new OperationResult();
        }

        public decimal AdittionalNetContributions { get => _adittionalNetContributions; set => _adittionalNetContributions = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
