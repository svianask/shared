﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClientContractsMessages
{
    public class ClientContractsRequest
    {
        private string _clientIdentifier;
        public ClientContractsRequest()
        {
        }

        public string ClientIdentifier { get => _clientIdentifier; set => _clientIdentifier = value; }
    }
}
