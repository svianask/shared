using ClientContractsDomain.BalanceAggregate;
using ClientContractsDomain.BankAccountAggregate;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.ClientContractProfileAggregate;
using ClientContractsDomain.ContractBankAccountAggregate;
using ClientContractsDomain.ContractInflationAggregate;
using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.InvestmentsAggregate;
using ClientContractsDomain.PlanAggregate;
using ClientContractsDomain.PortfolioProfileAggregate;
using ClientContractsMessages;
using ClientContractsProxy;
using Common.Domain;
using Common.Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ClientContractsApplication
{


    public class ClientContractsApp : IClientContractsApp
    {
        private readonly ISeriLogHelper _log;
        public readonly IRetailServiceProxy _retailServiceProxy;
        public readonly IRetailExtServiceProxy _retailExtServiceProxy;
        public readonly IWebRetailServiceProxy _webRetailServiceProxy;
        public readonly IMxAuthApiProxy _mxAuthApi;
        private readonly IParametersProxy _businessParametersPrxy;

        public ClientContractsApp(ISeriLogHelper log, IRetailServiceProxy retailServiceProxy, IRetailExtServiceProxy retailExtServiceProxy,
            IWebRetailServiceProxy webRetailServiceProxy, IMxAuthApiProxy mxAuthApi, IParametersProxy businessParametersPrxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
            _retailExtServiceProxy = retailExtServiceProxy;
            _webRetailServiceProxy = webRetailServiceProxy;
            _mxAuthApi = mxAuthApi;
            _businessParametersPrxy = businessParametersPrxy;
        }

        private bool _valScheduleTranfers;

        private List<string> _plansWithdrawals;
        private bool _validateSchedule;

        private List<string> _plansContributions;


        private delegate ContractInfo delGetContractInfo(string contractId, out OperationResult result);
        private delegate string delGetClientIdByContract(string contractId, out OperationResult result);

        private delegate ClientContracts delGetContract(string clientIdentifier, out OperationResult result);
        private delegate List<AssociatedContract> delGetAssociateContracts(string clientIdentifier, out OperationResult result);

        private delegate List<string> delGetClientContractsByFP(string fpEmail, List<string> clientContractsId, out OperationResult result);

        private delegate void delGetContractDetail(ContractInfo contract, List<string> lstPlansApplyContribution, out OperationResult result);
        private delegate void delGetContractBasicDetail(ContractInfo contract, out OperationResult result);
        private delegate List<RelatedImageInfo> delGetGoalsImage(List<short> images, out OperationResult result);
        private delegate List<Plan> delGetPlansById(List<short> plans, out OperationResult result);
        private delegate int delGetTypeContract(string contractId, out OperationResult result);
        private delegate decimal delGetLifeInsuranceAmount(string contractId, out OperationResult result);
        private delegate DateTime delGetBeginContractTransDate(string contractId, int source, out OperationResult result);
        private delegate SummaryContributions delGetSummaryContributionsNumber(string groupingContractId, out OperationResult result);
        private delegate ContractExtBasicInfo delGetContractExtBasicInfo(string contractId, out OperationResult result);
        private delegate CashTransaction delGetContractCashTransactions(string contractId, int platform, out OperationResult result);
        private delegate decimal delGetOnDemandCash(string contractId, out OperationResult result);
        private delegate List<Fund> delGetBalanceDetail(int platform, List<string> contracts, out OperationResult result);
        private delegate List<string> delGetPlansApplyContributions(out OperationResult result);


        public ClientContracts GetClientContracts(string clientIdentifier, out OperationResult result)
        {
            OperationResult _getClientContractsResult = new OperationResult();
            ClientContracts _clientContracts = null;
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            List<string> lstPlansApplyContribution = new List<string>();
            result = new OperationResult();

            try
            {
                result.Successful = true;

                _log.Info("Validando el horario");
                _validateSchedule = false;//_webRetailServiceProxy.ValidateWithdrawalWithinSchudle(out result);
                _log.Debug("{cntx}", _validateSchedule);

                _valScheduleTranfers = true;

                _log.Info("Obteniendo la información básica de los contratos del cliente {cntx}", clientIdentifier);
                delGetContract dGetContract = _retailServiceProxy.GetContracts;
                IAsyncResult rGetContract = dGetContract.BeginInvoke(clientIdentifier, out result, null, null);

                _log.Info("Obteniendo información de los contratos asociados {cntx}", clientIdentifier);
                delGetAssociateContracts dGetAssociateContracts = _retailServiceProxy.GetAssociateContracts;
                IAsyncResult rGetAssociateContracts = dGetAssociateContracts.BeginInvoke(clientIdentifier, out result, null, null);
                //Se comenta hasta que se implemente flujo de aportes en liferay
                //delGetPlansApplyContributions dGetPlansApplyContributions = _retailExtServiceProxy.GetPlansApplyContribution;
                //IAsyncResult rGetPlansApplyContributions = dGetPlansApplyContributions.BeginInvoke(out result, null, null);

                while (!rGetContract.IsCompleted || !rGetAssociateContracts.IsCompleted) { Thread.Sleep(20); }
                _clientContracts = dGetContract.EndInvoke(out result, rGetContract);
                _log.Debug("Contratos del cliente {cntx}", _clientContracts);

                associatedContracts = dGetAssociateContracts.EndInvoke(out result, rGetAssociateContracts);
                _log.Debug("Contratos asociados {cntx}", _clientContracts);
                //Se comenta hasta que se implemente flujo de aportes en liferay
                //lstPlansApplyContribution = dGetPlansApplyContributions.EndInvoke(out result, rGetPlansApplyContributions);

                List<IAsyncResult> AsyncContracts = new List<IAsyncResult>();
                List<OperationResult> results = new List<OperationResult>();

                List<IAsyncResult> AsyncDetails = new List<IAsyncResult>();
                List<delGetContractDetail> delGetContractDetails = new List<delGetContractDetail>();

                List<IAsyncResult> AsyncBalDetail = new List<IAsyncResult>();
                List<delGetBalanceDetail> delGetBalanceDetails = new List<delGetBalanceDetail>();

                _log.Info("Procesando los contratos del cliente {cntx}", clientIdentifier);
                for (int nCont = 0; nCont <= _clientContracts.Contracts.Count - 1; nCont++)
                {
                    List<ContractInfo> _cliCont = new List<ContractInfo>();

                    _cliCont.Add(_clientContracts.Contracts[nCont]);
                    if (nCont + 1 < _clientContracts.Contracts.Count)
                    {
                        nCont++;
                        _cliCont.Add(_clientContracts.Contracts[nCont]);
                    }

                    //Asynchronous transactions begin
                    int nContract = 1;
                    foreach (ContractInfo contract in _cliCont)
                    {
                        OperationResult resContrato = new OperationResult();

                        var associatedContr = associatedContracts.Where(a => a.AssociatedContractId == contract.Id).ToList<AssociatedContract>();

                        _log.Info("Estableciendo los contratos asociados al contrato");
                        _log.Debug("{cntx}", associatedContr);
                        contract.SetAssociatedContracts(associatedContr);

                        _log.Info("Obteniendo el detalle de saldos del contrato {cntx}", contract.Id);
                        delGetBalanceDetails.Add(_retailServiceProxy.GetBalanceDetail);
                        AsyncDetails.Add(delGetBalanceDetails[nContract - 1].BeginInvoke(
                            contract.Platform, associatedContr.Select(c => c.ContractId).ToList<string>(), out resContrato, null, null));

                        _log.Info("Obteniendo la información adicional del contrato {cntx}", contract.Id);
                        delGetContractDetails.Add(GetContractDetail);
                        AsyncContracts.Add(delGetContractDetails[nContract - 1].BeginInvoke(contract, lstPlansApplyContribution, out resContrato, null, null));
                        nContract++;
                    }

                    //Verification of completed asynchronous transactions
                    bool allComplete = false;
                    while (!allComplete)
                    {
                        allComplete = true;
                        AsyncContracts.ForEach(C => allComplete &= C.IsCompleted);
                        AsyncDetails.ForEach(D => allComplete &= D.IsCompleted);
                        Thread.Sleep(20);
                    }

                    //Get result of the asynchronous transactions
                    for (int proc = 0; proc < AsyncContracts.Count; proc++)
                    {
                        OperationResult resContrato = new OperationResult();
                        _log.Debug("{cntx}", _cliCont[proc]);
                        delGetContractDetails[proc].EndInvoke(out resContrato, AsyncContracts[proc]);
                        delGetContractDetails[proc] = null;
                        AsyncContracts[proc] = null;

                        OperationResult resBalance = new OperationResult();

                        var funds = delGetBalanceDetails[proc].EndInvoke(out resBalance, AsyncDetails[proc]);
                        _log.Debug("{cntx}", funds);
                        _cliCont[proc].SetInvestments(funds);
                        _cliCont[proc].CalculateBalanceContract();
                    }
                    AsyncContracts.Clear();
                    AsyncDetails.Clear();
                    delGetContractDetails.Clear();
                    delGetBalanceDetails.Clear();
                }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente GetClientContracts {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return _clientContracts;
        }

        private delegate ClientContractProfile delGetClientContractProfile(string contractId, int platform, out OperationResult result);
        private delegate int delGetContractSegmentType(string contractId, out OperationResult result);
        private delegate List<ContractBankAccount> delGetContractBankAccounts(string contractId, out OperationResult result);
        private delegate PortfolioProfile delGetContractPortafolioProfile(string contractId, int platform, out OperationResult result);
        private delegate bool delDoesPendingTransfers(string contractId, int platform);
        private delegate decimal delGetAmountForSaleTranfer(string contractId);
        private void GetContractDetail(ContractInfo contract, List<string> lstPlansApplyContribution, out OperationResult result)
        {

            List<IAsyncResult> AsyncDetail = new List<IAsyncResult>();
            result = new OperationResult();
            List<short> goalIds = new List<short>();
            List<short> BasPlanIds = new List<short>();


            goalIds.Add(contract.GoalId);
            BasPlanIds.Add(contract.PlanBasId);
            var ContractId = contract.Id;

            _log.Info("Obteniendo información de los planes: {cntx}", new { ContractId, BasPlanIds });
            var plansInfo = _retailExtServiceProxy.GetPlansById(BasPlanIds, out result);
            _log.Debug("{cntx}", plansInfo);

            var Platform = contract.Platform;
            _log.Info("Estableciendo infomación del plan en el contrato {cntx}", ContractId);
            contract.SetPlanInfo(plansInfo, Platform);

            _log.Info("Obteniendo el id del segmento para el contrato {cntx}", ContractId);
            delGetContractSegmentType dGetContractSegmentType = GetContractSegmentType;
            IAsyncResult rGetContractSegmentType = dGetContractSegmentType.BeginInvoke(ContractId, out result, null, null);

            //_log.Info("Obteniendo las cuentas bancarias para el contrato {cntx}", ContractId);
            //delGetContractBankAccounts dGetContractBankAccounts = GetContractBankAccounts;
            //IAsyncResult rGetContractBankAccounts = dGetContractBankAccounts.BeginInvoke(ContractId, out result, null, null);

            var AssociatedContracts = contract.AssociatedContracts;
            _log.Info("Obteniendo las aportaciones realizadas al contrato {cntx}", ContractId);
            var RealizedContributions = _retailServiceProxy.GetContractContributions(AssociatedContracts, Platform, out result);
            _log.Debug("{cntx}", RealizedContributions);

            _log.Info("Obteniendo los retiros realizados al contrato {cntx}", ContractId);
            var ContractWithdrawals = _retailServiceProxy.GetContractWithdrawals(AssociatedContracts, Platform, out result);
            _log.Debug("{cntx}", ContractWithdrawals);

            _log.Info("Obteniendo los aportaciones On Demand realizadas al contrato {cntx}", ContractId);
            var OnDemandCash = _retailServiceProxy.GetContributionsOnDemand(AssociatedContracts, Platform, out result);
            _log.Debug("{cntx}", OnDemandCash);

            _log.Info("Obteniendo la información extendida del contrato {cntx}", ContractId);
            var ContractExtBasicInfo = _retailExtServiceProxy.GetContractExtBasicInfo(ContractId, out result);
            _log.Debug("{cntx}", ContractExtBasicInfo);

            var summaryContributionNumber = SummaryContributions.Create(0, 0, 0, 0);
            var GroupingContractId = contract.GroupingContractId;
            if (contract.ContractType == 1)
            {
                _log.Info("Obteniendo el número de contribuciones por contrato {cntx}", ContractId);
                summaryContributionNumber = _retailServiceProxy.GetSummaryContributionsNumber(GroupingContractId, out result);
                _log.Debug("{cntx}", summaryContributionNumber);
            }

            var siifAfiliationDate = contract.AfiliationDate;
            var firstContributionDate = RealizedContributions.FirstContributionDate;
            var raAfiliationDate = ContractExtBasicInfo.AfiliationDate;
            _log.Info("Determinando la fecha fecha de afiliación del contrato {cntx}", new { contract.AfiliationDate, firstContributionDate, raAfiliationDate });
            contract.DetermineAfiliationDate(new List<DateTime> { contract.AfiliationDate, firstContributionDate, raAfiliationDate });
            _log.Debug("{cntx}", contract.AfiliationDate);

            _log.Info("Obteniendo periodo del contrato {cmtx}", ContractId);
            ContractPeriod period = _retailServiceProxy.GetContractPeriodByContract(ContractId, out result);
            _log.Debug("{cntx}", period);
            contract.SetPeriod(period);

            var TotalContributionsNumber = summaryContributionNumber.TotalContributions;
            var ExpectedContributionsNumber = summaryContributionNumber.ExpectedContributions;
            var RealizedContributionsNumber = RealizedContributions.OrdinalContributionsNumber == 0 ? summaryContributionNumber.RealizedContributions : RealizedContributions.OrdinalContributionsNumber;
            var FailedContributionsNumber = summaryContributionNumber.FailedContributions;
            _log.Info("Estableciendo el resumen del numero de contribuciones {cntx}", ContractId);
            contract.SetSummaryContributionsNumber(TotalContributionsNumber, ExpectedContributionsNumber, RealizedContributionsNumber, FailedContributionsNumber);

            var SavingTerm = ContractExtBasicInfo.SavingTerm;
            _log.Info("Estableciendo total de contribuciones y detrminando la pendientes {cntx}", ContractId);
            contract.SetTotalContributionsNumber(SavingTerm);

            var AfiliationDate = contract.AfiliationDate;
            _log.Info("Estableciendo total de contribuciones que debería de llevar {cntx}", ContractId);
            contract.CalculateExpectedContributionsNumber(AfiliationDate);

            _log.Info("Obteniendo la imagens según la meta de ahorro o el producto {cntx}", ContractId);
            var relatedImagesInfo = _retailExtServiceProxy.GetGoalsImage(goalIds, out result);
            _log.Debug("{cntx}", relatedImagesInfo);

            _log.Info("Estableciendo la imagen según la meta de ahorro {cntx}", ContractId);
            contract.SetGoalImage(relatedImagesInfo, contract.ContractType);

            var Balance = 0M;
            _log.Info("Obteniendo el monto de la suma asegurada para el contrato {cntx}", ContractId);
            var LifeInsuranceAmount = _retailExtServiceProxy.GetLifeInsuranceAmount(ContractId, out result);
            _log.Debug("{cntx}", LifeInsuranceAmount);

            var SavingGoal = ContractExtBasicInfo.SavingGoal;
            _log.Info("Estableciendo los saldos del contrato {cntx}", ContractId);
            contract.SetBalancesContract(Balance, LifeInsuranceAmount, SavingGoal);

            var amountContributionPending = 0M;
            _log.Info("Consultando contribuciones pendientes del contrato {cntx}", ContractId);
            amountContributionPending = _retailServiceProxy.GetPendingContributionAmount(ContractId, out result);
            contract.BalanceContract.SetPendingContributionAmount(amountContributionPending);
            _log.Debug("{cntx}", amountContributionPending);

            var amountContributionSum = 0M;
            _log.Info("Consultando la Suma de contribuciones en RA  del contrato {cntx}", ContractId);
            amountContributionSum = _retailServiceProxy.GetContributionSumAmount(ContractId, out result);
            contract.BalanceContract.SetContributionSumAmount(amountContributionSum);
            _log.Debug("{cntx}", amountContributionSum);

            _log.Info("Consultando Inflación del contrato {cntx}", ContractId);
            ContractInflation contractInflation = _retailServiceProxy.GetContractInflation(ContractId, out result);
            _log.Debug("Inflación del contraco", contractInflation);

            contract.BalanceContract.SetContractInflation(contractInflation);

            var OrdinalWithdrawalsAmount = ContractWithdrawals.OrdinalWithdrawalsAmount;
            var AdditionalWithdrawalsAmount = ContractWithdrawals.AdditionalWithdrawalsAmount;
            _log.Info("Estableciendo el monto de los retiros realizados {cntx}", ContractId);
            contract.SetWithdrawals(OrdinalWithdrawalsAmount, AdditionalWithdrawalsAmount);

            //Se comenta hasta que se implemente flujo de aportes en liferay
            _log.Info("Validando si aplican el proceso aportaciones para el contrato {cntx}", ContractId);
            var validApplyContributions = false;//ValidateApplyContributions(contractBankAccounts, lstPlansApplyContribution, contract.PlaId);
            _log.Debug("{cntx}", validApplyContributions);

            _log.Info("Estableciendo si aplican aportaciones para el contrato {cntx}", ContractId);
            contract.SetApplyContributions(validApplyContributions);

            var OrdinalContributionsAmount = RealizedContributions.OrdinalContributionsAmount;
            var AdditionalContributionsAmount = RealizedContributions.AdditionalContributionsAmount;

            _log.Info("Estableciendo los montos de las aportaciones {cntx}", ContractId);
            contract.SetContributions(OrdinalContributionsAmount, AdditionalContributionsAmount);

            var OrdinalOnDemandAmount = OnDemandCash.OrdinalOnDemandAmount;
            var AdditionalOnDemandAmount = OnDemandCash.AdditionalOnDemandAmount;

            _log.Info("Estableciendo los montos de las aportaciones On Demand {cntx}", ContractId);
            contract.SetOnDemandCash(OrdinalOnDemandAmount, AdditionalOnDemandAmount);

            _log.Info("Obteniendo los montos de los cargos {cntx}", ContractId);
            var Charges = _retailServiceProxy.GetContractCharges(AssociatedContracts, Platform, out result);
            _log.Debug("{cntx}", Charges);

            _log.Info("Estableciendo los montos de los cargos {cntx}", ContractId);
            contract.SetCharges(Charges);

            var InitialValuation = 0M;
            if (contract.ContractType != 1)
            {
                _log.Info("Obteniendo el saldo inicial del contrato {cntx}", ContractId);
                InitialValuation = GetHistoricInitialBalance(contract.AssociatedContracts, Platform, siifAfiliationDate);
                _log.Debug("{cntx}", InitialValuation);
            }

            var CommittedAmount = ContractExtBasicInfo.CommittedAmount;
            var SavingAdvanceContributions = summaryContributionNumber.RealizedContributions;

            _log.Info("Estableciendo el número máximo de aportaciones que se pueden realizar {cntx}", ContractId);
            contract.SetMaxRealizedContributionsNumber(SavingAdvanceContributions);
            if ((SavingAdvanceContributions == 0) && CommittedAmount != 0)
            {
                _log.Info("Calculando el número de contribuciones realizadas {cntx}", ContractId);
                contract.CalculateRealizedContributions(CommittedAmount);
            }

            _log.Info("Estableciendo el saldo inicial del contrato {cntx}", ContractId);
            contract.SetInitialValuation(InitialValuation);

            while (!rGetContractSegmentType.IsCompleted) { Thread.Sleep(20); }

            var SegmentId = dGetContractSegmentType.EndInvoke(out result, rGetContractSegmentType);
            _log.Info("Segment type {cntx}", SegmentId);
            contract.SetSegmentType(SegmentId);

            _log.Info("Validando y seteando si tiene trackerDetail");
            contract.SetHasTrackerDetail(HasTrackerDetail(contract.PlaId));
            _log.Info("HasTrackerDetail: {cntx}", contract.HasTrackerDetail);

            //var contractBankAccounts = dGetContractBankAccounts.EndInvoke(out result, rGetContractBankAccounts);
            //_log.Debug("Cuentas bancarias {cntx}", contractBankAccounts);

            _log.Info("Validando si aplican retiros para el contrato {cntx}", ContractId);
            var validateApplyWithdrawalsPlan = false;//ValidateApplyWithdrawalsContract(contract, ContractId, SegmentId, contractBankAccounts);
            _log.Debug("{cntx}", validateApplyWithdrawalsPlan);

            _log.Info("Estableciendo si aplican retiros para el contrato {cntx}", ContractId);
            contract.SetApplyWhitdrawals(validateApplyWithdrawalsPlan);
            contract.SetProductApplyTransfers();
            _log.Debug("{cntx}", contract.ApplyTransfers);
        }

        private bool ValidateApplyWithdrawalsContract(ContractInfo currentContract, string contractID, int segmentId, List<ContractBankAccount> bankAccounts)
        {
            try
            {
                if (!_validateSchedule) { return false; }

                var filterAccounts = new List<ContractBankAccount>();
                _log.Info("Validando las cuentas bancarias {cntx}", contractID);
                bankAccounts.ForEach(p =>
                {
                    if (p.BankId.Equals(12)) { if (p.BankAccountTypeId.Equals(5)) { filterAccounts.Add(p); } }
                    else { if (p.BankAccountTypeId.Equals(10)) { filterAccounts.Add(p); } }
                });
                _log.Debug("{cntx}", filterAccounts);
                if (filterAccounts is null || filterAccounts.Count < 1) { return false; }

                _log.Info("Validando que el plan del contrato {cntx} aplique para retiros ", contractID);
                var validateApplyWithdrawalsPlan = _webRetailServiceProxy.ValidatePlanApplyPartialWithdrawals(currentContract.PlaId, segmentId, out OperationResult result);
                _log.Debug("{cntx}", validateApplyWithdrawalsPlan);
                if (!validateApplyWithdrawalsPlan) { return false; }

                _log.Info("Validando si tiene retiros pendientes el contrato {cntx}", contractID);
                var pendingWihtdrawals = _webRetailServiceProxy.GetContractSummaryPendingWithdrawals(contractID, segmentId, out result);
                _log.Debug("{cntx}", _validateSchedule);
                if (pendingWihtdrawals > 0) { return false; }

                _log.Info("Obteniendo los fondos del contrato {cntx}", contractID);
                var lstFunds = _webRetailServiceProxy.GetPartialWithdrawalFunds(contractID, currentContract.Platform, segmentId, out result);
                _log.Debug("{cntx}", lstFunds);
                var amount = lstFunds.Sum(x => x.Valuation);

                _log.Info("Validando el monto disponible para retiros del contrato {cntx}", contractID);
                var validateAmount = _webRetailServiceProxy.ValidateAmountAvailable(contractID, amount, segmentId, out result);
                _log.Debug("{cntx}", validateAmount);
                if (validateAmount <= 0) { return false; }

                return true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al validar retiros del contrato {cntx}", new { contractID });
                return false;
            }
        }

        private bool HasTrackerDetail(String planId)
        {
            OperationResult result = new OperationResult();
            result.Successful = true;
            _log.Info("Evaluando HasTracker()");
            string trackerPlansParameter = _businessParametersPrxy.GetStringParameter("PLNSTRACKER", "", "", "Retail", "Standar", out result);
            _log.Debug("TrackerPlansParameter: {cntx}", trackerPlansParameter);
            _log.Debug("Sucessfull Tracker Plans: {cntx} ", result.Successful);
            if (!result.Successful) 
            {
                return false;
            }

            if (string.IsNullOrEmpty(trackerPlansParameter)) 
            {
                return false;
            }
            List<string> trackerPlans = trackerPlansParameter.Split( '|' ).ToList();

            var counterPlans = trackerPlans.Where(o => o.Equals(planId)).Count();
            _log.Debug("CounterPlans: {cntx}", counterPlans);
            return counterPlans > 0;
        }

        private bool ValidateApplyContributions(List<ContractBankAccount> bankAccounts, List<string> lstPlansApplyContribution, string planId)
        {
            if (bankAccounts is null) { return false; }

            if (lstPlansApplyContribution is null || !lstPlansApplyContribution.Contains(planId)) { return false; }

            return true;
        }

        public ClientContracts GetClientContractsByFP(string contractId, string fpEmail, out OperationResult result)
        {
            OperationResult _getClientContractsResult = new OperationResult();
            ClientContracts _clientContracts = ClientContracts.Create("EMPTY");
            ClientContracts _allClientContracts = null;
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            List<string> clientContractsId = new List<string>();
            List<string> contractsFp = new List<string>();
            List<string> lstPlansApplyContribution = new List<string>();
            result = new OperationResult();

            try
            {
                result.Successful = true;
                string clientIdentifier = _retailServiceProxy.GetClientIdByContract(contractId, out result);

                delGetContract dGetContract = _retailServiceProxy.GetContracts;
                IAsyncResult rGetContract = dGetContract.BeginInvoke(clientIdentifier, out result, null, null);

                while (!rGetContract.IsCompleted) { Thread.Sleep(20); }
                _allClientContracts = dGetContract.EndInvoke(out result, rGetContract);

                delGetAssociateContracts dGetAssociateContracts = _retailServiceProxy.GetAssociateContracts;
                IAsyncResult rGetAssociateContracts = dGetAssociateContracts.BeginInvoke(clientIdentifier, out result, null, null);

                clientContractsId = _allClientContracts.Contracts.Select(c => c.Id).ToList<string>();
                delGetClientContractsByFP dGetFpContracts = _retailExtServiceProxy.GetFpContracts;
                IAsyncResult rGetFpContracts = dGetFpContracts.BeginInvoke(fpEmail, clientContractsId, out result, null, null);

                delGetPlansApplyContributions dGetPlansApplyContributions = _retailExtServiceProxy.GetPlansApplyContribution;
                IAsyncResult rGetPlansApplyContributions = dGetPlansApplyContributions.BeginInvoke(out result, null, null);

                while (!rGetFpContracts.IsCompleted || !rGetAssociateContracts.IsCompleted) { Thread.Sleep(20); }
                associatedContracts = dGetAssociateContracts.EndInvoke(out result, rGetAssociateContracts);
                contractsFp = dGetFpContracts.EndInvoke(out result, rGetFpContracts);
                lstPlansApplyContribution = dGetPlansApplyContributions.EndInvoke(out result, rGetPlansApplyContributions);

                _clientContracts = ClientContracts.Create(_allClientContracts.Id);
                _allClientContracts.Contracts.Where(c => contractsFp.Contains(c.Id)).ToList().ForEach(x => _clientContracts.AddContract(x));

                List<IAsyncResult> AsyncContracts = new List<IAsyncResult>();
                List<OperationResult> results = new List<OperationResult>();

                List<IAsyncResult> AsyncDetails = new List<IAsyncResult>();
                List<delGetContractDetail> delGetContractDetails = new List<delGetContractDetail>();

                List<IAsyncResult> AsyncBalDetail = new List<IAsyncResult>();
                List<delGetBalanceDetail> delGetBalanceDetails = new List<delGetBalanceDetail>();

                for (int nCont = 0; nCont <= _clientContracts.Contracts.Count - 1; nCont++)
                {
                    List<ContractInfo> _cliCont = new List<ContractInfo>();

                    _cliCont.Add(_clientContracts.Contracts[nCont]);
                    //if (nCont + 1 < _clientContracts.Contracts.Count) _cliCont.Add(_clientContracts.Contracts[nCont + 1]);

                    //Asynchronous transactions begin
                    int nContract = 1;
                    foreach (ContractInfo contract in _cliCont)
                    {
                        OperationResult resContrato = new OperationResult();

                        var associatedContr = associatedContracts.Where(a => a.AssociatedContractId == contract.Id).ToList<AssociatedContract>();

                        contract.SetAssociatedContracts(associatedContr);

                        delGetBalanceDetails.Add(_retailServiceProxy.GetBalanceDetail);
                        AsyncDetails.Add(delGetBalanceDetails[nContract - 1].BeginInvoke(
                            contract.Platform, associatedContr.Select(c => c.ContractId).ToList<string>(), out resContrato, null, null));

                        delGetContractDetails.Add(GetContractDetail);
                        AsyncContracts.Add(delGetContractDetails[nContract - 1].BeginInvoke(contract, lstPlansApplyContribution, out resContrato, null, null));
                        nContract++;
                    }

                    //Verification of completed asynchronous transactions
                    bool allComplete = false;
                    while (!allComplete)
                    {
                        allComplete = true;
                        AsyncContracts.ForEach(C => allComplete &= C.IsCompleted);
                        AsyncDetails.ForEach(D => allComplete &= D.IsCompleted);
                        Thread.Sleep(20);
                    }

                    //Get result of the asynchronous transactions
                    for (int proc = 0; proc < AsyncContracts.Count; proc++)
                    {
                        OperationResult resContrato = new OperationResult();

                        delGetContractDetails[proc].EndInvoke(out resContrato, AsyncContracts[proc]);
                        delGetContractDetails[proc] = null;
                        AsyncContracts[proc] = null;

                        OperationResult resBalance = new OperationResult();

                        var funds = delGetBalanceDetails[proc].EndInvoke(out resBalance, AsyncDetails[proc]);
                        _cliCont[proc].SetInvestments(funds);
                        _cliCont[proc].CalculateBalanceContract();
                    }
                    AsyncContracts.Clear();
                    AsyncDetails.Clear();
                    delGetContractDetails.Clear();
                    delGetBalanceDetails.Clear();
                }
            }
            catch (Exception ex)
            {

                _log.Error(ex, "Error al obtener los contratos del cliente GetClientContracts {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return _clientContracts;

        }

        public ClientContracts GetContractsBasicInfoClient(string clientIdentifier, out OperationResult result)
        {
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("El identificador del cliente no puede ser nulo"); }

            result = new OperationResult();
            ClientContracts _clientContracts = null;

            try
            {
                _clientContracts = _retailServiceProxy.GetContracts(clientIdentifier, out result);
                _clientContracts.Contracts.ForEach(cont =>
                {
                    List<short> BasPlanIds = new List<short>
                {
                    cont.PlanBasId
                };
                    var plansInfo = _retailExtServiceProxy.GetPlansById(BasPlanIds, out OperationResult resultPlan);
                    var Platform = cont.Platform;
                    cont.SetPlanInfo(plansInfo, Platform);
                });

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente GetContractsBasicInfoClient {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return _clientContracts;
        }

        public ClientContracts GetClientContractsBasicInfoByContractId(string contractId, string emailFP, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato del cliente no puede ser nulo"); }
            if (string.IsNullOrEmpty(emailFP)) { throw new ArgumentException("El email del fp no puede ser nulo"); }

            result = new OperationResult();
            ClientContracts _clientContracts = null;
            ClientContracts _allClientContracts = null;

            try
            {
                _log.Info("Obteniendo el rfc del cliente para el contrato: {cntx}", contractId);
                var clientIdentifier = _retailServiceProxy.GetClientIdByContract(contractId, out result);
                _log.Debug("{cntx}", clientIdentifier);

                _log.Info("Obteniendo los contratos del cliente");
                _allClientContracts = _retailServiceProxy.GetContracts(clientIdentifier, out result);
                _log.Debug("{cntx}", _allClientContracts);

                var clientContractsId = _allClientContracts.Contracts.Select(c => c.Id).ToList();
                _log.Info("Obteniendo los contratos del fp");
                var contracstByFP = _retailExtServiceProxy.GetFpContracts(emailFP, clientContractsId, out result);
                _log.Debug("{cntx}", contracstByFP);

                _clientContracts = ClientContracts.Create(_allClientContracts.Id);
                _log.Info("Filtrando contratos del cliente con los contratos del fp.");
                _allClientContracts.Contracts.Where(c => contracstByFP.Contains(c.Id)).ToList().ForEach(x => _clientContracts.AddContract(x));
                _log.Debug("{cntx}", _clientContracts);

                _log.Info("Se itera los contatos obtenidos para setear los datos basicos");
                _clientContracts.Contracts.ForEach(cont =>
                {
                    List<short> BasPlanIds = new List<short> { cont.PlanBasId };
                    _log.Info("Obteniendo los datos para el plan bas: {cntx}", cont.PlanBasId);
                    var plansInfo = _retailExtServiceProxy.GetPlansById(BasPlanIds, out OperationResult resultPlan);
                    _log.Debug("{cntx}", plansInfo);

                    var Platform = cont.Platform;
                    cont.SetPlanInfo(plansInfo, Platform);
                });

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente GetClientContractsBasicInfoByContractId {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return _clientContracts;
        }

        #region Movements

        private delegate RealizedContributions delGetContractContributionsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        private delegate ContributionsOnDemand delGetContributionsOnDemandByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        private delegate ContractWithdrawals delGetContractWithdrawalsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        private delegate decimal delGetContractChargesByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        private delegate List<ContractMovementDetail> delGetContractDetailCashMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        public ContractMovementsInfo GetClientContractMovementsByDate(string contractId, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {

            result = new OperationResult();
            ContractMovementsInfo contractMovements = null;
            try
            {
                ContractInfo contractInfo = _retailServiceProxy.GetContractInfo(contractId, out result);
                List<short> BasPlanIds = new List<short>() { contractInfo.PlanBasId };

                var plansInfo = _retailExtServiceProxy.GetPlansById(BasPlanIds, out result);
                int platform = contractInfo.Platform;
                contractInfo.SetPlanInfo(plansInfo, platform);

                List<short> goalIds = new List<short>();
                goalIds.Add(contractInfo.GoalId);
                delGetGoalsImage delGetGoalsImage = _retailExtServiceProxy.GetGoalsImage;
                IAsyncResult asyncGetGoalsImage = delGetGoalsImage.BeginInvoke(goalIds, out OperationResult getGoalsImagesResult, null, null);

                _log.Info("Obteniendo el identificador del cliente del contrato");
                delGetClientIdByContract dGetClientIdByContract = _retailServiceProxy.GetClientIdByContract;
                IAsyncResult asyncGetClientId = dGetClientIdByContract.BeginInvoke(contractId, out OperationResult getClientIdResult, null, null);

                var contractType = contractInfo.ContractType;
                var contractComercialName = contractInfo.ComercialName;
                contractMovements = ContractMovementsInfo.Create(contractId, contractComercialName, contractType);

                var contractIniDate = contractInfo.AfiliationDate;
                initialDate = initialDate < contractIniDate ? contractIniDate : initialDate;
                TimeSpan timeInZero = new TimeSpan(0, 0, 0);
                finalDate = finalDate.Date + timeInZero;
                DateTime currentDate = DateTime.Now.Date + timeInZero;
                finalDate = currentDate < finalDate ? currentDate : finalDate;

                while (!asyncGetGoalsImage.IsCompleted || !asyncGetClientId.IsCompleted) { Thread.Sleep(10); }

                var relatedImagesInfo = delGetGoalsImage.EndInvoke(out getGoalsImagesResult, asyncGetGoalsImage);
                contractInfo.SetGoalImage(relatedImagesInfo, contractInfo.ContractType);
                contractMovements.SetGoalInfo(contractInfo.GoalId, contractInfo.GoalImage, contractInfo.GoalDescription);

                var clientId = dGetClientIdByContract.EndInvoke(out getClientIdResult, asyncGetClientId);
                var clientAssociatedContracts = _retailServiceProxy.GetAssociateContracts(clientId, out result);
                var singleAssociatedContracts = clientAssociatedContracts.Where(a => a.AssociatedContractId == contractId).ToList<AssociatedContract>();

                _log.Info("Obteniendo las apotaciones ordinarias.");
                delGetContractContributionsByDate delGetContractContributionsByDate = _retailServiceProxy.GetContractContributionsByDate;
                IAsyncResult asyncGetContractContributionsByDate = delGetContractContributionsByDate.BeginInvoke(singleAssociatedContracts, platform, initialDate, finalDate, out OperationResult getContractContributionByDateResult, null, null);

                _log.Info("Obteniendo aportaciones adicionales.");
                delGetContributionsOnDemandByDate delGetContributionsOnDemandByDate = _retailServiceProxy.GetContributionsOnDemandByDate;
                IAsyncResult asyncGetContributionsOnDemand = delGetContributionsOnDemandByDate.BeginInvoke(singleAssociatedContracts, platform, initialDate, finalDate, out OperationResult getContributionsOnDemandResult, null, null);

                _log.Info("Obteniendo retiros");
                delGetContractWithdrawalsByDate delGetContractWithdrawalsByDate = _retailServiceProxy.GetContractWithdrawalsByDate;
                IAsyncResult asyncGetContractWithdrawals = delGetContractWithdrawalsByDate.BeginInvoke(singleAssociatedContracts, platform, initialDate, finalDate, out OperationResult getContractWithdrawalsResult, null, null);

                _log.Info("Obteniendo cargos.");
                delGetContractChargesByDate delGetContractChargesByDate = _retailServiceProxy.GetContractChargesByDate;
                IAsyncResult asyncGetContractCharges = delGetContractChargesByDate.BeginInvoke(singleAssociatedContracts, platform, initialDate, finalDate, out OperationResult getChargesResult, null, null);

                _log.Info("Obteniendo detalle de movientos de efectivo.");
                delGetContractDetailCashMovementsByDate delGetContractDetailCashMovements = _retailServiceProxy.GetContractDetailCashMovementsByDate;
                IAsyncResult asyncGetContractDetailCashMovements = delGetContractDetailCashMovements.BeginInvoke(singleAssociatedContracts, platform, initialDate, finalDate, out getClientIdResult, null, null);

                _log.Info("Obteniendo detalle de movientos de efectivo.");
                delGetContractDetailCashMovementsByDate delGetContractDetailFundsMovements = _retailServiceProxy.GetContractDetailFundsMovementsByDate;
                IAsyncResult asyncGetContractDetailFundsMovements = delGetContractDetailFundsMovements.BeginInvoke(singleAssociatedContracts, platform, initialDate, finalDate, out getClientIdResult, null, null);

                decimal totalBalance = 0M;
                totalBalance = finalDate.Equals(currentDate) ? GetActualContractBalance(singleAssociatedContracts, platform) : GetHistoricBalance(singleAssociatedContracts, platform, finalDate.AddDays(1));
                contractMovements.SetBalance(Math.Round(totalBalance, 2));

                while (!asyncGetContractContributionsByDate.IsCompleted || !asyncGetContributionsOnDemand.IsCompleted
                    || !asyncGetContractWithdrawals.IsCompleted || !asyncGetContractCharges.IsCompleted || !asyncGetContractDetailCashMovements.IsCompleted) { Thread.Sleep(10); }


                var realizedContributions = delGetContractContributionsByDate.EndInvoke(out getContractContributionByDateResult, asyncGetContractContributionsByDate);
                _log.Debug("Apotaciones ordinarias para contrato " + contractId + ": {cntx}", realizedContributions);
                var onDemandContributions = delGetContributionsOnDemandByDate.EndInvoke(out getContributionsOnDemandResult, asyncGetContributionsOnDemand);
                _log.Debug("Aportaciones adicionales para contrato " + contractId + ": {cntx}", onDemandContributions);
                var contractWithdrawals = delGetContractWithdrawalsByDate.EndInvoke(out getContractWithdrawalsResult, asyncGetContractWithdrawals);
                _log.Debug("Retiros para contrato " + contractId + ": {cntx}", contractWithdrawals);
                var contractCharges = delGetContractChargesByDate.EndInvoke(out getChargesResult, asyncGetContractCharges);
                _log.Debug("Cargos para contrato " + contractId + ": {cntx}", contractCharges);
                var movementsDetail = delGetContractDetailCashMovements.EndInvoke(out getClientIdResult, asyncGetContractDetailCashMovements);
                _log.Debug("Detalle de movimientos efectivo para contrato " + contractId + ": {cntx}", movementsDetail);

                var movementsFundsDetail = delGetContractDetailFundsMovements.EndInvoke(out getClientIdResult, asyncGetContractDetailFundsMovements);
                _log.Debug("Detalle de movimientos efectivo para contrato " + contractId + ": {cntx}", movementsDetail);

                var totalOrdinalContributions = realizedContributions.OrdinalContributionsAmount + onDemandContributions.OrdinalOnDemandAmount;
                var totalAdditionalContributions = realizedContributions.AdditionalContributionsAmount + onDemandContributions.AdditionalOnDemandAmount;
                var totalContributions = totalOrdinalContributions + totalAdditionalContributions;

                contractMovements.SetContributions(Math.Round(totalContributions, 2));
                var totalWithdrawals = contractWithdrawals.AdditionalWithdrawalsAmount + contractWithdrawals.OrdinalWithdrawalsAmount;
                contractMovements.SetWithdrawals(Math.Round(totalWithdrawals, 2));
                var initialBalance = GetHistoricInitialBalance(singleAssociatedContracts, platform, initialDate);
                contractMovements.SetCharges(contractCharges);
                contractMovements.CalculateYieldAmount(initialBalance);
                contractMovements.SetDatesInfo(initialDate, finalDate);
                contractMovements.SetMovementsDetail(movementsDetail);
                contractMovements.SetMovementsFundsDetail(movementsFundsDetail);
                var movementsPending = GetContractMovementsPending(singleAssociatedContracts, platform, initialDate, finalDate, out result);
                contractMovements.SetMovementsPendingDetail(movementsPending);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los movimientos del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return contractMovements;
        }

        public decimal GetActualContractBalance(List<AssociatedContract> associatedContracts, int platform)
        {
            OperationResult result;
            var contracts = associatedContracts.Select(x => x.ContractId).ToList();
            var contractBalance = _retailServiceProxy.GetBalanceDetail(platform, contracts, out result);
            return contractBalance.Sum(x => x.MarketValues.MarketValue);
        }

        public decimal GetHistoricInitialBalance(List<AssociatedContract> associatedContracts, int platform, DateTime dateRequest)
        {
            OperationResult result;
            decimal initialBalance = 0M;
            if (associatedContracts.Count > 1)
            {
                var ordinalContract = associatedContracts.Where(x => x.AssociatedType == 2).Select(a => a.ContractId).First();
                var additionalContract = associatedContracts.Where(x => x.AssociatedType == 3).Select(a => a.ContractId).First();
                initialBalance = _retailServiceProxy.GetContractInitBalance("", platform, dateRequest, ordinalContract, additionalContract, out result);
            }
            else
            {
                var contractId = associatedContracts[0].ContractId;
                initialBalance = _retailServiceProxy.GetContractInitBalance(contractId, platform, dateRequest, "", "", out result);
            }

            return initialBalance;
        }

        public decimal GetHistoricBalance(List<AssociatedContract> associatedContracts, int platform, DateTime dateRequest)
        {
            OperationResult result;
            decimal historicBalance = 0M;
            if (associatedContracts.Count > 1)
            {
                var ordinalContract = associatedContracts.Where(x => x.AssociatedType == 2).Select(a => a.ContractId).First();
                var additionalContract = associatedContracts.Where(x => x.AssociatedType == 3).Select(a => a.ContractId).First();
                historicBalance = _retailServiceProxy.GetContractInitBalance("", platform, dateRequest, ordinalContract, additionalContract, out result);
            }
            else
            {
                var contractId = associatedContracts[0].ContractId;
                historicBalance = _retailServiceProxy.GetContractInitBalance(contractId, platform, dateRequest, "", "", out result);
            }

            return historicBalance;
        }
        public List<ContractMovementDetail> GetContractMovementsFunds(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractMovementDetail> movementsPending = null;
            try
            {
                result.Successful = true;
                List<ContractMovementDetail> movementsPendingSIIF = _retailServiceProxy.GetContractDetailPendingMovementsByDate(associatedContracts, platform, initialDate, finalDate, out result);
                List<ContractMovementDetail> movementsPendingDOM = _retailExtServiceProxy.GetContractPendingContributions(associatedContracts, initialDate, finalDate, out result);
                movementsPending = movementsPendingSIIF.Concat(movementsPendingDOM).ToList();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los movimientos pendientes de los contratos {cntx}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return movementsPending;
        }

        public List<ContractMovementDetail> GetContractMovementsPending(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractMovementDetail> movementsPending = null;
            try
            {
                result.Successful = true;
                List<ContractMovementDetail> movementsPendingSIIF = _retailServiceProxy.GetContractDetailPendingMovementsByDate(associatedContracts, platform, initialDate, finalDate, out result);
                List<ContractMovementDetail> movementsPendingDOM = _retailExtServiceProxy.GetContractPendingContributions(associatedContracts, initialDate, finalDate, out result);
                movementsPending = movementsPendingSIIF.Concat(movementsPendingDOM).ToList();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los movimientos pendientes de los contratos {cntx}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return movementsPending;
        }

        #endregion Movements

        public decimal GetAdittionalNetContributionsAmount(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result)
        {
            result = new OperationResult();
            List<AssociatedContract> AssociatedContracts = new List<AssociatedContract>();
            decimal adittionalNetContributionsAmout = 0;

            try
            {
                associatedContracts.ForEach(a => AssociatedContracts.Add(AssociatedContract.Create(a.ContractId, a.AssociatedContractId, a.AssociatedType)));
                var RealizedContributions = _retailServiceProxy.GetContractContributions(AssociatedContracts, platform, out result);
                var ContributionsOnDemand = _retailServiceProxy.GetContributionsOnDemand(AssociatedContracts, platform, out result);
                var ContractWithdrawals = _retailServiceProxy.GetContractWithdrawals(AssociatedContracts, platform, out result);

                decimal adittionalContributionsAmout = RealizedContributions.AdditionalContributionsAmount + ContributionsOnDemand.AdditionalOnDemandAmount;
                decimal additionalWithdrawalsAmount = ContractWithdrawals.AdditionalWithdrawalsAmount;

                adittionalNetContributionsAmout = adittionalContributionsAmout - Math.Round(additionalWithdrawalsAmount, 2);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el valor de las contribuciones netas: {cntx}", new { associatedContracts, platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el valor de las contribuciones " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return adittionalNetContributionsAmout;
        }

        public ContractBalance GetContractBalance(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var balance = 0M;

            _log.Info("Obteniendo el saldo para el contrato: {cntx}", contractId);
            try
            {
                _log.Info("Obteniendo información básica del contrato");
                var contractinfo = _retailServiceProxy.GetContractInfo(contractId, out result);
                _log.Debug("{cntx}", contractinfo);

                _log.Info("Obteniendo el identificador del cliente del contrato");
                var clientId = _retailServiceProxy.GetClientIdByContract(contractId, out result);
                _log.Debug("{cntx}", clientId);

                _log.Info("Obteniendo los contratos asociados al cliente");
                var clientAssociatedContracts = _retailServiceProxy.GetAssociateContracts(clientId, out result);
                _log.Debug("{cntx}", clientAssociatedContracts);

                _log.Info("Filtrando contratos asociados al contrato");
                var associatedContr = clientAssociatedContracts.Where(a => a.AssociatedContractId == contractId).ToList<AssociatedContract>();
                var contracts = associatedContr.Select(c => c.ContractId).ToList<string>();
                _log.Debug("{cntx}", contracts);

                _log.Info("Obteniendo saldos de los fondos del contrato");
                var balanceDet = _retailServiceProxy.GetBalanceDetail(contractinfo.Platform, contracts, out result);

                _log.Info("Sumando los saldos");
                balanceDet.ForEach(x => balance += x.MarketValues.MarketValue);
                _log.Debug("{cntx}", balance);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el saldo del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el saldo del contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return new ContractBalance(balance);
        }

        public Investments GetContractBalanceDetail(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            Investments investments = null;
            List<PortfolioProfile> portfoliosProfile = new List<PortfolioProfile>();


            _log.Info("Obteniendo el saldo para el contrato: {cntx}", contractId);
            try
            {
                _log.Info("Obteniendo información básica del contrato");
                delGetContractInfo dContractInfo = _retailServiceProxy.GetContractInfo;
                IAsyncResult rContractInfo = dContractInfo.BeginInvoke(contractId, out result, null, null);

                _log.Info("Obteniendo el identificador del cliente del contrato");
                delGetClientIdByContract dGetClientIdByContract = _retailServiceProxy.GetClientIdByContract;
                IAsyncResult rClientIdByContract = dGetClientIdByContract.BeginInvoke(contractId, out result, null, null);

                while (!rContractInfo.IsCompleted || !rClientIdByContract.IsCompleted) { Thread.Sleep(50); }

                var contractinfo = dContractInfo.EndInvoke(out result, rContractInfo);
                _log.Debug("Contrato: {cntx}", contractinfo);

                var clientId = dGetClientIdByContract.EndInvoke(out result, rClientIdByContract);
                _log.Debug("Cliente: {cntx}", clientId);

                //var contractinfo = _retailServiceProxy.GetContractInfo(contractId, out result);
                //var clientId = _retailServiceProxy.GetClientIdByContract(contractId, out result);

                _log.Info("Obteniendo la información del plan");
                delGetPlansById dPlansById = _retailExtServiceProxy.GetPlansById;
                IAsyncResult rdPlansById = dPlansById.BeginInvoke(new List<short> { contractinfo.PlanBasId }, out result, null, null);

                _log.Info("Obteniendo los contratos asociados al cliente");
                delGetAssociateContracts dAssociateContracts = _retailServiceProxy.GetAssociateContracts;
                IAsyncResult rAssociateContracts = dAssociateContracts.BeginInvoke(clientId, out result, null, null);

                while (!rdPlansById.IsCompleted || !rAssociateContracts.IsCompleted) { Thread.Sleep(50); }

                var Plans = dPlansById.EndInvoke(out result, rdPlansById);
                _log.Debug("plan: {cntx}", Plans);

                var clientAssociatedContracts = dAssociateContracts.EndInvoke(out result, rAssociateContracts);
                _log.Debug("contracts: {cntx}", clientAssociatedContracts);

                //var clientAssociatedContracts = _retailServiceProxy.GetAssociateContracts(clientId, out result);

                _log.Info("Filtrando contratos asociados al contrato");
                var associatedContr = clientAssociatedContracts.Where(a => a.AssociatedContractId == contractId).ToList<AssociatedContract>();
                var contracts = associatedContr.Select(c => c.ContractId).ToList<string>();
                _log.Debug("{cntx}", contracts);

                var platform = contractinfo.Platform;

                _log.Info("Obteniendo perfil del portafolio para el contrato");
                foreach (AssociatedContract assocContract in associatedContr)
                {
                    var prtProfile = _retailServiceProxy.GetPortfolioProfile(assocContract.ContractId, platform, out result);
                    portfoliosProfile.Add(prtProfile);
                }
                _log.Debug("{cntx}", portfoliosProfile);

                _log.Info("Obteniendo saldos de los fondos del contrato");
                investments = _retailServiceProxy.GetContractBalanceDetail(platform, contracts, out result);

                investments.SetPortfolioProfile(portfoliosProfile);
                investments.SetAssociatedContracts(associatedContr);

                var planInfo = Plans.Single(x => x.PlanClasification.Platform == platform);
                investments.SetPlanInfo(planInfo.ComercialInfo.ComercialName, planInfo.PlanClasification.ProductType);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el saldo del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el saldo del contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return investments;
        }

        public int GetContractSegmentType(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            try
            {
                return _retailExtServiceProxy.GetContractSegmentType(contractId, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el segmento del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el segmento del contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            throw new NotImplementedException();
        }


        public List<ContractBankAccount> GetContractBankAccounts(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractBankAccount> bankAccounts = new List<ContractBankAccount>();
            try
            {
                bankAccounts = _retailServiceProxy.GetContractBankAccounts(contractId, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las cuentas bancarias del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las cuentas bancarias del contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return bankAccounts;
        }

        public List<DetailBankAccount> GetContractBankAccountsByRfc(string RFC, out OperationResult result)
        {
            result = new OperationResult();
            List<DetailBankAccount> bankAccounts = new List<DetailBankAccount>();
            try
            {
                bankAccounts = _retailServiceProxy.GetContractBankAccountsByRfc(RFC, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las cuentas bancarias del rfc: {cntx}", new { RFC });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las cuentas bancarias del rfc " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return bankAccounts;
        }


        public ContractProductInfo GetProductInfo(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            try
            {
                short planBas = _retailServiceProxy.GetPlanBasId(contractId, out int platform, out result);
                var plansLts = _retailExtServiceProxy.GetPlansById(new List<short>() { planBas }, out result);
                var planInfo = plansLts.Single(x => x.PlanClasification.Platform == platform);
                int productType = planInfo.PlanClasification.ProductType;
                string planId = planInfo.Id;
                String comercialName = planInfo.ComercialInfo.ComercialName;

                ContractProductInfo productInfo = ContractProductInfo.Create(contractId, planBas, planId, platform, productType);
                productInfo.SetComercialName(comercialName);
                return productInfo;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener la información del contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return null;
        }

        public bool ValidateContractClient(string clientIdentifier, string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo"); }

            result = new OperationResult() { Successful = true };
            var isContractOfClient = false;
            try
            {
                _log.Info($"ClientContractsApp/ValidateContractClient -> Obteniendo los contratos del cliente: {clientIdentifier}");
                var contracts = _retailServiceProxy.GetContracts(clientIdentifier, out result);
                _log.Debug($"ClientContractsApp/ValidateContractClient -> Contratos del cliente {clientIdentifier}:" + " {cntx}", contracts);
                                
                if (contracts != null && contracts.Contracts.Count > 0)
                {
                    _log.Info($"ClientContractsApp/ValidateContractClient -> Validando que el contrato {contractId} del cliente {clientIdentifier} se encuentre en listado de contratos");
                    isContractOfClient = contracts.Contracts.Exists(x => x.Id.Equals(contractId));
                    _log.Debug($"ClientContractsApp/ValidateContractClient -> Resultado de la validacion del contrato {contractId} para el cliente {clientIdentifier} en el listado de contratos: {isContractOfClient}");

                    if (!isContractOfClient)
                    {
                        _log.Info($"ClientContractsApp/ValidateContractClient -> Obteniendo los contratos asociados del cliente: {clientIdentifier}");
                        var associateContracts = _retailServiceProxy.GetAssociateContracts(clientIdentifier, out result);
                        _log.Debug($"ClientContractsApp/ValidateContractClient -> Contratos asociados del cliente {clientIdentifier}:" + " {cntx}", associateContracts);

                        if(associateContracts != null && associateContracts.Count > 0)
                        {
                            _log.Info($"ClientContractsApp/ValidateContractClient -> Validando que el contrato {contractId} del cliente {clientIdentifier} se encuentre en listado de contratos asociados");
                            isContractOfClient = associateContracts.Exists(x => x.ContractId.Equals(contractId));
                            _log.Debug($"ClientContractsApp/ValidateContractClient -> Resultado de la validacion del contrato {contractId} para el cliente {clientIdentifier}  en el listado de contratos asociados: {isContractOfClient}");
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, $"ClientContractsApp/ValidateContractClient -> Error en la validación de los contratos del cliente, clientIdentifier: {clientIdentifier} contractId: {contractId}");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return isContractOfClient;
        }

        public List<ContractAccepted> GetContractsAcceptedByRFC(string rfc, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractAccepted> contracts = new List<ContractAccepted>();
            try
            {
                _log.Info("Obteniendo la lista de contratos aceptados:");
                var contractsResult = _retailServiceProxy.GetContractsAcceptedByRFC(rfc, out result);
                _log.Debug("Contratos aceptados: {cntx}", contracts);
                contracts = contractsResult;
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos aceptados");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return contracts;

        }

        public void UpdateContractsAccepted(string rfc, string contractId, bool isCommited, out OperationResult result)
        {
            result = new OperationResult();
            try
            {
                _log.Info("Actualizando la lista de contratos aceptados:");
                _retailServiceProxy.UpdateContractsAccepted(rfc, contractId, isCommited, out result);
                _log.Info("Se actualizaron los Contratos aceptados");
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar los contratos aceptados");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });

            }
        }


        public decimal GetContractSurrenderCancelPercent(int planIdentifier, int contractObjectiveNumContributions, decimal contractMonthsOnPlan, out OperationResult result)
        {
            result = new OperationResult();
            decimal percent = 0;
            try
            {
                _log.Info("Obteniendo el porcentaje de cancelación de {planId} - {contributionsMonth} - { monthsonplan}", planIdentifier, contractObjectiveNumContributions, contractMonthsOnPlan);
                var resultPercent = _retailServiceProxy.GetContractSurrenderCancelPercent(planIdentifier, contractObjectiveNumContributions, contractMonthsOnPlan, out result);
                _log.Debug("Porcentaje obtenido: {cntx}", resultPercent);
                percent = resultPercent;
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el porcentaje de cancelación");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return percent;

        }

        private delegate string delGetUrlEncrypt();
        private delegate string delGetContractEncrypt(string text);
        public Dictionary<string, string> GetUrlMovements(string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(contractId); }
            Dictionary<string, string> encryptResponse = new Dictionary<string, string>();
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Encripta contrato");
                delGetContractEncrypt delGetContractEncrypt = _mxAuthApi.GetEncryptText;
                var asyncEncryptContract = delGetContractEncrypt.BeginInvoke(contractId, null, null);

                _log.Info("Encripta la url de movimientos");
                delGetUrlEncrypt delGetUrlEncrypt = _mxAuthApi.GetEncryptUrlMovements;
                var asynEncryptUrl = delGetUrlEncrypt.BeginInvoke(null, null);

                while (!asyncEncryptContract.IsCompleted || !asynEncryptUrl.IsCompleted) { Thread.Sleep(10); }

                var encryptContract = delGetContractEncrypt.EndInvoke(asyncEncryptContract);
                var encryptUrl = delGetUrlEncrypt.EndInvoke(asynEncryptUrl);

                encryptResponse.Add(encryptContract, encryptUrl);
            }
            catch (Exception ex)
            {
                result.Exception = ex;
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Ocurrio un error al tratar de encryptar los datos" });
                _log.Error(ex, "Ocurrio un error al tratar de encryptar los datos");
            }

            return encryptResponse;
        }

        public string DecrypString(string data, out OperationResult result)
        {
            if (string.IsNullOrEmpty(data)) { throw new ArgumentException(data); }

            string decryptResult = string.Empty;
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Desencripta informacion");
                decryptResult = _mxAuthApi.GetDecryptText(data);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al tratar de desencriptar los datos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }
            return decryptResult;
        }

        public ContractPeriodicity GetContractPeriodicity(string contractMaster, out OperationResult result)
        {
            result = new OperationResult();
            ContractPeriodicity contractPeriodicity = null;
            try
            {
                _log.Info($"Obteniendo la periodicidad del contratos: {contractMaster}");
                var contractResult = _retailServiceProxy.GetContractPeriodicity(contractMaster, out result);
                _log.Debug("Contratos Periodicidad: {cntx}", contractResult);
                contractPeriodicity = contractResult;
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la periodicidad del contrato");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return contractPeriodicity;
        }

        public List<Bank> GetBanksAllowedDomi(out OperationResult result)
        {
            result = new OperationResult();
            List<Bank> banks = new List<Bank>();
            try
            {
                var banksCatalog = _retailServiceProxy.GetBankCatalog(10, out result);
                var banksAllowedDomiParameter = _retailExtServiceProxy.GetBanksAllowedDomiParameter(out result);

                var parameters = banksAllowedDomiParameter.SolicitudParametroValor.Split(',').ToList();
                banks.AddRange(banksCatalog.Where(b => parameters.Contains(b.Id)));

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el catalogo de bancos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el catalogo de bancos " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return banks;
        }

        public ClientContracts GetClientContractsActivesPaidUp(string clientIdentifier, out OperationResult result)
        {
            ClientContracts _clientContracts = null;
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo la información básica de los contratos del cliente {cntx}", clientIdentifier);
                delGetContract dGetContract = _retailServiceProxy.GetContractsActivePaidUp;
                IAsyncResult rGetContract = dGetContract.BeginInvoke(clientIdentifier, out result, null, null);

                _log.Info("Obteniendo información de los contratos asociados {cntx}", clientIdentifier);
                delGetAssociateContracts dGetAssociateContracts = _retailServiceProxy.GetAssociateContractsActivePaidUp;
                IAsyncResult rGetAssociateContracts = dGetAssociateContracts.BeginInvoke(clientIdentifier, out result, null, null);

                while (!rGetContract.IsCompleted || !rGetAssociateContracts.IsCompleted) { Thread.Sleep(20); }
                _clientContracts = dGetContract.EndInvoke(out result, rGetContract);
                _log.Debug("Contratos del cliente {cntx}", _clientContracts);

                associatedContracts = dGetAssociateContracts.EndInvoke(out result, rGetAssociateContracts);
                _log.Debug("Contratos asociados {cntx}", _clientContracts);

                List<IAsyncResult> AsyncContracts = new List<IAsyncResult>();
                List<OperationResult> results = new List<OperationResult>();

                List<IAsyncResult> AsyncDetails = new List<IAsyncResult>();
                List<delGetContractBasicDetail> delGetContractDetails = new List<delGetContractBasicDetail>();

                List<IAsyncResult> AsyncBalDetail = new List<IAsyncResult>();
                List<delGetBalanceDetail> delGetBalanceDetails = new List<delGetBalanceDetail>();

                _log.Info("Procesando los contratos del cliente {cntx}", clientIdentifier);
                for (int nCont = 0; nCont <= _clientContracts.Contracts.Count - 1; nCont++)
                {
                    List<ContractInfo> _cliCont = new List<ContractInfo>();

                    _cliCont.Add(_clientContracts.Contracts[nCont]);
                    if (nCont + 1 < _clientContracts.Contracts.Count)
                    {
                        nCont++;
                        _cliCont.Add(_clientContracts.Contracts[nCont]);
                    }

                    //Asynchronous transactions begin
                    int nContract = 1;
                    foreach (ContractInfo contract in _cliCont)
                    {
                        OperationResult resContrato = new OperationResult();

                        var associatedContr = associatedContracts.Where(a => a.AssociatedContractId == contract.Id).ToList<AssociatedContract>();

                        _log.Info("Estableciendo los contratos asociados al contrato");
                        _log.Debug("{cntx}", associatedContr);
                        contract.SetAssociatedContracts(associatedContr);

                        _log.Info("Obteniendo el detalle de saldos del contrato {cntx}", contract.Id);
                        delGetBalanceDetails.Add(_retailServiceProxy.GetBalanceDetail);
                        AsyncDetails.Add(delGetBalanceDetails[nContract - 1].BeginInvoke(
                            contract.Platform, associatedContr.Select(c => c.ContractId).ToList<string>(), out resContrato, null, null));

                        _log.Info("Obteniendo la información adicional del contrato {cntx}", contract.Id);
                        delGetContractDetails.Add(GetContractBasicDetail);
                        AsyncContracts.Add(delGetContractDetails[nContract - 1].BeginInvoke(contract, out resContrato, null, null));
                        nContract++;
                    }

                    //Verification of completed asynchronous transactions
                    bool allComplete = false;
                    while (!allComplete)
                    {
                        allComplete = true;
                        AsyncContracts.ForEach(C => allComplete &= C.IsCompleted);
                        AsyncDetails.ForEach(D => allComplete &= D.IsCompleted);
                        Thread.Sleep(10);
                    }

                    //Get result of the asynchronous transactions
                    for (int proc = 0; proc < AsyncContracts.Count; proc++)
                    {
                        OperationResult resContrato = new OperationResult();
                        _log.Debug("{cntx}", _cliCont[proc]);
                        delGetContractDetails[proc].EndInvoke(out resContrato, AsyncContracts[proc]);
                        delGetContractDetails[proc] = null;
                        AsyncContracts[proc] = null;

                        OperationResult resBalance = new OperationResult();

                        var funds = delGetBalanceDetails[proc].EndInvoke(out resBalance, AsyncDetails[proc]);
                        _log.Debug("{cntx}", funds);
                        _cliCont[proc].SetInvestments(funds);
                        _cliCont[proc].CalculateBalanceContract();
                    }
                    AsyncContracts.Clear();
                    AsyncDetails.Clear();
                    delGetContractDetails.Clear();
                    delGetBalanceDetails.Clear();
                }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente GetClientContracts {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos del cliente " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return _clientContracts;
        }

        private void GetContractBasicDetail(ContractInfo contract, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            List<short> goalIds = new List<short>();
            List<short> BasPlanIds = new List<short>();

            goalIds.Add(contract.GoalId);
            BasPlanIds.Add(contract.PlanBasId);
            var ContractId = contract.Id;

            _log.Info("Obteniendo información de los planes: {cntx}", new { ContractId, BasPlanIds });
            var plansInfo = _retailExtServiceProxy.GetPlansById(BasPlanIds, out result);
            _log.Debug("{cntx}", plansInfo);

            var Platform = contract.Platform;
            _log.Info("Estableciendo infomación del plan en el contrato {cntx}", ContractId);
            contract.SetPlanInfo(plansInfo, Platform);

            _log.Info("Obteniendo el id del segmento para el contrato {cntx}", ContractId);
            delGetContractSegmentType dGetContractSegmentType = GetContractSegmentType;
            IAsyncResult rGetContractSegmentType = dGetContractSegmentType.BeginInvoke(ContractId, out result, null, null);

            _log.Info("Obteniendo la información extendida del contrato {cntx}", ContractId);
            var ContractExtBasicInfo = _retailExtServiceProxy.GetContractExtBasicInfo(ContractId, out result);
            _log.Debug("{cntx}", ContractExtBasicInfo);

            var Balance = 0M;
            _log.Info("Obteniendo el monto de la suma asegurada para el contrato {cntx}", ContractId);
            var LifeInsuranceAmount = _retailExtServiceProxy.GetLifeInsuranceAmount(ContractId, out result);
            _log.Debug("{cntx}", LifeInsuranceAmount);

            var SavingGoal = ContractExtBasicInfo.SavingGoal;
            _log.Info("Estableciendo los saldos del contrato {cntx}", ContractId);
            contract.SetBalancesContract(Balance, LifeInsuranceAmount, SavingGoal);

            while (!rGetContractSegmentType.IsCompleted) { Thread.Sleep(20); }

            var SegmentId = dGetContractSegmentType.EndInvoke(out result, rGetContractSegmentType);
            _log.Info("Segment type {cntx}", SegmentId);
            contract.SetSegmentType(SegmentId);
        }

        public List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException(nameof(clientIdentifier)); }

            result = new OperationResult();
            var bankAccountAllowDomis = new List<ContractBankAccountAllowDomi>();
            try
            {
                bankAccountAllowDomis = _retailServiceProxy.GetContractBankAccountsAllowDomi(contractId, clientIdentifier, maskSensitiveInfo, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las cuentas bancarias del contrato validas para domiciliacion: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las cuentas bancarias del contrato validas para domiciliacion " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return bankAccountAllowDomis;
        }

        public ContractInfo GetContractDetailByContractId(string clientIdentifier, string contractId, out OperationResult result)
        {
            ContractInfo contractFilter = null;
            List<string> lstPlansApplyContribution = new List<string>();
            result = new OperationResult() { Successful = true };

            try
            {
                result.Successful = true;
                _validateSchedule = false;
                _valScheduleTranfers = true;

                _log.Info("Obteniendo la información básica de los contratos del cliente {cntx}", clientIdentifier);
                delGetContract dGetContract = _retailServiceProxy.GetContracts;
                IAsyncResult rGetContract = dGetContract.BeginInvoke(clientIdentifier, out result, null, null);

                _log.Info("Obteniendo información de los contratos asociados {cntx}", clientIdentifier);
                delGetAssociateContracts dGetAssociateContracts = _retailServiceProxy.GetAssociateContracts;
                IAsyncResult rGetAssociateContracts = dGetAssociateContracts.BeginInvoke(clientIdentifier, out result, null, null);

                while (!rGetContract.IsCompleted || !rGetAssociateContracts.IsCompleted) { Thread.Sleep(10); }
                var _clientContracts = dGetContract.EndInvoke(out result, rGetContract);
                _log.Debug("Contratos del cliente {cntx}", _clientContracts);

                var associatedContracts = dGetAssociateContracts.EndInvoke(out result, rGetAssociateContracts);
                _log.Debug("Contratos asociados {cntx}", _clientContracts);

                delGetContractDetail delGetContractDetails = GetContractDetail;
                delGetBalanceDetail delGetBalanceDetails = _retailServiceProxy.GetBalanceDetail;

                contractFilter = _clientContracts.Contracts.Count > 0 ? _clientContracts.Contracts.Where(x => x.Id.Equals(contractId)).FirstOrDefault() : null;
                if (contractFilter != null)
                {
                    _log.Info("Procesando el contrato del cliente {cntx}", clientIdentifier);
                    OperationResult resContrato = new OperationResult();
                    var associatedContr = associatedContracts.Where(a => a.AssociatedContractId == contractFilter.Id).ToList<AssociatedContract>();

                    _log.Info("Estableciendo los contratos asociados al contrato");
                    _log.Debug("{cntx}", associatedContr);
                    contractFilter.SetAssociatedContracts(associatedContr);

                    _log.Info("Obteniendo el detalle de saldos del contrato {cntx}", contractFilter.Id);
                    IAsyncResult AsyncDetails = delGetBalanceDetails.BeginInvoke(
                        contractFilter.Platform, associatedContr.Select(c => c.ContractId).ToList<string>(), out resContrato, null, null);

                    _log.Info("Obteniendo la información adicional del contrato {cntx}", contractFilter.Id);
                    IAsyncResult AsyncContracts = delGetContractDetails.BeginInvoke(contractFilter, lstPlansApplyContribution, out resContrato, null, null);

                    //Verification of completed asynchronous transactions
                    bool allComplete = false;
                    while (!allComplete)
                    {
                        allComplete = true;
                        allComplete &= AsyncContracts.IsCompleted;
                        allComplete &= AsyncDetails.IsCompleted;
                        Thread.Sleep(10);
                    }

                    var funds = delGetBalanceDetails.EndInvoke(out OperationResult resBalance, AsyncDetails);
                    _log.Debug("{cntx}", funds);
                    contractFilter.SetInvestments(funds);
                    contractFilter.CalculateBalanceContract();
                }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el detalle del contracto GetContractDetailByContractId {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el detalle del contracto " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return contractFilter;
        }

        public ContractExtBasicInfo GetContractExtBasicInfo(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true, SystemMessages = new List<SystemMessage>() };
            var response = ContractExtBasicInfo.CreateEmpty();
            try
            {
                response = _retailExtServiceProxy.GetContractExtBasicInfo(contractId, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar el la informacion basica extena del contrato para domiciliaciones.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return response;
        }
    }
}
