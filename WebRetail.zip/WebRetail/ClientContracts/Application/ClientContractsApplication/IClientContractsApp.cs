using ClientContractsDomain.BalanceAggregate;
using ClientContractsDomain.BankAccountAggregate;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.ContractBankAccountAggregate;
using ClientContractsDomain.InvestmentsAggregate;
using ClientContractsMessages;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientContractsApplication
{
    public interface IClientContractsApp
    {
        ClientContracts GetClientContracts(string clientIdentifier, out OperationResult result);
        ClientContracts GetClientContractsByFP(string clientIdentifier, string fpEmail, out OperationResult result);
        ContractMovementsInfo GetClientContractMovementsByDate(string contractId, DateTime initialDate, DateTime finalDate, out OperationResult result);
        decimal GetAdittionalNetContributionsAmount(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result);
        List<ContractMovementDetail> GetContractMovementsPending(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        ContractBalance GetContractBalance(string contractId, out OperationResult result);
        Investments GetContractBalanceDetail(string contractId, out OperationResult result);
        int GetContractSegmentType(string contractId, out OperationResult result);
        List<ContractBankAccount> GetContractBankAccounts(string contractId, out OperationResult result);
        List<DetailBankAccount> GetContractBankAccountsByRfc(string RFC, out OperationResult result);
        ContractProductInfo GetProductInfo(string contractId, out OperationResult result);
        bool ValidateContractClient(string clientIdentifier, string contractId, out OperationResult result);
        ClientContracts GetContractsBasicInfoClient(string clientIdentifier, out OperationResult result);
        ClientContracts GetClientContractsBasicInfoByContractId(string contractId, string emailFP, out OperationResult result);
        List<ContractAccepted> GetContractsAcceptedByRFC(string rfc, out OperationResult result);
        void UpdateContractsAccepted(string rfc, string contractId, bool isCommited, out OperationResult result);
        decimal GetContractSurrenderCancelPercent(int planIdentifier, int contractObjectiveNumContributions, decimal contractMonthsOnPlan, out OperationResult result);

        Dictionary<string, string> GetUrlMovements(string contractId, out OperationResult result);
        string DecrypString(string data, out OperationResult result);
        ContractPeriodicity GetContractPeriodicity(string contractMaster, out OperationResult result);
        List<Bank> GetBanksAllowedDomi(out OperationResult result);
        ClientContracts GetClientContractsActivesPaidUp(string clientIdentifier, out OperationResult result);
        List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result);
        ContractInfo GetContractDetailByContractId(string clientIdentifier, string contractId, out OperationResult result);
        ContractExtBasicInfo GetContractExtBasicInfo(string contractId, out OperationResult result);
    }
}
