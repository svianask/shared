﻿using ClientContractsApplication;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.ContractBankAccountAggregate;
using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.PlanAggregate;
using ClientContractsProxy;
using ClientWithdrawalsApplication;
using Common.Domain;
using Common.Proxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace ClientContractsApplicationTest
{
    [TestClass]
    public class ClientContractsAppTest
    {
        private readonly ISeriLogHelper _seriloHelper;
        private readonly Mock<IRetailServiceProxy> _retailServiceProxy;
        private readonly Mock<IRetailExtServiceProxy> _retailExtServiceProxy;
        private readonly ClientContractsApp _clientContractsBL;
        private readonly Mock<IClientWithdrawalsApp> _clientWithdrawalsApp;
        private readonly Mock<IWebRetailServiceProxy> _webRetailServiceProxy;
        private readonly Mock<IMxAuthApiProxy> _mxAuthApi;
        private readonly Mock<IParametersProxy> _businessParametersPrxy;

        public ClientContractsAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = "C:\\Files\\TestWebRetail-.txt";

            _seriloHelper = new SeriLogHelper();
            //_seriloHelper = new Mock<ISeriLogHelper>().Object; //Uncomment for execution without the log file otherwise log file is update

            _retailServiceProxy = new Mock<IRetailServiceProxy>();
            _retailExtServiceProxy = new Mock<IRetailExtServiceProxy>();
            _clientWithdrawalsApp = new Mock<IClientWithdrawalsApp>();
            _webRetailServiceProxy = new Mock<IWebRetailServiceProxy>();
            _mxAuthApi = new Mock<IMxAuthApiProxy>();
            _businessParametersPrxy = new Mock<IParametersProxy>();

            _clientContractsBL = new ClientContractsApp(_seriloHelper, _retailServiceProxy.Object, _retailExtServiceProxy.Object,
                _webRetailServiceProxy.Object, _mxAuthApi.Object, _businessParametersPrxy.Object);
        }


        #region GetContractsAcepted
        [TestMethod, TestCategory("ProcessOk")]
        public void GetContractsAcceptedOk()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsAcceptedOk();

            var contracts = _clientContractsBL.GetContractsAcceptedByRFC("DOLA911012PH2", out result);

            Assert.IsNotNull(contracts);
            Assert.IsTrue(result.Successful);

        }

        [TestMethod, TestCategory("ProcessFail")]
        public void GetContractsAcceptedFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsAcceptedFail();

            var contracts = _clientContractsBL.GetContractsAcceptedByRFC("DOLA911012PH2", out result);
            Assert.IsFalse(result.Successful);

        }

        #endregion GetContractsAccepted

        #region GetContractsClient Method

        [TestMethod, TestCategory("ProcessSuccessFul")]
        public void GetContractsClientSuccessFul()
        {
            OperationResult result = new OperationResult();
            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();
            WithdrawalsMock();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetContractsFail()
        {
            OperationResult result = new OperationResult();
            //PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.IsNull(clientContracts);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetAssociateContractsFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            //PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<ArgumentNullException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetBalanceDetailFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            //PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetPlansByIdFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            //PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<ArgumentNullException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetContractContributionsFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            //PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetContractWithdrawalsFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            //PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetContributionsOnDemandFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            //PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetContractExtBasicInfoFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            //PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetSummaryContributionsNumberFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            //PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void PrxyGetGoalsImageFail()
        {
            OperationResult result = new OperationResult();

            PrxyGetContractsOk();
            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            //PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContracts(successClientIdentifier, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<ArgumentNullException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("GetContractsBasicInfoClient")]
        [ExpectedException(typeof(ArgumentException))]
        public void GetContractsBasicInfoClientFail()
        {
            var clientContracts = _clientContractsBL.GetContractsBasicInfoClient("", out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("GetContractsBasicInfoClient")]
        public void GetContractsBasicInfoClientSuccess()
        {
            var result = new OperationResult();
            ClientContracts contracts = ClientContracts.Create("CATE8808183S8");
            List<short> BasPlanIds = new List<short> { 480 };
            _retailServiceProxy.Setup(s => s.GetContracts("CATE8808183S8", out result)).Returns(contracts.AddContract(ContractInfo.Create("567953", 480, 10, 15, "567953")));
            _retailExtServiceProxy.Setup(s => s.GetPlansById(BasPlanIds, out result)).Returns(DTPlanOk(480));
            contracts = _clientContractsBL.GetContractsBasicInfoClient("CATE8808183S8", out result);
            Assert.IsNotNull(contracts);
            Assert.IsTrue(result.Successful);
        }

        [TestMethod, TestCategory("GetClientContractsBasicInfoByContractId")]
        [ExpectedException(typeof(ArgumentException))]
        [DataRow("", "email@skandia.com.mx")]
        [DataRow("669826", "")]
        public void GetClientContractsBasicInfoByContractIdTestFail(string contractId, string emailFP)
        {
            var clientContracts = _clientContractsBL.GetClientContractsBasicInfoByContractId(contractId, emailFP, out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("GetClientContractsBasicInfoByContractId")]
        public void GetClientContractsBasicInfoByContractIdTestFailGetRFC()
        {
            var clientContracts = _clientContractsBL.GetClientContractsBasicInfoByContractId("669826", "email@skandia.com.mx", out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("GetClientContractsBasicInfoByContractId")]
        public void GetClientContractsBasicInfoByContractIdTestFailGetContracts()
        {
            GetClientIdByContract();
            var clientContracts = _clientContractsBL.GetClientContractsBasicInfoByContractId("669826", "email@skandia.com.mx", out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("GetClientContractsBasicInfoByContractId")]
        public void GetClientContractsBasicInfoByContractIdTestFailGetPlansById()
        {
            GetClientIdByContract();
            GetContracts();
            var clientContracts = _clientContractsBL.GetClientContractsBasicInfoByContractId("669826", "email@skandia.com.mx", out OperationResult result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("GetClientContractsBasicInfoByContractId")]
        public void GetClientContractsBasicInfoByContractIdTestSuccess()
        {
            GetClientIdByContract();
            GetContracts();
            GetPlansById();
            GetFpContracts();
            var clientContracts = _clientContractsBL.GetClientContractsBasicInfoByContractId("669826", "email@skandia.com.mx", out OperationResult result);
        }

        #region Mocks GetClientContractsBasicInfoByContractId
        public void GetClientIdByContract()
        {
            var result = new OperationResult() { Successful = true };
            _retailServiceProxy.Setup(c => c.GetClientIdByContract("669826", out result)).Returns("FOBR491115AP9");
        }

        public void GetContracts()
        {
            var result = new OperationResult() { Successful = true };
            ClientContracts client = ClientContracts.Create("FOBR491115AP9");
            ContractInfo contract1 = ContractInfo.Create("669826", 615, 10, 15, "669827");
            ContractInfo contract2 = ContractInfo.Create("740398", 765, 10, 15, "740398");
            client.AddContract(contract1);
            client.AddContract(contract2);
            _retailServiceProxy.Setup(c => c.GetContracts("FOBR491115AP9", out result)).Returns(client);
        }

        public void GetPlansById()
        {
            var result = new OperationResult() { Successful = true };
            List<short> BasPlanIds = new List<short> { 765 };
            List<Plan> plans = new List<Plan>();
            plans.Add(
                    Plan
                        .Create("669827", "SKANDIA CREA", "SKANDIA CREA", "615")
                        .SetComercialInfo(615, "SKANDIA CREA")
                        .SetPlanClasification(10, 1)
                );
            _retailExtServiceProxy.Setup(c => c.GetPlansById(BasPlanIds, out result)).Returns(plans).Verifiable();
        }

        public void GetFpContracts()
        {
            var result = new OperationResult() { Successful = true };
            var listContractsId = new List<string>() { "669826", "740398" };
            _retailExtServiceProxy.Setup(c => c.GetFpContracts("email@skandia.com.mx", listContractsId, out result)).Returns(listContractsId);
        }
        #endregion

        #endregion  GetContractsClient Method

        #region GetClientContractsByFP Method
        [TestMethod, TestCategory("ProcessSuccessFul")]
        [DynamicData("GetFpContractsDynDat", DynamicDataSourceType.Method)]
        public void GetClientContractsByFPSuccessFul(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();
            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void GetAssociateContractsFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            //PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<ArgumentNullException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void GetBalanceDetailFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            //PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void GetPlansByIdFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            //PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<ArgumentNullException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void PrxyGetContractContributionsFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            //PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void GetContractWithdrawalsFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            //PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void GetContributionsOnDemandFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            //PrxyGetContributionsOnDemandOk();
            PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ProcessFail")]
        [DataRow("599500", "103763@skandia.com.mx")]
        public void GetContractExtBasicInfoFpFail(string contractId, string fpEmail)
        {
            OperationResult result = new OperationResult();
            PrxyGetClientIdByContractOK(contractId);

            var contracts = PrxyGetContractsData(contractId);

            PrxyGetContractsOk();

            GetFpContractsOK(fpEmail, contracts);

            PrxyGetAssociateContractsOk();
            PrxyGetBalanceDetailOk();
            PrxyGetPlansByIdOk();
            PrxyGetContractContributionsOk();
            PrxyGetContractWithdrawalsOk();
            PrxyGetContributionsOnDemandOk();
            //PrxyGetContractExtBasicInfoOk();
            PrxyGetSummaryContributionsNumberOk();
            PrxyGetGoalsImageOk();
            PrxyGetLifeInsuranceAmountOk();
            PrxyGetContractChargesOk();
            PrxyGetContractInitBalanceOk();

            var clientContracts = _clientContractsBL.GetClientContractsByFP(contractId, fpEmail, out result);
            Assert.IsFalse(result.Successful);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        #endregion GetClientContractsByFP Method

        #region ValidateContractClient
        [TestMethod, TestCategory("ValidateContractClient")]
        public void ValidateContractClientClientNullFail()
        {
            var result = new OperationResult();
            PrxyGetContractsOk();

            var clientContracts = _clientContractsBL.ValidateContractClient("", "567757", out result);
            Assert.IsTrue(result.Successful);
            Assert.IsFalse(clientContracts);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }

        [TestMethod, TestCategory("ValidateContractClient")]
        public void ValidateContractClientContractNullFail()
        {
            var result = new OperationResult();
            PrxyGetContractsOk();

            Assert.ThrowsException<ArgumentException>(() => _clientContractsBL.ValidateContractClient(successClientIdentifier, "", out result));
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("ValidateContractClient")]
        public void ValidateContractClientTestOk()
        {
            var result = new OperationResult();
            PrxyGetContractsOk();
            var valid = _clientContractsBL.ValidateContractClient("BUNA790124E79", "660797", out result);

            Assert.IsTrue(result.Successful);
        }
        #endregion

        #region Domiciliations
        [TestMethod, TestCategory("Domiciliations")]
        public void GetContractBankAccountsAllowDomi()
        {
            var result = new OperationResult() { Successful = true };
            _retailServiceProxy.Setup(c => c.GetContractBankAccountsAllowDomi(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), out result)).Returns(Mock.Of<List<ContractBankAccountAllowDomi>>());
            var contractBankAccountAllowDomis = _clientContractsBL.GetContractBankAccountsAllowDomi("727599", "BEEJ930917SW1", true, out var resultValidation);
            Assert.IsTrue(resultValidation.Successful);
            Assert.IsNotNull(contractBankAccountAllowDomis);
        }


        [TestMethod, TestCategory("Domiciliations")]
        public void GetContractExtBasicInfo()
        {
            var result = new OperationResult() { Successful = true };
            const string contractId = "727599";
            var contractExtBasicInfo = ContractExtBasicInfo.Create(900000.0000M, 216, 3000.0000M)
                                        .SetEffectiveDates(new DateTime(2012, 09, 13), new DateTime(2047, 08, 31));

            _retailExtServiceProxy.Setup(c => c.GetContractExtBasicInfo(contractId, out result)).Returns(contractExtBasicInfo);

            var response = _clientContractsBL.GetContractExtBasicInfo(contractId, out var resultValidation);
            Assert.IsTrue(resultValidation.Successful);
            Assert.IsNotNull(response);
        }
        #endregion Domiciliations


        [TestInitialize]
        public void Initialize()
        {
            emptyClientIdentifier = "";
            successClientIdentifier = "ABCD010203XYZ";
            failClientIdentifier = "EFGH010203XYZ";
            contractsOK = new List<string> { "562969", "599500", "665235" };
        }


        private string successClientIdentifier;
        private string failClientIdentifier;
        private string emptyClientIdentifier;
        const int PLATAFORMA_ASEGURADORA = 10;
        const int PLATAFORMA_OPERADORA = 5;
        private List<string> contractsOK;

        private void WithdrawalsMock()
        {
            var result = new OperationResult();

            _clientWithdrawalsApp.Setup(s => s.AppliesTo(15)).Returns(true);

            _retailExtServiceProxy.Setup(s => s.GetContractSegmentType("562969", out result))
                .Callback(() => { result.Successful = true; })
                .Returns(15).Verifiable();

            _clientWithdrawalsApp.Setup(s => s.ValidatePlanApplyPartialWithdrawals("562969", out result))
                .Returns(true);

            _clientWithdrawalsApp.Setup(s => s.GetContractSummaryPendingWithdrawals("562969", out result))
                .Returns(0.0M);

            _retailServiceProxy.Setup(s => s.GetContractBankAccounts("562969", out result))
                .Returns(new List<ClientContractsDomain.BankAccountAggregate.ContractBankAccount>());
        }

        #region Mock retailProxy
        private void PrxyGetContractsOk()
        {
            var resultContratos = new OperationResult();

            _retailServiceProxy
            .Setup(s => s.GetContracts(successClientIdentifier, out resultContratos))
            .Callback(() => { resultContratos.Successful = true; resultContratos.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
            .Returns(DTClientContractsOk()).Verifiable();
        }

        private void PrxyGetAssociateContractsOk()
        {
            var resultAssociateContracts = new OperationResult();
            _retailServiceProxy
               .Setup(s => s.GetAssociateContracts(successClientIdentifier, out resultAssociateContracts))
               .Callback(() => { resultAssociateContracts.Successful = true; resultAssociateContracts.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetAssociateContracts" } }; })
               .Returns(DTAssociatedContractsOk).Verifiable();
        }

        private void PrxyGetBalanceDetailOk()
        {
            var resultBalanceDetail = new OperationResult();
            var contracts1 = DTListContractsOk(DTAssociatedContracts1Ok());
            var contracts2 = DTListContractsOk(DTAssociatedContracts2Ok());
            var contracts3 = DTListContractsOk(DTAssociatedContracts3Ok());
            var return1 = DTInvestments1OK();
            var return2 = DTInvestments2OK();
            var return3 = DTInvestments3OK();

            _retailServiceProxy
                .Setup(s => s.GetBalanceDetail(PLATAFORMA_ASEGURADORA, contracts1, out resultBalanceDetail))
                .Callback(() => { resultBalanceDetail.Successful = true; resultBalanceDetail.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetBalanceDetail" } }; })
                .Returns(return1).Verifiable();

            _retailServiceProxy
               .Setup(s => s.GetBalanceDetail(PLATAFORMA_ASEGURADORA, contracts2, out resultBalanceDetail))
               .Callback(() => { resultBalanceDetail.Successful = true; resultBalanceDetail.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetBalanceDetail" } }; })
               .Returns(return2).Verifiable();

            _retailServiceProxy
               .Setup(s => s.GetBalanceDetail(PLATAFORMA_ASEGURADORA, contracts3, out resultBalanceDetail))
               .Callback(() => { resultBalanceDetail.Successful = true; resultBalanceDetail.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetBalanceDetail" } }; })
               .Returns(return3).Verifiable();
        }

        private void PrxyGetContractsAcceptedOk()
        {
            var resultContractsAccepted = new OperationResult();

            _retailServiceProxy
                .Setup(s => s.GetContractsAcceptedByRFC("DOLA911012PH2", out resultContractsAccepted))
                .Callback(() => { resultContractsAccepted.Successful = true; resultContractsAccepted.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetBalanceDetail" } }; })
                .Returns(PrxyGetContractsAcceptedData());
        }

        private void PrxyGetContractsAcceptedFail()
        {
            var resultContractsAccepted = new OperationResult();

            _retailServiceProxy
                .Setup(s => s.GetContractsAcceptedByRFC("DOLA911012PH2", out resultContractsAccepted))
                .Callback(() => { resultContractsAccepted.Successful = false; resultContractsAccepted.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Ocurrió un error al consultar Contractos Aceptados -" } }; })
                .Throws(new Exception("Error al consultar BD"));
        }

        private void PrxyGetPlansByIdOk()
        {
            var resultPlans = new OperationResult();

            var planBasIds = new List<short> { 350, 480, 520 };

            foreach (short planBasId in planBasIds)
            {
                var lstPlanBasId = new List<short> { planBasId };
                var resp = DTPlanOk(planBasId);

                _retailExtServiceProxy
                    .Setup(s => s.GetPlansById(lstPlanBasId, out resultPlans))
                    .Callback(() => { resultPlans.Successful = true; resultPlans.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetPlansById" } }; })
                    .Returns(resp);
            }
        }

        private void PrxyGetContractContributionsOk()
        {
            var resultContractContributions = new OperationResult();

            foreach (string contract in contractsOK)
            {
                var dtRealizedContributions = DTRalizedContributionsOK(contract);
                resultContractContributions.Successful = true;

                _retailServiceProxy
                    .Setup(s => s.GetContractContributions(It.Is<List<AssociatedContract>>(a => a[0].AssociatedContractId.Equals(contract)), PLATAFORMA_ASEGURADORA, out resultContractContributions))
                    .Callback(() => { resultContractContributions.Successful = true; resultContractContributions.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractContributions" } }; })
                    .Returns(dtRealizedContributions).Verifiable();
            }
        }

        private void PrxyGetContractWithdrawalsOk()
        {
            var resultContractWithdrawals = new OperationResult();

            foreach (string contract in contractsOK)
            {
                var dtContractWithdrawals = DTContractWithdrawalsOK(contract);
                resultContractWithdrawals.Successful = true;

                _retailServiceProxy
                    .Setup(s => s.GetContractWithdrawals(It.Is<List<AssociatedContract>>(a => a[0].AssociatedContractId.Equals(contract)), PLATAFORMA_ASEGURADORA, out resultContractWithdrawals))
                    .Callback(() => { resultContractWithdrawals.Successful = true; resultContractWithdrawals.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractWithdrawals" } }; })
                    .Returns(dtContractWithdrawals).Verifiable();
            }
        }

        private void PrxyGetContributionsOnDemandOk()
        {
            var resultContributionsOnDemand = new OperationResult();

            foreach (string contract in contractsOK)
            {
                var dtContributionsOnDemand = DTContributionsOnDemandOK(contract);
                resultContributionsOnDemand.Successful = true;

                _retailServiceProxy
                   .Setup(s => s.GetContributionsOnDemand(It.Is<List<AssociatedContract>>(a => a[0].AssociatedContractId.Equals(contract)), PLATAFORMA_ASEGURADORA, out resultContributionsOnDemand))
                   .Callback(() => { resultContributionsOnDemand.Successful = true; resultContributionsOnDemand.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContributionsOnDemand" } }; })
                   .Returns(dtContributionsOnDemand).Verifiable();
            }
        }

        private void PrxyGetContractExtBasicInfoOk()
        {
            var resultContractExtBasicInfo = new OperationResult();

            foreach (string contract in contractsOK)
            {
                var dtContractExtBasicInfo = DTContractExtBasicInfoOK(contract);

                _retailExtServiceProxy
                   .Setup(s => s.GetContractExtBasicInfo(It.Is<string>(a => a.Equals(contract)), out resultContractExtBasicInfo))
                   .Callback(() => { resultContractExtBasicInfo.Successful = true; resultContractExtBasicInfo.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractExtBasicInfo" } }; })
                   .Returns(dtContractExtBasicInfo).Verifiable();
            }
        }


        private void PrxyGetSummaryContributionsNumberOk()
        {
            var resultSummaryContributionsNumber = new OperationResult();

            foreach (string contract in contractsOK)
            {
                var gContract = DTClientContractsOk().Contracts.Single(x => x.Id == contract);

                var dtSummaryContributions = DTSummaryContributionsOK(contract);

                _retailServiceProxy
                  .Setup(s => s.GetSummaryContributionsNumber(It.Is<string>(a => a.Equals(gContract.GroupingContractId)), out resultSummaryContributionsNumber))
                  .Callback(() => { resultSummaryContributionsNumber.Successful = true; resultSummaryContributionsNumber.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetSummaryContributionsNumber" } }; })
                  .Returns(dtSummaryContributions).Verifiable();
            }
        }

        private void PrxyGetGoalsImageOk()
        {
            var resultGoalsImage = new OperationResult();

            foreach (string contract in contractsOK)
            {
                List<RelatedImageInfo> dtRelatedImagesInfo = DTRelatedImagesInfo(contract);

                _retailExtServiceProxy
                  .Setup(s => s.GetGoalsImage(It.Is<List<short>>(a => a.Contains(dtRelatedImagesInfo[0].GoalId)), out resultGoalsImage))
                  .Callback(() => { resultGoalsImage.Successful = true; resultGoalsImage.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetGoalsImage" } }; })
                  .Returns(dtRelatedImagesInfo).Verifiable();
            }
        }

        private void PrxyGetLifeInsuranceAmountOk()
        {
            var resultLifeInsuranceAmount = new OperationResult();

            foreach (string contract in contractsOK)
            {
                _retailExtServiceProxy
                    .Setup(s => s.GetLifeInsuranceAmount(contract, out resultLifeInsuranceAmount))
                .Callback(() => { resultLifeInsuranceAmount.Successful = true; resultLifeInsuranceAmount.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores LifeInsuranceAmount" } }; })
                .Returns(10000M).Verifiable();
            }
        }

        private void PrxyGetContractChargesOk()
        {
            var resultContractCharges = new OperationResult();

            foreach (string contract in contractsOK)
            {
                _retailServiceProxy
                    .Setup(s => s.GetContractCharges(It.Is<List<AssociatedContract>>(a => a[0].AssociatedContractId.Equals(contract)), PLATAFORMA_ASEGURADORA, out resultContractCharges))
                .Callback(() => { resultContractCharges.Successful = true; resultContractCharges.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores ContractCharges" } }; })
                .Returns(0M).Verifiable();
            }
        }


        private void PrxyGetContractInitBalanceOk()
        {
            var resultContractInitBalance = new OperationResult();

            foreach (string contract in contractsOK)
            {
                _retailServiceProxy
                   .Setup(s => s.GetContractInitBalance(contract, PLATAFORMA_ASEGURADORA, new DateTime(2012, 09, 13), "", "", out resultContractInitBalance))
               .Callback(() => { resultContractInitBalance.Successful = true; resultContractInitBalance.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractInitBalance" } }; })
               .Returns(0M).Verifiable();
            }
        }

        private void PrxyGetClientIdByContractOK(string contractId)
        {
            var resultClientIdByContract = new OperationResult();

            var retValue = GetClientIdByContractData(contractId);

            _retailServiceProxy
            .Setup(s => s.GetClientIdByContract(contractId, out resultClientIdByContract))
            .Callback(() => { resultClientIdByContract.Successful = true; resultClientIdByContract.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetClientIdByContract" } }; })
            .Returns(retValue).Verifiable();

        }









        #endregion Mock retailProxy

        #region Mock retailExtendedService
        private void GetFpContractsOK(string fpEmail, List<string> contracts)
        {
            var resultFpContracts = new OperationResult();

            foreach (string contractId in contracts)
            {
                var retValue = GetFpContractsData(fpEmail);

                _retailExtServiceProxy
                .Setup(s => s.GetFpContracts(It.Is<string>(x => x.Equals(fpEmail)), It.IsAny<List<string>>(), out resultFpContracts))
                .Callback(() => { resultFpContracts.Successful = true; resultFpContracts.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetFpContracts" } }; })
                .Returns(retValue).Verifiable();
            }
        }

        #endregion Mock retailExtendedService

        #region DataExtendedProxy
        private static IEnumerable<object[]> GetFpContractsDynDat()
        {
            return new List<object[]>(){
                new object[]{ "100960", "103763@skandia.com.mx" },
                new object[]{ "562969", "103763@skandia.com.mx" },
                new object[]{ "599500", "103763@skandia.com.mx" },
                new object[]{ "599501", "103763@skandia.com.mx" },
                new object[]{ "599502", "103763@skandia.com.mx" },
                new object[]{ "665235", "103763@skandia.com.mx" },
            };
        }

        private List<string> GetFpContractsData(string fpEmail)
        {
            List<string> retValue = null;
            Dictionary<string, List<string>> retData = new Dictionary<string, List<string>>(){
                {"103763@skandia.com.mx", new List<string>(){ "562969", "665235" } },
            };
            retData.TryGetValue(fpEmail, out retValue);

            return retValue;
        }

        #endregion DataExtendedProxy

        #region Data proxy
        private ContributionsOnDemand DTContributionsOnDemandOK(string Contract_Id)
        {
            ContributionsOnDemand contributionsOnDemand = null;

            if (Contract_Id == "562969") { contributionsOnDemand = ContributionsOnDemand.Create(0M).SetAdditionalOnDemandAmount(0M); }
            if (Contract_Id == "599500") { contributionsOnDemand = ContributionsOnDemand.Create(21602.66M).SetAdditionalOnDemandAmount(0M); }
            if (Contract_Id == "665235") { contributionsOnDemand = ContributionsOnDemand.Create(0M).SetAdditionalOnDemandAmount(0M); }

            return contributionsOnDemand;
        }

        private ContractWithdrawals DTContractWithdrawalsOK(string Contract_Id)
        {
            ContractWithdrawals contractWithdrawals = null;

            if (Contract_Id == "562969") { contractWithdrawals = ContractWithdrawals.Create(0M, 0).SetAdditionalWithdrawals(0M, 0); }
            if (Contract_Id == "599500") { contractWithdrawals = ContractWithdrawals.Create(0M, 0).SetAdditionalWithdrawals(0M, 0); }
            if (Contract_Id == "665235") { contractWithdrawals = ContractWithdrawals.Create(120000, 2).SetAdditionalWithdrawals(0M, 0); }
            return contractWithdrawals;
        }


        //DTListContractsOk(DTAssociatedContracts1Ok())

        private ClientContracts DTClientContractsOk()
        {
            return ClientContracts
                .Create(successClientIdentifier)
                .AddContract(ContractInfo.Create("562969", 350, 10, 5, "562969"))
                .AddContract(ContractInfo.Create("599500", 520, 10, 5, "599501"))
                .AddContract(ContractInfo.Create("665235", 480, 10, 9999, "665235"))
                //.AddContract(ContractInfo.Create("100960", 15, 5, 9999, "100960"))
                ;
        }

        private List<AssociatedContract> DTAssociatedContractsOk()
        {
            var AssociatedContracts = new List<AssociatedContract>();
            AssociatedContracts.AddRange(DTAssociatedContracts1Ok());
            AssociatedContracts.AddRange(DTAssociatedContracts2Ok());
            AssociatedContracts.AddRange(DTAssociatedContracts3Ok());
            return AssociatedContracts;
        }

        private List<AssociatedContract> DTAssociatedContracts1Ok() => new List<AssociatedContract> {
            AssociatedContract.Create("562969", "562969", 1) };

        private List<AssociatedContract> DTAssociatedContracts2Ok() => new List<AssociatedContract> {
            AssociatedContract.Create("599500", "599500", 1),
            AssociatedContract.Create("599501", "599500", 2),
            AssociatedContract.Create("599502", "599500", 3)};

        private List<AssociatedContract> DTAssociatedContracts3Ok() => new List<AssociatedContract> {
            AssociatedContract.Create("665235", "665235", 1) };

        private List<string> DTListContractsOk(List<AssociatedContract> associatedContracts) => associatedContracts.Select(x => x.ContractId).ToList<string>();


        private List<Fund> DTInvestments1OK() => new List<Fund>{
            Fund.Create("SK-DCP B", "SK-DCP").SetContract("562969").SetShares(10986, 0, 0).SetPrices(1.483362M, 1.483362M, 1.483362M).SetMarketValues(16296.21M, 16296.21M, 16296.21M, 4.99M),
            Fund.Create("SK-DESTB", "SK-DEST").SetContract("562969").SetShares(101077, 0, 0).SetPrices(1.172516M, 1.172516M, 1.172516M).SetMarketValues(118514.4M, 118514.4M, 118514.4M, 36.3M),
            Fund.Create("SK-RVMXB", "SK-RVMX").SetContract("562969").SetShares(53286, 0, 0).SetPrices(1.220662M, 1.220662M, 1.220662M).SetMarketValues(65044.2M, 65044.2M, 65044.2M, 19.92M),
            Fund.Create("SK-RVSTB", "SK-RVST").SetContract("562969").SetShares(55991, 0, 0).SetPrices(2.26185M, 2.26185M, 2.26185M).SetMarketValues(126643.24M, 126643.24M, 126643.24M, 38.79M),
            Fund.Create("EFECTIVO", "EFECTIVO").SetContract("562969").SetShares(0, 0, 0).SetPrices(0M, 0M, 0M).SetMarketValues(22.69M, 22.69M, 22.69M, 0M) };

        private List<Fund> DTInvestments2OK() => new List<Fund>{
            Fund.Create("SK-DCP B", "SK-DCP").SetContract("562969").SetShares(10986, 0, 0).SetPrices(1.483362M, 1.483362M, 1.483362M).SetMarketValues(16296.21M, 16296.21M, 16296.21M, 4.99M),
            Fund.Create("SK-DESTB", "SK-DEST").SetContract("562969").SetShares(101077, 0, 0).SetPrices(1.172516M, 1.172516M, 1.172516M).SetMarketValues(118514.4M, 118514.4M, 118514.4M, 36.3M),
            Fund.Create("SK-RVMXB", "SK-RVMX").SetContract("562969").SetShares(53286, 0, 0).SetPrices(1.220662M, 1.220662M, 1.220662M).SetMarketValues(65044.2M, 65044.2M, 65044.2M, 19.92M),
            Fund.Create("SK-RVSTB", "SK-RVST").SetContract("562969").SetShares(55991, 0, 0).SetPrices(2.26185M, 2.26185M, 2.26185M).SetMarketValues(126643.24M, 126643.24M, 126643.24M, 38.79M),
            Fund.Create("EFECTIVO", "EFECTIVO").SetContract("562969").SetShares(0, 0, 0).SetPrices(0M, 0M, 0M).SetMarketValues(22.69M, 22.69M, 22.69M, 0M) };

        private List<Fund> DTInvestments3OK() => new List<Fund>{
            Fund.Create("SK-DCP B", "SK-DCP").SetContract("562969").SetShares(10986, 0, 0).SetPrices(1.483362M, 1.483362M, 1.483362M).SetMarketValues(16296.21M, 16296.21M, 16296.21M, 4.99M),
            Fund.Create("SK-DESTB", "SK-DEST").SetContract("562969").SetShares(101077, 0, 0).SetPrices(1.172516M, 1.172516M, 1.172516M).SetMarketValues(118514.4M, 118514.4M, 118514.4M, 36.3M),
            Fund.Create("SK-RVMXB", "SK-RVMX").SetContract("562969").SetShares(53286, 0, 0).SetPrices(1.220662M, 1.220662M, 1.220662M).SetMarketValues(65044.2M, 65044.2M, 65044.2M, 19.92M),
            Fund.Create("SK-RVSTB", "SK-RVST").SetContract("562969").SetShares(55991, 0, 0).SetPrices(2.26185M, 2.26185M, 2.26185M).SetMarketValues(126643.24M, 126643.24M, 126643.24M, 38.79M),
            Fund.Create("EFECTIVO", "EFECTIVO").SetContract("562969").SetShares(0, 0, 0).SetPrices(0M, 0M, 0M).SetMarketValues(22.69M, 22.69M, 22.69M, 0M) };


        private List<Plan> DTPlanOk(short planBasId)
        {
            return new List<Plan>
            {
                Plan.Create("430", "APORTAC REGULARES VISION NO DEDUCIBLE - FID 436", "SKANDIA VISIÓN", "350")
                    .SetComercialInfo(17, "SKANDIA VISIÓN")
                    .SetPlanClasification(10, 1),

                Plan.Create("531", "MULTITRUST NO DEDUCIBLE", "MULTITRUST NO DEDUCIBLE", "480")
                    .SetComercialInfo(11, "MULTITRUST")
                    .SetPlanClasification(10, 2),

                Plan.Create("540", "MAESTRA SKANDIA NO DEDUCIBLE CREA", "SK CREA ND-MTRA", "520")
                    .SetComercialInfo(15, "SKANDIA CREA")
                    .SetPlanClasification(10, 1)
            }.Where(p => p.BasPlanId == planBasId.ToString()).ToList<Plan>();
        }

        private RealizedContributions DTRalizedContributionsOK(string Contract_Id)
        {
            RealizedContributions realizedContract = null;

            if (Contract_Id == "562969") { realizedContract = RealizedContributions.Create(329208.3M, 105).SetAdditionalContributions(0, 0).SetFirstContributionDate(new DateTime(2012, 09, 24)); }
            if (Contract_Id == "599500") { realizedContract = RealizedContributions.Create(233263.33M, 72).SetAdditionalContributions(3207.43M, 1).SetFirstContributionDate(new DateTime(2015, 05, 29)); }
            if (Contract_Id == "665235") { realizedContract = RealizedContributions.Create(1470000M, 5).SetAdditionalContributions(0M, 0).SetFirstContributionDate(new DateTime(2013, 05, 17)); }

            return realizedContract;
        }

        private ContractExtBasicInfo DTContractExtBasicInfoOK(string Contract_Id)
        {
            ContractExtBasicInfo contractExtBasicInfo = null;

            if (Contract_Id == "562969") { contractExtBasicInfo = ContractExtBasicInfo.Create(900000.0000M, 216, 3000.0000M).SetEffectiveDates(new DateTime(2012, 09, 13), new DateTime(2047, 08, 31)); }
            if (Contract_Id == "599500") { contractExtBasicInfo = ContractExtBasicInfo.Create(1798865.35M, 216, 3526.39M).SetEffectiveDates(new DateTime(2015, 05, 26), new DateTime(2047, 08, 31)); }
            if (Contract_Id == "665235") { contractExtBasicInfo = ContractExtBasicInfo.Create(0M, 0, 0M).SetEffectiveDates(new DateTime(2017, 05, 18), new DateTime(2047, 08, 31)); }

            return contractExtBasicInfo;
        }

        private SummaryContributions DTSummaryContributionsOK(string Contract_Id)
        {
            SummaryContributions summaryContributions = null;

            if (Contract_Id == "562969") { summaryContributions = SummaryContributions.Create(0, 0, 0, 0); }
            if (Contract_Id == "599500") { summaryContributions = SummaryContributions.Create(216, 73, 72, 0); }
            if (Contract_Id == "665235") { summaryContributions = SummaryContributions.Create(0, 0, 0, 0); }

            return summaryContributions;
        }

        private List<RelatedImageInfo> DTRelatedImagesInfo(string Contract_Id)
        {
            List<RelatedImageInfo> relatedImagesInfo = null;

            var contract = DTClientContractsOk().Contracts.Single(x => x.Id == Contract_Id);

            short goalId = contract.GoalId;

            if (goalId == 5) { relatedImagesInfo = new List<RelatedImageInfo> { new RelatedImageInfo(5, "education.png", 1), new RelatedImageInfo(5, "vector.png", 2) }; }
            if (goalId == 9999) { relatedImagesInfo = new List<RelatedImageInfo> { new RelatedImageInfo(9999, "saving.png", 1), new RelatedImageInfo(9999, "vector.png", 2) }; }

            return relatedImagesInfo;
        }

        private string GetClientIdByContractData(string contractId)
        {
            string retValue = string.Empty;

            if ("100960,599500,599501,599502,562969,665235".Contains(contractId)) { retValue = "ABCD010203XYZ"; }

            return retValue;
        }

        private List<string> PrxyGetContractsData(string contractId)
        {
            List<string> retValue = null;
            Dictionary<string, List<string>> retData = new Dictionary<string, List<string>>(){
                {"100960", new List<string>(){ "100960" } },
                {"562969", new List<string>(){ "562969" } },
                {"599500", new List<string>(){ "599500", "599501", "599503" } },
                {"599501", new List<string>(){ "599500", "599501", "599503" } },
                {"599502", new List<string>(){ "599500", "599501", "599503" } },
                {"665235", new List<string>(){ "665235" } },
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private List<ContractAccepted> PrxyGetContractsAcceptedData()
        {
            List<ContractAccepted> contracts = new List<ContractAccepted>()
            {
                ContractAccepted.Create(1, "DOLA911012PH2", "9999999999999", new DateTime(2023, 11, 15)),
                ContractAccepted.Create(2, "", "8899999999999", new DateTime(2023, 11, 15)),
                ContractAccepted.Create(1, "MELR911116FH2", "9999999999999", new DateTime(2023, 11, 15)),
            };
            return contracts;

        }

        #endregion
    }
}
