﻿
using Ddd;

namespace ClientContractsDomain.BankAccountAggregate
{
    public class ContractProduct : Entity<string>
    {
        private readonly string _contractId;
        private readonly string _productName;
        private readonly bool _isAccountThird;

        public ContractProduct(string contractId, string productName, bool isAccountThird)
        {
            _contractId = contractId;
            _productName = productName;
            _isAccountThird = isAccountThird;
        }

        public string ContractId => _contractId;
        public string ProductName => _productName;
        public bool IsAccountThird => _isAccountThird;
    }
}
