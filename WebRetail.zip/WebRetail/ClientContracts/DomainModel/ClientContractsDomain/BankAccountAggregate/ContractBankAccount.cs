﻿using System;
using Ddd;

namespace ClientContractsDomain.BankAccountAggregate
{
    public class ContractBankAccount : Entity<string>
    {
        private int _accountId;
        private int _bankId;
        private int _bankAccountTypeId;
        private string _accountNumber;
        private string _accountBankName;
        private int _accountUseTypeId;
        private DateTime _accountCreatedDate;

        private ContractBankAccount(string contractId)
        {
            Id = contractId;
        }

        public int BankId => _bankId;
        public int BankAccountTypeId => _bankAccountTypeId;
        public int AccountId => _accountId;
        public string AccountNumber => _accountNumber;
        public string AccountBankName => _accountBankName;
        public int AccountUseTypeId => _accountUseTypeId;
        public DateTime AccountCreatedDate => _accountCreatedDate;


        public static ContractBankAccount Create(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío."); }

            return new ContractBankAccount(contractId);
        }

        public ContractBankAccount SetBankData(int bankId, string accountBankName, int bankAccountTypeId)
        {
            this._bankId = bankId;
            this._accountBankName = accountBankName;
            this._bankAccountTypeId = bankAccountTypeId;

            return this;
        }

        public ContractBankAccount SetAccountData(int accountId, string accountNumber, int accountUseTypeId)
        {
            this._accountId = accountId;
            this._accountNumber = accountNumber;
            this._accountUseTypeId = accountUseTypeId;

            return this;
        }

        public ContractBankAccount SetAccountCreatedDate(DateTime accountCreatedDate)
        {
            _accountCreatedDate = accountCreatedDate;
            return this;
        }

    }
}
