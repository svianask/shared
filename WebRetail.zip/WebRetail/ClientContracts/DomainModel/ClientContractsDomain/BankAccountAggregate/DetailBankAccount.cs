﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.BankAccountAggregate
{
    public class DetailBankAccount : Entity<string>
    {
        private readonly string _bankName;
        private readonly string _bankAccount;
        private readonly int _useType;
        private readonly string _AccountClabe;
        private readonly int _BankId;
        private readonly int _typeAccount;
        private readonly List<ContractProduct> _products;
        private readonly string _accountStatusDsc;
        private readonly string _accountUseTypeDsc;

        public DetailBankAccount(string bankName, string bankAccount, int useType, string accountStatusDsc, string accountUseTypeDsc)
        {
            _bankName = bankName;
            _bankAccount = bankAccount;
            _useType = useType;
            _accountStatusDsc = accountStatusDsc;
            _accountUseTypeDsc = accountUseTypeDsc;
            _products = new List<ContractProduct>();
        }

        public string BankName => _bankName;
        public string BankAccount => _bankAccount;
        public int Usetype => _useType;
        public string AccountClabe => _AccountClabe;
        public int BankId => _BankId;
        public int TypeAccount => _typeAccount;
        public List<ContractProduct> Products => _products;
        public string AccountStatusDsc => _accountStatusDsc;
        public string AccountUseTypeDsc => _accountUseTypeDsc;

        public static DetailBankAccount Create(string bankName, string bankAccount, int useType, string accountStatusDsc, string accountUseTypeDsc)
        {
            if (string.IsNullOrEmpty(bankName)) { throw new ArgumentException("El nombre del banco no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankAccount)) { throw new ArgumentException("La cuenta bancaria no puede ser nula."); }

            return new DetailBankAccount(bankName, bankAccount, useType, accountStatusDsc, accountUseTypeDsc);
        }

        public DetailBankAccount AddProduct(string nameComercial, string contractId, bool isAccountThird)
        {
            _products.Add(new ContractProduct(contractId, nameComercial, isAccountThird));
            return this;
        }
    }

    
}
