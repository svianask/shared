﻿using Ddd;

namespace ClientContractsDomain.BankAccountAggregate
{
    public class BanksAllowedDomiParameter : Entity<string>
    {
        private readonly int _solicitudParametroId;
        private readonly string _solicitudParametroNombre;
        private readonly string _solicitudParametroValor;

        public BanksAllowedDomiParameter(
            int solicitudParametroId,
            string solicitudParametroNombre,
            string solicitudParametroValor
            )
        {
            _solicitudParametroId = solicitudParametroId;
            _solicitudParametroNombre = solicitudParametroNombre;
            _solicitudParametroValor = solicitudParametroValor;
        }

        public int SolicitudParametroId => _solicitudParametroId;
        public string SolicitudParametroNombre => _solicitudParametroNombre;
        public string SolicitudParametroValor => _solicitudParametroValor;

        public static BanksAllowedDomiParameter Create(
            int solicitudParametroId,
            string solicitudParametroNombre,
            string solicitudParametroValor
            )
        {
            return new BanksAllowedDomiParameter(solicitudParametroId, solicitudParametroNombre, solicitudParametroValor);
        }
    }
}
