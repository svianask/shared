﻿using Ddd;

namespace ClientContractsDomain.BankAccountAggregate
{
    public class Bank : Entity<string>
    {
        private readonly string _description;
        private readonly string _descriptionShort;
        private readonly int _code;

        public Bank(
            string id,
            string description,
            string descriptionShort,
            int code
            )
        {
            Id = id;
            _description = description;
            _descriptionShort = descriptionShort;
            _code = code;
        }

        public string Description => _description;
        public string DescriptionShort => _descriptionShort;
        public int Code => _code;

        public static Bank Create(
            string id,
            string description,
            string descriptionShort,
            int code
            )
        {
            return new Bank(id, description, descriptionShort, code);
        }
    }
}
