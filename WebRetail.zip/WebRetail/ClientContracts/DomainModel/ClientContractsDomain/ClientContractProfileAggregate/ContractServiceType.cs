﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsDomain.ClientContractProfileAggregate
{
    public class ContractServiceType : Entity<string>
    {
        private readonly string _identifier;
        private readonly string _description;

        private ContractServiceType(string identifier, string description)
        {
            Id = identifier;
            _description = description;
        }

        public string Identifier => _identifier;

        public string Description => _description;

        public static ContractServiceType Create(string id, string description)
        {
            description = description.Trim().ToLower();
            description = description.Substring(0, 1).ToUpper() + description.Substring(1);

            return new ContractServiceType(id, description);
        }
    }
}
