﻿using Common.Domain;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsDomain.ClientContractProfileAggregate
{
    public class ClientContractProfile : Entity<string>
    {
        private ContractServiceType _serviceType;
        private string _productType;

        private ClientContractProfile(string contractId)
        {
            Id = contractId;
        }

        public static ClientContractProfile Create(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }

            return new ClientContractProfile(contractId);
        }

        public ContractServiceType ServiceType => _serviceType;

        public string ProductType => _productType;

        public ClientContractProfile SetServiceType(string id, string description)
        {
            if (string.IsNullOrEmpty(id)) { throw new ArgumentException("El id del perfil no puede ser nulo."); }

            _serviceType = ContractServiceType.Create(id, description);
            return this;
        }
    }
}
