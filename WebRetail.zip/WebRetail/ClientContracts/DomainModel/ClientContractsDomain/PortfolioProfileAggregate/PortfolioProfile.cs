﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsDomain.PortfolioProfileAggregate
{
    public class PortfolioProfile : CatalogEntity
    {
        private CatalogEntity _clientProfile;
        private string _contractId; 

        private PortfolioProfile(string identifier, string name) : base(identifier, name) { }

        public CatalogEntity ClientProfile => _clientProfile;
        
        public string ContractId => _contractId;

        /// <summary>
        /// Create portfolio profile 
        /// </summary>
        /// <param name="identifier">Identifier portfolio profile</param>
        /// <param name="name">Name portfolio profile</param>
        /// <returns>New PortfolioProfile</returns>
        public static PortfolioProfile Create(string identifier, string name)
        {
            return new PortfolioProfile(identifier, name);
        }

        /// <summary>
        /// Set client profile of portfolio profile
        /// </summary>
        /// <param name="identifier">Identifier portfolio profile</param>
        /// <param name="name">Name portfolio profile</param>
        /// <returns>PortfolioProfile Instance</returns>
        public PortfolioProfile SetClientProfile(string identifier, string name)
        {
            this._clientProfile = new CatalogEntity(identifier, name);
            return this;
        }

        /// <summary>
        /// Set contract identifier of portfolio profile
        /// </summary>
        /// <param name="contractId"></param>
        /// <returns>PortfolioProfile Instance</returns>
        public PortfolioProfile  SetContract(string contractId)
        {
            this._contractId = contractId;
            return this;
        }


    }
}
