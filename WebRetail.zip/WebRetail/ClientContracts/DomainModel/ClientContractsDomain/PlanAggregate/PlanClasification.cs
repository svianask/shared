﻿using Ddd;
using System.Collections.Generic;

namespace ClientContractsDomain.PlanAggregate
{
    public class PlanClasification : ValueObject<PlanClasification>
    {
        private readonly int _platform;
        private readonly int _productType;

        private PlanClasification(int platform, int productType)
        {
            _platform = platform;
            _productType = productType;
        }

        public int Platform => _platform;

        public int ProductType => _productType;

        internal static PlanClasification Create(int platform, int productType)
        {
            return new PlanClasification(platform, productType);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Platform,
                ProductType
            };
        }
    }
}
