﻿using Ddd;
using System;

namespace ClientContractsDomain.PlanAggregate
{
    public class Plan : Entity<string>
    {
        private readonly string _name;
        private readonly string _shortName;
        private readonly string _basPlanId;
        private PlanClasification _planClasification;
        private ComercialInfo _comercialInfo;

        private Plan(string planId, string name, string shortName, string basPlanId)
        {
            Id = planId;
            _name = name;
            _shortName = shortName;
            _basPlanId = basPlanId;
        }

        public string Name => _name;

        public string ShortName => _shortName;

        public string BasPlanId => _basPlanId;

        public PlanClasification PlanClasification => _planClasification;

        public ComercialInfo ComercialInfo => _comercialInfo;

        public static Plan Create(string planId, string name, string shortName, string basPlanId)
        {
            if (string.IsNullOrEmpty(name)) { throw new ArgumentException(nameof(name) + " no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(shortName)) { throw new ArgumentException(nameof(shortName) + " no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(basPlanId)) { throw new ArgumentException(nameof(basPlanId) + " no puede ser nulo ni vacío"); }

            return new Plan(planId, name, shortName, basPlanId);
        }

        public Plan SetPlanClasification(int platform, int productType)
        {
            this._planClasification = PlanClasification.Create(platform, productType);
            return this;
        }

        public Plan SetComercialInfo(short comercialPlanId, string comercialName)
        {
            this._comercialInfo = ComercialInfo.Create(comercialPlanId, comercialName);
            return this;
        }
    }
}
