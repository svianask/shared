﻿using Ddd;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class CashTransaction : ValueObject<CashTransaction>
    {
        private decimal _amountWithdrawals;
        private int _totalWithdrawals;
        private decimal _amountContributions;
        private int _totalContributions;

        public CashTransaction(decimal amountWithdrawals, int totalWithdrawals, decimal amountContributions, int totalContributions)
        {
            _amountWithdrawals = amountWithdrawals;
            _totalWithdrawals = totalWithdrawals;
            _amountContributions = amountContributions;
            _totalContributions = totalContributions;
        }

        public decimal AmountWithdrawals { get => _amountWithdrawals; set => _amountWithdrawals = value; }
        public int TotalWithdrawals { get => _totalWithdrawals; set => _totalWithdrawals = value; }
        public decimal AmountContributions { get => _amountContributions; set => _amountContributions = value; }
        public int TotalContributions { get => _totalContributions; set => _totalContributions = value; }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                AmountContributions,
                TotalWithdrawals,
                AmountContributions,
                TotalContributions
            };
        }
    }
}

