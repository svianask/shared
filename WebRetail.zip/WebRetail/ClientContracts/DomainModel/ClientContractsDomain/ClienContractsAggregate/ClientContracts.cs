﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ClientContracts : Entity<string>
    {
        private readonly List<ContractInfo> _contracts;


        private ClientContracts(string clientIdentifier)
        {
            Id = clientIdentifier;
            _contracts = new List<ContractInfo>();
        }

        public List<ContractInfo> Contracts => _contracts;


        public static ClientContracts Create(string clientIdentifier)
        {
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("clientIdentifier no puede ser nulo o vacío"); }

            return new ClientContracts(clientIdentifier);
        }


        public ClientContracts AddContract(ContractInfo contract)
        {
            this._contracts.Add(contract);
            return this;
        }
    }
}
