﻿
using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContractPeriod:ValueObject<ContractPeriod>
    {
        private  readonly DateTime _periodStart;
        private readonly DateTime _periodEnd;

        private ContractPeriod(DateTime periodStart, DateTime periodEnd)
        {
            _periodStart = periodStart;
            _periodEnd = periodEnd;
        }

        public static ContractPeriod Create(DateTime periodStart, DateTime periodEnd)
        {
            return new ContractPeriod(periodStart, periodEnd);
        }

        public static ContractPeriod CreateEmpty()
        {
            return new ContractPeriod(DateTime.MinValue, DateTime.MinValue);
        }

        public DateTime PeriodStart => _periodStart;
        public DateTime PeriodEnd => _periodEnd;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                PeriodStart,
                PeriodEnd
            };
        }
    }
}
