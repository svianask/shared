﻿using Ddd;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class RelatedImageInfo : ValueObject<RelatedImageInfo>
    {
        private readonly short _goalId;
        private readonly string _imageFileName;
        private readonly int _type;

        public RelatedImageInfo(short goalId, string imageFileName, int type)
        {
            _goalId = goalId;
            _imageFileName = imageFileName;
            _type = type;
        }

        public short GoalId => _goalId;

        public string ImageFileName => _imageFileName;

        public int Type => _type;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                GoalId,
                ImageFileName,
                Type
            };
        }
    }
}
