﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class SummaryContributions : ValueObject<SummaryContributions>
    {
        private int _totalContributions;
        private int _expectedContributions;
        private int _realizedContributions;
        private int _failedContributions;
        private int _pendingContributions;


        private SummaryContributions(int totalContributions, int expectedContributions, int realizedContributions, int failedContributions)
        {
            _totalContributions = totalContributions;
            _expectedContributions = expectedContributions;
            _realizedContributions = realizedContributions;
            _failedContributions = failedContributions;
        }

        public int TotalContributions => _totalContributions;
        public int ExpectedContributions => _expectedContributions;
        public int RealizedContributions => _realizedContributions;
        public int FailedContributions => _failedContributions;
        public int PendingContributions => _pendingContributions;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
               TotalContributions,
               ExpectedContributions,
               RealizedContributions,
               FailedContributions,
               PendingContributions
            };
        }

        public static SummaryContributions Create(int totalContributions, int expectedContributions, int realizedContributions, int failedContributions)
        {
            var retSummaryContributions = new SummaryContributions(totalContributions, expectedContributions, realizedContributions, failedContributions);
            retSummaryContributions.CalculatePendingContributions();
            return retSummaryContributions;
        }

        internal void SetTotalContributions(int totalContributions)
        {
            this._totalContributions = _totalContributions == 0 ? totalContributions : _totalContributions;
            CalculatePendingContributions();
        }

        internal void CalculateExpectedContributionsNumber(DateTime afiliationDate)
        {
            if (this._expectedContributions == 0 || this._expectedContributions > this.TotalContributions)
            {
                this._expectedContributions = ((DateTime.Now.Year - afiliationDate.Year) * 12) + (DateTime.Now.Month - afiliationDate.Month);
                if (DateTime.Now.Month == afiliationDate.Month && DateTime.Now.Day < afiliationDate.Day) { this._expectedContributions--; }
            }
            
            if (this._expectedContributions > this._totalContributions) { this._expectedContributions = this._totalContributions; }

            CalculatePendingContributions();
        }

        internal void CalculateRealizedContributions(decimal netContractContributions, decimal committedAmount)
        {
            this._realizedContributions = Convert.ToInt16(netContractContributions / committedAmount);
            if (this._realizedContributions > this._totalContributions)
            {
                this._realizedContributions = this._totalContributions;
            }
            CalculatePendingContributions();
        }

        private void CalculatePendingContributions()
        {
            this._pendingContributions = _totalContributions - _realizedContributions;
        }

        internal void SetMaxRealizedContributionsNumber(int savingAdvanceContributions)
        {
            this._realizedContributions = (this._realizedContributions > savingAdvanceContributions) ? this._realizedContributions : savingAdvanceContributions;
            CalculatePendingContributions();
        }
    }
}
