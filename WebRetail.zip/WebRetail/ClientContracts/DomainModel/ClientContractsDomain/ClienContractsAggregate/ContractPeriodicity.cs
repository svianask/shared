﻿using Ddd;
using System;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContractPeriodicity:Entity<String>
    {
        private string _contractId;
        private string _contractMaster;
        private int _periodicityId;
        private string _periodicityName;
        private int _termMonths;

        private ContractPeriodicity(string contractId, string contractMaster, int periodicityId, string periodicityName, int termMonths)
        {
            this.Id = contractId; // Tipo 2, cuenta normal  , no adicional
            this._contractMaster = contractMaster;
            this._periodicityId = periodicityId;
            this._periodicityName = periodicityName;
            this._termMonths = termMonths;
        }

        public static ContractPeriodicity Create(string contractId, string contractMaster, int periodicityId, string periodicityName, int termMonths)
        {
            if (String.IsNullOrEmpty(contractId)) { throw new ArgumentException("ContractId no puede ser nulo o vacío"); }
            if (String.IsNullOrEmpty(contractMaster)) { throw new ArgumentException("ContractMaster no puede ser nulo o vacío"); }
            if (periodicityId < 1) { throw new ArgumentException("PeriodicityId no puede ser negativo o cero,"); }
            if (String.IsNullOrEmpty(periodicityName)) { throw new ArgumentException("PeriodicityName no puede ser nulo o vacío"); }
            return new ContractPeriodicity(contractId, contractMaster, periodicityId, periodicityName, termMonths);
        }

        public String ContractMaster => _contractMaster;
        public int PeriodicityId => _periodicityId;
        public String PeriodicityName => _periodicityName;
        public int TermMonths => _termMonths;
    }
}
