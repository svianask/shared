﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContributionsOnDemand : ValueObject<ContributionsOnDemand>
    {
        private decimal _ordinalOnDemandAmount;
        private decimal _additionalOnDemandAmount;

        private ContributionsOnDemand(decimal ordinalOnDemandAmount)
        {
            _ordinalOnDemandAmount = ordinalOnDemandAmount;
        }

        public decimal OrdinalOnDemandAmount => _ordinalOnDemandAmount;
        public decimal AdditionalOnDemandAmount => _additionalOnDemandAmount;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                OrdinalOnDemandAmount,
                AdditionalOnDemandAmount
            };
        }

        public static ContributionsOnDemand Create(decimal ordinalOnDemandAmount)
        {
            return new ContributionsOnDemand(ordinalOnDemandAmount);
        }

        public ContributionsOnDemand SetAdditionalOnDemandAmount(decimal additionalOnDemandAmount)
        {
            this._additionalOnDemandAmount = additionalOnDemandAmount;
            return this;
        }

    }
}
