﻿using ClientContractsDomain.ContractInflationAggregate;
using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class BalanceContract : ValueObject<BalanceContract>
    {
        private readonly decimal _lifeInsuranceAmount;
        private readonly decimal _savingGoal;
        private decimal _balance;
        private decimal _charges;
        private decimal _yield;
        private decimal _ordinalWithdrawalsAmount;
        private decimal _additionalWithdrawalsAmount;
        private decimal _ordinalContributionsAmount;
        private decimal _additionalContributionsAmount;
        private decimal _ordinalOnDemandAmount;
        private decimal _additionalOnDemandAmount;
        private decimal _initialValuation;
        private decimal _pendingContributionAmount;
        private decimal _contributionSumAmount;
        private ContractInflation _contractInflation;

        private BalanceContract(decimal balance, decimal lifeInsuranceAmount, decimal savingGoal)
        {
            this._balance = Math.Round(balance, 2);
            this._lifeInsuranceAmount = Math.Round(lifeInsuranceAmount, 2);
            this._savingGoal = Math.Round(savingGoal, 2);
            this._pendingContributionAmount = 0M;
            this._contributionSumAmount = 0;
            _contractInflation = ContractInflation.CreateEmpty();
        }

        public decimal LifeInsuranceAmount => _lifeInsuranceAmount;
        public decimal SavingGoal => _savingGoal;
        public decimal Contributions => _ordinalContributionsAmount + _additionalContributionsAmount + OrdinalOnDemandAmount + AdditionalOnDemandAmount;
        public decimal Balance => _balance;
        public decimal Charges => _charges;
        public decimal Yield => _yield;
        public decimal Withdrawals => _ordinalWithdrawalsAmount + _additionalWithdrawalsAmount;
        public decimal OrdinalWithdrawalsAmount => _ordinalWithdrawalsAmount;
        public decimal AdditionalWithdrawalsAmount => _additionalWithdrawalsAmount;
        public decimal OrdinalContributionsAmount => _ordinalContributionsAmount;
        public decimal AdditionalContributionsAmount => _additionalContributionsAmount;
        public decimal OnDemandCash => OrdinalOnDemandAmount + AdditionalOnDemandAmount;
        public decimal OrdinalOnDemandAmount => _ordinalOnDemandAmount;
        public decimal AdditionalOnDemandAmount => _additionalOnDemandAmount;
        public decimal InitialValuation => _initialValuation;
        public decimal PendingContributionAmount => _pendingContributionAmount;
        public decimal ContributionSumAmount => _contributionSumAmount;
        public ContractInflation ContractInflation => _contractInflation;


        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                LifeInsuranceAmount,
                SavingGoal,
                Contributions,
                Balance,
                Charges,
                Yield,
                Withdrawals,
                OrdinalWithdrawalsAmount,
                AdditionalWithdrawalsAmount,
                OrdinalContributionsAmount,
                AdditionalContributionsAmount,
                OnDemandCash,
                OrdinalOnDemandAmount,
                AdditionalOnDemandAmount,
                InitialValuation,
                PendingContributionAmount,
                ContributionSumAmount,
                ContractInflation
            };
        }

        public static BalanceContract Create(decimal balance, decimal lifeInsuranceAmount, decimal savingGoal)
        {
            return new BalanceContract(balance, lifeInsuranceAmount, savingGoal);
        }

        internal void SetWithdrawals(decimal ordinalWithdrawalsAmount, decimal additionalWithdrawalsAmount)
        {
            this._ordinalWithdrawalsAmount = Math.Round(ordinalWithdrawalsAmount,2);
            this._additionalWithdrawalsAmount = Math.Round(additionalWithdrawalsAmount,2);
            CalculateYield();
        }

        internal void SetContributions(decimal ordinalContributionsAmount, decimal additionalContributionsAmount)
        {
            this._ordinalContributionsAmount = Math.Round(ordinalContributionsAmount,2);
            this._additionalContributionsAmount = Math.Round(additionalContributionsAmount,2);
            CalculateYield();
        }

        internal void SetOnDemandCash(decimal ordinalOnDemandAmount, decimal additionalOnDemandAmount)
        {
            this._ordinalOnDemandAmount = Math.Round(ordinalOnDemandAmount,2);
            this._additionalOnDemandAmount = Math.Round(additionalOnDemandAmount,2);
            CalculateYield();
        }

        internal void SetCharges(decimal charges)
        {
            this._charges = Math.Round(charges,2);
            CalculateYield();
        }

        internal void SetBalanceContract(decimal balance)
        {
            this._balance = Math.Round(balance,2);
            CalculateYield();
        }

        internal void SetInitialValuation(decimal initialValuation)
        {
            this._initialValuation = Math.Round(initialValuation,2);
        }

        private void CalculateYield()
        {
            this._yield = Math.Round( this._balance - (this._initialValuation + Contributions - Charges - Withdrawals),2);
        }

        public void SetPendingContributionAmount(decimal amount)
        {
            this._pendingContributionAmount = amount;
        }

        public void SetContributionSumAmount(decimal amount)
        {
            this._contributionSumAmount = amount;
        }

        public void SetContractInflation(ContractInflation contractInflation)
        {
            this._contractInflation = contractInflation;
        }

    }
}
