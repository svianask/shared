﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ddd;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContractMovementDetail : ValueObject<ContractMovementDetail>
    {
        private string _movementContract;
        private string _movementSubaccountName;
        private string _movementDescription;
        private decimal _movementAmount;
        private DateTime _movementProcessDate;
        private string _movementBankAccount;

        public ContractMovementDetail(string movementContract, string movementSubaccountName, decimal movementAmount, DateTime movementDate, string movementBankAccount)
        {
            _movementContract = movementContract;
            _movementSubaccountName = movementSubaccountName;
            _movementAmount = movementAmount;
            _movementProcessDate = movementDate;
            _movementBankAccount = movementBankAccount; 
            SetAccountMasked();
        }

        public string MovementContractId => _movementContract;
        public String MovementProcessDate => _movementProcessDate.ToString("dd MMM yyyy");
        public string MovementDescription => _movementDescription;
        public decimal MovementAmount => _movementAmount;
        public string MovementSubaccountName => _movementSubaccountName;
        public string MovementBankAccount => _movementBankAccount;

        public static ContractMovementDetail Create(string movementContract, string movementSubaccountName, decimal movementAmount, DateTime movementDate, string movementBankAccount)
        {
            return new ContractMovementDetail(movementContract, movementSubaccountName, movementAmount, movementDate, movementBankAccount);
        }

        public ContractMovementDetail SetMovementDescription(string movementDescription)
        {
            _movementDescription = movementDescription;
            return this;
        }

        private void SetAccountMasked()
        {
            bool isdigit = !string.IsNullOrEmpty(_movementBankAccount) && _movementBankAccount.All(char.IsDigit);
            if (isdigit)
            {
                _movementBankAccount = "**********" + _movementBankAccount.Substring(_movementBankAccount.Length - 4, 4);
            }

        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<Object>
            {
                MovementContractId,
                MovementProcessDate,
                MovementDescription,
                MovementAmount,
                MovementSubaccountName,
                MovementBankAccount
            };
        }
    }
}
