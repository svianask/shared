﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class RealizedContributions : ValueObject<RelatedImageInfo>
    {
        private readonly decimal _ordinalContributionsAmount;
        private readonly int _ordinalContributionsNumber;
        private decimal _additionalContributionsAmount;
        private int _additionalContributionsNumber;
        private DateTime _firstContributionDate;

        private RealizedContributions(decimal ordinalContributionsAmount, int ordinalContributionsNumber)
        {
            _ordinalContributionsAmount = ordinalContributionsAmount;
            _ordinalContributionsNumber = ordinalContributionsNumber;
        }

        public decimal OrdinalContributionsAmount => _ordinalContributionsAmount;

        public int OrdinalContributionsNumber => _ordinalContributionsNumber;

        public decimal AdditionalContributionsAmount => _additionalContributionsAmount;

        public int AdditionalContributionsNumber => _additionalContributionsNumber;

        public DateTime FirstContributionDate => _firstContributionDate;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                OrdinalContributionsAmount,
                OrdinalContributionsNumber,
                AdditionalContributionsAmount,
                AdditionalContributionsNumber,
                FirstContributionDate
            };
        }

        public static RealizedContributions Create(decimal ordinalContributionsAmount, int ordinalContributionsNumber)
        {
            return new RealizedContributions(ordinalContributionsAmount, ordinalContributionsNumber);
        }

        public RealizedContributions SetAdditionalContributions(decimal additionalContributionsAmount, int additionalContributionsNumber)
        {
            this._additionalContributionsAmount = additionalContributionsAmount;
            this._additionalContributionsNumber = additionalContributionsNumber;
            return this;
        }

        public RealizedContributions SetFirstContributionDate(DateTime firstContributionDate)
        {
            this._firstContributionDate = firstContributionDate;
            return this;
        }
    }
}
