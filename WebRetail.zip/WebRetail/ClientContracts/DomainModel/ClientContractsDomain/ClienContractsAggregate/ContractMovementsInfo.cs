﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ddd;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContractMovementsInfo : Entity<string>
    {
        private int _contractType;
        private short _goalId;
        private string _goalImage;
        private string _comercialName;
        private string _goalDescription;
        private decimal _totalBalance;
        private decimal _totalContributions;
        private decimal _totalWithdrawals;
        private decimal _totalCharges;
        private decimal _yieldAmount;
        private DateTime _initialDate;
        private DateTime _finalDate;
        private List<ContractMovementDetail> _contractMovementCashDetails;
        private List<ContractMovementDetail> _contractMovementPendingDetails;
        private List<ContractMovementDetail> _contractMovementFundsDetails;

        private ContractMovementsInfo(string contractId, string comercialName, int contractType)
        {
            Id = contractId;
            _comercialName = comercialName;
            _contractType = contractType;
        }



        public static ContractMovementsInfo Create(string contractId, string comercialName, int contractType)
        {
            return new ContractMovementsInfo(contractId, comercialName, contractType);
        }
        public DateTime InitialDate => _initialDate;
        public DateTime FinalDate => _finalDate;
        public short GoalId => _goalId;
        public string GoalImage => _goalImage;
        public string GoalDescription => _goalDescription;
        public string ComercialName => _comercialName;
        public decimal TotalContributions => _totalContributions;
        public decimal TotalWithdrawals => _totalWithdrawals;
        public decimal TotalCharges => _totalCharges;
        public decimal TotalBalance => _totalBalance;
        public decimal YieldAmount => _yieldAmount;
        public int ContractType => _contractType;
        public List<ContractMovementDetail> ContractMovementsCashDetail => _contractMovementCashDetails;
        public List<ContractMovementDetail> ContractMovementsPendingDetail => _contractMovementPendingDetails;
        public List<ContractMovementDetail> ContractMovementFundsDetails => _contractMovementFundsDetails;

        public void SetGoalInfo(short goalId, string goalImage, string goalDescription)
        {
            _goalId = goalId;
            _goalImage = goalImage;
            _goalDescription = goalDescription;
        }

        public void SetBalance(decimal totalBalance)
        {
            _totalBalance = totalBalance;
        }

        public void SetContributions(decimal totalContributions)
        {
            _totalContributions = totalContributions;
        }

        public void SetWithdrawals(decimal totalWithdrawals)
        {
            _totalWithdrawals = totalWithdrawals;
        }

        public void SetCharges(decimal totalCharges)
        {
            _totalCharges = totalCharges;
        }

        public void SetDatesInfo(DateTime initialDate, DateTime finalDate)
        {
            _initialDate = initialDate.Date;
            _finalDate = finalDate.Date;
        }
        public void CalculateYieldAmount(decimal initialBalance)
        {
            _yieldAmount = Math.Round(_totalBalance - ((initialBalance + _totalContributions) - (_totalWithdrawals + _totalCharges)), 2);
        }

        public void SetMovementsDetail(List<ContractMovementDetail> contractMovementCashDetails)
        {
            _contractMovementCashDetails = contractMovementCashDetails;
        }

        public void SetMovementsPendingDetail(List<ContractMovementDetail> contractMovementPendingDetails)
        {
            _contractMovementPendingDetails = contractMovementPendingDetails;
        }
        public void SetMovementsFundsDetail(List<ContractMovementDetail> contractMovementFundsDetails)
        {
            _contractMovementFundsDetails = contractMovementFundsDetails;
        }
    }
}
