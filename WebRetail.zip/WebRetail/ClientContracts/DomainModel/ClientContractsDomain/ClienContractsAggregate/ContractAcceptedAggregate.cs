﻿using Ddd;
using System;

namespace ClientContractsDomain.ClienContractsAggregate {
    public class ContractAccepted : Entity<int>
    {
        private string contractor_rfc;
        private string contract_id;
        private DateTime start_date;


        private ContractAccepted(int id, string contractor_rfc, string contract_id, DateTime start_date)
        {
            this.Id = id;
            this.contractor_rfc = contractor_rfc;
            this.contract_id = contract_id;
            this.start_date = start_date;
        }

        public static ContractAccepted Create(int id, string contractor_rfc, string contract_id, DateTime start_date)
        {
            return new ContractAccepted(id, contractor_rfc, contract_id, start_date);
        }

        public string ContractorRFC => this.contractor_rfc;
        public string ContractId => this.contract_id;
        public DateTime StartDate => this.start_date;


    }
}
