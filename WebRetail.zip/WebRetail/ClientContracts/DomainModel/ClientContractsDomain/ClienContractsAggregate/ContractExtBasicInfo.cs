﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContractExtBasicInfo : ValueObject<ContractExtBasicInfo>
    {
        private readonly decimal _savingGoal;
        private readonly int _savingTerm;
        private readonly decimal _committedAmount;
        private DateTime _efectiveEndDate;
        private DateTime _afiliationDate;

        private ContractExtBasicInfo(decimal savingGoal, int savingTerm, decimal committedAmount)
        {
            _savingGoal = savingGoal;
            _savingTerm = savingTerm;
            _committedAmount = committedAmount;
        }

        public decimal SavingGoal => _savingGoal;

        public int SavingTerm => _savingTerm;

        public decimal CommittedAmount => _committedAmount;

        public DateTime AfiliationDate => _afiliationDate;

        public DateTime EfectiveEndDate => _efectiveEndDate;

        public static ContractExtBasicInfo Create(decimal savingGoal, int savingTerm, decimal committedAmount)
        {
            return new ContractExtBasicInfo(savingGoal, savingTerm, committedAmount);
        }

        public ContractExtBasicInfo SetEffectiveDates(DateTime afiliationDate, DateTime effectiveEndDate)
        {
            _afiliationDate = afiliationDate;
            _efectiveEndDate = effectiveEndDate;

            return this;
        }

        public static ContractExtBasicInfo CreateEmpty()
        {
            return new ContractExtBasicInfo(0, 0, 0);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                SavingGoal,
                SavingTerm,
                CommittedAmount
            };
        }
    }
}
