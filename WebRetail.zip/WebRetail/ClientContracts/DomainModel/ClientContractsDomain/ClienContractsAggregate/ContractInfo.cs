﻿using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.PlanAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace ClientContractsDomain.ClienContractsAggregate
{
    public class ContractInfo : Entity<string>
    {
        private readonly short _planBasId;
        private readonly int _platform;
        private readonly short _goalId;
        private string _goalImage;
        private int _contractType;
        private string _comercialName;
        private string _plaId;
        private string _groupingContractId;
        private string _goalDescription;
        private DateTime _afiliationDate;
        private ContractPeriod _period;
        private SummaryContributions _summaryContributionsNumber;
        private BalanceContract _balanceContract;
        private List<AssociatedContract> _associatedContracts;
        private List<Fund> _investments;
        private bool _applyWithdrawals;
        private bool _applyContributions;
        private bool _applyTransfers;
        private int _segmentType;
        private int _statusContract;
        private int _statusOperation;
        private bool _applyDeducible;
        private bool _hasTrackerDetail;

        private ContractInfo(string contractId, short planBasId, int platform, short goalId, string groupingContractId)
        {
            Id = contractId;
            _planBasId = planBasId;
            _platform = platform;
            _goalId = goalId;
            _groupingContractId = groupingContractId;
            _associatedContracts = new List<AssociatedContract>();
            _hasTrackerDetail = false;
        }

        public short PlanBasId => _planBasId;
        public int Platform => _platform;
        public short GoalId => _goalId;
        public int ContractType => _contractType;
        public string ComercialName => _comercialName;
        public string GoalImage => _goalImage;
        public string GoalDescription => _goalDescription;
        public string PlaId => _plaId;
        public string GroupingContractId => _groupingContractId;
        public bool ApplyWithdrawals => _applyWithdrawals;
        public bool ApplyContribution => _applyContributions;
        public bool ApplyTransfers => _applyTransfers;

        public int SegmentType => _segmentType;

        public DateTime AfiliationDate => _afiliationDate;
        public ContractPeriod Period => _period;
        public SummaryContributions SummaryContributionsNumber => _summaryContributionsNumber;
        public BalanceContract BalanceContract => _balanceContract;
        public List<AssociatedContract> AssociatedContracts => _associatedContracts;
        public List<Fund> Investments { get => _investments; set => _investments = value; }
        public int StatusContract => _statusContract;
        public int StatusOperation => _statusOperation;
        public bool ApplyDeducible => _applyDeducible;
        public bool HasTrackerDetail => _hasTrackerDetail;

        

        public static ContractInfo Create(string contractId, short planBasId, int platform, short goalId, string groupingContractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(groupingContractId)) { throw new ArgumentException("groupingContractId no puede ser nulo ni vacío"); }
            if (planBasId < 0) { throw new ArgumentException("El valor de planId no es válido"); }
            if (platform != 5 && platform != 10) { throw new ArgumentException("El tipo de producto es inválido"); }
            if (goalId < 0) { throw new ArgumentException("el id de la meta es inválido"); }

            return new ContractInfo(contractId, planBasId, platform, goalId, groupingContractId);
        }

        private void SetContractType(int contractType)
        {
            _contractType = contractType;
        }

        public Plan SetPlanInfo(List<Plan> plansInfo, int platform)
        {
            var planInfo = plansInfo.Single(x => x.PlanClasification.Platform == Platform);

            _plaId = planInfo.Id;
            _comercialName = planInfo.ComercialInfo.ComercialName;
            var productType = planInfo.PlanClasification.ProductType;

            SetContractType(productType);
            return planInfo;
        }

        public void SetGoalImage(List<RelatedImageInfo> relatedImageInfos, int typeContract)
        {
            _goalImage = relatedImageInfos.Where(i => i.Type == typeContract).FirstOrDefault().ImageFileName;
        }

        public ContractInfo SetAfiliationDate(DateTime afiliationDate)
        {
            _afiliationDate = afiliationDate;
            return this;
        }

        public ContractInfo SetStatus(int statusContract, int statusOperation)
        {
            _statusContract = statusContract;
            _statusOperation = statusOperation;
            return this;
        }

        public void SetSummaryContributionsNumber(int totalContributions, int expectedContributions, int realizedContributions, int failedContributions)
        {
            _summaryContributionsNumber = SummaryContributions.Create(totalContributions, expectedContributions, realizedContributions, failedContributions);
        }


        #region Balances 
        public void SetBalancesContract(decimal balance, decimal lifeInsuranceAmount, decimal savingGoal)
        {
            this._balanceContract = BalanceContract.Create(balance, lifeInsuranceAmount, savingGoal);
        }

        public void SetContributions(decimal ordinalContributionsAmount, decimal additionalContributionsAmount)
        {
            this._balanceContract.SetContributions(ordinalContributionsAmount, additionalContributionsAmount);
        }

        public void SetInitialValuation(decimal initialValuation)
        {
            this._balanceContract.SetInitialValuation(initialValuation);
        }

        public void SetWithdrawals(decimal ordinalWithdrawalsAmount, decimal additionalWithdrawalsAmount)
        {
            this._balanceContract.SetWithdrawals(ordinalWithdrawalsAmount, additionalWithdrawalsAmount);
        }

        public void SetCharges(decimal charges)
        {
            this._balanceContract.SetCharges(charges);
        }

        public void SetOnDemandCash(decimal ordinalOnDemandAmount, decimal additionalOnDemandAmount)
        {
            this._balanceContract.SetOnDemandCash(ordinalOnDemandAmount, additionalOnDemandAmount);
        }
        #endregion

        public void SetAssociatedContracts(List<AssociatedContract> associatedContracts)
        {
            associatedContracts.ForEach(ac => _associatedContracts.Add(AssociatedContract.Create(ac.ContractId, ac.AssociatedContractId, ac.AssociatedType)));
        }

        public void SetInvestments(List<Fund> funds)
        {
            _investments = funds;
        }

        public void DetermineAfiliationDate(List<DateTime> dates)
        {
            DateTime mayorDateTime = new DateTime(1900, 1, 1);
            dates.ForEach(d => mayorDateTime = (mayorDateTime >= d) ? mayorDateTime : d);

            SetAfiliationDate(mayorDateTime);
        }

        public void SetTotalContributionsNumber(int savingTerm)
        {
            this.SummaryContributionsNumber.SetTotalContributions(savingTerm);
        }

        public void CalculateExpectedContributionsNumber(DateTime afiliationDate)
        {
            this.SummaryContributionsNumber.CalculateExpectedContributionsNumber(afiliationDate);
        }

        public void CalculateRealizedContributions(decimal committedAmount)
        {
            var ContractContributions = this._balanceContract.Contributions;
            var ContractWithdrawals = this._balanceContract.Withdrawals;
            var Charges = this._balanceContract.Charges;
            
            var OrdinalContractContributions = this._balanceContract.OrdinalContributionsAmount;
            var NetContractContributions = ContractContributions - ContractWithdrawals - Charges;

            this.SummaryContributionsNumber.CalculateRealizedContributions(NetContractContributions, committedAmount);
        }

        public void CalculateBalanceContract()
        {
            decimal TotalBalance = 0M;
            this._investments.ForEach(f => TotalBalance += f.MarketValues.MarketValue);

            this._balanceContract.SetBalanceContract(TotalBalance);
        }

        public void SetMaxRealizedContributionsNumber(int savingAdvanceContributions)
        {
            this.SummaryContributionsNumber.SetMaxRealizedContributionsNumber(savingAdvanceContributions);
        }

        public ContractInfo SetGoalDescription(string goalDescription)
        {
            _goalDescription = goalDescription;
            return this;
        }

        public void SetApplyWhitdrawals(bool apply)
        {
            _applyWithdrawals = apply;
        }

        public void SetApplyContributions(bool apply)
        {
            _applyContributions = apply;
        }

        public void SetProductApplyTransfers()
        {
            _applyTransfers = true;
        }

        public void SetSegmentType(int segmenttype)
        {
            _segmentType = segmenttype;
        }

        public ContractInfo SetApplyDeducible(bool applyDeducible)
        {
            _applyDeducible = applyDeducible;
            return this;
        }

        public void SetPeriod(ContractPeriod period)
        {
            _period = period;
        }

        public ContractInfo SetHasTrackerDetail(bool hasTrackerDetail)
        {
            _hasTrackerDetail = hasTrackerDetail;
            return this;
        }
    }

}
