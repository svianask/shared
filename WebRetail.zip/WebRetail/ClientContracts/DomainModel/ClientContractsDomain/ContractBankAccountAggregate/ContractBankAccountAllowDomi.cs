﻿using Ddd;
using System;

namespace ClientContractsDomain.ContractBankAccountAggregate
{
    public class ContractBankAccountAllowDomi : Entity<string>
    {
        private ContractBankAccountAllowDomi(string contractId)
        {
            Id = contractId;
        }

        public static ContractBankAccountAllowDomi Create(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío."); }

            return new ContractBankAccountAllowDomi(contractId);
        }

        public ContractBankAccountAllowDomi SetAccountData(int accountId, string accountNumber, int accountUseTypeId, string accountUseTypeDsc)
        {
            this.AccountId = accountId;
            this.AccountNumber = accountNumber;
            this.AccountUseTypeId = accountUseTypeId;
            this.AccountUseTypeDsc = accountUseTypeDsc;
            return this;
        }

        public ContractBankAccountAllowDomi SetBankData(int bankId, string accountBankName, int bankAccountTypeId)
        {
            this.BankId = bankId;
            this.AccountBankName = accountBankName;
            this.BankAccountTypeId = bankAccountTypeId;
            return this;
        }

        public ContractBankAccountAllowDomi SetClassificationAccount(int classificationId, string classificationDsc)
        {
            this.ClassificationId = classificationId;
            this.Classification = classificationDsc;
            return this;
        }

        public ContractBankAccountAllowDomi SetAccountStatusDsc(int accountStatusId, string accountStatusDsc)
        {
            this.AccountStatusId = accountStatusId;
            this.AccountStatus = accountStatusDsc;
            return this;
        }

        public ContractBankAccountAllowDomi MaskSensitiveInfo(bool maskSensitiveInfo)
        {
            if (maskSensitiveInfo)
                this.AccountNumber = this.AccountNumber.Length > 4 ?
                    $"{new string('*', this.AccountNumber.Length - 4)}{this.AccountNumber.Substring(this.AccountNumber.Length - 4, 4)}" : this.AccountNumber;
            return this;
        }

        public int AccountId { get; private set; }

        public string AccountNumber { get; private set; }

        public int AccountUseTypeId { get; private set; }

        public string AccountUseTypeDsc { get; private set; }

        public int BankId { get; private set; }

        public string AccountBankName { get; private set; }

        public int BankAccountTypeId { get; private set; }

        public int ClassificationId { get; private set; }

        public string Classification { get; private set; }

        public int AccountStatusId { get; private set; }

        public string AccountStatus { get; private set; }
    }
}
