﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContractsDomain.FundAggregate
{
    public class Prices : ValueObject<Prices>
    {
        private readonly decimal _price;
        private readonly decimal _purchasePrice;
        private readonly decimal _salesPrice;
        private DateTime _priceDate;
        private Prices(decimal price, decimal purchasePrice, decimal salesPrice)
        {
            _price = price;
            _purchasePrice = purchasePrice;
            _salesPrice = salesPrice;
        }

        public decimal Price => _price;

        public decimal PurchasePrice => _purchasePrice;

        public decimal SalesPrice => _salesPrice;

        public DateTime PriceDate => _priceDate;

        internal static Prices Create(decimal price, decimal purchasePrice, decimal salesPrice)
        {
            return new Prices(price, purchasePrice, salesPrice);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Price,
                PurchasePrice,
                SalesPrice,
                PriceDate
            };
        }

        internal void SetPriceDate(DateTime priceDate)
        {
            _priceDate = priceDate;
        }
    }
}
