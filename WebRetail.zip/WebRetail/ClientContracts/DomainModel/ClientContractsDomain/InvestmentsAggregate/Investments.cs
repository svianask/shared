﻿using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.PortfolioProfileAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsDomain.InvestmentsAggregate
{
    public class Investments : ValueObject<Investments>
    {
        private readonly List<Fund> _cash;
        private readonly List<Fund> _funds;
        private List<PortfolioProfile> _portfoliosProfile;
        private List<AssociatedContract> _associatedContracts;
        private string _comercialName;
        private int _productType;

        private Investments(List<Fund> cash, List<Fund> funds)
        {
            _cash = cash;
            _funds = funds;
        }

        public List<Fund> Cash => _cash;

        public List<Fund> Funds => _funds;

        public List<PortfolioProfile> PortfoliosProfile => _portfoliosProfile;

        public List<AssociatedContract> AssociatedContracts => _associatedContracts;

        public string ComercialName => _comercialName;

        public int ProductType { get => _productType; set => _productType = value; }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Cash,
                Funds
            };
        }

        public static Investments Create(List<Fund> cash, List<Fund> funds)
        {
            return new Investments(cash, funds);
        }

        public Investments SetPortfolioProfile(List<PortfolioProfile> portfolioProfile)
        {
            this._portfoliosProfile = portfolioProfile;
            return this;
        }

        public Investments SetAssociatedContracts(List<AssociatedContract> associatedContracts)
        {
            this._associatedContracts = associatedContracts;
            return this;
        }

        public void SetPlanInfo(string comercialName, int productType)
        {
            this._comercialName = comercialName;
            this._productType = productType;
        }
    }
}
