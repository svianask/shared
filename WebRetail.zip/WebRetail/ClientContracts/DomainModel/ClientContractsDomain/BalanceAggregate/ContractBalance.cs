﻿using System.Collections.Generic;
using Ddd;

namespace ClientContractsDomain.BalanceAggregate
{
    public class ContractBalance : ValueObject<ContractBalance>
    {
        private readonly decimal balance;

        public ContractBalance(decimal balance)
        {
            this.balance = balance;
        }

        public decimal Balance => balance;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Balance
            };
        }
    }
}
