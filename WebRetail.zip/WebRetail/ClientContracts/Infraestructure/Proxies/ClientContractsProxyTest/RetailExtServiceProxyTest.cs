﻿using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.PlanAggregate;
using ClientContractsProxy;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxyTest
{
    [TestClass]
    public class RetailExtServiceProxyTest
    {
        private readonly Mock<IProxyEngine> _proxyEngine;
        private readonly RetailExtServiceProxy _retailExtServiceProxy;

        public RetailExtServiceProxyTest()
        {

            ConfigurationManager.AppSettings["RetailExtendedService:URLService"] = "http://localhost/RetailExtendedServiceApi/api/";

            _proxyEngine = new Mock<IProxyEngine>();

            _retailExtServiceProxy = new RetailExtServiceProxy(_proxyEngine.Object);

        }

        #region GetGoalsImage Method
        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("GoalsImageDynDat", DynamicDataSourceType.Method)]
        public void GetGoalsImageOK(List<short> goalIds)
        {
            PrxyGoalsImageRequest request = new PrxyGoalsImageRequest();
            PrxyGoalsImageResponse response = new PrxyGoalsImageResponse();
            OperationResult resGoalsImage = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetGoalsImage";

            var retValue = GetGoalsImageData(goalIds);

            request.GoalIds = goalIds;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyGoalsImageRequest>(c => c.GoalIds.Equals(goalIds)), out resGoalsImage))
                .Callback(() => { resGoalsImage.Successful = true; resGoalsImage.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetGoalsImage" } }; })
                .Returns(retValue).Verifiable();

            var GoalImages = _retailExtServiceProxy.GetGoalsImage(goalIds, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsTrue(GoalImages.Count > 0);
            Assert.IsInstanceOfType(GoalImages, typeof(List<RelatedImageInfo>));
        }


        [TestMethod, TestCategory("FailProcess")]
        public void GetGoalsImageNoServiceFail()
        {
            List<short> goalIds = new List<short> { -1 };

            PrxyGoalsImageRequest request = new PrxyGoalsImageRequest();
            PrxyGoalsImageResponse response = new PrxyGoalsImageResponse();
            OperationResult resGoalsImage = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContractss/GetGoalsImage";

            var retValue = GetGoalsImageDataFail();

            request.GoalIds = goalIds;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyGoalsImageRequest>(c => c.GoalIds.Equals(goalIds)), out resGoalsImage))
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetGoalsImage(goalIds, out OperationResult result));
        }

        [TestMethod, TestCategory("FailProcess")]
        public void GetGoalsImageGoalIdsFail()
        {
            List<short> goalIds = new List<short> { -1 };

            PrxyGoalsImageRequest request = new PrxyGoalsImageRequest();
            PrxyGoalsImageResponse response = new PrxyGoalsImageResponse();
            OperationResult resGoalsImage = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetGoalsImage";

            var retValue = GetGoalsImageDataFail();

            request.GoalIds = goalIds;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyGoalsImageRequest>(c => c.GoalIds.Equals(goalIds)), out resGoalsImage))
                .Callback(() => { resGoalsImage.Successful = false; resGoalsImage.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener las imagenes GetGoalsImage" } }; })
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetGoalsImage(goalIds, out OperationResult result));
        }

        private static IEnumerable<object[]> GoalsImageDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<short> { 9999 } },
                new object[]{ new List<short> { 5 } }
            };
        }

        private string GetGoalsImageData(List<short> goalIds)
        {
            string retValue = string.Empty;
            Dictionary<short, string> retData = new Dictionary<short, string>(){
                { 9999, "{\"Images\":[{\"GoalId\":9999,\"ImageFileName\":\"saving.png\",\"Type\":1},{\"GoalId\":9999,\"ImageFileName\":\"vector.png\",\"Type\":2}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { 5, "{\"Images\":[{\"GoalId\":5,\"ImageFileName\":\"education.png\",\"Type\":1},{\"GoalId\":5,\"ImageFileName\":\"vector.png\",\"Type\":2}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(goalIds[0], out retValue);

            return retValue;
        }

        private string GetGoalsImageDataFail()
        {
            return "{\"Images\":[],\"Result\":{\"Successful\":false,\"SystemMessages\":[\"Error al obtener la imagenes - GetGoalsImage - at...\"]}}";
        }

        #endregion GetGoalsImage Method

        #region GetPlansById Method
        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("PlansByIdDynDat", DynamicDataSourceType.Method)]
        public void GetPlansByIdOK(List<short> basPlanIds)
        {
            PrxyPlansRequest request = new PrxyPlansRequest();
            PrxyPlansResponse response = new PrxyPlansResponse();
            OperationResult resPlansById = new OperationResult();


            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetPlansById"; //Controller/Action

            var retValue = GetPlansByIdData(basPlanIds);

            request.PlanIds = basPlanIds;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyPlansRequest>(c => c.PlanIds.Equals(basPlanIds)), out resPlansById))
                .Callback(() => { resPlansById.Successful = true; resPlansById.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin error GetPlansById" } }; })
                .Returns(retValue).Verifiable();

            var Plans = _retailExtServiceProxy.GetPlansById(basPlanIds, out OperationResult result);

            Assert.IsTrue(resPlansById.Successful);
            Assert.IsTrue(Plans.Count > 0);
            Assert.IsInstanceOfType(Plans, typeof(List<Plan>));
        }

        [TestMethod, TestCategory("FailProcess")]
        public void GetPlansByIdNoServiceFail()
        {
            List<short> plansIds = new List<short> { -1 };

            PrxyPlansRequest request = new PrxyPlansRequest();
            PrxyPlansResponse response = new PrxyPlansResponse();
            OperationResult resPlansById = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Productss/GetPlansById"; //Controller/Action

            var retValue = GetPlansByIdDataFail();

            request.PlanIds = plansIds;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyPlansRequest>(c => c.PlanIds.Equals(plansIds)), out resPlansById))
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetPlansById(plansIds, out OperationResult result));
        }

        [TestMethod, TestCategory("FailProcess")]
        public void GetPlansByIdPlanIdFail()
        {
            List<short> plansIds = new List<short> { -1 };

            PrxyPlansRequest request = new PrxyPlansRequest();
            PrxyPlansResponse response = new PrxyPlansResponse();
            OperationResult resPlansById = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetPlansById"; //Controller/Action

            var retValue = GetPlansByIdDataFail();

            request.PlanIds = plansIds;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyPlansRequest>(c => c.PlanIds.Equals(plansIds)), out resPlansById))
                .Callback(() => { resPlansById.Successful = false; resPlansById.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener la información de los planes" } }; })
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetPlansById(plansIds, out OperationResult result));
        }

        private static IEnumerable<object[]> PlansByIdDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<short> { 350 } },
                new object[]{ new List<short> { 5 } },
                new object[]{ new List<short> { 520 } },
                new object[]{ new List<short> { 480 } }
            };
        }

        private string GetPlansByIdData(List<short> basPlanIds)
        {
            string retValue = string.Empty;
            Dictionary<short, string> retData = new Dictionary<short, string>(){
                {350, "{\"Plans\":[{\"Name\":\"APORTAC REGULARES VISION NO DEDUCIBLE - FID 436\",\"ShortName\":\"SKANDIA VISIÓN\",\"BasPlanId\":\"350\",\"PlanClasification\":{\"Platform\":10," +
                "\"ProductType\":1},\"ComercialInfo\":{\"ComercialPlanId\":17,\"ComercialName\":\"SKANDIA VISIÓN\"},\"Id\":\"430\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { 5, "{\"Plans\":[{\"Name\":\"VIVIENDA\",\"ShortName\":\"VIVIENDA\",\"BasPlanId\":\"15\",\"PlanClasification\":{\"Platform\":10,\"ProductType\":1}," +
                "\"ComercialInfo\":{\"ComercialPlanId\":7,\"ComercialName\":\"APORTACIONES REGULARES - VIVIENDA\"},\"Id\":\"10\"},{\"Name\":\"GLOBALTRUST PLAN PERSONAL DE RETIRO\"," +
                "\"ShortName\":\"GLOBALTRUST RE\",\"BasPlanId\":\"15\",\"PlanClasification\":{\"Platform\":5,\"ProductType\":2},\"ComercialInfo\":{\"ComercialPlanId\":100," +
                "\"ComercialName\":\"GLOBALTRUST\"},\"Id\":\"40\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { 520, "{\"Plans\":[{\"Name\":\"MAESTRA SKANDIA NO DEDUCIBLE CREA\",\"ShortName\":\"SK CREA ND-MTRA\",\"BasPlanId\":\"520\",\"PlanClasification\":{\"Platform\":10,\"ProductType\":1},\"ComercialInfo\":{\"ComercialPlanId\":15,\"ComercialName\":\"SKANDIA CREA\"},\"Id\":\"540\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { 480, "{\"Plans\":[{\"Name\":\"MULTITRUST NO DEDUCIBLE\",\"ShortName\":\"MULTITRUST NO DEDUCIBLE\",\"BasPlanId\":\"480\",\"PlanClasification\":{\"Platform\":10,\"ProductType\":2},\"ComercialInfo\":{\"ComercialPlanId\":11,\"ComercialName\":\"MULTITRUST\"},\"Id\":\"531\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(basPlanIds[0], out retValue);

            return retValue;
        }

        private string GetPlansByIdDataFail()
        {
            return "{\"Plans\":[],\"Result\":{\"Successful\":false,\"SystemMessages\":[\"Error al obtener la información del plan - GetPlansById - at...\"]}}";
        }
        #endregion GetPlansById Method

        #region GetTypeContract Method
        [TestMethod, TestCategory("SuccefulProcess")]
        [DataRow("100960")]
        [DataRow("562969")]
        [DataRow("599500")]
        [DataRow("665235")]
        public void GetTypeContractOK(string contractId)
        {
            PrxyTypeOfContractRequest request = new PrxyTypeOfContractRequest();
            PrxyTypeOfContractResponse response = new PrxyTypeOfContractResponse();
            OperationResult resTypeContract = new OperationResult();


            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetTypeOfContract"; //Controller/Action

            var retValue = GetTypeContractData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyTypeOfContractRequest>(c => c.ContractId.Contains(contractId)), out resTypeContract))
                .Callback(() => { resTypeContract.Successful = true; resTypeContract.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin error GetTypeContract" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            var typeContract = _retailExtServiceProxy.GetTypeContract(contractId, out result);

            Assert.IsTrue(resTypeContract.Successful);
            Assert.IsTrue(result.Successful);
            Assert.IsTrue((new List<int> { 1, 2 }).Contains(typeContract));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DataRow("000000")]
        public void GetTypeContractNoServiceFail(string contractId)
        {
            PrxyTypeOfContractRequest request = new PrxyTypeOfContractRequest();
            PrxyTypeOfContractResponse response = new PrxyTypeOfContractResponse();
            OperationResult resTypeContract = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContractss/GetTypeOfContract"; //Controller/Action

            var retValue = GetTypeContractData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyTypeOfContractRequest>(c => c.ContractId.Contains(contractId)), out resTypeContract))
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetTypeContract(contractId, out OperationResult result));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DataRow("000000")]
        public void GetTypeContractContractIdFail(string contractId)
        {
            PrxyTypeOfContractRequest request = new PrxyTypeOfContractRequest();
            PrxyTypeOfContractResponse response = new PrxyTypeOfContractResponse();
            OperationResult resTypeContract = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetTypeOfContract"; //Controller/Action

            var retValue = GetTypeContractData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyTypeOfContractRequest>(c => c.ContractId.Contains(contractId)), out resTypeContract))
                .Callback(() => { resTypeContract.Successful = false; resTypeContract.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener el tipo de contracto" } }; })
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetTypeContract(contractId, out OperationResult result));
        }

        private string GetTypeContractData(string contractId)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "100960", "{\"TypeOfContract\": 2, \"Result\": {\"Successful\": true, \"SystemMessages\": []}}"},
                { "599500", "{\"TypeOfContract\": 1, \"Result\": {\"Successful\": true, \"SystemMessages\": []}}"},
                { "562969", "{\"TypeOfContract\": 1, \"Result\": {\"Successful\": true, \"SystemMessages\": []}}"},
                { "665235", "{\"TypeOfContract\": 2, \"Result\": {\"Successful\": true, \"SystemMessages\": []}}"},
                { "000000", "{\"TypeOfContract\": 0, \"Result\": {\"Successful\": false, \"SystemMessages\": [\"Error al obtener el tipo de contrato - at...\"]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        #endregion GetTypeContract Method

        #region GetLifeInsuranceAmount Method
        [TestMethod, TestCategory("SuccefulProcess")]
        [DataRow("100960")]
        [DataRow("562969")]
        [DataRow("599500")]
        [DataRow("665235")]
        public void GetLifeInsuranceAmountOK(string contractId)
        {
            PrxyLifeInsuranceAmountRequest request = new PrxyLifeInsuranceAmountRequest();
            PrxyLifeInsuranceAmountResponse response = new PrxyLifeInsuranceAmountResponse();
            OperationResult reslifeInsuranceAmount = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetLifeInsuranceAmount"; //Controller/Action

            var retValue = GetLifeInsuranceAmountData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyLifeInsuranceAmountRequest>(c => c.ContractId.Contains(contractId)), out reslifeInsuranceAmount))
                .Callback(() => { reslifeInsuranceAmount.Successful = true; reslifeInsuranceAmount.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin error GetLifeInsuranceAmount" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            var lifeInsuranceAmount = _retailExtServiceProxy.GetLifeInsuranceAmount(contractId, out result);

            Assert.IsTrue(reslifeInsuranceAmount.Successful);
            Assert.IsTrue(result.Successful);
            Assert.IsTrue(lifeInsuranceAmount >= 0M);
        }

        [TestMethod, TestCategory("FailProcess")]
        [DataRow("000000")]
        public void GetLifeInsuranceAmountContractIdFail(string contractId)
        {
            PrxyLifeInsuranceAmountRequest request = new PrxyLifeInsuranceAmountRequest();
            PrxyLifeInsuranceAmountResponse response = new PrxyLifeInsuranceAmountResponse();
            OperationResult reslifeInsuranceAmount = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetLifeInsuranceAmount"; //Controller/Action

            var retValue = GetLifeInsuranceAmountData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyLifeInsuranceAmountRequest>(c => c.ContractId.Contains(contractId)), out reslifeInsuranceAmount))
                .Callback(() => { reslifeInsuranceAmount.Successful = false; reslifeInsuranceAmount.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener la información de la suma asegurada" } }; })
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetLifeInsuranceAmount(contractId, out OperationResult result));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DataRow("000000")]
        public void GetLifeInsuranceAmountNoServiceFail(string contractId)
        {
            PrxyLifeInsuranceAmountRequest request = new PrxyLifeInsuranceAmountRequest();
            PrxyLifeInsuranceAmountResponse response = new PrxyLifeInsuranceAmountResponse();
            OperationResult reslifeInsuranceAmount = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContractss/GetLifeInsuranceAmount"; //Controller/Action

            var retValue = GetLifeInsuranceAmountData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyLifeInsuranceAmountRequest>(c => c.ContractId.Contains(contractId)), out reslifeInsuranceAmount))
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetLifeInsuranceAmount(contractId, out OperationResult result));
        }

        private string GetLifeInsuranceAmountData(string contractId)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"LifeInsuranceAmount\":0.00,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"LifeInsuranceAmount\":615000.00,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"LifeInsuranceAmount\":653792.71,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"LifeInsuranceAmount\":16274.51,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"000000", "{\"LifeInsuranceAmount\":0.0,\"Result\":{\"Successful\":false,\"SystemMessages\":[\"Error al obtener la información de la suma asegurada at ...\"]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }
        #endregion  GetLifeInsuranceAmount Method

        #region GetContractExtBasicInfo Method
        [TestMethod, TestCategory("SuccefulProcess")]
        [DataRow("100960")]
        [DataRow("562969")]
        [DataRow("599500")]
        [DataRow("665235")]
        public void GetContractExtBasicInfoOK(string contractId)
        {
            PrxyContractExtBasicInfoRequest request = new PrxyContractExtBasicInfoRequest();
            PrxyContractExtBasicInfoResponse response = new PrxyContractExtBasicInfoResponse();
            OperationResult resContractExtBasicInfo = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractExtBasicInfo"; //Controller/Action

            var retValue = GetContractExtBasicInfoData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractExtBasicInfoRequest>(c => c.ContractId.Contains(contractId)), out resContractExtBasicInfo))
                .Callback(() => { resContractExtBasicInfo.Successful = true; resContractExtBasicInfo.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin error GetContractExtBasicInfo" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            var lifeInsuranceAmount = _retailExtServiceProxy.GetContractExtBasicInfo(contractId, out result);

            Assert.IsTrue(resContractExtBasicInfo.Successful);
            Assert.IsTrue(result.Successful);
            //Assert.IsTrue(lifeInsuranceAmount >= 0M);
        }

        [TestMethod, TestCategory("FailProcess")]
        [DataRow("000000")]
        public void GetContractExtBasicInfoContractIdFail(string contractId)
        {
            PrxyContractExtBasicInfoRequest request = new PrxyContractExtBasicInfoRequest();
            PrxyContractExtBasicInfoResponse response = new PrxyContractExtBasicInfoResponse();
            OperationResult resContractExtBasicInfo = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractExtBasicInfo"; //Controller/Action

            var retValue = GetContractExtBasicInfoData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractExtBasicInfoRequest>(c => c.ContractId.Contains(contractId)), out resContractExtBasicInfo))
                .Callback(() => { resContractExtBasicInfo.Successful = false; resContractExtBasicInfo.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener la información extendida del contrato - GetContractExtBasicInfo" } }; })
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetContractExtBasicInfo(contractId, out OperationResult result));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DataRow("000000")]
        public void GetContractExtBasicInfoNoServiceFail(string contractId)
        {
            PrxyContractExtBasicInfoRequest request = new PrxyContractExtBasicInfoRequest();
            PrxyContractExtBasicInfoResponse response = new PrxyContractExtBasicInfoResponse();
            OperationResult resContractExtBasicInfo = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContractss/GetContractExtBasicInfo"; //Controller/Action

            var retValue = GetContractExtBasicInfoData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractExtBasicInfoRequest>(c => c.ContractId.Contains(contractId)), out resContractExtBasicInfo))
                .Returns(retValue).Verifiable();

            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetContractExtBasicInfo(contractId, out OperationResult result));
        }

        private string GetContractExtBasicInfoData(string contractId)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "100960", "{\"ContractExtBasicInfo\":{\"SavingGoal\":0.0000,\"SavingTerm\":0,\"CommittedAmount\":0.0000,\"AfiliationDate\":\"2004-12-14T00:00:00\"," +
                "\"EfectiveEndDate\":\"2004-12-14T00:00:00\",\"IsVanityContract\":false,\"Id\":\"100960\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "562969", "{\"ContractExtBasicInfo\":{\"SavingGoal\":900000.0000,\"SavingTerm\":216,\"CommittedAmount\":3000.0000,\"AfiliationDate\":\"2012-09-13T00:00:00\"," +
                "\"EfectiveEndDate\":\"2047-08-31T00:00:00\",\"IsVanityContract\":true,\"Id\":\"562969\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "599500", "{\"ContractExtBasicInfo\":{\"SavingGoal\":1798865.3500,\"SavingTerm\":216,\"CommittedAmount\":3526.3900,\"AfiliationDate\":\"2015-05-26T00:00:00\"," +
                "\"EfectiveEndDate\":\"2047-08-31T00:00:00\",\"IsVanityContract\":false,\"Id\":\"599500\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "665235", "{\"ContractExtBasicInfo\":{\"SavingGoal\":0.0000,\"SavingTerm\":0,\"CommittedAmount\":0.0000,\"AfiliationDate\":\"2017-05-18T00:00:00\"," +
                "\"EfectiveEndDate\":\"2047-08-31T00:00:00\",\"IsVanityContract\":true,\"Id\":\"665235\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "000000", "{\"ContractExtBasicInfo\":null," +
                "\"Result\":{\"Successful\":false,\"SystemMessages\":[\"Error al obtener la información extendida del contrato - GetContractExtBasicInfo - at...\"]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }
        #endregion  GetContractExtBasicInfo Method
        
        #region GetFpContracts Method
        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("FpContractsDynDat", DynamicDataSourceType.Method)]
        public void GetFpContractsOK(string fpEmail, List<string> clientContractsId)
        {
            PrxyFpContractsRequest request = new PrxyFpContractsRequest();
            PrxyFpContractsResponse response = new PrxyFpContractsResponse();
            OperationResult resGetFpContracts = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetFpContracts"; //Controller/Action

            var retValue = GetFpContractsData(fpEmail);

            request.FpEmail = fpEmail;
            request.ClientContractsId = clientContractsId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyFpContractsRequest>(c => c.ClientContractsId.Equals(clientContractsId) && c.FpEmail.Contains(fpEmail)), out resGetFpContracts))
                .Callback(() => { resGetFpContracts.Successful = true; resGetFpContracts.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin error GetFpContracts" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            var FpContracts = _retailExtServiceProxy.GetFpContracts(fpEmail, clientContractsId, out result);

            Assert.IsTrue(resGetFpContracts.Successful);
            Assert.IsTrue(result.Successful);
            Assert.IsTrue(FpContracts.Count > 0);
            Assert.IsInstanceOfType(FpContracts, typeof(List<string>));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DynamicData("FpContractsFailDynDat", DynamicDataSourceType.Method)]
        public void GetFpContractsContractIdFail(string fpEmail, List<string> clientContractsId)
        {
            PrxyFpContractsRequest request = new PrxyFpContractsRequest();
            PrxyFpContractsResponse response = new PrxyFpContractsResponse();
            OperationResult resGetFpContracts = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetFpContracts"; //Controller/Action

            var retValue = GetContractExtBasicInfoData(fpEmail);

            request.FpEmail = fpEmail;
            request.ClientContractsId = clientContractsId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyFpContractsRequest>(c => c.ClientContractsId.Equals(clientContractsId) && c.FpEmail.Contains(fpEmail)), out resGetFpContracts))
                .Callback(() => { resGetFpContracts.Successful = false; resGetFpContracts.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener los contratos por cliente y FpMail - GetFpContracts" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetFpContracts(fpEmail, clientContractsId, out result));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DynamicData("FpContractsDynDat", DynamicDataSourceType.Method)]
        public void GetFpContractsNoServiceFail(string fpEmail, List<string> clientContractsId)
        {
            PrxyFpContractsRequest request = new PrxyFpContractsRequest();
            PrxyFpContractsResponse response = new PrxyFpContractsResponse();
            OperationResult resGetFpContracts = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContractss/GetFpContracts"; //Controller/Action

            var retValue = "{\"ClientContractsId\":[],\"Result\":{\"Successful\":false,\"SystemMessages\":[\"Error al obtener los contratos por cliente y FpMail - GetFpContracts\"]}}";

            request.FpEmail = fpEmail;
            request.ClientContractsId = clientContractsId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyFpContractsRequest>(c => c.ClientContractsId.Equals(clientContractsId) && c.FpEmail.Contains(fpEmail)), out resGetFpContracts))
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetFpContracts(fpEmail, clientContractsId, out result));
        }

        private static IEnumerable<object> FpContractsDynDat()
        {
            return new List<object[]>(){
                new object[]{ "103763@skandia.com.mx", new List<string> { "599500", "100960", "562969", "665235" } },
                new object[]{ "103764@skandia.com.mx", new List<string> { "599500", "100960", "562969", "665235" } },
            };
        }

        private static IEnumerable<object> FpContractsFailDynDat()
        {
            return new List<object[]>(){
                new object[]{ "103768@skandia.com.mx", new List<string> { "599500", "100960", "562969", "665235" } },
            };
        }

        private string GetFpContractsData(string fpEmail)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "103763@skandia.com.mx", "{\"ClientContractsId\":[\"562969\",\"665235\"],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
                { "103764@skandia.com.mx", "{\"ClientContractsId\":[\"599500\",\"100960\"],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" }
            };
            retData.TryGetValue(fpEmail, out retValue);

            return retValue;
        }
        #endregion  GetFpContracts Method

        #region GetContractPendingContributions Method
        [TestMethod, TestCategory("FailProcess")]
        [DynamicData("ContractPendingContributionsDynDat", DynamicDataSourceType.Method)]
        public void GetContractPendingContributionsOK(List<AssociatedContract> associatedContracts, DateTime initialDate, DateTime finalDate)
        {
            PrxyMovementDetailResponse response = new PrxyMovementDetailResponse();
            PrxyMovementDetailRequest request = new PrxyMovementDetailRequest();
            OperationResult resGetContractPendingContributions = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractPendingContributions";

            var retValue = GetContractPendingContributionsData(associatedContracts);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );

            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyMovementDetailRequest>(c => c.AssociatedContracts[0].AssociatedContractId.Contains(associatedContracts[0].AssociatedContractId)), out resGetContractPendingContributions))
                .Callback(() => { resGetContractPendingContributions.Successful = true; resGetContractPendingContributions.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin error GetFpContracts" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            var contractPendingContributions = _retailExtServiceProxy.GetContractPendingContributions(associatedContracts, initialDate, finalDate, out result);

            Assert.IsTrue(resGetContractPendingContributions.Successful);
            Assert.IsTrue(result.Successful);
            Assert.IsTrue(contractPendingContributions.Count > 0);
            Assert.IsInstanceOfType(contractPendingContributions, typeof(List<ContractMovementDetail>));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DynamicData("ContractPendingContributionsFailDynDat", DynamicDataSourceType.Method)]
        public void GetContractPendingContributionsFail(List<AssociatedContract> associatedContracts, DateTime initialDate, DateTime finalDate)
        {
            PrxyMovementDetailResponse response = new PrxyMovementDetailResponse();
            PrxyMovementDetailRequest request = new PrxyMovementDetailRequest();
            OperationResult resGetContractPendingContributions = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractPendingContributions";

            var retValue = GetContractPendingContributionsData(associatedContracts);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );

            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyMovementDetailRequest>(c => c.AssociatedContracts[0].AssociatedContractId.Contains(associatedContracts[0].AssociatedContractId)), out resGetContractPendingContributions))
                .Callback(() => { resGetContractPendingContributions.Successful = false; resGetContractPendingContributions.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener los movimientos pendientes - GetContractPendingContributions" } }; })
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetContractPendingContributions(associatedContracts, initialDate, finalDate, out result));
        }

        [TestMethod, TestCategory("FailProcess")]
        [DynamicData("ContractPendingContributionsDynDat", DynamicDataSourceType.Method)]
        public void GetContractPendingContributionsNoServiceFail(List<AssociatedContract> associatedContracts, DateTime initialDate, DateTime finalDate)
        {
            PrxyMovementDetailResponse response = new PrxyMovementDetailResponse();
            PrxyMovementDetailRequest request = new PrxyMovementDetailRequest();
            OperationResult resGetContractPendingContributions = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContractss/GetContractPendingContributions";

            var retValue = GetContractPendingContributionsData(associatedContracts);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );

            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyMovementDetailRequest>(c => c.AssociatedContracts[0].AssociatedContractId.Contains(associatedContracts[0].AssociatedContractId)), out resGetContractPendingContributions))
                .Returns(retValue).Verifiable();

            OperationResult result = new OperationResult();
            Assert.ThrowsException<ApplicationException>(() => _retailExtServiceProxy.GetContractPendingContributions(associatedContracts, initialDate, finalDate, out result));
        }

        private static IEnumerable<object> ContractPendingContributionsDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1), AssociatedContract.Create("599501", "599500", 2), AssociatedContract.Create("599502", "599500", 3)
                     }, new DateTime(2000,01,01), new DateTime(2020,12,31) },
            };
        }

        private static IEnumerable<object> ContractPendingContributionsFailDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599600", "599600", 1), AssociatedContract.Create("599601", "599600", 2), AssociatedContract.Create("599602", "599600", 3)
                     }, new DateTime(2000,01,01), new DateTime(2020,12,31) },
            };
        }

        private string GetContractPendingContributionsData(List<AssociatedContract> associatedContracts)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){

                { "599500", "{\"ContractMovementsPendingDetail\":[{\"MovementContractId\":\"599500\",\"MovementProcessDate\":\"2017-04-21T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9000,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"Rechazado\"," +
                "\"Id\":\"599500\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
            };
            retData.TryGetValue(associatedContracts[0].AssociatedContractId, out retValue);

            return retValue;
        }
        #endregion GetContractPendingContributions Method

    }
}
