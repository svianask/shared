﻿using System;
using System.Collections.Generic;
using System.Configuration;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.PortfolioProfileAggregate;
using ClientContractsProxy;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Proxy;

namespace ClientContractsProxyTest
{
    [TestClass]
    public class RetailServiceProxyTest
    {
        private readonly Mock<IProxyEngine> _proxyEngine;
        private readonly RetailServiceProxy _retailServiceProxy;

        private List<string> contractsOK;
        private List<string> initBalanceContractsOK;
        private List<string> clientIdentifiersOK;

        public RetailServiceProxyTest()
        {

            ConfigurationManager.AppSettings["RetailService:URLService"] = "http://localhost/RetailServiceApi/api/";

            _proxyEngine = new Mock<IProxyEngine>();

            _retailServiceProxy = new RetailServiceProxy(_proxyEngine.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            contractsOK = new List<string> { "100960", "562969", "599500", "665235" };
            clientIdentifiersOK = new List<string> { "ABCD010203XYZ" };
            initBalanceContractsOK = new List<string>() { "100960", "665235" };
        }



        [TestMethod, TestCategory("SuccefulProcess")]
        public void GetContractsOK()
        {
            PrxyContractsRequest request = new PrxyContractsRequest();
            PrxyContractsResponse response = new PrxyContractsResponse();
            OperationResult resGetContracts = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContracts";

            foreach (string client in clientIdentifiersOK)
            {
                var retValue = GetContractsData(client);

                request.ClientIdentifier = client;

                _proxyEngine
                    .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractsRequest>(c => c.ClientIdentifier == client), out resGetContracts))
                    .Callback(() => { resGetContracts.Successful = true; resGetContracts.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                    .Returns(retValue).Verifiable();

                var clientContracts = _retailServiceProxy.GetContracts(client, out OperationResult result);

                Assert.IsTrue(result.Successful);
                Assert.IsTrue(clientContracts.Contracts.Count == 4);
                Assert.IsTrue(clientContracts.Id == client);
            }
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        public void GetSummaryContributionsNumberOK()
        {
            PrxySummaryContributionsNumberRequest request = new PrxySummaryContributionsNumberRequest();
            PrxySummaryContributionsNumberResponse response = new PrxySummaryContributionsNumberResponse();
            OperationResult resGetSummaryContributionsNumber = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetSummaryContributionsNumber";


            foreach (string contract in contractsOK)
            {
                var retValue = GetSummaryContributionsNumberData(contract);

                request.ContractId = contract;

                _proxyEngine
                    .Setup(s => s.SendMSRequestJson(url, It.Is<PrxySummaryContributionsNumberRequest>(x => x.ContractId.Equals(contract)), out resGetSummaryContributionsNumber))
                    .Callback(() => { resGetSummaryContributionsNumber.Successful = true; resGetSummaryContributionsNumber.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                    .Returns(retValue).Verifiable();

                var summaryContributions = _retailServiceProxy.GetSummaryContributionsNumber(contract, out OperationResult result);

                Assert.IsTrue(result.Successful);
                Assert.IsInstanceOfType(summaryContributions, typeof(SummaryContributions));
            }
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        public void GetOnDemandCashOK()
        {
            PrxyOnDemandCashRequest request = new PrxyOnDemandCashRequest();
            PrxyOnDemandCashResponse response = new PrxyOnDemandCashResponse();
            OperationResult resGetOnDemandCash = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetOnDemandCash";

            foreach (string contract in contractsOK)
            {
                var retValue = GetOnDemandCashData(contract);

                request.ContractId = contract;

                _proxyEngine
                    .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyOnDemandCashRequest>(x => x.ContractId.Equals(contract)), out resGetOnDemandCash))
                    .Callback(() => { resGetOnDemandCash.Successful = true; resGetOnDemandCash.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                    .Returns(retValue).Verifiable();

                var onDemandCash = _retailServiceProxy.GetOnDemandCash(contract, out OperationResult result);

                Assert.IsTrue(result.Successful);
                Assert.IsInstanceOfType(onDemandCash, typeof(decimal));
            }
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        public void GetAssociateContractsOK()
        {
            PrxyAssociateContractsRequest request = new PrxyAssociateContractsRequest();
            PrxyAssociateContractsResponse response = new PrxyAssociateContractsResponse();
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            OperationResult resAssociatedContracts = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetAssociateContracts";

            foreach (string client in clientIdentifiersOK)
            {
                var retValue = GetAssociateContractsData(client);

                request.ClientIdentifier = client;

                _proxyEngine
                    .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyAssociateContractsRequest>(c => c.ClientIdentifier == client), out resAssociatedContracts))
                    .Callback(() => { resAssociatedContracts.Successful = true; resAssociatedContracts.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                    .Returns(retValue).Verifiable();

                var clientContracts = _retailServiceProxy.GetAssociateContracts(client, out OperationResult result);

                Assert.IsTrue(result.Successful);
            }
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        public void GetContractInitBalanceOK()
        {
            PrxyContractBalanceRequest request = new PrxyContractBalanceRequest();
            PrxyContractBalanceResponse response = new PrxyContractBalanceResponse();
            OperationResult resContractInitBalance = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInitBalance";

            var req = new List<PrxyContractBalanceRequest> { new PrxyContractBalanceRequest { ContractId = "100960", Platform = 10, AfiliationDate = new DateTime(2010,11,01), AdditionalContributionsContract = "", ContractControlContributions = "" },
                      new PrxyContractBalanceRequest { ContractId = "665235", Platform = 10, AfiliationDate = new DateTime(), AdditionalContributionsContract = "", ContractControlContributions = "" } };


            foreach (PrxyContractBalanceRequest contract in req)
            {

                var contractid = contract.ContractId;
                var platform = contract.Platform;
                var afiliationDate = contract.AfiliationDate;
                var additionalContributionsContract = contract.AdditionalContributionsContract;
                var contractControlContributions = contract.ContractControlContributions;

                var retValue = GetContractInitBalanceData(contractid);

                _proxyEngine
                    .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractBalanceRequest>(c => (c.ContractId == contractid) && (c.Platform == platform) && (c.AfiliationDate == afiliationDate)), out resContractInitBalance))
                    .Callback(() => { resContractInitBalance.Successful = true; resContractInitBalance.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                    .Returns(retValue).Verifiable();

                var clientContracts = _retailServiceProxy.GetContractInitBalance(contractid, platform, afiliationDate, additionalContributionsContract, contractControlContributions, out OperationResult result);

                Assert.IsTrue(result.Successful);
            }
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("ContractChargesDynDat", DynamicDataSourceType.Method)]
        public void GetContractChargesOK(List<AssociatedContract> associatedContracts, int platform)
        {
            PrxyContractChargesRequest request = new PrxyContractChargesRequest();
            PrxyContractChargesResponse response = new PrxyContractChargesResponse();
            OperationResult resContractCharges = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractCharges";
            string contractId = associatedContracts[0].ContractId;

            string retValue = GetContractChargesData(contractId);

            associatedContracts.ForEach(a =>
               request.AssociatedContracts.Add(
                   new PrxyAssociatedContractMess
                   {
                       ContractId = a.ContractId,
                       AssociatedContractId = a.AssociatedContractId,
                       AssociatedType = a.AssociatedType
                   }
               )
            );
            request.Platform = platform;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractChargesRequest>(c => (c.AssociatedContracts[0].ContractId == contractId) && (c.Platform == platform)), out resContractCharges))
                .Callback(() => { resContractCharges.Successful = true; resContractCharges.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns(retValue).Verifiable();

            var charges = _retailServiceProxy.GetContractCharges(associatedContracts, platform, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsInstanceOfType(charges, typeof(decimal));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("BalanceDetailDynDat", DynamicDataSourceType.Method)]
        public void GetBalanceDetailOK(List<string> contracts, int platform)
        {
            PrxyContractBalanceDetailRequest request = new PrxyContractBalanceDetailRequest();
            PrxyContractBalanceDetailResponse response = new PrxyContractBalanceDetailResponse();
            OperationResult resBalanceDetail = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBalanceDetail";

            string contractId = contracts[0];

            string retValue = GetBalanceDetailData(contractId);

            request.Contracts = contracts;
            request.Platform = platform;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractBalanceDetailRequest>(c => (c.Contracts[0] == contractId) && (c.Platform == platform)), out resBalanceDetail))
                .Callback(() => { resBalanceDetail.Successful = true; resBalanceDetail.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns(retValue).Verifiable();

            var Detail = _retailServiceProxy.GetBalanceDetail(platform, contracts, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(Detail);
            Assert.IsTrue(contracts.Contains(Detail[0].ContractId));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("ContractContributionsDynDat", DynamicDataSourceType.Method)]
        public void GetContractContributionsOK(List<AssociatedContract> associatedContracts, int platform)
        {
            PrxyContractContributionsResponse response = new PrxyContractContributionsResponse();
            PrxyContractContributionsRequest request = new PrxyContractContributionsRequest();
            OperationResult resContractContributions = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractContributions";
            string contractId = associatedContracts[0].ContractId;

            string retValue = GetContractContributionsData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractContributionsRequest>(c => (c.AssociatedContracts[0].ContractId == contractId) && (c.Platform == platform)), out resContractContributions))
                .Callback(() => { resContractContributions.Successful = true; resContractContributions.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns(retValue).Verifiable();

            var Contributions = _retailServiceProxy.GetContractContributions(associatedContracts, platform, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(Contributions);
            Assert.IsInstanceOfType(Contributions, typeof(RealizedContributions));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("ContractWithdrawalsDynDat", DynamicDataSourceType.Method)]
        public void GetContractWithdrawalsOK(List<AssociatedContract> associatedContracts, int platform)
        {
            PrxyContractWithdrawalsResponse response = new PrxyContractWithdrawalsResponse();
            PrxyContractWithdrawalsRequest request = new PrxyContractWithdrawalsRequest();
            OperationResult resContractWithdrawals = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractWithdrawals";

            string contractId = associatedContracts[0].ContractId;
            string retValue = GetContractWithdrawalsData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractWithdrawalsRequest>(c => (c.AssociatedContracts[0].ContractId == contractId) && (c.Platform == platform)), out resContractWithdrawals))
                .Callback(() => { resContractWithdrawals.Successful = true; resContractWithdrawals.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns(retValue).Verifiable();

            var contractWithdrawals = _retailServiceProxy.GetContractWithdrawals(associatedContracts, platform, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contractWithdrawals);
            Assert.IsInstanceOfType(contractWithdrawals, typeof(ContractWithdrawals));

        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("ContributionsOnDemandDynDat", DynamicDataSourceType.Method)]
        public void GetContributionsOnDemandOK(List<AssociatedContract> associatedContracts, int platform)
        {
            PrxyOnDemandContributionsResponse response = new PrxyOnDemandContributionsResponse();
            PrxyOnDemandContributionsRequest request = new PrxyOnDemandContributionsRequest();
            OperationResult resContributionsOnDemand = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContributionsOnDemand";

            string contractId = associatedContracts[0].ContractId;
            string retValue = GetContributionsOnDemandData(contractId);

            associatedContracts.ForEach(
               ac => request.AssociatedContracts.Add(
                   new PrxyAssociatedContractMess
                   {
                       ContractId = ac.ContractId,
                       AssociatedContractId = ac.AssociatedContractId,
                       AssociatedType = ac.AssociatedType
                   }
               )
            );
            request.Platform = platform;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyOnDemandContributionsRequest>(c => (c.AssociatedContracts[0].ContractId == contractId) && (c.Platform == platform)), out resContributionsOnDemand))
                .Callback(() => { resContributionsOnDemand.Successful = true; resContributionsOnDemand.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns(retValue).Verifiable();

            var contributionsOnDemand = _retailServiceProxy.GetContributionsOnDemand(associatedContracts, platform, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contributionsOnDemand);
            Assert.IsInstanceOfType(contributionsOnDemand, typeof(ContributionsOnDemand));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DataRow("100960")]
        [DataRow("562969")]
        [DataRow("599500")]
        [DataRow("665235")]
        public void GetClientIdByContractOK(string contractId)
        {
            PrxyClientIdByContractRequest request = new PrxyClientIdByContractRequest();
            PrxyClientIdByContractResponse response = new PrxyClientIdByContractResponse();
            OperationResult resClientIdByContract = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetClientIdByContract";

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyClientIdByContractRequest>(c => c.ContractId == contractId), out resClientIdByContract))
                .Callback(() => { resClientIdByContract.Successful = true; resClientIdByContract.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns("{\"Result\":{\"Successful\":true,\"SystemMessages\":[]},\"ClientIdentifier\":\"MEAJ720808J25\"}").Verifiable();

            var clientIdentifier = _retailServiceProxy.GetClientIdByContract(contractId, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsFalse(string.IsNullOrEmpty(clientIdentifier));
            Assert.IsInstanceOfType(clientIdentifier, typeof(string));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DataRow("100960")]
        [DataRow("562969")]
        [DataRow("599500")]
        [DataRow("665235")]
        public void GetContractInfoOK(string contractId)
        {
            PrxyContractInfoRequest request = new PrxyContractInfoRequest();
            PrxyContractInfoResponse response = new PrxyContractInfoResponse();
            OperationResult resContractInfo = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";

            string retValue = GetContractInfoData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractInfoRequest>(c => c.ContractId == contractId), out resContractInfo))
                .Callback(() => { resContractInfo.Successful = true; resContractInfo.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContracts" } }; })
                .Returns(retValue).Verifiable();

            var contractInfo = _retailServiceProxy.GetContractInfo(contractId, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contractInfo);
            Assert.IsInstanceOfType(contractInfo, typeof(ContractInfo));
            Assert.IsTrue(contractInfo.Id == contractId);
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("ContractContributionsByDateDynDat", DynamicDataSourceType.Method)]
        public void GetContractContributionsByDateOK(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate)
        {
            PrxyContractContributionsResponse response = new PrxyContractContributionsResponse();
            PrxyContractContributionsByDateRequest request = new PrxyContractContributionsByDateRequest();
            OperationResult resContractContributionsByDate = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractContributionsByDate";

            string contractId = associatedContracts[0].ContractId;
            string retValue = GetContractContributionsByDateData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractContributionsByDateRequest>(c => c.AssociatedContracts[0].ContractId == contractId), out resContractContributionsByDate))
                .Callback(() => { resContractContributionsByDate.Successful = true; resContractContributionsByDate.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractContributionsByDate" } }; })
                .Returns(retValue).Verifiable();

            var realizedContributions = _retailServiceProxy.GetContractContributionsByDate(associatedContracts, platform, initialDate, finalDate, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(realizedContributions);
            Assert.IsInstanceOfType(realizedContributions, typeof(RealizedContributions));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("GetContributionsOnDemandByDateDynDat", DynamicDataSourceType.Method)]
        public void GetContributionsOnDemandByDateOK(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate)
        {
            PrxyOnDemandContributionsResponse response = new PrxyOnDemandContributionsResponse();
            PrxyOnDemandContributionsByDateRequest request = new PrxyOnDemandContributionsByDateRequest();
            OperationResult resContributionsOnDemandByDate = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContributionsOnDemandByDate";

            string contractId = associatedContracts[0].ContractId;
            string retValue = GetContributionsOnDemandByDateData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyOnDemandContributionsByDateRequest>(c => c.AssociatedContracts[0].ContractId == contractId), out resContributionsOnDemandByDate))
                .Callback(() => { resContributionsOnDemandByDate.Successful = true; resContributionsOnDemandByDate.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContributionsOnDemandByDate" } }; })
                .Returns(retValue).Verifiable();

            var contributionsOnDemand = _retailServiceProxy.GetContributionsOnDemandByDate(associatedContracts, platform, initialDate, finalDate, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contributionsOnDemand);
            Assert.IsInstanceOfType(contributionsOnDemand, typeof(ContributionsOnDemand));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("GetContractWithdrawalsByDateDynDat", DynamicDataSourceType.Method)]
        public void GetContractWithdrawalsByDateOK(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate)
        {
            PrxyContractWithdrawalsResponse response = new PrxyContractWithdrawalsResponse();
            PrxyContractWithdrawalsByDateRequest request = new PrxyContractWithdrawalsByDateRequest();
            OperationResult resContractWithdrawalsByDate = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractWithdrawalsByDate";

            string contractId = associatedContracts[0].ContractId;
            string retValue = ContractWithdrawalsByDateData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractWithdrawalsByDateRequest>(c => c.AssociatedContracts[0].ContractId == contractId), out resContractWithdrawalsByDate))
                .Callback(() => { resContractWithdrawalsByDate.Successful = true; resContractWithdrawalsByDate.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractWithdrawalsByDate" } }; })
                .Returns(retValue).Verifiable();

            var contractWithdrawals = _retailServiceProxy.GetContractWithdrawalsByDate(associatedContracts, platform, initialDate, finalDate, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contractWithdrawals);
            Assert.IsInstanceOfType(contractWithdrawals, typeof(ContractWithdrawals));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("GetContractChargesByDateDynDat", DynamicDataSourceType.Method)]
        public void GetContractChargesByDateOK(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate)
        {
            PrxyContractChargesByDateRequest request = new PrxyContractChargesByDateRequest();
            PrxyContractChargesResponse response = new PrxyContractChargesResponse();
            OperationResult resContractChargesByDate = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractChargesByDate";

            string contractId = associatedContracts[0].ContractId;
            string retValue = ContractChargesByDateData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractChargesByDateRequest>(c => c.AssociatedContracts[0].ContractId == contractId), out resContractChargesByDate))
                .Callback(() => { resContractChargesByDate.Successful = true; resContractChargesByDate.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractChargesByDate" } }; })
                .Returns(retValue).Verifiable();

            var ContractCharges = _retailServiceProxy.GetContractChargesByDate(associatedContracts, platform, initialDate, finalDate, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(ContractCharges);
            Assert.IsInstanceOfType(ContractCharges, typeof(decimal));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("GetContractDetailCashMovementsByDateDynDat", DynamicDataSourceType.Method)]
        public void GetContractDetailCashMovementsByDateOK(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate)
        {
            PrxyMovementCashDetailsResponse response = new PrxyMovementCashDetailsResponse();
            PrxyMovementCashDetailsRequest request = new PrxyMovementCashDetailsRequest();
            OperationResult resContractDetailCashMovementsByDate = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractDetailCashMovementsByDate";

            string contractId = associatedContracts[0].ContractId;
            string retValue = ContractDetailCashMovementsByDateData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyMovementCashDetailsRequest>(c => c.AssociatedContracts[0].ContractId == contractId), out resContractDetailCashMovementsByDate))
                .Callback(() => { resContractDetailCashMovementsByDate.Successful = true; resContractDetailCashMovementsByDate.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractDetailCashMovementsByDate" } }; })
                .Returns(retValue).Verifiable();

            var contractMovementCashDetails = _retailServiceProxy.GetContractDetailCashMovementsByDate(associatedContracts, platform, initialDate, finalDate, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contractMovementCashDetails);
            Assert.IsInstanceOfType(contractMovementCashDetails, typeof(List<ContractMovementDetail>));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("GetContractDetailPendingMovementsByDateDynDat", DynamicDataSourceType.Method)]
        public void GetContractDetailPendingMovementsByDateOK(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate)
        {
            PrxyMovementPendingDetailsResponse response = new PrxyMovementPendingDetailsResponse();
            PrxyMovementPendingDetailsRequest request = new PrxyMovementPendingDetailsRequest();
            OperationResult resContractDetailPendingMovementsByDate = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractDetailPendingMovementsByDate";

            string contractId = associatedContracts[0].ContractId;
            string retValue = ContractDetailPendingMovementsByDateData(contractId);

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyMovementPendingDetailsRequest>(c => c.AssociatedContracts[0].ContractId == contractId), out resContractDetailPendingMovementsByDate))
                .Callback(() => { resContractDetailPendingMovementsByDate.Successful = true; resContractDetailPendingMovementsByDate.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractDetailPendingMovementsByDate" } }; })
                .Returns(retValue).Verifiable();

            var ContractDetailPendingMovements = _retailServiceProxy.GetContractDetailPendingMovementsByDate(associatedContracts, platform, initialDate, finalDate, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(ContractDetailPendingMovements);
            Assert.IsInstanceOfType(ContractDetailPendingMovements, typeof(List<ContractMovementDetail>));
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DynamicData("ContractBalanceDetailDynDat", DynamicDataSourceType.Method)]
        public void GetContractBalanceDetailOK(List<string> contracts, int platform)
        {
            PrxyContractBalanceDetailRequest request = new PrxyContractBalanceDetailRequest();
            PrxyContractBalanceDetailResponse response = new PrxyContractBalanceDetailResponse();
            OperationResult resContractBalanceDetail = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBalanceDetail";

            string contractId = contracts[0];
            string retValue = GetContractBalanceDetailData(contractId);

            request.Contracts = contracts;
            request.Platform = platform;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyContractBalanceDetailRequest>(c => (c.Contracts[0] == contractId) && (c.Platform == platform)), out resContractBalanceDetail))
                .Callback(() => { resContractBalanceDetail.Successful = true; resContractBalanceDetail.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetContractBalanceDetail" } }; })
                .Returns(retValue).Verifiable();

            var investments = _retailServiceProxy.GetContractBalanceDetail(platform, contracts, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(investments);
        }

        [TestMethod, TestCategory("SuccefulProcess")]
        [DataRow("100960", 5)]
        [DataRow("562969", 10)]
        [DataRow("599500", 10)]
        [DataRow("599501", 10)]
        [DataRow("599502", 10)]
        [DataRow("665235", 10)]
        public void GetPortfolioProfileOK(string contractId, int platform)
        {
            PrxyPortfolioProfileRequest request = new PrxyPortfolioProfileRequest();
            PrxyPortfolioProfileResponse response = new PrxyPortfolioProfileResponse();
            OperationResult resPortfolioProfile = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetPortfolioProfile";

            string retValue = GetPortfolioProfileData(contractId);

            request.ContractId = contractId;

            _proxyEngine
                .Setup(s => s.SendMSRequestJson(url, It.Is<PrxyPortfolioProfileRequest>(c => c.ContractId == contractId), out resPortfolioProfile))
                .Callback(() => { resPortfolioProfile.Successful = true; resPortfolioProfile.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetPortfolioProfile" } }; })
                .Returns(retValue).Verifiable();

            var portfolioProfile = _retailServiceProxy.GetPortfolioProfile(contractId, platform, out OperationResult result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(portfolioProfile);
            Assert.IsInstanceOfType(portfolioProfile, typeof(PortfolioProfile));
            Assert.IsTrue(portfolioProfile.ContractId == contractId);
        }


        private string GetContractsData(string clientIdentifier)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"ABCD010203XYZ", "{\"ContractsOfClient\":{\"Contracts\":[{\"PlanBasId\":\"15\",\"Platform\":5,\"GoalId\":9999,\"ContratoAgrupa\":\"100960\"," +
                "\"AfiliationDate\":\"2004-12-14T00:00:00\",\"GoalDescription\":\"(No Asignado)\",\"ContractDigit\":\"S53\",\"ApplyDeducible\":true," +
                "\"Id\":\"100960\"},{\"PlanBasId\":\"350\",\"Platform\":10,\"GoalId\":5,\"ContratoAgrupa\":\"562969\",\"AfiliationDate\":\"2012-09-13T12:58:00\"," +
                "\"GoalDescription\":\"Educación\",\"ContractDigit\":\"S53\",\"ApplyDeducible\":false,\"Id\":\"562969\"},{\"PlanBasId\":\"520\",\"Platform\":10," +
                "\"GoalId\":5,\"ContratoAgrupa\":\"599501\",\"AfiliationDate\":\"2015-05-26T11:41:00\",\"GoalDescription\":\"Educación\",\"ContractDigit\":\"S53\"," +
                "\"ApplyDeducible\":false,\"Id\":\"599500\"},{\"PlanBasId\":\"480\",\"Platform\":10,\"GoalId\":9999,\"ContratoAgrupa\":\"665235\"," +
                "\"AfiliationDate\":\"2017-05-18T17:03:00\",\"GoalDescription\":\"(No Asignado)\",\"ContractDigit\":\"S53\",\"ApplyDeducible\":false," +
                "\"Id\":\"665235\"}],\"Id\":\"ABCD010203XYZ\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
            };
            retData.TryGetValue(clientIdentifier, out retValue);

            return retValue;
        }

        private string GetSummaryContributionsNumberData(string contractId)
        {
            string retValue = string.Empty;
            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {   "100960",
                    "{\"SummaryContributions\":{\"TotalContributions\":0,\"ExpectedContributions\":0,\"RealizedContributions\":0,\"FailedContributions\":0," +
                    "\"PendingContributions\":0,\"AfiliationDate\":\"1900-01-01T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
                {   "599500",
                    "{\"SummaryContributions\":{\"TotalContributions\":216,\"ExpectedContributions\":73,\"RealizedContributions\":72,\"FailedContributions\":0," +
                    "\"PendingContributions\":144,\"AfiliationDate\":\"1900-01-01T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
                {   "562969",
                    "{\"SummaryContributions\":{\"TotalContributions\":0,\"ExpectedContributions\":0,\"RealizedContributions\":0,\"FailedContributions\":0," +
                    "\"PendingContributions\":0,\"AfiliationDate\":\"1900-01-01T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
                {   "665235",
                    "{\"SummaryContributions\":{\"TotalContributions\":0,\"ExpectedContributions\":0,\"RealizedContributions\":0,\"FailedContributions\":0," +
                    "\"PendingContributions\":0,\"AfiliationDate\":\"1900-01-01T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" }
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private string GetOnDemandCashData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "100960", "{\"OnDemandCash\": 0,\"Result\": {\"Successful\": true,\"SystemMessages\": []}}" },
                { "599500", "{\"OnDemandCash\": 0,\"Result\": {\"Successful\": true,\"SystemMessages\": []}}" },
                { "562969", "{\"OnDemandCash\": 0,\"Result\": {\"Successful\": true,\"SystemMessages\": []}}" },
                { "665235", "{\"OnDemandCash\": 0,\"Result\": {\"Successful\": true,\"SystemMessages\": []}}" }
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private string GetAssociateContractsData(string clientIdentifier)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "ABCD010203XYZ",
                    "{\"Result\":{\"Successful\":true,\"SystemMessages\":[]},\"LstAssociatedContracts\":[{\"ContractId\":\"100960\",\"AssociatedContractId\":\"100960\"," +
                    "\"AssociatedType\":1},{\"ContractId\":\"562969\",\"AssociatedContractId\":\"562969\",\"AssociatedType\":1},{\"ContractId\":\"599500\"," +
                    "\"AssociatedContractId\":\"599500\",\"AssociatedType\":1},{\"ContractId\":\"599501\",\"AssociatedContractId\":\"599500\",\"AssociatedType\":2}," +
                    "{\"ContractId\":\"599502\",\"AssociatedContractId\":\"599500\",\"AssociatedType\":3},{\"ContractId\":\"665235\",\"AssociatedContractId\":\"665235\"," +
                    "\"AssociatedType\":1}]}" }
            };
            retData.TryGetValue(clientIdentifier, out retValue);

            return retValue;
        }

        private string GetContractInitBalanceData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "100960","{\"ContractBalance\":0.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" },
                { "665235","{\"ContractBalance\":0.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}" }
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> ContractChargesDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10 }
            };
        }

        private string GetContractChargesData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                { "100960","{\"Charges\":0.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "562969","{\"Charges\":1.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "599500","{\"Charges\":2.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "665235","{\"Charges\":3.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> BalanceDetailDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<string> { "100960" }, 10 },
                new object[]{ new List<string> { "562969" }, 10 },
                new object[]{ new List<string> { "599500", "599501", "599502" }, 10 },
                new object[]{ new List<string> { "665235" }, 10 }
            };
        }

        private string GetBalanceDetailData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"100960\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":0.75,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.75,\"MarketPurchaseValue\":0.75," +
                "\"MarketSalesValue\":0.75,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"100960\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"100960\",\"Name\":\"SK-DCP\",\"Shares\":{\"AvailableShares\":95968.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.709598," +
                "\"PurchasePrice\":1.709598,\"SalesPrice\":1.709598,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":164066.70,\"MarketPurchaseValue\":164066.70," +
                "\"MarketSalesValue\":164066.70,\"DistributionPercent\":14.56},\"Id\":\"SK-DCP E\"},{\"ContractId\":\"100960\",\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":531817.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.341777,\"PurchasePrice\":1.341777,\"SalesPrice\":1.341777,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":713579.82,\"MarketPurchaseValue\":713579.82,\"MarketSalesValue\":713579.82,\"DistributionPercent\":63.32},\"Id\":\"SK-DESTE\"},{\"ContractId\":\"100960\"," +
                "\"Name\":\"SK-RVMX\",\"Shares\":{\"AvailableShares\":58606.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.627487,\"PurchasePrice\":1.627487," +
                "\"SalesPrice\":1.627487,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":95380.50,\"MarketPurchaseValue\":95380.50,\"MarketSalesValue\":95380.50," +
                "\"DistributionPercent\":8.46},\"Id\":\"SK-RVMXE\"},{\"ContractId\":\"100960\",\"Name\":\"SK-RVST\",\"Shares\":{\"AvailableShares\":59441.0,\"CommittedShares\":0.0," +
                "\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":2.588552,\"PurchasePrice\":2.588552,\"SalesPrice\":2.588552,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":153866.12,\"MarketPurchaseValue\":153866.12,\"MarketSalesValue\":153866.12,\"DistributionPercent\":13.65},\"Id\":\"SK-RVSTE\"}," +
                "{\"ContractId\":\"\",\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":0.0,\"PurchasePrice\":0.0," +
                "\"SalesPrice\":0.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.75,\"MarketPurchaseValue\":0.75,\"MarketSalesValue\":0.75,\"DistributionPercent\":0.0}," +
                "\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"562969\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":13.85,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":13.85,\"MarketPurchaseValue\":13.85," +
                "\"MarketSalesValue\":13.85,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"562969\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"562969\",\"Name\":\"PRINFGU\",\"Shares\":{\"AvailableShares\":13.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":18.090442,\"PurchasePrice\":18.090442,\"SalesPrice\":18.090442,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":235.18," +
                "\"MarketPurchaseValue\":235.18,\"MarketSalesValue\":235.18,\"DistributionPercent\":0.06},\"Id\":\"PRINFGUF2\"},{\"ContractId\":\"562969\",\"Name\":\"SK-DCP\"," +
                "\"Shares\":{\"AvailableShares\":11985.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.505423,\"PurchasePrice\":1.505423,\"SalesPrice\":1.505423," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":18042.49,\"MarketPurchaseValue\":18042.49,\"MarketSalesValue\":18042.49,\"DistributionPercent\":4.54}," +
                "\"Id\":\"SK-DCP B\"},{\"ContractId\":\"562969\",\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":110003.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.176302,\"PurchasePrice\":1.176302,\"SalesPrice\":1.176302,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":129396.75," +
                "\"MarketPurchaseValue\":129396.75,\"MarketSalesValue\":129396.75,\"DistributionPercent\":32.57},\"Id\":\"SK-DESTB\"},{\"ContractId\":\"562969\",\"Name\":\"SK-RVMX\"," +
                "\"Shares\":{\"AvailableShares\":57403.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.629738,\"PurchasePrice\":1.629738,\"SalesPrice\":1.629738," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":93551.85,\"MarketPurchaseValue\":93551.85,\"MarketSalesValue\":93551.85,\"DistributionPercent\":23.55}," +
                "\"Id\":\"SK-RVMXB\"},{\"ContractId\":\"562969\",\"Name\":\"SK-RVST\",\"Shares\":{\"AvailableShares\":60876.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":2.562754," +
                "\"PurchasePrice\":2.562754,\"SalesPrice\":2.562754,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":156010.21,\"MarketPurchaseValue\":156010.21," +
                "\"MarketSalesValue\":156010.21,\"DistributionPercent\":39.27},\"Id\":\"SK-RVSTB\"},{\"ContractId\":\"\",\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":0.0,\"PurchasePrice\":0.0,\"SalesPrice\":0.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":13.85,\"MarketPurchaseValue\":13.85,\"MarketSalesValue\":13.85,\"DistributionPercent\":0.0},\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true," +
                "\"SystemMessages\":[]}}"},
                {"599500", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"599500\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0," +
                "\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"},{\"ContractId\":\"599501\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":673.11," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":673.11,\"MarketPurchaseValue\":673.11,\"MarketSalesValue\":673.11,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"599501\"," +
                "\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0," +
                "\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0}," +
                "\"Id\":\"|Operaciones Pendientes\"},{\"ContractId\":\"599502\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":5.68,\"CommittedShares\":0.00,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":5.68,\"MarketPurchaseValue\":5.68," +
                "\"MarketSalesValue\":5.68,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"599502\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"599501\",\"Name\":\"OM-ESP1\",\"Shares\":{\"AvailableShares\":211981.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.167003,\"PurchasePrice\":1.167003,\"SalesPrice\":1.167003,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":247382.46," +
                "\"MarketPurchaseValue\":247382.46,\"MarketSalesValue\":247382.46,\"DistributionPercent\":100.0},\"Id\":\"OM-ESP1B\"},{\"ContractId\":\"599502\",\"Name\":\"SK-DCP\"," +
                "\"Shares\":{\"AvailableShares\":484.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.505423,\"PurchasePrice\":1.505423,\"SalesPrice\":1.505423," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":728.62,\"MarketPurchaseValue\":728.62,\"MarketSalesValue\":728.62,\"DistributionPercent\":20.23}," +
                "\"Id\":\"SK-DCP B\"},{\"ContractId\":\"599502\",\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":2260.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.176302,\"PurchasePrice\":1.176302,\"SalesPrice\":1.176302,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":2658.44," +
                "\"MarketPurchaseValue\":2658.44,\"MarketSalesValue\":2658.44,\"DistributionPercent\":73.82},\"Id\":\"SK-DESTB\"},{\"ContractId\":\"599502\",\"Name\":\"SK-RVMX\"," +
                "\"Shares\":{\"AvailableShares\":56.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.629738,\"PurchasePrice\":1.629738,\"SalesPrice\":1.629738," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":91.27,\"MarketPurchaseValue\":91.27,\"MarketSalesValue\":91.27,\"DistributionPercent\":2.53},\"Id\":\"SK-RVMXB\"}," +
                "{\"ContractId\":\"599502\",\"Name\":\"SK-RVST\",\"Shares\":{\"AvailableShares\":48.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":2.562754," +
                "\"PurchasePrice\":2.562754,\"SalesPrice\":2.562754,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":123.01,\"MarketPurchaseValue\":123.01,\"MarketSalesValue\":123.01," +
                "\"DistributionPercent\":3.42},\"Id\":\"SK-RVSTB\"},{\"ContractId\":\"\",\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":0.0,\"PurchasePrice\":0.0,\"SalesPrice\":0.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":678.79,\"MarketPurchaseValue\":678.79," +
                "\"MarketSalesValue\":678.79,\"DistributionPercent\":0.0},\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"665235\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":4.85,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":4.85,\"MarketPurchaseValue\":4.85," +
                "\"MarketSalesValue\":4.85,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"665235\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":2001.38," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":2001.38,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"665235\",\"Name\":\"FT-BOND\",\"Shares\":{\"AvailableShares\":119722.0,\"CommittedShares\":3019.0,\"CommittedSharesSales\":3019.0},\"Prices\":{\"Price\":3.146827," +
                "\"PurchasePrice\":3.146827,\"SalesPrice\":3.146827,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":376744.42,\"MarketPurchaseValue\":376744.42," +
                "\"MarketSalesValue\":376744.42,\"DistributionPercent\":23.72},\"Id\":\"FT-BONDBF1\"},{\"ContractId\":\"665235\",\"Name\":\"FT-GLOB\",\"Shares\":{\"AvailableShares\":22109.0," +
                "\"CommittedShares\":96.0,\"CommittedSharesSales\":96.0},\"Prices\":{\"Price\":6.76578,\"PurchasePrice\":6.76578,\"SalesPrice\":6.76578,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":149584.63,\"MarketPurchaseValue\":149584.63,\"MarketSalesValue\":149584.63,\"DistributionPercent\":9.42},\"Id\":\"FT-GLOBBF4\"},{\"ContractId\":\"665235\"," +
                "\"Name\":\"FT-MEXA\",\"Shares\":{\"AvailableShares\":265853.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.05435,\"PurchasePrice\":1.05435," +
                "\"SalesPrice\":1.05435,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":280302.11,\"MarketPurchaseValue\":280302.11,\"MarketSalesValue\":280302.11," +
                "\"DistributionPercent\":17.64},\"Id\":\"FT-MEXABF3\"},{\"ContractId\":\"665235\",\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":108646.0,\"CommittedShares\":0.0," +
                "\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.176302,\"PurchasePrice\":1.176302,\"SalesPrice\":1.176302,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":127800.51,\"MarketPurchaseValue\":127800.51,\"MarketSalesValue\":127800.51,\"DistributionPercent\":8.04},\"Id\":\"SK-DESTB\"},{\"ContractId\":\"665235\"," +
                "\"Name\":\"SURASIA\",\"Shares\":{\"AvailableShares\":70437.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":4.178927,\"PurchasePrice\":4.178927," +
                "\"SalesPrice\":4.178927,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":294351.08,\"MarketPurchaseValue\":294351.08,\"MarketSalesValue\":294351.08," +
                "\"DistributionPercent\":18.53},\"Id\":\"SURASIABF\"},{\"ContractId\":\"665235\",\"Name\":\"SURBONO\",\"Shares\":{\"AvailableShares\":132877.0,\"CommittedShares\":739.0," +
                "\"CommittedSharesSales\":739.0},\"Prices\":{\"Price\":2.708098,\"PurchasePrice\":2.708098,\"SalesPrice\":2.708098,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":359843.94,\"MarketPurchaseValue\":359843.94,\"MarketSalesValue\":359843.94,\"DistributionPercent\":22.65},\"Id\":\"SURBONOBDF\"}," +
                "{\"ContractId\":\"\",\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":0.0," +
                "\"PurchasePrice\":0.0,\"SalesPrice\":0.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":2006.23,\"MarketPurchaseValue\":4.85,\"MarketSalesValue\":4.85," +
                "\"DistributionPercent\":0.0},\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> ContractContributionsDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10 }
            };
        }

        private string GetContractContributionsData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":827724.270000,\"OrdinalContributionsNumber\":71,\"AdditionalContributionsAmount\":0.0,\"AdditionalContributionsNumber\":0,\"FirstContributionDate\":\"2004-12-15T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":329208.300000,\"OrdinalContributionsNumber\":105,\"AdditionalContributionsAmount\":0.0,\"AdditionalContributionsNumber\":0,\"FirstContributionDate\":\"2012-09-24T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":211660.670000,\"OrdinalContributionsNumber\":66,\"AdditionalContributionsAmount\":3207.430000,\"AdditionalContributionsNumber\":1,\"FirstContributionDate\":\"2015-05-28T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":1470000.000000,\"OrdinalContributionsNumber\":5,\"AdditionalContributionsAmount\":0.0,\"AdditionalContributionsNumber\":0,\"FirstContributionDate\":\"2017-05-23T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> ContractWithdrawalsDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10 }
            };
        }

        private string GetContractWithdrawalsData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":0.0,\"OrdinalWithdrawalsNumber\":0,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":0.0,\"OrdinalWithdrawalsNumber\":0,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":0.0,\"OrdinalWithdrawalsNumber\":0,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":120000.0,\"OrdinalWithdrawalsNumber\":2,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> ContributionsOnDemandDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10 },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10 },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10 }
            };
        }

        private string GetContributionsOnDemandData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":0.0,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":0.0,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":21602.66,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":0.0,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private string GetContractInfoData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractInfo\":{\"PlanBasId\":\"15\",\"Platform\":5,\"GoalId\":9999,\"ContratoAgrupa\":\"100960\",\"AfiliationDate\":\"2004-12-14T00:00:00\"," +
                "\"GoalDescription\":\"(No Asignado)\",\"ContractDigit\":\"P35\",\"ApplyDeducible\":true,\"Id\":\"100960\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "562969", "{\"ContractInfo\":{\"PlanBasId\":\"350\",\"Platform\":10,\"GoalId\":5,\"ContratoAgrupa\":\"562969\",\"AfiliationDate\":\"2012-09-13T12:58:00\"," +
                "\"GoalDescription\":\"Educación\",\"ContractDigit\":\"V25\",\"ApplyDeducible\":false,\"Id\":\"562969\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "599500", "{\"ContractInfo\":{\"PlanBasId\":\"520\",\"Platform\":10,\"GoalId\":5,\"ContratoAgrupa\":\"599501\",\"AfiliationDate\":\"2015-05-26T11:41:00\"," +
                "\"GoalDescription\":\"Educación\",\"ContractDigit\":\"X21\",\"ApplyDeducible\":false,\"Id\":\"599500\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                { "665235", "{\"ContractInfo\":{\"PlanBasId\":\"480\",\"Platform\":10,\"GoalId\":9999,\"ContratoAgrupa\":\"665235\",\"AfiliationDate\":\"2017-05-18T17:03:00\"," +
                "\"GoalDescription\":\"(No Asignado)\",\"ContractDigit\":\"V65\",\"ApplyDeducible\":false,\"Id\":\"665235\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> ContractContributionsByDateDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now  },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10, new DateTime(2000, 1, 1), DateTime.Now }
            };
        }

        private string GetContractContributionsByDateData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":827724.27,\"OrdinalContributionsNumber\":70,\"AdditionalContributionsAmount\":0.0,\"AdditionalContributionsNumber\":0,\"FirstContributionDate\":\"2004-12-15T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":329208.30,\"OrdinalContributionsNumber\":105,\"AdditionalContributionsAmount\":0.0,\"AdditionalContributionsNumber\":0,\"FirstContributionDate\":\"2012-09-24T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":211660.67,\"OrdinalContributionsNumber\":66,\"AdditionalContributionsAmount\":3207.43,\"AdditionalContributionsNumber\":1,\"FirstContributionDate\":\"2015-05-28T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContractsContributions\":{\"OrdinalContributionsAmount\":1470000.00,\"OrdinalContributionsNumber\":4,\"AdditionalContributionsAmount\":0.0,\"AdditionalContributionsNumber\":0,\"FirstContributionDate\":\"2017-05-23T00:00:00\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> GetContributionsOnDemandByDateDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now  },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10, new DateTime(2000, 1, 1), DateTime.Now }
            };
        }

        private string GetContributionsOnDemandByDateData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":0.0,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":0.0,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":21602.66,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContributionsOnDemand\":{\"OrdinalContributionsOnDemandAmount\":0.0,\"AdditionalContributionsOnDemandAmount\":0.0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> GetContractWithdrawalsByDateDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now  },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10, new DateTime(2000, 1, 1), DateTime.Now }
            };
        }

        private string ContractWithdrawalsByDateData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":0.0,\"OrdinalWithdrawalsNumber\":0,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":0.0,\"OrdinalWithdrawalsNumber\":0,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":0.0,\"OrdinalWithdrawalsNumber\":0,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContractWithdrawals\":{\"OrdinalWithdrawalsAmount\":120000.0,\"OrdinalWithdrawalsNumber\":2,\"AdditionalWithdrawalsAmount\":0.0,\"AdditionalWithdrawalsNumber\":0},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> GetContractChargesByDateDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now  },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10, new DateTime(2000, 1, 1), DateTime.Now }
            };
        }

        private string ContractChargesByDateData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"Charges\":0.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"Charges\":0.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"Charges\":62.71,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"Charges\":0.0,\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}};
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> GetContractDetailCashMovementsByDateDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now  },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10, new DateTime(2000, 1, 1), DateTime.Now }
            };
        }

        private string ContractDetailCashMovementsByDateData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractCashMovementsDetail\":[{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2021-05-21T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2021-05-07T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\"," +
                "\"MovementProcessDate\":\"2020-12-31T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2020-12-18T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2020-12-08T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":20000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\"," +
                "\"MovementProcessDate\":\"2020-11-12T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2020-07-10T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2020-06-12T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\"," +
                "\"MovementProcessDate\":\"2020-05-07T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2020-03-20T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2019-12-27T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\"," +
                "\"MovementProcessDate\":\"2019-12-16T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2019-12-09T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":20000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2019-11-04T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2019-07-30T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2019-07-10T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":30000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2018-12-31T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":7500.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2018-12-21T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2018-12-07T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":25000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2018-11-20T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":15000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-11-27T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":16000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-08-15T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":20000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-07-28T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":25000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-06-02T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":6700.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-05-30T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":4300.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-05-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-05-08T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":20000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-03-14T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-02-10T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-01-30T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2017-01-20T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2016-12-30T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":15000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2016-12-19T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":6000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2016-12-13T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":15000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2016-06-03T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2016-05-27T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":12000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2015-12-21T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2015-12-14T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":15000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2015-11-20T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2014-12-10T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2014-11-28T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":20000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2014-04-29T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2014-02-21T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2014-01-16T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-12-16T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":15000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-11-14T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-09-30T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-08-15T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-07-31T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-06-14T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-05-16T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":50000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-01-28T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2013-01-14T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2012-12-18T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2012-10-12T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2012-09-17T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2012-08-13T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2012-05-15T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":30000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2011-12-21T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2011-12-13T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":10000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2011-07-13T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":2500.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2011-07-12T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":2500.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2011-06-13T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":23866.95,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2011-06-07T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":2357.32," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2009-12-29T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2009-12-15T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2008-12-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":4000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2006-12-28T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":30000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"},{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2005-11-21T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":30000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}," +
                "{\"MovementContractId\":\"100960\",\"MovementProcessDate\":\"2004-12-15T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":30000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"100960\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContractCashMovementsDetail\":[{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2021-05-24T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":3561.6,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2021-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3561.6,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2021-03-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3561.6,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2021-02-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3561.6," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2021-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"}," +
                "{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-11-24T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-10-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2020-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-08-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-07-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2020-06-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2020-03-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-02-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3452.84," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2020-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2019-12-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-10-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2019-09-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-07-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2019-06-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-04-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2019-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-02-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3357.81," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2019-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2018-12-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-10-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2018-09-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-07-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2018-06-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-04-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2018-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3203.1,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-02-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2018-01-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2017-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-10-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2017-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-07-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2017-06-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-05-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-04-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2017-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-02-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2017-01-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2016-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-11-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-10-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2016-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-08-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-07-25T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2016-06-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-05-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2016-03-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-02-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2016-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2015-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-11-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-10-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2015-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-08-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-07-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2015-06-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2015-03-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-02-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2015-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2014-12-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-11-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-10-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2014-09-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-07-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2014-06-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2014-03-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-02-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2014-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2013-12-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-10-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2013-09-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-07-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2013-06-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-04-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2013-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-03-01T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2013-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2012-12-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2012-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\",\"MovementProcessDate\":\"2012-10-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"562969\"},{\"MovementContractId\":\"562969\"," +
                "\"MovementProcessDate\":\"2012-09-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"562969\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContractCashMovementsDetail\":[{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2021-05-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3637.47," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"123456789123456789\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2021-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3637.47,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"123456789123456789\",\"Id\":\"599500\"}," +
                "{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2021-03-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3637.47,\"MovementSubaccountName\":\"Ahorro Ordinario\"," +
                "\"MovementBankAccount\":\"123456789123456789\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2021-02-22T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":3637.47,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"123456789123456789\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2021-01-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\"," +
                "\"MovementBankAccount\":\"123456789123456789\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-12-22T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"123456789123456789\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2020-11-25T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-10-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-09-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2020-08-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-07-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-06-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2020-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-04-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-03-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2020-02-25T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3526.39,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2020-01-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-12-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2019-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-10-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-09-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2019-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-07-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-06-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2019-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-04-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3429.34," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599502\",\"MovementProcessDate\":\"2019-03-25T00:00:00\"," +
                "\"MovementDescription\":\"Cargo por aportación\",\"MovementAmount\":-32.71,\"MovementSubaccountName\":\"Ahorro Extraordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"}," +
                "{\"MovementContractId\":\"599502\",\"MovementProcessDate\":\"2019-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Extraordinario\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-02-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2019-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2018-12-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-10-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2018-09-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-07-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"}," +
                "{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-06-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3271.33,\"MovementSubaccountName\":\"Ahorro Ordinario\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-05-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-04-30T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2018-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-02-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2018-01-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2017-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-11-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-10-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2017-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-08-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-07-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2017-06-26T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-05-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-05-05T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"}," +
                "{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-03-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-02-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2017-01-25T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2016-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-11-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-10-24T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2016-10-17T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-08-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2016-06-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-05-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3063.9," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-04-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2016-03-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-02-23T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2016-01-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2015-12-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2015-11-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2015-10-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\"," +
                "\"MovementProcessDate\":\"2015-09-22T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2015-08-24T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0," +
                "\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2015-07-22T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599502\"," +
                "\"MovementProcessDate\":\"2015-06-24T00:00:00\",\"MovementDescription\":\"Cargo por aportación\",\"MovementAmount\":-30.0,\"MovementSubaccountName\":\"Ahorro Extraordinario\"," +
                "\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599502\",\"MovementProcessDate\":\"2015-06-23T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Extraordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"},{\"MovementContractId\":\"599501\",\"MovementProcessDate\":\"2015-05-28T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":3000.0,\"MovementSubaccountName\":\"Ahorro Ordinario\",\"MovementBankAccount\":\"\",\"Id\":\"599500\"}]," +
                "\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContractCashMovementsDetail\":[{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2020-11-09T00:00:00\",\"MovementDescription\":\"Retiro\",\"MovementAmount\":-50000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"014180565426486646\",\"Id\":\"665235\"},{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2019-03-28T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":400000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"665235\"},{\"MovementContractId\":\"665235\"," +
                "\"MovementProcessDate\":\"2019-02-11T00:00:00\",\"MovementDescription\":\"Aportación\",\"MovementAmount\":500000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\"," +
                "\"Id\":\"665235\"},{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2017-06-21T00:00:00\",\"MovementDescription\":\"Retiro\",\"MovementAmount\":-70000.0,\"MovementSubaccountName\":\"\"," +
                "\"MovementBankAccount\":\"5579100133580116\",\"Id\":\"665235\"},{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2017-05-24T00:00:00\",\"MovementDescription\":\"Aportación\"," +
                "\"MovementAmount\":70000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"665235\"},{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2017-05-23T00:00:00\"," +
                "\"MovementDescription\":\"Aportación\",\"MovementAmount\":500000.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"\",\"Id\":\"665235\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}};
            retData.TryGetValue(contractId, out retValue);

            return retValue;

        }

        private static IEnumerable<object[]> GetContractDetailPendingMovementsByDateDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("100960", "100960", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("562969", "562969", 1 ) }, 10, new DateTime(2000,1,1), DateTime.Now  },
                new object[]{ new List<AssociatedContract> {
                    AssociatedContract.Create("599500", "599500", 1),
                    AssociatedContract.Create("599501", "599500", 2),
                    AssociatedContract.Create("599502", "599500", 3)
                }
                , 10, new DateTime(2000,1,1), DateTime.Now },
                new object[]{ new List<AssociatedContract> { AssociatedContract.Create("665235", "665235", 1) }, 10, new DateTime(2000, 1, 1), DateTime.Now }
            };
        }

        private string ContractDetailPendingMovementsByDateData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"ContractMovementsPendingDetail\":[],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"ContractMovementsPendingDetail\":[],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"ContractMovementsPendingDetail\":[{\"MovementContractId\":\"599502\",\"MovementProcessDate\":\"2021-08-26T00:00:00\",\"MovementDescription\":\"Aportacion On Demand\"," +
                "\"MovementAmount\":2000.0,\"MovementSubaccountName\":\"Ahorro Extraordinario\",\"MovementBankAccount\":\"12345678\",\"Id\":\"599500\"},{\"MovementContractId\":\"599500\"," +
                "\"MovementProcessDate\":\"1900-01-01T00:00:00\",\"MovementDescription\":\"Aportacion\",\"MovementAmount\":3637.47,\"MovementSubaccountName\":\"Ahorro Ordinario\"," +
                "\"MovementBankAccount\":\"Rechazado\",\"Id\":\"599500\"}],\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"ContractMovementsPendingDetail\":[{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2021-08-27T00:00:00\",\"MovementDescription\":\"Aportacion On Demand\"," +
                "\"MovementAmount\":1500.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"12345678\",\"Id\":\"665235\"},{\"MovementContractId\":\"665235\"," +
                "\"MovementProcessDate\":\"2021-08-26T00:00:00\",\"MovementDescription\":\"Retiro\",\"MovementAmount\":-2650.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"12345678\"," +
                "\"Id\":\"665235\"},{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2021-08-18T00:00:00\",\"MovementDescription\":\"Retiro\",\"MovementAmount\":-5000.0," +
                "\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"12345678\",\"Id\":\"665235\"},{\"MovementContractId\":\"665235\",\"MovementProcessDate\":\"2021-08-17T00:00:00\"," +
                "\"MovementDescription\":\"Retiro\",\"MovementAmount\":-4500.0,\"MovementSubaccountName\":\"\",\"MovementBankAccount\":\"12345678\",\"Id\":\"665235\"}],\"Result\":{\"Successful\":true," +
                "\"SystemMessages\":[]}}"}};
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private static IEnumerable<object[]> ContractBalanceDetailDynDat()
        {
            return new List<object[]>(){
                new object[]{ new List<string> { "100960" }, 10 },
                new object[]{ new List<string> { "562969" }, 10 },
                new object[]{ new List<string> { "599500", "599501", "599502" }, 10 },
                new object[]{ new List<string> { "665235" }, 10 }
            };
        }

        private string GetContractBalanceDetailData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"100960\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":0.75,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.75,\"MarketPurchaseValue\":0.75," +
                "\"MarketSalesValue\":0.75,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"100960\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"100960\",\"Name\":\"SK-DCP\",\"Shares\":{\"AvailableShares\":95968.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.709863," +
                "\"PurchasePrice\":1.709863,\"SalesPrice\":1.709863,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":164092.13,\"MarketPurchaseValue\":164092.13," +
                "\"MarketSalesValue\":164092.13,\"DistributionPercent\":14.53},\"Id\":\"SK-DCP E\"},{\"ContractId\":\"100960\",\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":531817.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.342367,\"PurchasePrice\":1.342367,\"SalesPrice\":1.342367,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":713893.59,\"MarketPurchaseValue\":713893.59,\"MarketSalesValue\":713893.59,\"DistributionPercent\":63.23},\"Id\":\"SK-DESTE\"}," +
                "{\"ContractId\":\"100960\",\"Name\":\"SK-RVMX\",\"Shares\":{\"AvailableShares\":58606.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.641921," +
                "\"PurchasePrice\":1.641921,\"SalesPrice\":1.641921,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":96226.42,\"MarketPurchaseValue\":96226.42," +
                "\"MarketSalesValue\":96226.42,\"DistributionPercent\":8.52},\"Id\":\"SK-RVMXE\"},{\"ContractId\":\"100960\",\"Name\":\"SK-RVST\",\"Shares\":{\"AvailableShares\":59441.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":2.605626,\"PurchasePrice\":2.605626,\"SalesPrice\":2.605626,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":154881.02,\"MarketPurchaseValue\":154881.02,\"MarketSalesValue\":154881.02,\"DistributionPercent\":13.72},\"Id\":\"SK-RVSTE\"},{\"ContractId\":\"\"," +
                "\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":0.0,\"PurchasePrice\":0.0,\"SalesPrice\":0.0," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.75,\"MarketPurchaseValue\":0.75,\"MarketSalesValue\":0.75,\"DistributionPercent\":0.0},\"Id\":\"EFECTIVO\"}]}," +
                "\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"562969\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":13.85,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":13.85,\"MarketPurchaseValue\":13.85," +
                "\"MarketSalesValue\":13.85,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"562969\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"562969\",\"Name\":\"PRINFGU\",\"Shares\":{\"AvailableShares\":13.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":18.090442," +
                "\"PurchasePrice\":18.090442,\"SalesPrice\":18.090442,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":235.18,\"MarketPurchaseValue\":235.18," +
                "\"MarketSalesValue\":235.18,\"DistributionPercent\":0.06},\"Id\":\"PRINFGUF2\"},{\"ContractId\":\"562969\",\"Name\":\"SK-DCP\",\"Shares\":{\"AvailableShares\":11985.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.505423,\"PurchasePrice\":1.505423,\"SalesPrice\":1.505423,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":18042.49,\"MarketPurchaseValue\":18042.49,\"MarketSalesValue\":18042.49,\"DistributionPercent\":4.54},\"Id\":\"SK-DCP B\"},{\"ContractId\":\"562969\"," +
                "\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":110003.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.176302,\"PurchasePrice\":1.176302," +
                "\"SalesPrice\":1.176302,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":129396.75,\"MarketPurchaseValue\":129396.75,\"MarketSalesValue\":129396.75," +
                "\"DistributionPercent\":32.57},\"Id\":\"SK-DESTB\"},{\"ContractId\":\"562969\",\"Name\":\"SK-RVMX\",\"Shares\":{\"AvailableShares\":57403.0,\"CommittedShares\":0.0," +
                "\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.629738,\"PurchasePrice\":1.629738,\"SalesPrice\":1.629738,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":93551.85,\"MarketPurchaseValue\":93551.85,\"MarketSalesValue\":93551.85,\"DistributionPercent\":23.55},\"Id\":\"SK-RVMXB\"},{\"ContractId\":\"562969\"," +
                "\"Name\":\"SK-RVST\",\"Shares\":{\"AvailableShares\":60876.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":2.562754,\"PurchasePrice\":2.562754," +
                "\"SalesPrice\":2.562754,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":156010.21,\"MarketPurchaseValue\":156010.21,\"MarketSalesValue\":156010.21," +
                "\"DistributionPercent\":39.27},\"Id\":\"SK-RVSTB\"},{\"ContractId\":\"\",\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":0.0,\"PurchasePrice\":0.0,\"SalesPrice\":0.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":13.85,\"MarketPurchaseValue\":13.85," +
                "\"MarketSalesValue\":13.85,\"DistributionPercent\":0.0},\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"599500\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0," +
                "\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.0," +
                "\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"},{\"ContractId\":\"599501\",\"Name\":\"EFECTIV\"," +
                "\"Shares\":{\"AvailableShares\":673.11,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":673.11,\"MarketPurchaseValue\":673.11,\"MarketSalesValue\":673.11,\"DistributionPercent\":0.0}," +
                "\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"599501\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0," +
                "\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"},{\"ContractId\":\"599502\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":5.68," +
                "\"CommittedShares\":0.00,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":5.68,\"MarketPurchaseValue\":5.68,\"MarketSalesValue\":5.68,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"599502\"," +
                "\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0," +
                "\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":0.0,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0}," +
                "\"Id\":\"|Operaciones Pendientes\"}],\"Funds\":[{\"ContractId\":\"599501\",\"Name\":\"OM-ESP1\",\"Shares\":{\"AvailableShares\":211981.0,\"CommittedShares\":0.0," +
                "\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.167003,\"PurchasePrice\":1.167003,\"SalesPrice\":1.167003,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":247382.46,\"MarketPurchaseValue\":247382.46,\"MarketSalesValue\":247382.46,\"DistributionPercent\":100.0},\"Id\":\"OM-ESP1B\"}," +
                "{\"ContractId\":\"599502\",\"Name\":\"SK-DCP\",\"Shares\":{\"AvailableShares\":484.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.505423," +
                "\"PurchasePrice\":1.505423,\"SalesPrice\":1.505423,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":728.62,\"MarketPurchaseValue\":728.62," +
                "\"MarketSalesValue\":728.62,\"DistributionPercent\":20.23},\"Id\":\"SK-DCP B\"},{\"ContractId\":\"599502\",\"Name\":\"SK-DEST\",\"Shares\":{\"AvailableShares\":2260.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.176302,\"PurchasePrice\":1.176302,\"SalesPrice\":1.176302,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":2658.44,\"MarketPurchaseValue\":2658.44,\"MarketSalesValue\":2658.44,\"DistributionPercent\":73.82},\"Id\":\"SK-DESTB\"}," +
                "{\"ContractId\":\"599502\",\"Name\":\"SK-RVMX\",\"Shares\":{\"AvailableShares\":56.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.629738," +
                "\"PurchasePrice\":1.629738,\"SalesPrice\":1.629738,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":91.27,\"MarketPurchaseValue\":91.27," +
                "\"MarketSalesValue\":91.27,\"DistributionPercent\":2.53},\"Id\":\"SK-RVMXB\"},{\"ContractId\":\"599502\",\"Name\":\"SK-RVST\",\"Shares\":{\"AvailableShares\":48.0," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":2.562754,\"PurchasePrice\":2.562754,\"SalesPrice\":2.562754,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":123.01,\"MarketPurchaseValue\":123.01,\"MarketSalesValue\":123.01,\"DistributionPercent\":3.42},\"Id\":\"SK-RVSTB\"},{\"ContractId\":\"\"," +
                "\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":0.0,\"PurchasePrice\":0.0,\"SalesPrice\":0.0," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":678.79,\"MarketPurchaseValue\":678.79,\"MarketSalesValue\":678.79,\"DistributionPercent\":0.0}," +
                "\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"Investments\":{\"Cash\":[{\"ContractId\":\"665235\",\"Name\":\"EFECTIV\",\"Shares\":{\"AvailableShares\":4.85,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":4.85,\"MarketPurchaseValue\":4.85," +
                "\"MarketSalesValue\":4.85,\"DistributionPercent\":0.0},\"Id\":\"|EFECTIVO\"},{\"ContractId\":\"665235\",\"Name\":\"Operaciones Pendientes\",\"Shares\":{\"AvailableShares\":2001.38," +
                "\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.0,\"PurchasePrice\":1.0,\"SalesPrice\":1.0,\"PriceDate\":\"0001-01-01T00:00:00\"}," +
                "\"MarketValues\":{\"MarketValue\":2001.38,\"MarketPurchaseValue\":0.0,\"MarketSalesValue\":0.0,\"DistributionPercent\":0.0},\"Id\":\"|Operaciones Pendientes\"}]," +
                "\"Funds\":[{\"ContractId\":\"665235\",\"Name\":\"FT-BOND\",\"Shares\":{\"AvailableShares\":119722.0,\"CommittedShares\":3019.0,\"CommittedSharesSales\":3019.0}," +
                "\"Prices\":{\"Price\":3.146827,\"PurchasePrice\":3.146827,\"SalesPrice\":3.146827,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":376744.42," +
                "\"MarketPurchaseValue\":376744.42,\"MarketSalesValue\":376744.42,\"DistributionPercent\":23.72},\"Id\":\"FT-BONDBF1\"},{\"ContractId\":\"665235\",\"Name\":\"FT-GLOB\"," +
                "\"Shares\":{\"AvailableShares\":22109.0,\"CommittedShares\":96.0,\"CommittedSharesSales\":96.0},\"Prices\":{\"Price\":6.76578,\"PurchasePrice\":6.76578,\"SalesPrice\":6.76578," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":149584.63,\"MarketPurchaseValue\":149584.63,\"MarketSalesValue\":149584.63,\"DistributionPercent\":9.42}," +
                "\"Id\":\"FT-GLOBBF4\"},{\"ContractId\":\"665235\",\"Name\":\"FT-MEXA\",\"Shares\":{\"AvailableShares\":265853.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":1.05435,\"PurchasePrice\":1.05435,\"SalesPrice\":1.05435,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":280302.11," +
                "\"MarketPurchaseValue\":280302.11,\"MarketSalesValue\":280302.11,\"DistributionPercent\":17.64},\"Id\":\"FT-MEXABF3\"},{\"ContractId\":\"665235\",\"Name\":\"SK-DEST\"," +
                "\"Shares\":{\"AvailableShares\":108646.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":1.176302,\"PurchasePrice\":1.176302,\"SalesPrice\":1.176302," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":127800.51,\"MarketPurchaseValue\":127800.51,\"MarketSalesValue\":127800.51,\"DistributionPercent\":8.04}," +
                "\"Id\":\"SK-DESTB\"},{\"ContractId\":\"665235\",\"Name\":\"SURASIA\",\"Shares\":{\"AvailableShares\":70437.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0}," +
                "\"Prices\":{\"Price\":4.178927,\"PurchasePrice\":4.178927,\"SalesPrice\":4.178927,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":294351.08," +
                "\"MarketPurchaseValue\":294351.08,\"MarketSalesValue\":294351.08,\"DistributionPercent\":18.53},\"Id\":\"SURASIABF\"},{\"ContractId\":\"665235\",\"Name\":\"SURBONO\"," +
                "\"Shares\":{\"AvailableShares\":132877.0,\"CommittedShares\":739.0,\"CommittedSharesSales\":739.0},\"Prices\":{\"Price\":2.708098,\"PurchasePrice\":2.708098,\"SalesPrice\":2.708098," +
                "\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":359843.94,\"MarketPurchaseValue\":359843.94,\"MarketSalesValue\":359843.94,\"DistributionPercent\":22.65}," +
                "\"Id\":\"SURBONOBDF\"},{\"ContractId\":\"\",\"Name\":\"EFECTIVO\",\"Shares\":{\"AvailableShares\":0.0,\"CommittedShares\":0.0,\"CommittedSharesSales\":0.0},\"Prices\":{\"Price\":0.0," +
                "\"PurchasePrice\":0.0,\"SalesPrice\":0.0,\"PriceDate\":\"0001-01-01T00:00:00\"},\"MarketValues\":{\"MarketValue\":2006.23,\"MarketPurchaseValue\":4.85,\"MarketSalesValue\":4.85," +
                "\"DistributionPercent\":0.0},\"Id\":\"EFECTIVO\"}]},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}
            };
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

        private string GetPortfolioProfileData(string contractId)
        {
            string retValue = string.Empty;

            Dictionary<string, string> retData = new Dictionary<string, string>(){
                {"100960", "{\"PortfolioType\":{\"Description\":\"Portafolio Premium moderado exento\",\"ClientType\":{\"Id\":\"10\",\"Description\":\"PREMIUM MODERADO EXENTO\"},\"Id\":\"5\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"562969", "{\"PortfolioType\":{\"Description\":\"Portafolio Premium especulativo\",\"ClientType\":{\"Id\":\"9\",\"Description\":\"PREMIUM ESPECULATIVO\"},\"Id\":\"5\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599500", "{\"PortfolioType\":{\"Description\":\"Portafolio Premium estabilidad\",\"ClientType\":{\"Id\":\"6\",\"Description\":\"PREMIUM ESTABILIDAD\"},\"Id\":\"5\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599501", "{\"PortfolioType\":{\"Description\":\"Portafolio personalizado skandia\",\"ClientType\":{\"Id\":\"2\",\"Description\":\"Conservador\"},\"Id\":\"10\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"599502", "{\"PortfolioType\":{\"Description\":\"Portafolio Premium estabilidad\",\"ClientType\":{\"Id\":\"6\",\"Description\":\"PREMIUM ESTABILIDAD\"},\"Id\":\"5\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"},
                {"665235", "{\"PortfolioType\":{\"Description\":\"Portafolio personalizado skandia\",\"ClientType\":{\"Id\":\"2\",\"Description\":\"Conservador\"},\"Id\":\"10\"},\"Result\":{\"Successful\":true,\"SystemMessages\":[]}}"}};
            retData.TryGetValue(contractId, out retValue);

            return retValue;
        }

    }
}
