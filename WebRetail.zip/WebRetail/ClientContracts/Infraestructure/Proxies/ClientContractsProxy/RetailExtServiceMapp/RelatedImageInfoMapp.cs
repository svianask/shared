﻿using ClientContractsDomain.ClienContractsAggregate;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailExtServiceMapp
{
    public class RelatedImageInfoMapp
    {
        public static List<RelatedImageInfo> Mapp(PrxyGoalsImageResponse goalsImages)
        {
            List<RelatedImageInfo> relatedImagesInfo = new List<RelatedImageInfo>();
            goalsImages.Images.ForEach( x =>
                relatedImagesInfo.Add(
                    new RelatedImageInfo(x.GoalId,x.ImageFileName,x.Type )
                )
            );

            return relatedImagesInfo;
        }
    }
}
