﻿using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.PlanAggregate;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailExtServiceMapp
{
    public class PlansMapp
    {
        public static List<Plan> Mapp(PrxyPlansResponse prxPlansResponse)
        {
            List<Plan> Plans = new List<Plan>();
            prxPlansResponse.Plans.ForEach(p =>
                Plans.Add(
                    Plan
                        .Create(p.Id, p.Name, p.ShortName, p.BasPlanId )
                        .SetComercialInfo(p.ComercialInfo.ComercialPlanId, p.ComercialInfo.ComercialName)
                        .SetPlanClasification(p.PlanClasification.Platform,p.PlanClasification.ProductType)
                )
            );
            return Plans;
        }
    }
}
