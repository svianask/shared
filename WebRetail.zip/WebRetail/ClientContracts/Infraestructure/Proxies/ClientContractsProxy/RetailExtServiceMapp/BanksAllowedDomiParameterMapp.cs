﻿using ClientContractsDomain.BankAccountAggregate;

namespace ClientContractsProxy.RetailExtServiceMapp
{
    public class BanksAllowedDomiParameterMapp
    {
        public static BanksAllowedDomiParameter Mapp(BanksAllowedDomiParameterPrxy banksAllowedDomiParameterPrxy)
        {
            BanksAllowedDomiParameter banksAllowedDomiParameter = BanksAllowedDomiParameter.Create(
                banksAllowedDomiParameterPrxy.SolicitudParametroId,
                banksAllowedDomiParameterPrxy.SolicitudParametroNombre,
                banksAllowedDomiParameterPrxy.SolicitudParametroValor
                );


            return banksAllowedDomiParameter;
        }
    }
}
