﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailExtServiceMapp
{
    public class ContractPendingContributuionsMapp
    {
        internal static List<ContractMovementDetail> Mapp(List<PrxyMovementDetail> response)
        {
            List<ContractMovementDetail> contractMovementPendingDetails = new List<ContractMovementDetail>();

            foreach (PrxyMovementDetail movement in response)
            {
                var movementContract = movement.MovementContractId;
                var movementSubaccountName = movement.MovementSubaccountName;
                var movementDate = movement.MovementProcessDate;
                var movementDescription = movement.MovementDescription;
                var movementBankAccount = movement.MovementBankAccount;
                var movementAmount = movement.MovementAmount;
                ContractMovementDetail movementCashDetail = ContractMovementDetail
                                                                        .Create(movementContract, movementSubaccountName, movementAmount, movementDate, movementBankAccount)
                                                                        .SetMovementDescription(movementDescription);

                contractMovementPendingDetails.Add(movementCashDetail);
            }
            return contractMovementPendingDetails;
        }
    }
}
