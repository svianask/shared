﻿using ClientContractsDomain.BankAccountAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClientContractsProxy
{
    #region Goals Image
    public class PrxyGoalsImageRequest
    {
        public List<short> GoalIds;
    }

    public class PrxyGoalsImageResponse
    {
        public List<PrxyRelatedImageInfo> Images;
        public OperationResult Result;
    }

    public class PrxyRelatedImageInfo
    {
        public short GoalId;
        public string ImageFileName;
        public int Type;
    }
    #endregion

    #region Plans
    public class PrxyPlansRequest
    {
        public List<short> PlanIds;
    }
    public class PrxyPlansResponse
    {
        public List<PrxyPlan> Plans;
        public OperationResult Result;
    }

    public class PrxyPlan
    {
        public string Id;
        public string Name;
        public string ShortName;
        public string BasPlanId;
        public PrxyPlanClasification PlanClasification;
        public PrxyComercialInfo ComercialInfo;
    }
    public class PrxyComercialInfo
    {
        public short ComercialPlanId;
        public string ComercialName;
    }

    public class PrxyPlanClasification
    {
        public int Platform;
        public int ProductType;
    }

    #endregion

    #region  Type Of Contrac
    public class PrxyTypeOfContractRequest
    {
        public string ContractId;
    }

    public class PrxyTypeOfContractResponse
    {
        public int TypeOfContract;
        public OperationResult Result;
    }
    #endregion

    #region Life insurance amount
    public class PrxyLifeInsuranceAmountRequest
    {
        public string ContractId;
    }

    public class PrxyLifeInsuranceAmountResponse
    {
        public decimal LifeInsuranceAmount;
        public OperationResult Result;
    }
    #endregion

    #region Contract extended basic info
    public class PrxyContractExtBasicInfoResponse
    {
        public PrxyContractExtBasicInfo ContractExtBasicInfo;
        public OperationResult Result;
    }

    public class PrxyContractExtBasicInfoRequest
    {
        public string ContractId;
    }

    public class PrxyContractExtBasicInfo
    {
        public decimal SavingGoal;
        public int SavingTerm;
        public decimal CommittedAmount;
        public DateTime AfiliationDate;
        public DateTime EfectiveEndDate;
    }
    #endregion

    #region Financial Planner Contracts

    public class PrxyFpContractsRequest
    {
        public List<string> ClientContractsId;
        public string FpEmail;
    }

    public class PrxyFpContractsResponse
    {
        public List<string> ClientContractsId;
        public OperationResult Result;
    }
    #endregion

    #region ContractMovementsDetail

    public class PrxyMovementDetailRequest
    {
        public PrxyMovementDetailRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public DateTime InitialDate;
        public DateTime FinalDate;
    }

    public class PrxyMovementDetailResponse
    {
        public List<PrxyMovementDetail> ContractMovementsPendingDetail;
        public OperationResult Result;
    }

    public class PrxyMovementDetail
    {
        public string MovementContractId;
        public DateTime MovementProcessDate;
        public string MovementDescription;
        public decimal MovementAmount;
        public string MovementSubaccountName;
        public string MovementBankAccount;
    }

    #endregion

    #region Solvencia
    public class PrxySolvenciaBasicInfoRequest
    {
        public string UserId;
        public int PortalId;
    }

    public class PrxySolvenciaBasicInfoResponse
    {
        public OperationResult Result;
        public PrxySolvenciaData SolvenciaInfo;
    }

    public class PrxySolvenciaData
    {
        public string User;
        public string Email;
        public string CellPhone;
        public string FullName;
    }


    #endregion

    #region ContractSegmentType
    public class PrxyProductSegmentTypeRequest
    {
        public string ContractId;
    }

    public class PrxyProductSegmentTypeResponse
    {
        public int SegmentOfContractType;
        public OperationResult Result;
    }
    #endregion

    #region ProductComercialName
    public class PrxyProductComercialNameRequest
    {
        public string ContractId;
    }

    public class PrxyProductComercialNameResponse
    {
        public string ComercialName;
        public OperationResult Result;
    }


    #endregion

    #region Plan Contribution
    public class GetProductsApplyContributionsPxy
    {
        public List<string> ProductsApplyContribution;
        public OperationResult Result;
    }
    #endregion

    #region Product transfer
    public class PlansApplyTransferResponsePrxy
    {
        public List<string> PlansTransferApply;
        public OperationResult Result;
    }

    public class ValidateScheduleTransferResponsePrxy
    {
        public OperationResult Result;
    }
    #endregion

    #region GetBanksAllowedDomiParameter
    public class BanksAllowedDomiParameterResponsePrxy
    {
        public OperationResult Result { get; set; }
        public BanksAllowedDomiParameterPrxy BanksAllowedDomiParameter { get; set; }
    }

    public class BanksAllowedDomiParameterPrxy
    {
        public int SolicitudParametroId { get; set; }
        public string SolicitudParametroNombre { get; set; }
        public string SolicitudParametroValor { get; set; }

        public BanksAllowedDomiParameterPrxy(
            int solicitudParametroId,
            string solicitudParametroNombre,
            string solicitudParametroValor
            )
        {
            SolicitudParametroId = solicitudParametroId;
            SolicitudParametroNombre = solicitudParametroNombre;
            SolicitudParametroValor = solicitudParametroValor;
        }
    }
    #endregion
}