﻿using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientContractsProxy
{
    #region Contract information
    public class PrxyContractsResponse
    {
        public ContractsOf ContractsOfClient;
        public OperationResult Result;

        public PrxyContractsResponse()
        {
            ContractsOfClient = new ContractsOf();
            Result = new OperationResult();
        }
    }

    public class PrxyContractsRequest
    {
        public string ClientIdentifier;
    }

    public class ContractsOf
    {
        public string Id;
        public List<Contr> Contracts;
    }

    public class Contr
    {
        public string Id;
        public short PlanBasId;
        public int Platform;
        public short GoalId;
        public string GoalDescription;
        public string ContratoAgrupa;
        public DateTime AfiliationDate;
        public int StatusContract;
        public int StatusOperation;
        public bool ApplyDeducible;
    }
    #endregion

    #region Begin trans date of one contract
    public class PrxyBeginContTransDateRequest
    {
        public string ContractId;
        public int Source;
    }

    public class PrxyBeginContTransDateResponse
    {
        public OperationResult Result;
        public DateTime BeginContractTransDate;
    }
    #endregion

    #region Summary contributions number
    public class PrxySummaryContributionsNumberRequest
    {
        public string ContractId;
    }

    public class PrxySummaryContributionsNumberResponse
    {
        public PrxySummaryContributions SummaryContributions;
        public OperationResult Result;
    }

    public class PrxySummaryContributions
    {
        public int TotalContributions;
        public int ExpectedContributions;
        public int RealizedContributions;
        public int FailedContributions;
        public int PendingContributions;
    }
    #endregion

    #region cash transactions of contract
    public class PrxyContractCashTransactionsResponse
    {
        public OperationResult Result;
        public PrxyCashTransaction CashTransaction;
    }

    public class PrxyContractCashTransactionsRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class PrxyCashTransaction
    {
        public decimal AmountWithdrawals;
        public int TotalWithdrawals;
        public decimal AmountContributions;
        public int TotalContributions;
    }
    #endregion

    #region OnDemandCash
    public class PrxyOnDemandCashResponse
    {
        public decimal OnDemandCash;
        public OperationResult Result;
    }

    public class PrxyOnDemandCashRequest
    {
        public string ContractId;
    }
    #endregion

    #region Associated contracts
    public class PrxyAssociateContractsResponse
    {
        public OperationResult Result;
        public List<PrxyAssociatedContract> LstAssociatedContracts;
    }
    public class PrxyAssociateContractsRequest
    {
        public string ClientIdentifier;
    }

    public class PrxyAssociatedContract
    {
        public string ContractId;
        public string AssociatedContractId;
        public int AssociatedType;
    }
    #endregion

    #region contract balance
    public class PrxyContractBalanceRequest
    {
        public string ContractId;
        public int Platform;
        public string AdditionalContributionsContract;
        public string ContractControlContributions;
        public DateTime AfiliationDate;
    }

    public class PrxyContractBalanceResponse
    {
        public decimal ContractBalance;
        public OperationResult Result;
    }
    #endregion

    #region  Contract charges
    public class PrxyContractChargesRequest
    {
        public PrxyContractChargesRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
    }
    public class PrxyContractChargesResponse
    {
        public decimal Charges;
        public OperationResult Result;
    }
    #endregion  Contract charges

    #region  Contract charges by Date
    public class PrxyContractChargesByDateRequest
    {
        public PrxyContractChargesByDateRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
        public DateTime InitialDate { get; set; }
        public DateTime FinalDate { get; set; }
    }
    #endregion

    #region Investments services

    public class PrxyContractBalanceDetailRequest
    {
        public int Platform;
        public List<string> Contracts;
    }

    public class PrxyContractBalanceDetailResponse
    {
        public PrxyInvestments Investments;
        public OperationResult Result;
    }

    public class PrxyInvestments
    {
        public List<PrxyFund> Cash;
        public List<PrxyFund> Funds;
    }

    public class PrxyFund
    {
        public string Id;
        public string ContractId;
        public string Name;
        public PrxyShares Shares;
        public PrxyPrices Prices;
        public PrxMarketValues MarketValues;
    }

    public class PrxMarketValues
    {
        public decimal MarketValue;
        public decimal MarketPurchaseValue;
        public decimal MarketSalesValue;
        public decimal DistributionPercent;
    }

    public class PrxyShares
    {
        public decimal AvailableShares;
        public decimal CommittedShares;
        public decimal CommittedSharesSales;
    }

    public class PrxyPrices
    {
        public decimal Price;
        public decimal PurchasePrice;
        public decimal SalesPrice;
        public DateTime PriceDate;
    }
    #endregion

    #region Realized Contributions
    public class PrxyContractContributionsResponse
    {
        public PrxyContractContributions ContractsContributions { get; set; }
        public OperationResult Result { get; set; }

    }
    public class PrxyContractContributionsRequest
    {
        public PrxyContractContributionsRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
    }
    public class PrxyContractContributions
    {
        public decimal OrdinalContributionsAmount { get; set; }
        public int OrdinalContributionsNumber { get; set; }
        public decimal AdditionalContributionsAmount { get; set; }
        public int AdditionalContributionsNumber { get; set; }
        public DateTime FirstContributionDate { get; set; }
    }
    public class PrxyAssociatedContractMess
    {
        public string ContractId { get; set; }
        public string AssociatedContractId { get; set; }
        public int AssociatedType { get; set; }
    }
    #endregion

    #region Realized Contributions by Date
    public class PrxyContractContributionsByDateRequest
    {
        public PrxyContractContributionsByDateRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
        public DateTime InitialDate { get; set; }
        public DateTime FinalDate { get; set; }
    }
    #endregion

    #region Contract Withdrawals
    public class PrxyContractWithdrawalsRequest
    {
        public PrxyContractWithdrawalsRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }
        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
    }
    public class PrxyContractWithdrawalsResponse
    {
        public PrxyContractWithdrawals ContractWithdrawals;
        public OperationResult Result;
    }
    public class PrxyContractWithdrawals
    {
        public decimal OrdinalWithdrawalsAmount;
        public int OrdinalWithdrawalsNumber;
        public decimal AdditionalWithdrawalsAmount;
        public int AdditionalWithdrawalsNumber;
    }
    #endregion

    #region Contract Withdrawals by Date
    public class PrxyContractWithdrawalsByDateRequest
    {
        public PrxyContractWithdrawalsByDateRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }
        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
        public DateTime InitialDate;
        public DateTime FinalDate;
    }
    #endregion

    #region OnDemandCash2
    public class PrxyOnDemandContributionsResponse
    {
        public PrxyContributionsOnDemand ContributionsOnDemand;
        public OperationResult Result;
    }

    public class PrxyOnDemandContributionsRequest
    {
        public PrxyOnDemandContributionsRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
    }

    public class PrxyContributionsOnDemand
    {
        public decimal OrdinalContributionsOnDemandAmount;
        public decimal AdditionalContributionsOnDemandAmount;
    }
    #endregion

    #region OnDemandCash2ByDate
    public class PrxyOnDemandContributionsByDateRequest
    {
        public PrxyOnDemandContributionsByDateRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
        public DateTime InitialDate;
        public DateTime FinalDate;
    }
    #endregion


    #region ClientIdentifier

    public class PrxyClientIdByContractRequest
    {
        public string ContractId;
    }

    public class PrxyClientIdByContractResponse
    {
        public OperationResult Result;
        public string ClientIdentifier;
    }
    #endregion

    #region ContractInfo
    public class PrxyContractInfoResponse
    {
        public PrxyContractInfo ContractInfo;
        public OperationResult Result;

        public PrxyContractInfoResponse()
        {
            Result = new OperationResult();
        }
        public class PrxyContractInfo
        {
            public string Id;
            public short PlanBasId;
            public int Platform;
            public short GoalId;
            public string ContratoAgrupa;
            public DateTime AfiliationDate;
            public string GoalDescription;
            public int ContractType;
        }

    }

    public class PrxyContractInfoRequest
    {
        public string ContractId;
    }

    #endregion

    #region MovementsCashDetails
    public class PrxyMovementCashDetailsRequest
    {
        public PrxyMovementCashDetailsRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
        public DateTime InitialDate;
        public DateTime FinalDate;
    }
    public class PrxyMovementFundsDetailsRequest
    {
        public PrxyMovementFundsDetailsRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
        public DateTime InitialDate;
        public DateTime FinalDate;
    }

    public class PrxyMovementCashDetailsResponse
    {
        public List<PrxyMovementDetail> ContractCashMovementsDetail;
        public OperationResult Result;
    }
    public class PrxyMovementFundsDetailsResponse
    {
        public List<PrxyMovementDetail> ContractFundsMovementsDetail;
        public OperationResult Result;
    }

    public class PrxyMovementCashDetail
    {
        public string MovementContractId;
        public DateTime MovementProcessDate;
        public string MovementDescription;
        public decimal MovementAmount;
        public string MovementSubaccountName;
        public string MovementBankAccount;
    }


    #endregion MovementsCashDetails

    #region MovementsPendingDetails
    public class PrxyMovementPendingDetailsRequest
    {
        public PrxyMovementPendingDetailsRequest()
        {
            AssociatedContracts = new List<PrxyAssociatedContractMess>();
        }

        public List<PrxyAssociatedContractMess> AssociatedContracts;
        public int Platform;
        public DateTime InitialDate;
        public DateTime FinalDate;
    }

    public class PrxyMovementPendingDetailsResponse
    {
        public List<PrxyMovementDetail> ContractMovementsPendingDetail;
        public OperationResult Result;
    }

    #endregion MovementsCashDetails

    #region "BankAccounts"
    public class PrxyContractBankAccountsRequest
    {
        public string ContractId;
    }

    public class PrxyContractBankAccountsResponse
    {
        public List<PrxyContractBankAccount> ContractBankAccounts;
        public OperationResult Result;
    }

    public class PrxyContractBankAccount
    {
        public int AccountId;
        public int BankId;
        public int BankAccountTypeId;
        public string AccountNumber;
        public string AccountBankName;
        public int AccountUseTypeId;
        public int ClassificationId;
        public DateTime AccountCreatedDate;
        public string AccountDescClasification;
        public string AccountUseType;
    }
    #endregion

    #region "BankAccounts by RFC"
    public class PrxyContractBankAccountsByRfcRequest
    {
        public string RFC { get; set; }

        public PrxyContractBankAccountsByRfcRequest(string rfc)
        {
            RFC = rfc;
        }
    }

    public class PrxyContractBankAccountsByRfcResponse
    {
        public List<PrxyDetailBankAccount> BankAccounts { get; set; }
        public OperationResult Result { get; set; }

        public PrxyContractBankAccountsByRfcResponse(List<PrxyDetailBankAccount> bankAccounts, OperationResult result)
        {
            BankAccounts = bankAccounts;
            Result = result;
        }
    }

    public class PrxyDetailBankAccount
    {
        public string BankName { get; set; }
        public string BankAccount { get; set; }
        public int Usetype { get; set; }
        public string AccountClabe { get; set; }
        public int BankId { get; set; }
        public int TypeAccount { get; set; }
        public List<PrxyContractProduct> Products { get; set; }
        public string AccountStatusDsc { get; set; }
        public string AccountUseTypeDsc { get; set; }

        public PrxyDetailBankAccount(
                string bankName,
                string bankAccount,
                int usetype,
                string accountClabe,
                int bankId,
                int typeAccount,
                List<PrxyContractProduct> products,
                string accountStatusDsc,
                string accountUseTypeDsc
                )
        {
            BankName = bankName;
            BankAccount = bankAccount;
            Usetype = usetype;
            AccountClabe = accountClabe;
            BankId = bankId;
            TypeAccount = typeAccount;
            Products = products;
            AccountStatusDsc = accountStatusDsc;
            AccountUseTypeDsc = accountUseTypeDsc;
        }
    }
    public class PrxyContractProduct
    {
        public string ContractId { get; set; }
        public string ProductName { get; set; }
        public bool IsAccountThird { get; set; }

        public PrxyContractProduct(
                string contractId,
                string productName,
                bool isAccountThird
                )
        {
            ContractId = contractId;
            ProductName = productName;
            IsAccountThird = isAccountThird;
        }
    }
    #endregion

    #region PortfolioProfile
    public class PrxySalesPractClientType
    {
        public string Id;
        public string Description;
    }

    public class PrxyPortfolioProfileResponse
    {
        public PrxySalesPractPortfolioType PortfolioType;
        public OperationResult Result;
    }

    public class PrxyPortfolioProfileRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class PrxySalesPractPortfolioType
    {
        public PrxySalesPractClientType ClientType;
        public string Id;
        public string Description;
    }

    public class PrxySalesPracticeContractProfileRequest
    {
        public string ContractId;
    }
    #endregion

    #region ClientProfile
    public class PxyClientProfileResponse
    {
        public PxyClientProfile ClientProfile;
        public OperationResult Result;
    }

    public class PxyClientProfile
    {
        public string Id;
        public PxyServiceType ServiceType;
    }

    public class PxyServiceType
    {
        public string Id;
        public string Description;
    }

    public class PxyClientProfileRequest
    {
        public string ContractId;
        public int Platform;
    }

    #endregion

    #region Contracs Accepted

    public class PrxyContractsAcceptedGetByRFCResponse
    {
        public List<PrxyContractAccepted> contracts;
        public OperationResult Result;

    }

    public class PrxyContractsAcceptedGetByRFCRequest
    {
        public string Rfc;
    }

    public class PrxyContractsAcceptedUpdateResponse
    {
        public OperationResult Result;
    }

    public class PrxyContractsAcceptedUpdateRequest
    {
        public String Rfc;
        public String ContractId;
        public bool IsCommited;
    }


    public class PrxyCancelChargeResponse
    {
        public OperationResult Result;
        public decimal Charge;
    }

    public class PrxyCancelChargeRequest
    {
        public int ContractObjectiveNumContributions { get; set; }
        public decimal ContractMonthsOnPlan { get; set; }
        public int PlanIdentifier { get; set; }
    }


    public class PrxyContractAccepted
    {
        public int Id;
        public string ContractorRFC;
        public string ContractId;
        public DateTime StartDate;
        public bool FlagActivarPantalla;
        public bool? FlagCompromiso;
        public DateTime? FechaSeleccion;
        public DateTime? FechaVisualizacion;
        public DateTime CreatedDate;
    }

    #endregion

    #region Contracs Periodicity
    public class PrxyContractPeriodicityResponse
    {
        public OperationResult Result;
        public PrxyContractPeriodicity ContractPeriodicity;
    }

    public class PrxyContractPeriodicityRequest
    {
        public String ContractMaster;
    }

    public class PrxyContractPeriodicity
    {
        public String Id;
        public String ContractMaster;
        public int PeriodicityId;
        public String PeriodicityName;
        public int TermMonths;
    }
    #endregion

    #region GetBankCatalog
    public class ProxyGetBankCatalogResponse
    {
        public OperationResult Result { get; set; }
        public List<ProxyBank> Banks { get; set; }

        public ProxyGetBankCatalogResponse()
        {
            Result = new OperationResult();
            Banks = new List<ProxyBank>();
        }
    }

    public class ProxyBank
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string DescriptionShort { get; set; }
        public int Code { get; set; }

        public ProxyBank(
            string id,
            string description,
            string descriptionShort,
            int code
            )
        {
            Id = id;
            Description = description;
            DescriptionShort = descriptionShort;
            Code = code;
        }

    }

    public class ProxyGetBankCatalogRequest
    {
        public int Platform { get; set; }

        public ProxyGetBankCatalogRequest(int platform)
        {
            Platform = platform;
        }
    }
    #endregion

    #region GetPendingContributionAmount
    public class PrxyGetPendingAmountByContractRequest
    {
        public string ContractId { get; set; }
    }

    public class PrxyGetPendingAmountByContractResponse
    {
        public decimal PendingAmount { get; set; }
        public OperationResult Result { get; set; }
    }
    #endregion

    #region GetContributionAmount
    public class PrxyGetContributionSumAmountByContractResponse
    {
        public OperationResult Result { get; set; }
        public decimal ContributionSumAmount { get; set; }
    }

    public class PrxyGetContributionSumAmountByContractRequest
    {
        public string ContractId { get; set; }
    }

    #endregion

    #region GetContractInflation
    public class PrxyGetContractInflationRequest
    {
        public string ContractId { get; set; }
    }

    public class PrxyGetContractInflationResponse
    {
        public PrxyContractInflation ContractInflation { get; set; }
        public OperationResult Result { get; set; }
    }

    public class PrxyContractInflation
    {
        public bool HasAutomaticInflation { get; set; }
        public decimal CustomPercentInflation { get; set; }
    }

    #endregion

    #region BankAccountsAllowDomi

    public class PrxyContractBankAccountsAllowDomiRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
    }
    public class PrxyContractBankAccountsAllowDomiResponse
    {
        public List<PrxyContractBankAccountAllowDomi> ContractBankAccountAllowDomis { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class PrxyContractBankAccountAllowDomi
    {
        public int AccountId { get; set; }
        public string AccountNumber { get; set; }
        public int AccountUseTypeId { get; set; }
        public string AccountUseTypeDsc { get; set; }

        public int BankId { get; set; }
        public string AccountBankName { get; set; }
        public int BankAccountTypeId { get; set; }

        public int ClassificationId { get; set; }
        public string Classification { get; set; }

        public int AccountStatusId { get; set; }
        public string AccountStatus { get; set; }
    }

    #endregion

    #region ContractPeriod
    public class PrxyGetContractPeriodRequest
    {
        public string ContractId { get; set; }
    }


    public class PrxyGetContractPeriodResponse
    {
        public PrxyContractPeriod Period { get; set; }
        public OperationResult Result { get; set; }
    }

    public class PrxyContractPeriod
    {
        public DateTime PeriodStart { get; set; }
        public DateTime PeriodEnd { get; set; }
    }

    #endregion
}

