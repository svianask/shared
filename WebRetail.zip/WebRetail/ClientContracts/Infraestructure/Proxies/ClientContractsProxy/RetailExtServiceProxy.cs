﻿using ClientContractsDomain.BankAccountAggregate;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.PlanAggregate;
using ClientContractsProxy.RetailExtServiceMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientContractsProxy
{
    public class RetailExtServiceProxy : IRetailExtServiceProxy
    {

        private readonly IProxyEngine _proxyEngine;

        public RetailExtServiceProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<RelatedImageInfo> GetGoalsImage(List<short> goalIds, out OperationResult result)
        {
            PrxyGoalsImageRequest request = new PrxyGoalsImageRequest();
            PrxyGoalsImageResponse response = new PrxyGoalsImageResponse();
            result = new OperationResult();
            List<RelatedImageInfo> relatedImages = null;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetGoalsImage"; //Controller/Action

            request.GoalIds = goalIds;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyGoalsImageResponse>(JsonResult);
                relatedImages = RelatedImageInfoMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else
                {
                    throw new ApplicationException("Error al consumir el servicio " + url);
                }

            }

            return relatedImages;
        }

        public List<Plan> GetPlansById(List<short> basPlanIds, out OperationResult result)
        {
            PrxyPlansRequest request = new PrxyPlansRequest();
            PrxyPlansResponse response = new PrxyPlansResponse();
            List<Plan> Plans = new List<Plan>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetPlansById"; //Controller/Action

            request.PlanIds = basPlanIds;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyPlansResponse>(JsonResult);
                Plans = PlansMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else
                {
                    throw new ApplicationException("Error al consumir el servicio " + url);
                }
            }

            return Plans;
        }

        public int GetTypeContract(string contractId, out OperationResult result)
        {
            PrxyTypeOfContractRequest request = new PrxyTypeOfContractRequest();
            PrxyTypeOfContractResponse response = new PrxyTypeOfContractResponse();
            int typeOfContract = 0;

            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetTypeOfContract"; //Controller/Action

            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyTypeOfContractResponse>(JsonResult);
                typeOfContract = response.TypeOfContract;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return typeOfContract;
        }

        public decimal GetLifeInsuranceAmount(string contractId, out OperationResult result)
        {
            PrxyLifeInsuranceAmountRequest request = new PrxyLifeInsuranceAmountRequest();
            PrxyLifeInsuranceAmountResponse response = new PrxyLifeInsuranceAmountResponse();
            decimal lifeInsuranceAmount = 0;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetLifeInsuranceAmount"; //Controller/Action

            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyLifeInsuranceAmountResponse>(JsonResult);
                lifeInsuranceAmount = response.LifeInsuranceAmount;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return lifeInsuranceAmount;
        }

        public ContractExtBasicInfo GetContractExtBasicInfo(string contractId, out OperationResult result)
        {
            var request = new PrxyContractExtBasicInfoRequest() { ContractId = contractId };
            ContractExtBasicInfo contractExtBasicInfo;
            result = new OperationResult() { Successful = true };

            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractExtBasicInfo";

            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyContractExtBasicInfoResponse>(jsonResult);
                contractExtBasicInfo = ContractExtBasicInfoMapp.Mapp(response.ContractExtBasicInfo);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return contractExtBasicInfo;
        }

        public List<string> GetFpContracts(string fpEmail, List<string> clientContractsId, out OperationResult result)
        {
            PrxyFpContractsRequest request = new PrxyFpContractsRequest();
            PrxyFpContractsResponse response = new PrxyFpContractsResponse();
            List<string> contractsFp = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetFpContracts"; //Controller/Action

            request.ClientContractsId = clientContractsId;
            request.FpEmail = fpEmail;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyFpContractsResponse>(JsonResult);
                contractsFp = response.ClientContractsId;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return contractsFp;
        }

        public List<ContractMovementDetail> GetContractPendingContributions(List<AssociatedContract> associatedContracts, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyMovementDetailResponse response = new PrxyMovementDetailResponse();
            PrxyMovementDetailRequest request = new PrxyMovementDetailRequest();
            List<ContractMovementDetail> contractMovementPendingDetails = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractPendingContributions";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.FinalDate = finalDate;
            request.InitialDate = initialDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyMovementDetailResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractMovementPendingDetails = ContractPendingContributuionsMapp.Mapp(response.ContractMovementsPendingDetail);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return contractMovementPendingDetails;
        }

        public int GetContractSegmentType(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            PrxyProductSegmentTypeResponse response = new PrxyProductSegmentTypeResponse();
            PrxyProductSegmentTypeRequest request = new PrxyProductSegmentTypeRequest()
            {
                ContractId = contractId
            };

            int contractSegment;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetContractSegmentType";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyProductSegmentTypeResponse>(JsonResult);
                contractSegment = response.SegmentOfContractType;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return contractSegment;
        }

        public string GetProductComercialName(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            PrxyProductComercialNameRequest request = new PrxyProductComercialNameRequest() { ContractId = contractId };
            PrxyProductComercialNameResponse response;
            String comercialName = String.Empty;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetProductComercialNameByContractId";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyProductComercialNameResponse>(JsonResult);
                comercialName = response.ComercialName;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return comercialName;
        }

        public List<string> GetPlansApplyContribution(out OperationResult result)
        {
            result = new OperationResult();
            var response = new GetProductsApplyContributionsPxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetProductsApplyContributions";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, "", out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetProductsApplyContributionsPxy>(JsonResult);
            }

            return response.ProductsApplyContribution;
        }

        public List<string> GetPlansApplyTransfer(out OperationResult result)
        {
            result = new OperationResult();
            var response = new PlansApplyTransferResponsePrxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetPlansApplyTransfer";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, "", out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PlansApplyTransferResponsePrxy>(JsonResult);
            }

            return response.PlansTransferApply;
        }

        public bool ValidateScheduleTransfer(out OperationResult result)
        {
            result = new OperationResult();
            var response = new ValidateScheduleTransferResponsePrxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/ValidateScheduleTransfer";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, "", out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ValidateScheduleTransferResponsePrxy>(JsonResult);
            }

            return response.Result.Successful;
        }

        public BanksAllowedDomiParameter GetBanksAllowedDomiParameter(out OperationResult result)
        {
            var url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientContracts/GetBanksAllowedDomiParameter";
            var JsonResult = _proxyEngine.SendMSRequestJson(url, "", out result);

            BanksAllowedDomiParameter banksAllowedDomiParameter;
            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<BanksAllowedDomiParameterResponsePrxy>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                banksAllowedDomiParameter = BanksAllowedDomiParameterMapp.Mapp(response.BanksAllowedDomiParameter);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return banksAllowedDomiParameter;
        }
    }
}
