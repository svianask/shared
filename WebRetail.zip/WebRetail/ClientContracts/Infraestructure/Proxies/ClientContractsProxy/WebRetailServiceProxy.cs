﻿using ClientWithdrawalsDomain.PartialWithdrawalsAggregate;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientContractsProxy
{
    public class WebRetailServiceProxy : IWebRetailServiceProxy
    {
        private readonly IProxyEngine _proxyEngine;

        public WebRetailServiceProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public bool ValidateWithdrawalWithinSchudle(out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientWithdrawals/ValidateWithdrawalWithinSchudle";
            var response = new ValidateWithdrawalWithinSchudleResponsePxy();

            string JsonResult = _proxyEngine.SendMSRequestJson(url, "", out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ValidateWithdrawalWithinSchudleResponsePxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.IsValidSchudle;
        }

        public bool ValidatePlanApplyPartialWithdrawals(string planId, int productSegmentId, out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientWithdrawals/ValidatePlanApplyPartialWithdrawals";
            var response = new PlanApplyPartialWithdrawalsResponsePxy();
            var request = new PlanApplyPartialWithdrawalsRequestPxy() { PlanId = planId, ProductSegment = productSegmentId };

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PlanApplyPartialWithdrawalsResponsePxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.ApplyWithdrawals;
        }

        public decimal GetContractSummaryPendingWithdrawals(string contractId, int productSegmentId, out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientWithdrawals/GetContractSummaryPendingWithdrawals";
            var response = new ContractSummaryPendingWithdrawalsResponsePxy();
            var request = new ContractSummaryPendingWithdrawalsRequestPxy() { ContractId = contractId, ProductSegment = productSegmentId };

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ContractSummaryPendingWithdrawalsResponsePxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.SummaryPendingWithdrawals;
        }

        public List<WithdrawalsFund> GetPartialWithdrawalFunds(string contractID, int platform, int productSegmentId, out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientWithdrawals/GetPartialWithdrawalFunds";
            var response = new PartialWithdrawalFundsResponsePxy();
            var request = new PartialWithdrawalFundsRequestPxy() { ContractId = contractID, Platform = platform, ProductSegment = productSegmentId };
            var funds = new List<WithdrawalsFund>();

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PartialWithdrawalFundsResponsePxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                else
                {
                    response.Funds.ForEach(fund =>
                    {
                        var withdrawalFund = WithdrawalsFund.Create(fund.Id, fund.ContractId, fund.Percentage, fund.PendingOperation)
                                .SetInformation(fund.Price, fund.Titles, fund.Valuation);
                        funds.Add(withdrawalFund);
                    });
                }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return funds;
        }

        public decimal ValidateAmountAvailable(string contractId, decimal amountToValidate, int productSegmentId, out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientWithdrawals/ValidateAmountAvailable";
            var response = new AmountAvailableResponsePxy();
            var request = new ValidateAmountAvailableRequestPxy() { ContractId = contractId, AmountToValidate = amountToValidate, ProductSegment = productSegmentId };

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<AmountAvailableResponsePxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.AmountAvailable;
        }

        public bool ValidatePendingTransferContract(string contractId, int platform)
        {
            var isPending = false;

            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientFundTransfer/GetFundOrdersPending";
            var request = new GetFundOrdersPendingRequestPrxy() { ContractId = contractId, Platform = platform };

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GetFundOrdersPendingResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                isPending = response.TransferOrders.Count > 0;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return isPending;
        }

        public decimal GetSaleAmountTransfer(string contractId)
        {
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "ClientFundTransfer/GetFundsforSale";
            var request = new FundsforSaleRequestPrxy() { ContractId = contractId, BaseDate = DateTime.Now };
            decimal saleAmoun = 0;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundsforSaleResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                response.FundsForSale.ForEach(fund => { saleAmoun += fund.AvailableAmount; });
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return saleAmoun;

        }

    }
}
