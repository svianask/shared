﻿using System;
using System.Collections.Generic;
using ClientContractsDomain.BankAccountAggregate;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.PlanAggregate;
using Common.Domain;

namespace ClientContractsProxy
{
    public interface IRetailExtServiceProxy
    {
        List<RelatedImageInfo> GetGoalsImage(List<short> images, out OperationResult result);
        List<Plan> GetPlansById(List<short> basPlanIds, out OperationResult result);
        int GetTypeContract(string contractId, out OperationResult result);
        decimal GetLifeInsuranceAmount(string contractId, out OperationResult result);
        ContractExtBasicInfo GetContractExtBasicInfo(string contractId, out OperationResult result);
        List<string> GetFpContracts(string fpEmail, List<string> clientContractsId, out OperationResult result);
        List<ContractMovementDetail> GetContractPendingContributions(List<AssociatedContract> associatedContracts, DateTime initialDate, DateTime finalDate, out OperationResult result);
        int GetContractSegmentType(string contractId, out OperationResult result);
        string GetProductComercialName(string contractId, out OperationResult result);
        List<string> GetPlansApplyContribution(out OperationResult result);
        List<string> GetPlansApplyTransfer(out OperationResult result);
        bool ValidateScheduleTransfer(out OperationResult result);
        BanksAllowedDomiParameter GetBanksAllowedDomiParameter(out OperationResult result);
    }
}
