﻿using ClientWithdrawalsDomain.PartialWithdrawalsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy
{
    public class ValidateWithdrawalWithinSchudleResponsePxy
    {
        public bool IsValidSchudle { get; set; }
        public OperationResult Result { get; set; }
    }

    public class PlanApplyPartialWithdrawalsResponsePxy
    {
        public OperationResult Result;
        public bool ApplyWithdrawals;
    }

    public class PlanApplyPartialWithdrawalsRequestPxy
    {
        public string PlanId;
        public int ProductSegment;
    }

    public class ContractSummaryPendingWithdrawalsResponsePxy
    {
        public OperationResult Result;
        public decimal SummaryPendingWithdrawals;
    }

    public class ContractSummaryPendingWithdrawalsRequestPxy
    {
        public string ContractId;
        public int ProductSegment;
    }

    public class PartialWithdrawalFundsResponsePxy
    {
        public OperationResult Result;
        public List<WithdrawalsFundPxy> Funds;
    }

    public class PartialWithdrawalFundsRequestPxy
    {
        public string ContractId;
        public int ProductSegment;
        public int Platform;

    }

    public class AmountAvailableResponsePxy
    {
        public OperationResult Result;
        public decimal AmountAvailable;
    }

    public class ValidateAmountAvailableRequestPxy
    {
        public string ContractId;
        public decimal AmountToValidate;
        public int ProductSegment;
    }

    public class WithdrawalsFundPxy
    {
        public string Id;
        public string FundName;
        public decimal Titles;
        public decimal Price;
        public decimal Valuation;
        public decimal Percentage;
        public bool PendingOperation;
        public DateTime LiquiditySaleDate;
        public string ContractId;
    }

    public class GetFundOrdersPendingResponsePrxy
    {
        public List<TransferFundOrderPrxy> TransferOrders;
        public OperationResult Result;
    }

    public class GetFundOrdersPendingRequestPrxy
    {
        public string ContractId;
        public int Platform;
    }

    public class TransferFundOrderPrxy
    {
        public int Id;
        public string EmisionId;
        public int Shares;
        public double Price;
        public double Amount;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public DateTime ProcessDate;
        public int StatusId;
    }

    public class FundsforSaleRequestPrxy
    {
        public string ContractId;
        public DateTime? BaseDate;
    }

    public class FundsforSaleResponsePrxy
    {
        public string ProductComercialName;
        public List<FundForSalePrxy> FundsForSale;
        public OperationResult Result;
    }

    public class FundForSalePrxy
    {
        public decimal SalesPrice;
        public decimal SalesMarketValue;
        public decimal AvailableAmount;
        public decimal Shares;
        public decimal AvailableShares;
        public decimal CommittedShares;
    }
}
