﻿using ClientContractsDomain.ClienContractsAggregate;
using System;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractAcceptedMapp
    {
        public static List<ContractAccepted> Mapp(List<PrxyContractAccepted> contractsPrxy)
        {
            List<ContractAccepted> contracts = new List<ContractAccepted>();
            contractsPrxy.ForEach(contract =>
            {
                ContractAccepted contractTMP = ContractAccepted.Create(contract.Id, contract.ContractorRFC, contract.ContractId, contract.StartDate);
                contracts.Add(contractTMP);
            });
            return contracts;

        }
    }
}
