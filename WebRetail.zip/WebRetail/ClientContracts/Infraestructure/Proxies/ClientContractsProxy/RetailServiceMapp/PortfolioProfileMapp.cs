﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContractsDomain.PortfolioProfileAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class PortfolioProfileMapp
    {
        internal static PortfolioProfile MappPortfolio(string contractId, PrxyPortfolioProfileResponse response)
        {
            return PortfolioProfile
                .Create(
                    identifier: response.PortfolioType.Id,
                    name: response.PortfolioType.Description
                )
                .SetContract(contractId)
                .SetClientProfile(
                    identifier: response.PortfolioType.ClientType.Id,
                    name: response.PortfolioType.ClientType.Description
                );
        }
    }
}
