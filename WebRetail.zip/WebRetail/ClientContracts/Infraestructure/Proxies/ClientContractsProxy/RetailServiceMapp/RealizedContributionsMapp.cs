﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class RealizedContributionsMapp
    {
        internal static RealizedContributions Mapp(PrxyContractContributions contractsContributions)
        {
            return RealizedContributions
                .Create(contractsContributions.OrdinalContributionsAmount, contractsContributions.OrdinalContributionsNumber)
                .SetAdditionalContributions(contractsContributions.AdditionalContributionsAmount, contractsContributions.AdditionalContributionsNumber)
                .SetFirstContributionDate(contractsContributions.FirstContributionDate);
        }
    }
}
