﻿using ClientContractsDomain.BankAccountAggregate;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class BankMapp
    {
        public static List<Bank> Mapp(List<ProxyBank> proxyBanks)
        {
            List<Bank> banks = new List<Bank>();

            proxyBanks.ForEach(b =>
                banks.Add(Bank.Create(
                    b.Id,
                    b.Description,
                    b.DescriptionShort,
                    b.Code
                    ))
            );

            return banks;
        }
    }
}
