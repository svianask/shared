﻿using ClientContractsDomain.ContractInflationAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractInflationMapp
    {
        public static ContractInflation Mapp(PrxyContractInflation prxyContractInflation)
        {
            ContractInflation contractInflation = ContractInflation.CreateEmpty();

            if( prxyContractInflation != null)
            {
                contractInflation = ContractInflation.Create(prxyContractInflation.HasAutomaticInflation, prxyContractInflation.CustomPercentInflation);
            }

            return contractInflation;
        }
    }
}
