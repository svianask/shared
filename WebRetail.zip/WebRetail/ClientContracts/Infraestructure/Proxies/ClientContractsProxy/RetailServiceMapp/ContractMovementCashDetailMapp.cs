﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractPendingContributuionsMapp
    {
        internal static List<ContractMovementDetail> Mapp(List<PrxyMovementDetail> response)
        {
            List<ContractMovementDetail> contractMovementCashDetails = new List<ContractMovementDetail>();

            foreach (PrxyMovementDetail movement in response.OrderByDescending(x => x.MovementProcessDate))
            {
                var movementContract = movement.MovementContractId;
                var movementSubaccountName = movement.MovementSubaccountName;
                var movementDate = movement.MovementProcessDate;
                var movementDescription = movement.MovementDescription;
                var movementBankAccount = movement.MovementBankAccount;
                var movementAmount = movement.MovementAmount;
                ContractMovementDetail movementCashDetail = ContractMovementDetail
                                                                        .Create(movementContract, movementSubaccountName, movementAmount, movementDate, movementBankAccount)
                                                                        .SetMovementDescription(movementDescription);

                contractMovementCashDetails.Add(movementCashDetail);
            }
            return contractMovementCashDetails;
        }
    }
}
