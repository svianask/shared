﻿using ClientContractsDomain.BankAccountAggregate;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class DetailBankAccountMapp
    {
        public static List<DetailBankAccount> Mapp(List<PrxyDetailBankAccount> prxyDetailBankAccount)
        {
            List<DetailBankAccount> bankAccounts = new List<DetailBankAccount>();

            prxyDetailBankAccount.ForEach(f =>
                {
                    var detailBankAccount = DetailBankAccount.Create(f.BankName, f.BankAccount, f.Usetype, f.AccountStatusDsc, f.AccountUseTypeDsc);
                    if (f.Products != null && f.Products.Count > 0)
                        f.Products.ForEach(p => detailBankAccount.AddProduct(p.ProductName, p.ContractId, p.IsAccountThird));

                    bankAccounts.Add(detailBankAccount);
                });

            return bankAccounts;
        }
    }
}
