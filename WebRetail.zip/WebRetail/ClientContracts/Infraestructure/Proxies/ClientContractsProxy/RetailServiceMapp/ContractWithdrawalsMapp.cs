﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractWithdrawalsMapp
    {
        internal static ContractWithdrawals Mapp(PrxyContractWithdrawals contractWithdrawals)
        {
            return ContractWithdrawals
                .Create(contractWithdrawals.OrdinalWithdrawalsAmount, contractWithdrawals.OrdinalWithdrawalsNumber)
                .SetAdditionalWithdrawals(contractWithdrawals.AdditionalWithdrawalsAmount, contractWithdrawals.AdditionalWithdrawalsNumber);
        }
    }
}
