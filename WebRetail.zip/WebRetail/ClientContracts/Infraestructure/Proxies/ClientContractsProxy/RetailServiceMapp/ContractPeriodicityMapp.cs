﻿using ClientContractsDomain.ClienContractsAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractPeriodicityMapp
    {
        public static ContractPeriodicity Mapp( PrxyContractPeriodicity contractsPeriodicityPrxy)
        {
            ContractPeriodicity contractPeriodicity = null;
            contractPeriodicity = ContractPeriodicity.Create(contractsPeriodicityPrxy.Id, contractsPeriodicityPrxy.ContractMaster, contractsPeriodicityPrxy.PeriodicityId, contractsPeriodicityPrxy.PeriodicityName, contractsPeriodicityPrxy.TermMonths);
            return contractPeriodicity;

        }
    }
}
