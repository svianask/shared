﻿

using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractPeriodMapp
    {
        public static ContractPeriod Mapp(PrxyContractPeriod prxyContractPeriod)
        {
            ContractPeriod contractPeriod = ContractPeriod.CreateEmpty();
            
            if( prxyContractPeriod != null)
            {
                contractPeriod = ContractPeriod.Create(prxyContractPeriod.PeriodStart, prxyContractPeriod.PeriodEnd);
            }

            return contractPeriod;
        }
    }
}
