﻿using System;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractInfoMapp
    {
        public static ContractInfo Mapp(PrxyContractInfoResponse prxyResponse)
        {
            string contractId = prxyResponse.ContractInfo.Id;
            short planBasId = prxyResponse.ContractInfo.PlanBasId;
            int platform = prxyResponse.ContractInfo.Platform;
            short goalId = prxyResponse.ContractInfo.GoalId;
            string groupingContractId = prxyResponse.ContractInfo.ContratoAgrupa;
            DateTime afiliationDate = prxyResponse.ContractInfo.AfiliationDate;
            int contractType = prxyResponse.ContractInfo.ContractType;
            string goalDescription = prxyResponse.ContractInfo.GoalDescription;
            return ContractInfo
                        .Create(contractId, planBasId, platform, goalId, groupingContractId)
                        .SetAfiliationDate(afiliationDate)
                        .SetGoalDescription(goalDescription);
                        
        }
    }
}
