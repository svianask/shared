﻿using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class SummaryContributionsMapp
    {
        public static SummaryContributions Mapp(PrxySummaryContributions prxySummaryContributions)
        {
            return SummaryContributions.Create(
                prxySummaryContributions.TotalContributions,
                prxySummaryContributions.ExpectedContributions,
                prxySummaryContributions.RealizedContributions,
                prxySummaryContributions.FailedContributions
                );
        }
    }
}
