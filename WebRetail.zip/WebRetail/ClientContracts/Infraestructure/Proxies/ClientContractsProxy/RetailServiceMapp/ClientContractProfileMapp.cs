﻿using ClientContractsDomain.ClientContractProfileAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ClientContractProfileMapp
    {
        public static ClientContractProfile Mapp(PxyClientProfile pxyClient)
        {
            ClientContractProfile contractProfile = null;
            if(pxyClient != null && pxyClient.ServiceType != null)
            {
                contractProfile = ClientContractProfile.Create(pxyClient.Id)
                    .SetServiceType(pxyClient.ServiceType.Id, pxyClient.ServiceType.Description);
            }
            return contractProfile;
        }
    }
}
