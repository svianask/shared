﻿using System;
using System.Collections.Generic;
using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.InvestmentsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class InvestmentsMapp
    {
        internal static Investments Mapp(PrxyInvestments prxyInvestments)
        {
            List<Fund> cashFunds = FundsMapp.Mapp(prxyInvestments.Cash);
            List<Fund> invstFunds = FundsMapp.Mapp(prxyInvestments.Funds);

            Investments investments = Investments.Create(cashFunds, invstFunds);

            return investments;
        }
    }
}
