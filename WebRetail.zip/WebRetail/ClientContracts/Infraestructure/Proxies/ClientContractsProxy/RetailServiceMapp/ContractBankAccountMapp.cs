﻿using System;
using System.Collections.Generic;
using ClientContractsDomain.BankAccountAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractBankAccountMapp
    {
        public static List<ContractBankAccount> Mapp(List<PrxyContractBankAccount> prxyContractBankAccounts, string contractId)
        {
            List<ContractBankAccount> bankAccounts = new List<ContractBankAccount>();

            prxyContractBankAccounts.ForEach(f =>
                bankAccounts.Add(
                    ContractBankAccount
                        .Create(contractId)
                        .SetAccountData(f.AccountId, f.AccountNumber, f.AccountUseTypeId)
                        .SetBankData(f.BankId, f.AccountBankName, f.BankAccountTypeId)
                        .SetAccountCreatedDate( f.AccountCreatedDate)
                    )
            );

            return bankAccounts;
        }
    }
}
