﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContributionsOnDemandMapp
    {
        internal static ContributionsOnDemand Mapp(PrxyContributionsOnDemand contributionsOnDemand)
        {
            return ContributionsOnDemand
                .Create(contributionsOnDemand.OrdinalContributionsOnDemandAmount)
                .SetAdditionalOnDemandAmount(contributionsOnDemand.AdditionalContributionsOnDemandAmount);
        }
    }
}
