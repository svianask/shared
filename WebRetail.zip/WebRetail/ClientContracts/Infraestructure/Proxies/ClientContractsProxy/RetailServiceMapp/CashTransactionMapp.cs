﻿using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class CashTransactionMapp
    {
        public static CashTransaction Mapp(PrxyCashTransaction prxyCashTransaction)
        {
            return new CashTransaction(
                prxyCashTransaction.AmountWithdrawals,
                prxyCashTransaction.TotalWithdrawals,
                prxyCashTransaction.AmountContributions,
                prxyCashTransaction.TotalContributions
            );
        }
    }
}
