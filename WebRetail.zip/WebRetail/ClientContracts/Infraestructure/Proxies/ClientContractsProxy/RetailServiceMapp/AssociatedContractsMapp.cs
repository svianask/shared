﻿using ClientContractsDomain.ClienContractsAggregate;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class AssociatedContractsMapp
    {
        public static List<AssociatedContract> Mapp(List<PrxyAssociatedContract> lstPrxyAssociatedContracts)
        {
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();

            lstPrxyAssociatedContracts.ForEach(a =>
               associatedContracts.Add(
                   AssociatedContract.Create(a.ContractId, a.AssociatedContractId, a.AssociatedType)
                    )
                );

            return associatedContracts;
        }
    }
}
