﻿using ClientContractsDomain.FundAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class FundsMapp
    {
        public static List<Fund> Mapp(List<PrxyFund> prxyFunds)
        {
            List<Fund> funds = new List<Fund>();

            prxyFunds.ForEach(f =>
                funds.Add(
                    Fund.Create(f.Id, f.Name)
                        .SetMarketValues(f.MarketValues.MarketValue, f.MarketValues.MarketPurchaseValue, f.MarketValues.MarketSalesValue, f.MarketValues.DistributionPercent)
                        .SetContract(f.ContractId)
                        .SetPrices(f.Prices.Price, f.Prices.PurchasePrice, f.Prices.SalesPrice)
                        .SetShares(f.Shares.AvailableShares,f.Shares.CommittedShares,f.Shares.CommittedSharesSales)
                )
            );
            return funds;
        }
    }
}
