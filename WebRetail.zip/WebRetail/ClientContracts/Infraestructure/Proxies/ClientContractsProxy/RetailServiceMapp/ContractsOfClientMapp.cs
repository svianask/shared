﻿using ClientContractsDomain.ClienContractsAggregate;

namespace ClientContractsProxy.RetailServiceMapp
{
    public class ContractsOfClientMapp
    {
        public static ClientContracts Mapp(PrxyContractsResponse contracts, ClientContracts contractsOfClient)
        {
            contracts.ContractsOfClient
                .Contracts.ForEach(x =>
                   contractsOfClient.AddContract(
                           ContractInfo.Create(x.Id, x.PlanBasId, x.Platform, x.GoalId, x.ContratoAgrupa)
                           .SetAfiliationDate(x.AfiliationDate)
                           .SetStatus(x.StatusContract, x.StatusOperation)
                           .SetGoalDescription(x.GoalDescription)
                           .SetApplyDeducible(x.ApplyDeducible)
                    )
                );

            return contractsOfClient;
        }
    }
}
