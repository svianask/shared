﻿using ClientContractsDomain.ContractBankAccountAggregate;
using System.Collections.Generic;

namespace ClientContractsProxy.RetailServiceMapp
{
    public static class ContractBankAccountAllowDomiMapp
    {
        public static List<ContractBankAccountAllowDomi> Mapp(List<PrxyContractBankAccountAllowDomi> prxyContractBankAccountAllowDomis, string contractId, bool maskSensitiveInfo)
        {
            var bankAccountsAllowDomis = new List<ContractBankAccountAllowDomi>();

            prxyContractBankAccountAllowDomis.ForEach(f =>
                bankAccountsAllowDomis.Add(ContractBankAccountAllowDomi
                    .Create(contractId)
                    .SetAccountData(f.AccountId, f.AccountNumber, f.AccountUseTypeId, f.AccountUseTypeDsc)
                    .SetBankData(f.BankId, f.AccountBankName, f.BankAccountTypeId)
                    .SetClassificationAccount(f.ClassificationId, f.Classification)
                    .SetAccountStatusDsc(f.AccountStatusId, f.AccountStatus)
                    .MaskSensitiveInfo(maskSensitiveInfo)
                )
            );

            return bankAccountsAllowDomis;
        }
    }
}
