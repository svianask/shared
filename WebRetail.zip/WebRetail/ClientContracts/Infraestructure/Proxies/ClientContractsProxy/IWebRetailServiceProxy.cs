﻿using ClientWithdrawalsDomain.PartialWithdrawalsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy
{
    public interface IWebRetailServiceProxy
    {
        bool ValidateWithdrawalWithinSchudle(out OperationResult result);
        bool ValidatePlanApplyPartialWithdrawals(string planId, int productSegmentId, out OperationResult result);
        decimal GetContractSummaryPendingWithdrawals(string contractId, int productSegmentId, out OperationResult result);
        List<WithdrawalsFund> GetPartialWithdrawalFunds(string contractID, int platform, int productSegmentId, out OperationResult result);
        decimal ValidateAmountAvailable(string contractId, decimal amountToValidate, int productSegmentId, out OperationResult result);
        bool ValidatePendingTransferContract(string contractId, int platform);
        decimal GetSaleAmountTransfer(string contractId);
    }
}
