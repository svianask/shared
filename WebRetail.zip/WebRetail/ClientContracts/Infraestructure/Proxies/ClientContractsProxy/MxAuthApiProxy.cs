﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ClientContractsProxy
{
    public class MxAuthApiProxy : IMxAuthApiProxy
    {
        private readonly IProxyEngine _proxyEngine;

        public MxAuthApiProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public string GetEncryptText(string text)
        {
            EncrytpTextRequestPrxy request = new EncrytpTextRequestPrxy() { TextToEncrypt = text };
            EncrytpTextResponsePrxy response = new EncrytpTextResponsePrxy();

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "OTP/GetTextEncrypt";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<EncrytpTextResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.TextEcript;
        }

        public string GetEncryptUrlMovements()
        {
            string urlToEncrypt = ConfigurationManager.AppSettings["Url:MovementsLiferay"];
            EncrytpTextRequestPrxy request = new EncrytpTextRequestPrxy() { TextToEncrypt = urlToEncrypt };
            EncrytpTextResponsePrxy response = new EncrytpTextResponsePrxy();

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "OTP/GetTextEncrypt";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<EncrytpTextResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.TextEcript;
        }

        public string GetDecryptText(string textEncrypt)
        {
            DecryptStringRequestPrxy request = new DecryptStringRequestPrxy() { StringTodecrypt = textEncrypt };
            DecryptStringResponsePrxy response = new DecryptStringResponsePrxy();

            string url = ConfigurationManager.AppSettings["AuthenticationService:URLService"].ToString() + "OTP/DecryptString";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<DecryptStringResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.StringDecrypt;
        }
    }
}
