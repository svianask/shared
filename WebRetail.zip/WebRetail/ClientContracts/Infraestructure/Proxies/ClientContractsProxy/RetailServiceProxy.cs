﻿using ClientContractsDomain.BankAccountAggregate;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.ClientContractProfileAggregate;
using ClientContractsDomain.ContractBankAccountAggregate;
using ClientContractsDomain.ContractInflationAggregate;
using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.InvestmentsAggregate;
using ClientContractsDomain.PortfolioProfileAggregate;
using ClientContractsProxy.RetailServiceMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientContractsProxy
{
    public class RetailServiceProxy : IRetailServiceProxy
    {
        private readonly IProxyEngine _proxyEngine;

        public RetailServiceProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ClientContracts GetContracts(string clientIdentifier, out OperationResult result)
        {
            PrxyContractsRequest request = new PrxyContractsRequest();
            PrxyContractsResponse response = new PrxyContractsResponse();
            ClientContracts contractsOfClient = ClientContracts.Create(clientIdentifier);
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContracts";

            request.ClientIdentifier = clientIdentifier;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractsOfClient = ContractsOfClientMapp.Mapp(response, contractsOfClient);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractsOfClient;
        }

        public DateTime GetBeginContractDate(string contractId, int source, out OperationResult result)
        {
            /*
            PrxyBeginContTransDateRequest request = new PrxyBeginContTransDateRequest();
            PrxyBeginContTransDateResponse response = new PrxyBeginContTransDateResponse();
            DateTime contractTransDate = new DateTime(1900, 1, 1);
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetBeginContractTransactionDate";

            request.ContractId = contractId;
            request.Source = source;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyBeginContTransDateResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractTransDate = response.BeginContractTransDate;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractTransDate;
            */
            throw new Exception("Not implemented");
        }

        public SummaryContributions GetSummaryContributionsNumber(string contractId, out OperationResult result)
        {
            PrxySummaryContributionsNumberRequest request = new PrxySummaryContributionsNumberRequest();
            PrxySummaryContributionsNumberResponse response = new PrxySummaryContributionsNumberResponse();
            SummaryContributions summaryContributions = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetSummaryContributionsNumber";

            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxySummaryContributionsNumberResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                summaryContributions = SummaryContributionsMapp.Mapp(response.SummaryContributions);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return summaryContributions;
        }

        public CashTransaction GetContractCashTransactions(string contractId, int platform, out OperationResult result)
        {
            /*    PrxyContractCashTransactionsRequest request = new PrxyContractCashTransactionsRequest();
                PrxyContractCashTransactionsResponse response = new PrxyContractCashTransactionsResponse();
                CashTransaction cashTransaction = null;
                result = new OperationResult();

                string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractCashTransactions";

                request.ContractId = contractId;
                request.Platform = platform;
                string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

                if (result.Successful)
                {
                    response = JsonConvert.DeserializeObject<PrxyContractCashTransactionsResponse>(JsonResult);

                    if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                    cashTransaction = CashTransactionMapp.Mapp(response.CashTransaction);
                }
                else
                {
                    result.Successful = false;
                    throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }

                return cashTransaction;*/
            throw new Exception("Not implemented");
        }

        public decimal GetOnDemandCash(string contractId, out OperationResult result)
        {
            PrxyOnDemandCashRequest request = new PrxyOnDemandCashRequest();
            PrxyOnDemandCashResponse response = new PrxyOnDemandCashResponse();
            decimal onDemandCash = 0M;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetOnDemandCash";

            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyOnDemandCashResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                onDemandCash = response.OnDemandCash;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return onDemandCash;
        }

        public List<AssociatedContract> GetAssociateContracts(string clientIdentifier, out OperationResult result)
        {
            PrxyAssociateContractsRequest request = new PrxyAssociateContractsRequest();
            PrxyAssociateContractsResponse response = new PrxyAssociateContractsResponse();
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetAssociateContracts";

            request.ClientIdentifier = clientIdentifier;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyAssociateContractsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                associatedContracts = AssociatedContractsMapp.Mapp(response.LstAssociatedContracts);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return associatedContracts;
        }

        public decimal GetContractInitBalance(string contractId, int platform, DateTime afiliationDate, string additionalContributionsContract, string contractControlContributions, out OperationResult result)
        {
            PrxyContractBalanceRequest request = new PrxyContractBalanceRequest();
            PrxyContractBalanceResponse response = new PrxyContractBalanceResponse();
            decimal contractBalance = 0M;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInitBalance";

            request.ContractId = contractId;
            request.Platform = platform;
            request.AfiliationDate = afiliationDate;
            request.AdditionalContributionsContract = additionalContributionsContract;
            request.ContractControlContributions = contractControlContributions;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractBalanceResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractBalance = response.ContractBalance;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractBalance;
        }

        public decimal GetContractCharges(List<AssociatedContract> associatedContracts, int platform, out OperationResult result)
        {
            PrxyContractChargesRequest request = new PrxyContractChargesRequest();
            PrxyContractChargesResponse response = new PrxyContractChargesResponse();
            decimal contractCharge = 0M;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractCharges";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractChargesResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractCharge = response.Charges;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractCharge;
        }


        public List<Fund> GetBalanceDetail(int platform, List<string> contracts, out OperationResult result)
        {
            PrxyContractBalanceDetailRequest request = new PrxyContractBalanceDetailRequest();
            PrxyContractBalanceDetailResponse response = new PrxyContractBalanceDetailResponse();
            List<Fund> funds = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBalanceDetail";

            request.Contracts = contracts;
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractBalanceDetailResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                funds = FundsMapp.Mapp(response.Investments.Funds);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return funds;
        }

        public RealizedContributions GetContractContributions(List<AssociatedContract> associatedContracts, int platform, out OperationResult result)
        {
            PrxyContractContributionsResponse response = new PrxyContractContributionsResponse();
            PrxyContractContributionsRequest request = new PrxyContractContributionsRequest();
            RealizedContributions realizedContributions = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractContributions";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractContributionsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                realizedContributions = RealizedContributionsMapp.Mapp(response.ContractsContributions);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return realizedContributions;
        }

        public ContractWithdrawals GetContractWithdrawals(List<AssociatedContract> associatedContracts, int platform, out OperationResult result)
        {
            PrxyContractWithdrawalsResponse response = new PrxyContractWithdrawalsResponse();
            PrxyContractWithdrawalsRequest request = new PrxyContractWithdrawalsRequest();
            ContractWithdrawals contractWithdrawals = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractWithdrawals";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractWithdrawalsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractWithdrawals = ContractWithdrawalsMapp.Mapp(response.ContractWithdrawals);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractWithdrawals;
        }

        public ContributionsOnDemand GetContributionsOnDemand(List<AssociatedContract> associatedContracts, int platform, out OperationResult result)
        {
            PrxyOnDemandContributionsResponse response = new PrxyOnDemandContributionsResponse();
            PrxyOnDemandContributionsRequest request = new PrxyOnDemandContributionsRequest();
            ContributionsOnDemand contributionsOnDemand = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContributionsOnDemand";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyOnDemandContributionsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contributionsOnDemand = ContributionsOnDemandMapp.Mapp(response.ContributionsOnDemand);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contributionsOnDemand;
        }

        public string GetClientIdByContract(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            PrxyClientIdByContractRequest request = new PrxyClientIdByContractRequest();
            PrxyClientIdByContractResponse response = new PrxyClientIdByContractResponse();
            string clientIdentifier = string.Empty;

            request.ContractId = contractId;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetClientIdByContract";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientIdByContractResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                clientIdentifier = response.ClientIdentifier;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientIdentifier;
        }

        public ContractInfo GetContractInfo(string contractId, out OperationResult result)
        {
            PrxyContractInfoRequest request = new PrxyContractInfoRequest();
            PrxyContractInfoResponse response = new PrxyContractInfoResponse();
            ContractInfo contractDetail = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";
            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractInfoResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                contractDetail = ContractInfoMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractDetail;
        }

        public short GetPlanBasId(string contractId, out int platform, out OperationResult result)
        {
            PrxyContractExtBasicInfoRequest request = new PrxyContractExtBasicInfoRequest();
            PrxyContractInfoResponse response = new PrxyContractInfoResponse();
            ContractProductInfo contracProductInfo = null;
            result = new OperationResult();
            short planBasId = 0;
            platform = 0;

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";

            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractInfoResponse>(JsonResult);
                planBasId = response.ContractInfo.PlanBasId;
                platform = response.ContractInfo.Platform;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); }
                else { throw new ApplicationException("Error al consumir el servicio " + url); }
            }

            return planBasId;
        }

        public RealizedContributions GetContractContributionsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyContractContributionsResponse response = new PrxyContractContributionsResponse();
            PrxyContractContributionsByDateRequest request = new PrxyContractContributionsByDateRequest();
            RealizedContributions realizedContributions = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractContributionsByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractContributionsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                realizedContributions = RealizedContributionsMapp.Mapp(response.ContractsContributions);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return realizedContributions;
        }

        public ContributionsOnDemand GetContributionsOnDemandByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyOnDemandContributionsResponse response = new PrxyOnDemandContributionsResponse();
            PrxyOnDemandContributionsByDateRequest request = new PrxyOnDemandContributionsByDateRequest();
            ContributionsOnDemand contributionsOnDemand = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContributionsOnDemandByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyOnDemandContributionsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contributionsOnDemand = ContributionsOnDemandMapp.Mapp(response.ContributionsOnDemand);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contributionsOnDemand;
        }

        public ContractWithdrawals GetContractWithdrawalsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyContractWithdrawalsResponse response = new PrxyContractWithdrawalsResponse();
            PrxyContractWithdrawalsByDateRequest request = new PrxyContractWithdrawalsByDateRequest();
            ContractWithdrawals contractWithdrawals = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractWithdrawalsByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractWithdrawalsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractWithdrawals = ContractWithdrawalsMapp.Mapp(response.ContractWithdrawals);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractWithdrawals;
        }

        public decimal GetContractChargesByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyContractChargesByDateRequest request = new PrxyContractChargesByDateRequest();
            PrxyContractChargesResponse response = new PrxyContractChargesResponse();
            decimal contractCharge = 0M;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractChargesByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractChargesResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractCharge = response.Charges;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractCharge;
        }

        public List<ContractMovementDetail> GetContractDetailCashMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyMovementCashDetailsResponse response = new PrxyMovementCashDetailsResponse();
            PrxyMovementCashDetailsRequest request = new PrxyMovementCashDetailsRequest();
            List<ContractMovementDetail> contractMovementCashDetails = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractDetailCashMovementsByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyMovementCashDetailsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractMovementCashDetails = ContractPendingContributuionsMapp.Mapp(response.ContractCashMovementsDetail);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractMovementCashDetails;
        }
        public List<ContractMovementDetail> GetContractDetailFundsMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyMovementFundsDetailsResponse response = new PrxyMovementFundsDetailsResponse();
            PrxyMovementFundsDetailsRequest request = new PrxyMovementFundsDetailsRequest();
            List<ContractMovementDetail> contractMovementFundsDetails = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractDetailFundsMovementsByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyMovementFundsDetailsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractMovementFundsDetails = ContractPendingContributuionsMapp.Mapp(response.ContractFundsMovementsDetail);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractMovementFundsDetails;
        }


        public List<ContractMovementDetail> GetContractDetailPendingMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            PrxyMovementPendingDetailsResponse response = new PrxyMovementPendingDetailsResponse();
            PrxyMovementPendingDetailsRequest request = new PrxyMovementPendingDetailsRequest();
            List<ContractMovementDetail> contractMovementCashDetails = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractDetailPendingMovementsByDate";

            associatedContracts.ForEach(
                ac => request.AssociatedContracts.Add(
                    new PrxyAssociatedContractMess
                    {
                        ContractId = ac.ContractId,
                        AssociatedContractId = ac.AssociatedContractId,
                        AssociatedType = ac.AssociatedType
                    }
                )
            );
            request.Platform = platform;
            request.InitialDate = initialDate;
            request.FinalDate = finalDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyMovementPendingDetailsResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractMovementCashDetails = ContractPendingContributuionsMapp.Mapp(response.ContractMovementsPendingDetail);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractMovementCashDetails;
        }

        public Investments GetContractBalanceDetail(int platform, List<string> contracts, out OperationResult result)
        {
            PrxyContractBalanceDetailRequest request = new PrxyContractBalanceDetailRequest();
            PrxyContractBalanceDetailResponse response = new PrxyContractBalanceDetailResponse();
            Investments investments = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBalanceDetail";

            request.Contracts = contracts;
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractBalanceDetailResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                investments = InvestmentsMapp.Mapp(response.Investments);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return investments;
        }

        public List<ContractBankAccount> GetContractBankAccounts(string contractId, out OperationResult result)
        {
            PrxyContractBankAccountsRequest request = new PrxyContractBankAccountsRequest() { ContractId = contractId };
            PrxyContractBankAccountsResponse response = new PrxyContractBankAccountsResponse();
            List<ContractBankAccount> bankAccounts = null;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBankAccounts";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractBankAccountsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                bankAccounts = ContractBankAccountMapp.Mapp(response.ContractBankAccounts, contractId);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return bankAccounts;
        }

        public List<DetailBankAccount> GetContractBankAccountsByRfc(string RFC, out OperationResult result)
        {
#pragma warning disable IDE0059 // Asignación innecesaria de un valor
            result = new OperationResult();
#pragma warning restore IDE0059 // Asignación innecesaria de un valor
            var url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBankAccountsByRfc";
            var JsonResult = _proxyEngine.SendMSRequestJson(url, new PrxyContractBankAccountsByRfcRequest(RFC), out result);

            List<DetailBankAccount> bankAccounts;
            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyContractBankAccountsByRfcResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                bankAccounts = DetailBankAccountMapp.Mapp(response.BankAccounts);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return bankAccounts;
        }

        #region call profile proxy
        public PortfolioProfile GetPortfolioProfile(string contractId, int platform, out OperationResult result)
        {
            PrxyPortfolioProfileRequest request = new PrxyPortfolioProfileRequest();
            PrxyPortfolioProfileResponse response = new PrxyPortfolioProfileResponse();

            PortfolioProfile portfolioProfile = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetPortfolioProfile";
            request.ContractId = contractId;
            request.Platform = platform;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyPortfolioProfileResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                portfolioProfile = PortfolioProfileMapp.MappPortfolio(contractId, response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return portfolioProfile;
        }

        public ClientContractProfile GetClientContractProfile(string contractId, int platform, out OperationResult result)
        {
            PxyClientProfileRequest request = new PxyClientProfileRequest() { ContractId = contractId, Platform = platform };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetClientProfile";
            request.ContractId = contractId;
            request.Platform = platform;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            ClientContractProfile profile;
            if (result.Successful)
            {
                PxyClientProfileResponse response = JsonConvert.DeserializeObject<PxyClientProfileResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                profile = ClientContractProfileMapp.Mapp(response.ClientProfile);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return profile;
        }

        #endregion

        public List<ContractAccepted> GetContractsAcceptedByRFC(string rfc, out OperationResult result)
        {
            PrxyContractsAcceptedGetByRFCResponse response = new PrxyContractsAcceptedGetByRFCResponse();
            PrxyContractsAcceptedGetByRFCRequest request = new PrxyContractsAcceptedGetByRFCRequest();
            request.Rfc = rfc;
            List<ContractAccepted> contracts = null;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractsAcceptedByRFC";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractsAcceptedGetByRFCResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contracts = ContractAcceptedMapp.Mapp(response.contracts);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return contracts;
        }

        public void UpdateContractsAccepted(string rfc, string contractId, bool isCommited, out OperationResult result)
        {
            PrxyContractsAcceptedUpdateResponse response = new PrxyContractsAcceptedUpdateResponse();
            PrxyContractsAcceptedUpdateRequest request = new PrxyContractsAcceptedUpdateRequest();
            request.Rfc = rfc;
            request.ContractId = contractId;
            request.IsCommited = isCommited;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/UpdateContractsAccepted";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractsAcceptedUpdateResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
        }

        public decimal GetContractSurrenderCancelPercent(int planIdentifier, int contractObjectiveNumContributions, decimal contractMonthsOnPlan, out OperationResult result)
        {
            decimal percent = 0;
            PrxyCancelChargeResponse response = new PrxyCancelChargeResponse();
            PrxyCancelChargeRequest request = new PrxyCancelChargeRequest();
            request.PlanIdentifier = planIdentifier;
            request.ContractObjectiveNumContributions = contractObjectiveNumContributions;
            request.ContractMonthsOnPlan = contractMonthsOnPlan;

            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientFullSurrender/GetFullSurrenderCancellationChargePercent";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyCancelChargeResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                percent = response.Charge;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return percent;
        }

        public ContractPeriodicity GetContractPeriodicity(string contractMaster, out OperationResult result)
        {
            PrxyContractPeriodicityResponse response = new PrxyContractPeriodicityResponse();
            PrxyContractPeriodicityRequest request = new PrxyContractPeriodicityRequest();
            request.ContractMaster = contractMaster;
            ContractPeriodicity contractPeriodicity = null;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractPeriodicity";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractPeriodicityResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractPeriodicity = ContractPeriodicityMapp.Mapp(response.ContractPeriodicity);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return contractPeriodicity;
        }

        public List<Bank> GetBankCatalog(int platform, out OperationResult result)
        {
            var url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetBankCatalog";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, new ProxyGetBankCatalogRequest(platform), out result);

            List<Bank> banks;
            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ProxyGetBankCatalogResponse>(jsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                banks = BankMapp.Mapp(response.Banks);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return banks;
        }


        public ClientContracts GetContractsActivePaidUp(string clientIdentifier, out OperationResult result)
        {
            ClientContracts contractsOfClient = ClientContracts.Create(clientIdentifier);
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractsActivePaidUp";

            PrxyContractsRequest request = new PrxyContractsRequest() { ClientIdentifier = clientIdentifier };
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyContractsResponse>(JsonResult);

                if (response.Result.Successful)
                {
                    contractsOfClient = ContractsOfClientMapp.Mapp(response, contractsOfClient);
                }
                else
                {
                    result.Successful = false;
                    throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]);
                }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractsOfClient;
        }

        public List<AssociatedContract> GetAssociateContractsActivePaidUp(string clientIdentifier, out OperationResult result)
        {
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            result = new OperationResult() { Successful = true };
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetAssociateContractsActivePaidUp";

            PrxyAssociateContractsRequest request = new PrxyAssociateContractsRequest() { ClientIdentifier = clientIdentifier };
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyAssociateContractsResponse>(JsonResult);

                if (response.Result.Successful)
                {
                    associatedContracts = AssociatedContractsMapp.Mapp(response.LstAssociatedContracts);
                }
                else
                {
                    result.Successful = false;
                    throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]);
                }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return associatedContracts;
        }
        public decimal GetPendingContributionAmount(string contractId, out OperationResult result)
        {
            PrxyGetPendingAmountByContractResponse response = null;
            PrxyGetPendingAmountByContractRequest request = new PrxyGetPendingAmountByContractRequest();
            request.ContractId = contractId;

            decimal amount = 0M;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetPendingAmountByContract";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyGetPendingAmountByContractResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                amount = response.PendingAmount;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return amount;
        }

        public decimal GetContributionSumAmount(string contractId, out OperationResult result)
        {
            PrxyGetContributionSumAmountByContractResponse response = null;
            PrxyGetContributionSumAmountByContractRequest request = new PrxyGetContributionSumAmountByContractRequest();
            request.ContractId = contractId;

            decimal amount = 0M;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContributionSumAmount";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyGetContributionSumAmountByContractResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                amount = response.ContributionSumAmount;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return amount;
        }

        public ContractInflation GetContractInflation(string contractId, out OperationResult result)
        {
            PrxyGetContractInflationRequest request = new PrxyGetContractInflationRequest();
            PrxyGetContractInflationResponse response = null;
            request.ContractId = contractId;

            ContractInflation contractInflation = null;
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInflation";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyGetContractInflationResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractInflation = ContractInflationMapp.Mapp(response.ContractInflation);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return contractInflation;
        }

        public List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier, bool maskSensitiveInfo, out OperationResult result)
        {
            var request = new PrxyContractBankAccountsAllowDomiRequest() { ContractId = contractId, ClientIdentifier = clientIdentifier };
            List<ContractBankAccountAllowDomi> contractBankAccountAllowDomis;
            result = new OperationResult();
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "ClientContracts/GetContractBankAccountsAllowDomi";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyContractBankAccountsAllowDomiResponse>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractBankAccountAllowDomis = ContractBankAccountAllowDomiMapp.Mapp(response.ContractBankAccountAllowDomis, contractId, maskSensitiveInfo);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contractBankAccountAllowDomis;
        }

        public ContractPeriod GetContractPeriodByContract(string contractId, out OperationResult result)
        {
            PrxyGetContractPeriodRequest request = new PrxyGetContractPeriodRequest();
            PrxyGetContractPeriodResponse response = null;
            request.ContractId = contractId;

            ContractPeriod contractPeriod = ContractPeriod.CreateEmpty();

            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractClientPeriod";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyGetContractPeriodResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                contractPeriod = ContractPeriodMapp.Mapp(response.Period);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return contractPeriod;
        }

    }
}
