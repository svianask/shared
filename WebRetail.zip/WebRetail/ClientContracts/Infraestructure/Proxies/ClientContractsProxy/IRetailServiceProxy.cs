﻿using ClientContractsDomain.BankAccountAggregate;
using ClientContractsDomain.ClienContractsAggregate;
using ClientContractsDomain.ClientContractProfileAggregate;
using ClientContractsDomain.ContractBankAccountAggregate;
using ClientContractsDomain.ContractInflationAggregate;
using ClientContractsDomain.FundAggregate;
using ClientContractsDomain.InvestmentsAggregate;
using ClientContractsDomain.PortfolioProfileAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientContractsProxy
{
    public interface IRetailServiceProxy
    {
        ClientContracts GetContracts(string clientIdentifier, out OperationResult result);
        DateTime GetBeginContractDate(string contractId, int source, out OperationResult result);
        SummaryContributions GetSummaryContributionsNumber(string contractId, out OperationResult result);
        CashTransaction GetContractCashTransactions(string contractId, int platform, out OperationResult result);
        decimal GetOnDemandCash(string contractId, out OperationResult result);
        List<AssociatedContract> GetAssociateContracts(string clientIdentifier, out OperationResult result);
        decimal GetContractInitBalance(string contractId, int platform, DateTime afiliationDate, string additionalContributionsContract, string contractControlContributions, out OperationResult result);
        decimal GetContractCharges(List<AssociatedContract> associatedContracts, int platform, out OperationResult result);
        List<Fund> GetBalanceDetail(int platform, List<string> contracts, out OperationResult result);
        RealizedContributions GetContractContributions(List<AssociatedContract> associatedContracts, int platform, out OperationResult result);
        ContractWithdrawals GetContractWithdrawals(List<AssociatedContract> associatedContracts, int platform, out OperationResult result);
        ContributionsOnDemand GetContributionsOnDemand(List<AssociatedContract> associatedContracts, int platform, out OperationResult result);
        string GetClientIdByContract(string contractId, out OperationResult result);
        ContractInfo GetContractInfo(string contractId, out OperationResult result);
        RealizedContributions GetContractContributionsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        ContributionsOnDemand GetContributionsOnDemandByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        ContractWithdrawals GetContractWithdrawalsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        decimal GetContractChargesByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        List<ContractMovementDetail> GetContractDetailCashMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        List<ContractMovementDetail> GetContractDetailFundsMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        List<ContractMovementDetail> GetContractDetailPendingMovementsByDate(List<AssociatedContract> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        Investments GetContractBalanceDetail(int platform, List<string> contracts, out OperationResult result);
        List<ContractBankAccount> GetContractBankAccounts(string contractId, out OperationResult result);
        List<DetailBankAccount> GetContractBankAccountsByRfc(string RFC, out OperationResult result);
        short GetPlanBasId(string contractId, out int platform, out OperationResult result);

        #region call profile proxy
        PortfolioProfile GetPortfolioProfile(string contractId, int platform, out OperationResult result);
        ClientContractProfile GetClientContractProfile(string contractId, int platform, out OperationResult result);
        #endregion

        List<ContractAccepted> GetContractsAcceptedByRFC(string rfc, out OperationResult result);
        void UpdateContractsAccepted(string rfc, string contractId, bool isCommited, out OperationResult result);
        decimal GetContractSurrenderCancelPercent(int planIdentifier, int contractObjectiveNumContributions, decimal contractMonthsOnPlan, out OperationResult result);
        ContractPeriodicity GetContractPeriodicity(string contractMaster, out OperationResult result);
        List<Bank> GetBankCatalog(int platform, out OperationResult result);
        ClientContracts GetContractsActivePaidUp(string clientIdentifier, out OperationResult result);
        List<AssociatedContract> GetAssociateContractsActivePaidUp(string clientIdentifier, out OperationResult result);
        decimal GetPendingContributionAmount(string contractId, out OperationResult result);
        decimal GetContributionSumAmount(string contractId, out OperationResult result);
        ContractInflation GetContractInflation(string contractId, out OperationResult result);
        List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier, bool maskAccountNumber, out OperationResult result);
        ContractPeriod GetContractPeriodByContract(string contractId, out OperationResult result);
    }
}
