﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy
{
    public class EncrytpTextResponsePrxy
    {
        public OperationResult Result;
        public string TextEcript;
    }

    public class EncrytpTextRequestPrxy
    {
        public string TextToEncrypt;
    }

    public class DecryptStringResponsePrxy
    {
        public OperationResult Result;
        public string StringDecrypt;
    }

    public class DecryptStringRequestPrxy
    {
        public string StringTodecrypt;
    }
}
