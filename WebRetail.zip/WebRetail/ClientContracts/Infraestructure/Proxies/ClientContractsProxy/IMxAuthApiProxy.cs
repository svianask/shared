﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContractsProxy
{
    public interface IMxAuthApiProxy
    {
        string GetEncryptText(string text);
        string GetEncryptUrlMovements();
        string GetDecryptText(string textEncrypt);
    }
}
