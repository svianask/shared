﻿using ClientFundTransfer.Application.Cav;
using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using ClientFundTransfer.Proxies;
using Common.Domain;
using Common.Proxy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientFundTransfer.ApplicationTest
{
    [TestClass]
    public class CavTransferFundAdministrationTest
    {
        private readonly Mock<IClientFundTransferRetailPrxy> _retailServiceProxy;

        private readonly CavTransferFundAdministration _cavTransferFundAdministration;

        private OperationResult _result;
        private int _platform;
        private string _userId;
        private string _processId;
        private string _transferId;
        private string _contractId;
        private double _portfolioTitImp;
        private double _portfolioCommitted;
        private double _priceFundAmount;
        private DateTime _priceFundDate;
        private string _fundSource;
        private string _fundTarget;
        private string _fundReinvestment;


        public CavTransferFundAdministrationTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = @"C:\Files\TestWebRetail-.txt";
            ConfigurationManager.AppSettings["ApplyTranferTypePortafolio"] = "10";
            ConfigurationManager.AppSettings["ApplyTransferProductTypes"] = "2";

            _retailServiceProxy = new Mock<IClientFundTransferRetailPrxy>();

            var log = new SeriLogHelper();
            var retailExtServiceProxy = new Mock<IClientFundTransferRetailExtPrxy>();
            var webRetailServiceProxy = new Mock<IClientFundTransferWebRetailPrxy>();
            var parametersProxy = new Mock<IParametersProxy>();
            var proxyEngine = new Mock<IProxyEngine>();
            var notificationsPrxy = new INotificationsPrxy[]
            {
                new NotificationsColombiaPrxy(),
                new SendinBlueNotificationsPrxy(proxyEngine.Object)
            };

            var clientFundWebRetailAuthPrxy = new Mock<IClientFundWebRetailAuthPrxy>();

            _cavTransferFundAdministration = new CavTransferFundAdministration(log, _retailServiceProxy.Object, retailExtServiceProxy.Object, webRetailServiceProxy.Object, parametersProxy.Object, notificationsPrxy, clientFundWebRetailAuthPrxy.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            _result = new OperationResult() { Successful = true };
            _platform = 10;
            _userId = "OCEANS\\MunAnt";
            _processId = Guid.NewGuid().ToString().ToUpper();
            _transferId = Guid.NewGuid().ToString().ToUpper();
            _contractId = "768407";
            _portfolioTitImp = 78397;
            _portfolioCommitted = 1040;
            _priceFundAmount = 1.057722;
            _priceFundDate = DateTime.Now;
            _fundSource = "CAVPLUS12";
            _fundTarget = "SK-DCP B";
            _fundReinvestment = "CAVPLUS12";
        }

        [TestMethod, TestCategory("GetPortfolioFunds")]
        [ExpectedException(typeof(ArgumentException), "El Fondo a buscar no puede estar vacio.")]
        public void GetFundsForSaleEmtpyFund()
        {
            _result = new OperationResult() { Successful = true };
            var portfolioFunds = _cavTransferFundAdministration.GetPortfolioFunds("", _platform, out _result);

            Assert.IsFalse(_result.Successful);
            Assert.IsNull(portfolioFunds);
        }

        [TestMethod, TestCategory("GetPortfolioFunds")]
        public void GetPortfolioFunds()
        {
            _result = new OperationResult() { Successful = true };
            var portfolioFund = PortfolioFundTransfer.Create(_fundSource, _contractId)
                .SetEmision(_fundSource, _fundSource)
                .SetPortfolio(_portfolioTitImp, _portfolioCommitted, (_portfolioTitImp - _portfolioCommitted))
                .SetFund(_priceFundAmount, _priceFundDate)
                .SetFundValue(82922.23);
            var portfolioFunds = new List<PortfolioFundTransfer>() { portfolioFund };

            _retailServiceProxy.Setup(x => x.GetPortfolioFunds(It.IsAny<string>(), It.IsAny<int>(), out _result)).Returns(portfolioFunds);

            var portfolioFundsResult = _cavTransferFundAdministration.GetPortfolioFunds(_fundSource, _platform, out var result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(portfolioFundsResult);
        }

        [TestMethod, TestCategory("GetCavFundsToReprocess")]
        public void GetCavFundsToReprocess()
        {
            _result = new OperationResult() { Successful = true };
            const short processTypeId = (short)FundProcessType.Transfer;
            const int noDaysBefore = 5;

            var mockFundProcesses = new List<FundProcess>()
            {
                FundProcess.Create(_processId, _userId, FundProcessType.Transfer)
            };

            _retailServiceProxy.Setup(x => x.GetCavFundsToReprocess(processTypeId, noDaysBefore, out _result)).Returns(mockFundProcesses);
            var fundProcesses = _cavTransferFundAdministration.GetCavFundsToReprocess(processTypeId, noDaysBefore, out _result);
            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcesses);
        }
    }
}
