﻿using ClientFundTransfer.Application.Cav.Common;
using ClientFundTransfer.Domain.FundTransferValueAggregate;
using ClientFundTransfer.Proxies;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;

namespace ClientFundTransfer.ApplicationTest
{
    [TestClass]
    public class ClientFundTransferAppTest
    {
        private readonly Mock<IClientFundTransferRetailPrxy> _retailServiceProxy;
        private readonly Mock<IClientFundTransferRetailExtPrxy> _retailExtServiceProxy;

        private readonly CavFundAdministrationApp _cavFundAdministrationApp;

        private OperationResult _result;
        private int _platform;
        private string _fundSource;

        public ClientFundTransferAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = @"C:\Files\TestWebRetail-.txt";
            ConfigurationManager.AppSettings["ApplyTranferTypePortafolio"] = "10";
            ConfigurationManager.AppSettings["ApplyTransferProductTypes"] = "2";

            var log = new SeriLogHelper();
            _retailServiceProxy = new Mock<IClientFundTransferRetailPrxy>();
            _retailExtServiceProxy = new Mock<IClientFundTransferRetailExtPrxy>();

            _cavFundAdministrationApp = new CavFundAdministrationApp(log, _retailServiceProxy.Object, _retailExtServiceProxy.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            _result = new OperationResult() { Successful = true };
            _platform = 10;
            _fundSource = "CAVPLUS12";
        }

        [TestMethod, TestCategory("ValidateTransferSchedule")]
        public void ValidateTransferSchedule()
        {
            _result = new OperationResult() { Successful = true };
            var initSchedule = DateTime.Now.AddHours(-5).ToString(CultureInfo.CurrentCulture);
            var endSchedule = DateTime.Now.AddHours(+5).ToString(CultureInfo.CurrentCulture);
            _retailExtServiceProxy.Setup(x => x.ValidateTransferSchedule(out initSchedule, out endSchedule)).Returns(true);
            var fundsTransferValidate = _cavFundAdministrationApp.ValidateTransferSchedule(out _result);
            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundsTransferValidate);
        }

        [TestMethod, TestCategory("GetFundsTrading")]
        public void GetFundsTrading()
        {
            _result = new OperationResult() { Successful = true };

            var baseDate = DateTime.Today;

            var fundsIds = new List<string>() { _fundSource };
            var mockFundTradings = new List<FundTrading>()
            {
                FundTrading.Create(_fundSource)
            };

            _retailServiceProxy.Setup(x => x.GetFundsTrading(fundsIds, _platform, baseDate, out _result)).Returns(mockFundTradings);
            var fundTradings = _cavFundAdministrationApp.GetFundsTrading(fundsIds, _platform, baseDate, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundTradings);
        }

    }
}
