﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientFundTransfer.Application.Cav
{
    public interface ICavReinvestmentFundAdministration
    {
        FundProcess ApplyProcessReinvestmentFund(string userId, int platform, string fundSourceId, string fundTargetId, string fundPreviousId, int nDaysBefore, out OperationResult result);
        List<FundProcess> GetCavFundsToReinvestment(int nDaysBefore, out OperationResult result);
    }
}
