﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientFundTransfer.Application.Cav
{
    public interface ICavTransferFundAdministration
    {
        List<PortfolioFundTransfer> GetPortfolioFunds(string fundId, int platform, out OperationResult result);

        FundProcess ApplyProcessTransferFund(string userId, int platform, string fundSourceId, string fundTargetId, string fundReinvestmentId, out OperationResult result);

        List<FundProcess> GetCavFundsToReprocess(short processTypeId, int nDaysBefore, out OperationResult result);
    }
}
