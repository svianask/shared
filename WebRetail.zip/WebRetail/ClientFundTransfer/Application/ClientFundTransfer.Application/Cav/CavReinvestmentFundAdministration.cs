﻿using ClientFundTransfer.Application.Cav.Common;
using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using ClientFundTransfer.Proxies;
using Common.Domain;
using Common.Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClientFundTransfer.Application.Cav
{
    public sealed class CavReinvestmentFundAdministration : FundAdministrationApp, ICavReinvestmentFundAdministration
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientFundTransferRetailPrxy _retailServiceProxy;

        public CavReinvestmentFundAdministration(ISeriLogHelper log, IClientFundTransferRetailPrxy retailServiceProxy, IClientFundTransferRetailExtPrxy retailExtServiceProxy,
            IClientFundTransferWebRetailPrxy webRetailPrxy, IParametersProxy parametersProxy, INotificationsPrxy[] notificationsPrxy, IClientFundWebRetailAuthPrxy clientFundWebRetailAuthPrxy) : base(log, retailServiceProxy, retailExtServiceProxy, webRetailPrxy, parametersProxy, notificationsPrxy, clientFundWebRetailAuthPrxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
        }

        protected override void CreateCavProcessTransferLog(string processId, string transferId, FundProcessMovement fundProcessMovement)
        {
            _log.Info($"ProcesoId: {processId} - Reinversion: {transferId} - Creando proceso de administracion CAV");
            _log.Debug("{cntx}", fundProcessMovement);
            var ftpCreated = _retailServiceProxy.GenerateCavProcessReinvestment(fundProcessMovement, out var ftpResult);
            _log.Debug("{cntx}", ftpCreated);
            if (!ftpResult.Successful)
            {
                _log.Warn($"ProcesoId: {processId} - Reinversion: {transferId} - Creando proceso de administracion CAV: {ftpResult.ToMessage()}");
            }
            _log.Info($"ProcesoId: {processId} - Proceso de administracion CAV creado correctamente.");
        }

        protected override void UpdateCavProcessTransferLog(string processId, string transferId, FundProcessMovement fundProcessMovement)
        {
            _log.Info($"ProcesoId: {processId} - Reinversion: {transferId} - Actualizando proceso de administracion CAV");
            _log.Debug("{cntx}", fundProcessMovement);
            var ftpUpdated = _retailServiceProxy.UpdateCavProcessReinvestment(fundProcessMovement, out var ftpuResult);
            _log.Debug("{cntx}", ftpUpdated);
            if (!ftpuResult.Successful)
            {
                _log.Warn($"ProcesoId: {processId} - Reinversion: {transferId} - Actualizando proceso de administracion CAV: {ftpuResult.ToMessage()}");
            }
            _log.Info($"ProcesoId: {processId} - Proceso de administracion CAV actualizado correctamente.");
        }

        public FundProcess ApplyProcessReinvestmentFund(string userId, int platform, string fundSourceId, string fundTargetId, string fundPreviousId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El Usuario no puede estar vacio."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }
            if (string.IsNullOrEmpty(fundSourceId)) { throw new ArgumentException("El Fondo Origen no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundTargetId)) { throw new ArgumentException("El Fondo Destino no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundPreviousId)) { throw new ArgumentException("El Fondo Anterior no puede estar vacio."); }
            if (nDaysBefore < 0) { throw new ArgumentException("El numero de dias antes no puede ser menor a 0."); }

            var fProcess = FundProcess.Empty();

            try
            {
                var processId = Guid.NewGuid().ToString().ToUpper();
                _log.Info("Generando programacion de proceso de reinversiones en adminsitracion de fondos {cntx}", processId);

                _log.Info($"ProcesoId: {processId} - Creando proceso de reinversiones CAV");
                fProcess = _retailServiceProxy.GenerateCavProcess(FundProcess.Create(processId, userId, FundProcessType.Reinvestment).SetFund(fundSourceId, fundTargetId), out var fpResult);
                _log.Debug("{cntx}", fProcess);
                if (!fpResult.Successful)
                {
                    result.Successful = false;
                    result.SystemMessages.AddRange(fpResult.SystemMessages);
                    return fProcess;
                }
                _log.Info($"ProcesoId: {processId} - Proceso de reinversiones CAV creado correctamente, se ejecutara en el servidor; espere actualizaciones.");

                Task.Run(() => PreProcessFundToApply(processId, fProcess, userId, platform, fundPreviousId, nDaysBefore));
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al programar proceso de reinversiones en adminsitracion de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al programar proceso de reinversiones en adminsitracion de fondos" + ex.Message });
            }

            return fProcess;
        }

        public List<FundProcess> GetCavFundsToReinvestment(int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (nDaysBefore < 0) { throw new ArgumentException("El filtro de numero de dias antes para buscar transferencias no puede ser menor a 0."); }
            var fundProcesses = new List<FundProcess>();

            try
            {
                _log.Info("Consultando fondos para reinvertir en adminsitracion de fondos {cntx}", nDaysBefore);
                fundProcesses = _retailServiceProxy.GetCavFundsToReinvestment(nDaysBefore, out var fpResult);
                _log.Debug("{cntx}", fundProcesses);
                if (!fpResult.Successful)
                {
                    result.Successful = false;
                    result.SystemMessages.AddRange(fpResult.SystemMessages);
                    return fundProcesses;
                }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar fondos para reinvertir en adminsitracion de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al consultar fondos para reinvertir en adminsitracion de fondos" + ex.Message });
            }

            return fundProcesses;
        }

        private void PreProcessFundToApply(string processId, FundProcess fundProcess, string userId, int platform, string fundPreviousId, int nDaysBefore)
        {
            try
            {
                _log.Info($"ProcesoId: {processId} - Obteniendo la información detallada de Plataforma-{platform} / FundBridge-{fundProcess.FundSource} / FundReinvestment-{fundProcess.FundTarget} para proceso de administracion de fondos");
                var portfolioFunds = GetPortfolioFundsToReinvestment(fundProcess.FundSource, fundProcess.FundTarget, fundPreviousId, nDaysBefore, out var pfresult);
                _log.Debug("{cntx}", portfolioFunds);
                if (!pfresult.Successful)
                {
                    _log.Warn($"ProcesoId: {processId} - Obteniendo la información detallada de Plataforma-{platform} / FundBridge-{fundProcess.FundSource} / FundReinvestment-{fundProcess.FundTarget} para proceso de administracion de fondos: {pfresult.ToMessage()}");
                    FinalizeCavProcessLog(processId, fundProcess.EndProcess("Error al programar proceso de transferencia en adminsitracion de fondos"));
                    return;
                }

                var transferredContracts = ApplyProcessFund(processId, fundProcess, userId, platform, portfolioFunds);

                PostProcessFundToApply(processId, fundProcess, transferredContracts, userId, platform, fundPreviousId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al preparar el proceso de transferencias en adminsitracion de fondos");
            }
        }

        private List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (string.IsNullOrEmpty(fundBridge)) { throw new ArgumentException("El Fondo Puente a buscar no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundReinvestment)) { throw new ArgumentException("El Fondo Reinversion a buscar no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundPreviousId)) { throw new ArgumentException("El Fondo Previo a buscar no puede estar vacio."); }
            if (nDaysBefore < 0) { throw new ArgumentException("El filtro de numero de dias antes para buscar transferencias no puede ser menor a 0."); }

            var portfolioFunds = new List<PortfolioFundReinvestment>();

            try
            {
                _log.Info($"Obteniendo la información detallada de FondoPuente-{fundBridge} - FondoReinversion-{fundReinvestment} - FondoPrevio-{fundPreviousId}");
                portfolioFunds = _retailServiceProxy.GetPortfolioFundsToReinvestment(fundBridge, fundReinvestment, fundPreviousId, nDaysBefore, out result);
                if (!result.Successful)
                {
                    _log.Warn($"Obteniendo la información detallada de FondoPuente-{fundBridge} - FondoReinversion-{fundReinvestment} - FondoPrevio-{fundPreviousId}: {result.ToMessage()}");
                }
                _log.Debug("{cntx}", portfolioFunds);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los fondos" + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return portfolioFunds;
        }

        private void PostProcessFundToApply(string processId, FundProcess fundProcess, List<string> transferredContracts, string userId, int platform, string fundPreviousId)
        {
            try
            {
                foreach (var transferredContract in transferredContracts)
                {
                    var fundAdministration = FundAdministration
                        .Create(fundPreviousId, transferredContract, userId)
                        .SetFundReinvestment(fundProcess.FundTarget)
                        .SetReinvestmentProcessLogId(processId);
                    _log.Info($"ProcesoId: {processId} - Actualizando la información para Administacion del CAV de Plataforma-{platform} / FundBridge-{fundProcess.FundSource} / FundReinvestment-{fundProcess.FundTarget} / Contrato-{transferredContract}");
                    _log.Debug("{cntx}", fundAdministration);
                    var resultFundAdministration = _retailServiceProxy.UpdateCavAdministration(fundAdministration, out var faResult);
                    if (!faResult.Successful)
                    {
                        _log.Warn($"ProcesoId: {processId} - Actualizando la información para Administacion del CAV de Plataforma-{platform} / FundBridge-{fundProcess.FundSource} / FundReinvestment-{fundProcess.FundTarget} / Contrato-{transferredContract} : {faResult.ToMessage()}");
                        continue;
                    }

                    _log.Debug("Generado: {cntx}", resultFundAdministration);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar la información para Administacion del CAV");
            }
        }
    }
}
