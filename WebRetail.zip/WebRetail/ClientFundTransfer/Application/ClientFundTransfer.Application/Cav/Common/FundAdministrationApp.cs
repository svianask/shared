﻿using ClientFundTransfer.Domain.FundAllocationAggregate;
using ClientFundTransfer.Domain.FundOrderAggregate;
using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.FundsForSaleAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using ClientFundTransfer.Messages;
using ClientFundTransfer.Proxies;
using Common.Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClientFundTransfer.Application.Cav.Common
{
    public abstract class FundAdministrationApp : ClientFundTransferApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientFundTransferRetailPrxy _retailServiceProxy;

        protected List<FundTransferredOrder> FundTransferredOrders;
        protected FundAdministrationApp(ISeriLogHelper log, IClientFundTransferRetailPrxy retailServiceProxy, IClientFundTransferRetailExtPrxy retailExtServiceProxy,
            IClientFundTransferWebRetailPrxy webRetailPrxy, IParametersProxy parametersProxy, INotificationsPrxy[] notificationsPrxy, IClientFundWebRetailAuthPrxy clientFundWebRetailAuthPrxy) : base(log, retailServiceProxy, retailExtServiceProxy, webRetailPrxy, parametersProxy, notificationsPrxy, clientFundWebRetailAuthPrxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
            FundTransferredOrders = new List<FundTransferredOrder>();
        }

        protected abstract void CreateCavProcessTransferLog(string processId, string transferId, FundProcessMovement fundProcessMovement);

        protected abstract void UpdateCavProcessTransferLog(string processId, string transferId, FundProcessMovement fundProcessMovement);

        protected List<string> ApplyProcessFund(string processId, FundProcess fundProcess, string userId, int platform, IEnumerable<PortfolioFund> portfolioFunds)
        {
            var transferredContracts = new List<string>();
            try
            {
                InitCavProcessLog(processId, fundProcess);

                foreach (var portfolioFund in portfolioFunds)
                {
                    FundTransferredOrders = new List<FundTransferredOrder>();
                    var transferId = Guid.NewGuid().ToString().ToUpper();
                    var fundProcessMovement = FundProcessMovement.Create(transferId, processId, portfolioFund.ContractId, userId)
                        .SetPorfolio(portfolioFund.PortfolioTitImp, portfolioFund.PortfolioCommitted)
                        .InitMovement();
                    CreateCavProcessTransferLog(processId, transferId, fundProcessMovement);

                    var amountToTransfer = Math.Round((portfolioFund.PortfolioTitImp - portfolioFund.PortfolioCommitted) * portfolioFund.PriceFundAmount, 2);
                    if (amountToTransfer <= 0)
                    {
                        _log.Warn($"ProcesoId: {processId} - ContractId: {portfolioFund.ContractId} - Ejecucion de proceso de administracion CAV - No hay titulos disponibles para transferir:");
                        _log.Warn("{cntx}", portfolioFund);
                        UpdateCavProcessTransferLog(processId, transferId, fundProcessMovement.EndMovement(string.Empty));
                        continue;
                    }

                    _log.Info($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - ValidateApplyFundsTransfer");
                    var validateTransferContract = ValidateApplyFundsTransfer(portfolioFund.ContractId, out var pfResult);
                    _log.Debug("{cntx}", validateTransferContract);
                    if (!pfResult.Successful || !validateTransferContract.IsTransferValidate)
                    {
                        _log.Warn($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - ValidateApplyFundsTransfer: {validateTransferContract?.MessageMotive ?? string.Empty} - {pfResult.ToMessage()}");

                        UpdateCavProcessTransferLog(processId, transferId, fundProcessMovement.EndMovement($"ValidateApplyFundsTransfer: {validateTransferContract?.MessageMotive ?? string.Empty} - {pfResult.ToMessage()}"));
                        continue;
                    }
                    _log.Info($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - ValidateApplyFundsTransfer Exitosa: {validateTransferContract.IsTransferValidate}");

                    _log.Info($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - ApplyFundsTransferManyToMany");
                    var transferContractResult = ApplyFundsTransferManyToMany(portfolioFund.ContractId, userId,
                        new FundsTransferValuesReq()
                        {
                            SourceInvestmentFunds = new List<FundTransferMess>()
                                { new FundTransferMess() { Id = fundProcess.FundSource, Amount = amountToTransfer } },
                            TargetInvestmentFunds = new List<FundTransferMess>()
                                { new FundTransferMess() { Id = fundProcess.FundTarget, Amount = amountToTransfer } },
                        });
                    _log.Debug("{cntx}", transferContractResult);
                    if (!transferContractResult.Successful)
                    {
                        _log.Warn($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - ApplyFundsTransferManyToMany: {transferContractResult.ToMessage()}");
                        UpdateCavProcessTransferLog(processId, transferId, fundProcessMovement.EndMovement($"ApplyFundsTransferManyToMany: {transferContractResult.ToMessage()}"));
                        continue;
                    }
                    _log.Info($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - ApplyFundsTransferManyToMany Exitosa: {transferContractResult.Successful}");
                    transferredContracts.Add(portfolioFund.ContractId);

                    var targetPortfolioTransferred = GetTargetPortfolioTransferred(portfolioFund.ContractId, platform, fundProcess.FundTarget);
                    var sourcePortfolioTransferred = GetSourcePortfolioTransferred(portfolioFund.ContractId, platform, fundProcess.FundSource);

                    _log.Debug($"ProcesoId: {processId} - Transferencia: {transferId} - Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: ");
                    _log.Debug("{CNTX}", targetPortfolioTransferred);
                    _log.Debug("{CNTX}", sourcePortfolioTransferred);

                    UpdateCavProcessTransferLog(processId, transferId, fundProcessMovement.SetPortfolioTransferred(targetPortfolioTransferred.Shares, targetPortfolioTransferred.OrderId).SetSourcePortfolioTransferred(sourcePortfolioTransferred.Shares, sourcePortfolioTransferred.OrderId).EndMovement(string.Empty));
                }

                FinalizeCavProcessLog(processId, fundProcess.EndProcess(string.Empty));
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al programar proceso de transferencia en adminsitracion de fondos");
                try
                {
                    FinalizeCavProcessLog(processId, fundProcess.EndProcess("Error al programar proceso de transferencia en adminsitracion de fondos"));
                }
                catch (Exception e)
                {
                    _log.Error(e, "Error al actualizar proceso de transferencia en adminsitracion de fondos");
                }
            }

            return transferredContracts;
        }

        protected override void ApplyDistributionFunds(FundsTransferValuesReq fundsTransferValuesReq, List<FundForSale> fundForSales, string transactionId, DateTime baseDate, FundAllocationDistribution clientPortafolio)
        {
            _log.Info("Administracion CAV No Aplica actualizacion de distribucion del portafolio.");
        }

        private FundTransferredOrder GetTargetPortfolioTransferred(string contractId, int platform, string fundTargetId)
        {
            var transferredOrder = FundTransferredOrder.Empty();
            try
            {
                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: FundTargetId: {fundTargetId} - ContractId: {contractId} - Platform: {platform} - FundTransferredOrders:");
                _log.Debug("{CNTX}", FundTransferredOrders);

                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: FundTargetId: {fundTargetId} - ContractId: {contractId} - Platform: {platform}");
                var targetTransferredOrder = FundTransferredOrders.Find(m => m.EmisionId == fundTargetId && m.ContractId == contractId);
                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: FundTargetId: {fundTargetId} - ContractId: {contractId} - Platform: {platform} - TransferredOrder:");
                _log.Debug("{CNTX}", targetTransferredOrder);

                transferredOrder = targetTransferredOrder != null ? FundTransferredOrder.Create(targetTransferredOrder.OrderId, targetTransferredOrder.EmisionId, targetTransferredOrder.ContractId, targetTransferredOrder.Shares) : FundTransferredOrder.Empty();
                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred FundTargetId: {fundTargetId} - ContractId: {contractId} - Platform: {platform} - FundTransferredOrders:");
                _log.Debug("{CNTX}", transferredOrder);
            }
            catch (Exception ex)
            {
                _log.Error(ex, $"Error al obtener el portafolio transferido del contrato: {contractId}");
            }

            return transferredOrder;
        }

        private void InitCavProcessLog(string processId, FundProcess fundProcess)
        {
            _log.Info($"ProcesoId: {processId} - Iniciando proceso de administracion CAV");
            fundProcess.InitProcess();
            _log.Debug("{cntx}", fundProcess);
            var fpUpdate = _retailServiceProxy.UpdateCavProcess(fundProcess, out var fpuResult);
            _log.Debug("{cntx}", fpUpdate);
            if (!fpuResult.Successful)
            {
                _log.Warn($"ProcesoId: {processId} - Iniciando proceso de administracion CAV: {string.Join(",", fpuResult.SystemMessages.Select(s => s.Message))}");
                return;
            }
            _log.Info($"ProcesoId: {processId} - Proceso de administracion CAV iniciado");
        }

        protected void FinalizeCavProcessLog(string processId, FundProcess fundProcess)
        {
            _log.Info($"ProcesoId: {processId} - Finalizando proceso de administracion CAV");
            _log.Debug("{cntx}", fundProcess);
            var fpUpdate = _retailServiceProxy.UpdateCavProcess(fundProcess, out var fptResult);
            _log.Debug("{cntx}", fpUpdate);
            if (!fptResult.Successful)
            {
                _log.Warn($"ProcesoId: {processId} - Ejecucion de proceso de administracion CAV - Programacion: {string.Join(",", fptResult.SystemMessages.Select(s => s.Message))}");
            }
            _log.Info($"ProcesoId: {processId} - Proceso de administracion CAV finalizado");
        }

        protected override void TrackFundTransferOrderAdded(int orderId, TransferOrder transferOrder)
        {
            _log.Info($"Registrando FundTransferOrder: OrderId/{orderId}-EmisionId/{transferOrder.EmisionId}-ContractId/{transferOrder.ContractId}-Shares/{transferOrder.Shares}");
            _log.Info($"Registrando FundTransferOrder: OrderId/{orderId}-ProcessDate/{transferOrder.ProcessDate}-LiquidationDate/{transferOrder.LiquidationDate}-OperationDate/{transferOrder.OperationDate}");
            _log.Debug("{CNTX}", transferOrder);
            FundTransferredOrders.Add(FundTransferredOrder.Create(orderId, transferOrder.EmisionId, transferOrder.ContractId, (double)transferOrder.Shares));
        }

        private FundTransferredOrder GetSourcePortfolioTransferred(string contractId, int platform, string fundSourceId)
        {
            var transferredOrder = FundTransferredOrder.Empty();
            try
            {
                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: FundSourceId: {fundSourceId} - ContractId: {contractId} - Platform: {platform} - FundTransferredOrders:");
                _log.Debug("{CNTX}", FundTransferredOrders);

                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: FundSourceId: {fundSourceId} - ContractId: {contractId} - Platform: {platform}");
                var sourceTransferredOrder = FundTransferredOrders.Find(m => m.EmisionId == fundSourceId && m.ContractId == contractId);
                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred: FundSourceId: {fundSourceId} - ContractId: {contractId} - Platform: {platform} - TransferredOrder:");
                _log.Debug("{CNTX}", sourceTransferredOrder);

                transferredOrder = sourceTransferredOrder != null ? FundTransferredOrder.Create(sourceTransferredOrder.OrderId, sourceTransferredOrder.EmisionId, sourceTransferredOrder.ContractId, sourceTransferredOrder.Shares) : FundTransferredOrder.Empty();
                _log.Info($"Ejecucion de proceso de administracion CAV - GetPortfolioTransferred FundSourceId: {fundSourceId} - ContractId: {contractId} - Platform: {platform} - FundTransferredOrders:");
                _log.Debug("{CNTX}", transferredOrder);
            }
            catch (Exception ex)
            {
                _log.Error(ex, $"Error al obtener el portafolio transferido del contrato: {contractId}");
            }

            return transferredOrder;
        }
    }
}
