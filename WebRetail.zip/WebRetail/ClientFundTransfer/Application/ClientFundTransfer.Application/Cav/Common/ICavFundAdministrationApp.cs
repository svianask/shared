﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.FundTransferValueAggregate;
using ClientFundTransfer.Messages;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Application.Cav.Common
{
    public interface ICavFundAdministrationApp
    {
        FundProcessValidate ValidateTransferSchedule(out OperationResult result);

        List<FundTrading> GetFundsTrading(List<string> fundsId, int platform, DateTime? baseDate, out OperationResult result);

        List<FundAdministration> GetClientAdministration(List<string> funds, out OperationResult result);

        List<FundAdministration> UpdateCavClientAdministration(List<FundClientAdministration> fundClientAdministrations, out OperationResult result);

        DateTime GetBusinessDateDaysBefore(int nDaysBefore, DateTime currentDate, out OperationResult result);

        List<FundAdministrationConfig> GetFundsAdministrationConfig(int nMonthsLater, out OperationResult result);
    }
}
