﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.FundTransferValueAggregate;
using ClientFundTransfer.Messages;
using ClientFundTransfer.Proxies;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Threading;

namespace ClientFundTransfer.Application.Cav.Common
{
    public class CavFundAdministrationApp : ICavFundAdministrationApp
    {

        private readonly ISeriLogHelper _log;
        private readonly IClientFundTransferRetailPrxy _retailServiceProxy;
        private readonly IClientFundTransferRetailExtPrxy _retailExtServiceProxy;

        protected delegate bool DelValidateScheduleTransfer(out string initSchedule, out string endSchedule);

        public CavFundAdministrationApp(ISeriLogHelper log, IClientFundTransferRetailPrxy retailServiceProxy, IClientFundTransferRetailExtPrxy retailExtServiceProxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
            _retailExtServiceProxy = retailExtServiceProxy;
        }

        public FundProcessValidate ValidateTransferSchedule(out OperationResult result)
        {
            FundProcessValidate transferValidate = null;
            result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Validando el horario para la transferencia");
                DelValidateScheduleTransfer delValidateScheduleTransfer = _retailExtServiceProxy.ValidateTransferSchedule;
                var asyncValidateScheduleTransfer = delValidateScheduleTransfer.BeginInvoke(out var initSchedule, out var endSchedule, null, null);
                while (!asyncValidateScheduleTransfer.IsCompleted) { Thread.Sleep(20); }
                var applySchedule = delValidateScheduleTransfer.EndInvoke(out initSchedule, out endSchedule, asyncValidateScheduleTransfer);
                _log.Debug("Aplica horario para transferencia {cntx}", applySchedule);
                transferValidate = FundProcessValidate.Create(initSchedule, endSchedule)
                    .SetApplySchedule(applySchedule)
                    .ValidateApplyTransfer();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al validar si permite transferencias en administracion de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al validar si permite transferencias en administracion de fondos" + ex.Message });
            }

            return transferValidate;
        }

        public List<FundTrading> GetFundsTrading(List<string> fundsId, int platform, DateTime? baseDate, out OperationResult result)
        {
            var fundTradings = new List<FundTrading>();
            if (fundsId.Count <= 0) { throw new ArgumentException("El listado de fondos a buscar no contiene items."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }
            if (baseDate is null) { throw new ArgumentException("La fecha no puede ser nula."); }
            result = new OperationResult() { Successful = true };

            try
            {
                baseDate = baseDate ?? DateTime.Today;
                _log.Info("Consulta la configuracion de fondos para Compra/Venta");
                _log.Info("Fecha({baseDate})-Plataforma({platform}): Consulta la configuracion de fondos para venta/compra: {fundsId} ", baseDate, platform, fundsId);
                fundTradings = _retailServiceProxy.GetFundsTrading(fundsId, platform, baseDate, out result);
                if (!result.Successful)
                {
                    _log.Warn("Fecha({baseDate})-Plataforma({platform}): Consulta la configuracion de fondos para venta/compra: {fundsId} ", baseDate, platform, fundsId, result.ToMessage());
                }
                _log.Debug("Fecha({baseDate})-Plataforma({platform}): Consulta la configuracion de fondos para venta/compra: {fundsId} ", baseDate, platform, fundsId, fundTradings);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al validar si permite la consulta la configuracion de fondos para Compra/Venta en administracion de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al validar si permite la consulta la configuracion de fondos para Compra/Venta en administracion de fondos" + ex.Message });
            }

            return fundTradings;
        }

        public List<FundAdministration> GetClientAdministration(List<string> funds, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (funds.Count <= 0) { throw new ArgumentException("El listado de fondos a buscar no contiene elementos."); }
            var fundAdministrations = new List<FundAdministration>();

            try
            {
                _log.Info("Obteniendo la información detallada de CAV administacion de clientes {cntx}", funds);
                fundAdministrations = _retailServiceProxy.GetClientAdministration(funds, out var fpResult);
                _log.Debug("{cntx}", fundAdministrations);
                if (!fpResult.Successful)
                {
                    result.Successful = false;
                    result.SystemMessages.AddRange(fpResult.SystemMessages);
                    return fundAdministrations;
                }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de CAV administacion de clientes");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener la información de CAV administacion de clientes" + ex.Message });
            }

            return fundAdministrations;
        }

        public List<FundAdministration> UpdateCavClientAdministration(List<FundClientAdministration> fundClientAdministrations, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var faResult = new List<FundAdministration>();

            try
            {
                foreach (var clientAdministration in fundClientAdministrations)
                {
                    var fundAdministration = FundAdministration.Create(clientAdministration.FundSource, clientAdministration.ContractId, clientAdministration.UserId)
                        .SetStatus(clientAdministration.IsReinvestment);

                    _log.Info($"CAV Generado AdministrationId-{fundAdministration.Id} / ProcesoId-{fundAdministration.FundSource} / ContractId-{fundAdministration.ContractId} / UsuarioId-{fundAdministration.UserId} / StatusId-{fundAdministration.StatusId}");
                    var cavClientAdministration = _retailServiceProxy.UpdateCavClientAdministration(fundAdministration, out var fpResult);
                    _log.Debug("{cntx}", cavClientAdministration);
                    if (!fpResult.Successful)
                    {
                        _log.Warn("Error al guardar la información de administacion de clientes {cntx}", fpResult.ToMessage());
                        continue;
                    }

                    faResult.Add(cavClientAdministration);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al guardar la información de administacion de clientes");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al guardar la información de administacion de clientes" + ex.Message });
            }

            return faResult;
        }

        public DateTime GetBusinessDateDaysBefore(int nDaysBefore, DateTime currentDate, out OperationResult result)
        {

            result = new OperationResult() { Successful = true };
            if (nDaysBefore < 0) { throw new ArgumentException("El filtro de numero de dias antes no puede ser menor a 0."); }
            var businessDate = currentDate.Date;

            try
            {
                _log.Info($"Calcular la fecha habil dias antes de nDaysBefore-{nDaysBefore} / currentDate-{currentDate.ToShortDateString()}");
                businessDate = _retailServiceProxy.GetBusinessDateDaysBefore(nDaysBefore, currentDate, out result);
                if (!result.Successful)
                {
                    _log.Warn($"Calcular la fecha habil dias antes de nDaysBefore-{nDaysBefore} / currentDate-{currentDate.ToShortDateString()}: {result.ToMessage()}");
                }

                _log.Debug("{cntx}", businessDate);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Calcular la fecha habil dias antes");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage
                    {
                        Message = "Calcular la fecha habil dias antes: " + ex.Message,
                        MessageType = SystemMessageTypes.Error
                    }
                );
            }

            return businessDate;
        }

        public List<FundAdministrationConfig> GetFundsAdministrationConfig(int nMonthsLater, out OperationResult result)
        {

            result = new OperationResult() { Successful = true };
            if (nMonthsLater < 0) { throw new ArgumentException("El filtro de numero de meses no puede ser menor a 0."); }

            var cavFundConfigs = new List<FundAdministrationConfig>();
            try
            {
                var baseDate = DateTime.Today;
                _log.Info($"Consultar el listado de fondos proximos a liquidar: nDaysBefore-{nMonthsLater} / currentDate-{baseDate.ToShortDateString()}");
                cavFundConfigs = _retailServiceProxy.GetFundsAdministrationConfig(baseDate, nMonthsLater, out result);
                if (!result.Successful)
                {
                    _log.Warn($"Consultar el listado de fondos proximos a liquidar: nDaysBefore-{nMonthsLater} / currentDate-{baseDate.ToShortDateString()}: {result.ToMessage()}");
                }

                _log.Debug("{cntx}", cavFundConfigs);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar el listado de fondos proximos a liquidar.");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage
                    {
                        Message = "Error al consultar el listado de fondos proximos a liquidar: " + ex.Message,
                        MessageType = SystemMessageTypes.Error
                    }
                );
            }

            return cavFundConfigs;
        }

    }
}
