﻿using ClientFundTransfer.Application.Cav.Common;
using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using ClientFundTransfer.Proxies;
using Common.Domain;
using Common.Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClientFundTransfer.Application.Cav
{
    public sealed class CavTransferFundAdministration : FundAdministrationApp, ICavTransferFundAdministration
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientFundTransferRetailPrxy _retailServiceProxy;

        public CavTransferFundAdministration(ISeriLogHelper log, IClientFundTransferRetailPrxy retailServiceProxy,
            IClientFundTransferRetailExtPrxy retailExtServiceProxy,
            IClientFundTransferWebRetailPrxy webRetailPrxy, IParametersProxy parametersProxy,
            INotificationsPrxy[] notificationsPrxy, IClientFundWebRetailAuthPrxy clientFundWebRetailAuthPrxy) : base(
            log, retailServiceProxy, retailExtServiceProxy, webRetailPrxy, parametersProxy, notificationsPrxy,
            clientFundWebRetailAuthPrxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
        }

        protected override void CreateCavProcessTransferLog(string processId, string transferId, FundProcessMovement fundProcessMovement)
        {
            _log.Info($"ProcesoId: {processId} - Transferencia: {transferId} - Creando proceso de administracion CAV");
            _log.Debug("{cntx}", fundProcessMovement);
            var ftpCreated = _retailServiceProxy.GenerateCavProcessTransfer(fundProcessMovement, out var ftpResult);
            _log.Debug("{cntx}", ftpCreated);
            if (!ftpResult.Successful)
            {
                _log.Warn(
                    $"ProcesoId: {processId} - Transferencia: {transferId} - Creando proceso de administracion CAV: {ftpResult.ToMessage()}");
            }

            _log.Info($"ProcesoId: {processId} - Proceso de administracion CAV creado correctamente.");
        }

        protected override void UpdateCavProcessTransferLog(string processId, string transferId, FundProcessMovement fundProcessMovement)
        {
            _log.Info(
                $"ProcesoId: {processId} - Transferencia: {transferId} - Actualizando proceso de administracion CAV");
            _log.Debug("{cntx}", fundProcessMovement);
            var ftpUpdated = _retailServiceProxy.UpdateCavProcessTransfer(fundProcessMovement, out var ftpuResult);
            _log.Debug("{cntx}", ftpUpdated);
            if (!ftpuResult.Successful)
            {
                _log.Warn(
                    $"ProcesoId: {processId} - Transferencia: {transferId} - Actualizando proceso de administracion CAV: {ftpuResult.ToMessage()}");
            }

            _log.Info($"ProcesoId: {processId} - Proceso de administracion CAV actualizado correctamente.");
        }

        public List<PortfolioFundTransfer> GetPortfolioFunds(string fundId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El Fondo a buscar no puede estar vacio."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }

            var portfolioFunds = new List<PortfolioFundTransfer>();

            try
            {
                _log.Info($"Obteniendo la información detallada de Plataforma-{platform} / Fondo-{fundId}");
                portfolioFunds = _retailServiceProxy.GetPortfolioFunds(fundId, platform, out result);
                if (!result.Successful)
                {
                    _log.Warn(
                        $"Obteniendo la información detallada de Plataforma-{platform} / Fondo-{fundId}: {result.ToMessage()}");
                }

                _log.Debug("{cntx}", portfolioFunds);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage
                    {
                        Message = "Error al obtener la información de los fondos" + ex.Message,
                        MessageType = SystemMessageTypes.Error
                    }
                );
            }

            return portfolioFunds;
        }

        public FundProcess ApplyProcessTransferFund(string userId, int platform, string fundSourceId, string fundTargetId, string fundReinvestmentId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El Usuario no puede estar vacio."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }
            if (string.IsNullOrEmpty(fundSourceId)) { throw new ArgumentException("El Fondo Origen no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundTargetId)) { throw new ArgumentException("El Fondo Destino no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundReinvestmentId)) { throw new ArgumentException("El Fondo Reinversion no puede estar vacio."); }

            var fProcess = FundProcess.Empty();

            try
            {
                var processId = Guid.NewGuid().ToString().ToUpper();
                _log.Info("Generando programacion de proceso de transferencias en adminsitracion de fondos {cntx}",
                    processId);

                _log.Info($"ProcesoId: {processId} - Creando proceso de transferencias CAV");
                fProcess = _retailServiceProxy.GenerateCavProcess(
                    FundProcess.Create(processId, userId, FundProcessType.Transfer)
                        .SetFund(fundSourceId, fundTargetId, fundReinvestmentId), out var fpResult);
                _log.Debug("{cntx}", fProcess);
                if (!fpResult.Successful)
                {
                    result.Successful = false;
                    result.SystemMessages.AddRange(fpResult.SystemMessages);
                    return fProcess;
                }

                _log.Info(
                    $"ProcesoId: {processId} - Proceso de transferencias CAV creado correctamente, se ejecutara en el servidor; espere actualizaciones.");

                Task.Run(() => PreProcessFundToApply(processId, fProcess, userId, platform));
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al programar proceso de transferencias en adminsitracion de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = "Error al programar proceso de transferencias en adminsitracion de fondos" + ex.Message
                });
            }

            return fProcess;
        }

        public List<FundProcess> GetCavFundsToReprocess(short processTypeId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (processTypeId <= 0) { throw new ArgumentException("No existe tipo de proceso con ese identificador."); }
            if (nDaysBefore < 0) { throw new ArgumentException("El numero de dias antes no puede ser menor a 0."); }

            var fundProcesses = new List<FundProcess>();

            try
            {
                _log.Info("Consultando fondos para reprocesar en adminsitracion de fondos {cntx}", processTypeId);
                fundProcesses =
                    _retailServiceProxy.GetCavFundsToReprocess(processTypeId, nDaysBefore, out var fpResult);
                _log.Debug("{cntx}", fundProcesses);
                if (!fpResult.Successful)
                {
                    result.Successful = false;
                    result.SystemMessages.AddRange(fpResult.SystemMessages);
                    return fundProcesses;
                }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar fondos para reprocesar en adminsitracion de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                { Message = "Error al consultar fondos para reprocesar en adminsitracion de fondos" + ex.Message });
            }

            return fundProcesses;
        }

        private void PreProcessFundToApply(string processId, FundProcess fundProcess, string userId, int platform)
        {
            try
            {
                _log.Info($"ProcesoId: {processId} - Obteniendo la información detallada de Plataforma-{platform} / Fondo-{fundProcess.FundSource} para proceso de administracion CAV");
                var portfolioFunds = GetPortfolioFunds(fundProcess.FundSource, platform, out var pfresult);
                _log.Debug("{cntx}", portfolioFunds);
                if (!pfresult.Successful)
                {
                    _log.Warn(
                        $"ProcesoId: {processId} - Obteniendo la información detallada de Plataforma-{platform} / Fondo-{fundProcess.FundSource} para proceso de administracion CAV: {pfresult.ToMessage()}");
                    FinalizeCavProcessLog(processId, fundProcess.EndProcess("Error al programar proceso de transferencia en adminsitracion de fondos"));
                    return;
                }

                var transferredContracts = ApplyProcessFund(processId, fundProcess, userId, platform, portfolioFunds.FindAll(f => f.EmisionId == fundProcess.FundSource));

                PostProcessFundToApply(processId, fundProcess, transferredContracts, userId, platform);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al preparar el proceso de transferencias en adminsitracion de fondos");
            }
        }

        private void PostProcessFundToApply(string processId, FundProcess fundProcess, List<string> transferredContracts, string userId, int platform)
        {
            try
            {
                foreach (var transferredContract in transferredContracts)
                {
                    var fundAdministration = FundAdministration
                        .Create(fundProcess.FundSource, transferredContract, userId)
                        .SetFundTarget(fundProcess.FundTarget)
                        .SetFundReinvestment(fundProcess.FundReinvestment)
                        .SetTransferProcessLogId(processId);
                    _log.Info(
                        $"ProcesoId: {processId} - Generando la información para Administacion del CAV de Plataforma-{platform} / Fondo-{fundProcess.FundSource}  / Contrato-{transferredContract}");
                    _log.Debug("{cntx}", fundAdministration);
                    var resultFundAdministration = _retailServiceProxy.GenerateCavAdministration(fundAdministration, out var faResult);
                    if (!faResult.Successful)
                    {
                        _log.Warn($"ProcesoId: {processId} - Generando la información para Administacion del CAV de Plataforma-{platform} / Fondo-{fundProcess.FundSource}  / Contrato-{transferredContract} : {faResult.ToMessage()}");
                        continue;
                    }

                    _log.Debug("Generado: {cntx}", resultFundAdministration);
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al generar la información para Administacion del CAV");
            }
        }
    }
}
