﻿using ClientFundTransfer.Domain.FundsForPurchaseAggregate;
using ClientFundTransfer.Domain.FundsForSaleAggregate;
using ClientFundTransfer.Domain.FundsTransferValidateAggregate;
using ClientFundTransfer.Domain.TransferFundOrderAggregate;
using ClientFundTransfer.Messages;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Application
{
    public interface IClientFundTransferApp
    {
        List<FundForSale> GetFundsforSale(string contractId, DateTime? baseDate, out string ProductComercialName, out OperationResult result);
        List<FundsForPurchase> GetFundsForPurchases(string contractId, out OperationResult result);
        OperationResult ApplyFundsTransferManyToMany(string contractId, string userId, FundsTransferValuesReq fundsTransferValues);
        List<TransferFundOrder> GetOrdersPending(string contractId, int platform, out OperationResult result);
        FundsTransferValidate ValidateApplyFundsTransfer(string contractId, out OperationResult result);
        void SendTransferAppliedEmail(string contractId, out OperationResult result);
        void SendTransferAppliedEmailAsync(string contractId, out OperationResult result);

    }
}
