﻿using ClientFundTransfer.Domain.ContractInfoAggregate;
using ClientFundTransfer.Domain.FundAllocationAggregate;
using ClientFundTransfer.Domain.FundOrderAggregate;
using ClientFundTransfer.Domain.FundSalesInfoAggregate;
using ClientFundTransfer.Domain.FundsForPurchaseAggregate;
using ClientFundTransfer.Domain.FundsForSaleAggregate;
using ClientFundTransfer.Domain.FundsTranferValuesAggregate;
using ClientFundTransfer.Domain.FundsTransferValidateAggregate;
using ClientFundTransfer.Domain.FundTransferValueAggregate;
using ClientFundTransfer.Domain.PlanAggregate;
using ClientFundTransfer.Domain.ProductInfoAggregate;
using ClientFundTransfer.Domain.TransferFundOrderAggregate;
using ClientFundTransfer.Messages;
using ClientFundTransfer.Proxies;
using Common.Domain;
using Common.Proxy;
using Newtonsoft.Json;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ClientFundTransfer.Application
{
    public class ClientFundTransferApp : IClientFundTransferApp
    {
        //Delegates
        private delegate string delGetClientIdByContract(string contractId, out OperationResult result);
        private delegate ContractInfo delGetContractInfo(string contractId, out OperationResult result);
        private delegate List<Plan> delGetPlansById(List<short> basPlanids, out OperationResult result);
        private delegate List<FundSalesInfo> delGetFundSalesInfo(List<string> findsId, int platform, DateTime? baseDate, out OperationResult result);
        private delegate int delGetPersonTypeId(string contractId, out OperationResult result);
        private delegate string delGetComercialName(string contractId, out OperationResult result);
        private delegate void delSendTransferAppliedEmail(string contractId, out OperationResult result);

        private readonly ISeriLogHelper _log;
        private readonly IClientFundTransferRetailPrxy _retailServiceProxy;
        private readonly IClientFundTransferRetailExtPrxy _retailExtServiceProxy;
        private readonly IClientFundTransferWebRetailPrxy _webRetailServiceProxy;
        private readonly IParametersProxy _parametersProxy;
        private readonly INotificationsPrxy[] _notificationsPrxy;
        private readonly IClientFundWebRetailAuthPrxy _clientFundWebRetailAuthPrxy;

        //variables utilizadas para el proceso de transferencia - ApplyFundsTransferManyToMany
        private int ByAmount = 0, ByShares = 1;
        private string ContractId;
        private int Platform;
        private int PersonTypeId;
        private int PlanBasId;
        private List<FundBalanceDetail> _balanceDetailFunds;
        private FundTrading BridgeFundTrading;

        public ClientFundTransferApp(ISeriLogHelper log, IClientFundTransferRetailPrxy retailServiceProxy, IClientFundTransferRetailExtPrxy retailExtServiceProxy,
            IClientFundTransferWebRetailPrxy webRetailPrxy, IParametersProxy parametersProxy, INotificationsPrxy[] notificationsPrxy, IClientFundWebRetailAuthPrxy clientFundWebRetailAuthPrxy)
        {
            _log = log;
            _retailServiceProxy = retailServiceProxy;
            _retailExtServiceProxy = retailExtServiceProxy;
            _webRetailServiceProxy = webRetailPrxy;
            _parametersProxy = parametersProxy;
            _notificationsPrxy = notificationsPrxy;
            _clientFundWebRetailAuthPrxy = clientFundWebRetailAuthPrxy;
        }

        public List<FundForSale> GetFundsforSale(string contractId, DateTime? baseDate, out string ProductComercialName, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            List<FundForSale> fundsForSale = new List<FundForSale>();
            List<short> basPlanIds = new List<short>();
            ProductComercialName = string.Empty;

            try
            {
                _log.Info("Obteniendo la información básica del contratoe {cntx}", contractId);
                delGetContractInfo delGetContractInfo = _retailServiceProxy.GetContractInfo;
                IAsyncResult asyncGetContractInfo = delGetContractInfo.BeginInvoke(contractId, out OperationResult ContractInfoResult, null, null);

                _log.Info("Obteniendo el rfc del cliente para el contrato: {cntx}", contractId);
                delGetClientIdByContract delGetClientIdByContract = _retailServiceProxy.GetClientIdByContract;
                IAsyncResult asyncGetClientIdByContract = delGetClientIdByContract.BeginInvoke(contractId, out OperationResult ClientIdByContractResult, null, null);

                _log.Info("Obteniendo el nombre comercial del contrato");
                delGetComercialName delGetComercialName = _retailExtServiceProxy.GetCommercialName;
                IAsyncResult asyncGetComercialName = delGetComercialName.BeginInvoke(contractId, out OperationResult commercialNameResult, null, null);

                while (!asyncGetContractInfo.IsCompleted || !asyncGetClientIdByContract.IsCompleted) { Thread.Sleep(20); }

                var contract = delGetContractInfo.EndInvoke(out ContractInfoResult, asyncGetContractInfo);
                _log.Debug("{cntx}", contract);

                var clientIdentifier = delGetClientIdByContract.EndInvoke(out ClientIdByContractResult, asyncGetClientIdByContract);
                _log.Debug("{cntx}", clientIdentifier);

                _log.Info("Obteniendo información de los contratos asociados {cntx}", clientIdentifier);
                var associatedContracts = _retailServiceProxy.GetAssociatedContracts(clientIdentifier, out OperationResult AssociatedContractsResult);
                var contracts = associatedContracts.Where(c => c.AssociatedContractId == contractId).Select(c => c.ContractId).ToList<string>();

                var platform = contract.Platform;

                _log.Info("Obteniendo los saldos de los fondos para el contrato {cntx}", contracts);
                var fundBalanceForSales = _retailServiceProxy.GetFundBalanceByContract(contract.Platform, contracts, out OperationResult FunBalanceResult);
                _log.Debug("{cntx}", fundBalanceForSales);
                var FundsId = fundBalanceForSales.Select(x => x.Id).ToList<string>();
                _log.Debug("{cntx}", FundsId);

                basPlanIds.Add(contract.PlanBasId);

                _log.Info("Obteniendo información de los planes: {cntx}", new { contractId, basPlanIds });
                delGetPlansById delGetPlansById = _retailExtServiceProxy.GetPlansById;
                IAsyncResult asyncGetPlansById = delGetPlansById.BeginInvoke(basPlanIds, out OperationResult PlansByIdResult, null, null);

                _log.Info("Obteniendo los datos para proceso de venta de los fondos {cntx}", FundsId);
                delGetFundSalesInfo delGetFundSalesInfo = _retailServiceProxy.GetFundSalesInfo;
                IAsyncResult asyncGetTradeInfo = delGetFundSalesInfo.BeginInvoke(FundsId, platform, baseDate, out OperationResult TradeInfoResult, null, null);

                while (!asyncGetPlansById.IsCompleted || !asyncGetTradeInfo.IsCompleted) { Thread.Sleep(20); }

                var plansInfo = delGetPlansById.EndInvoke(out PlansByIdResult, asyncGetPlansById);
                _log.Debug("{cntx}", plansInfo);

                var fundsTradeInfo = delGetFundSalesInfo.EndInvoke(out TradeInfoResult, asyncGetTradeInfo);
                _log.Debug("{cntx}", fundsTradeInfo);

                fundsTradeInfo.ForEach(fundSalesInfo =>
                {
                    var fundsValues = fundBalanceForSales.Where(x => x.Id == fundSalesInfo.Id);

                    var salesPrice = 0M;
                    var availableShares = 0M;
                    var committedShares = 0M;
                    var marketValue = 0M;

                    foreach (FundBalanceForSale f in fundsValues)
                    {
                        salesPrice = f.Prices.SalesPrice;
                        availableShares += f.Shares.AvailableShares;
                        committedShares += f.Shares.CommittedShares;
                        marketValue += f.MarketValues.MarketValue;
                    }

                    fundsForSale.Add(
                        new FundForSale(fundSalesInfo.Id)
                        .SetInformationForSales(
                            salesPrice,
                            availableShares,
                            committedShares,
                            marketValue)
                    );
                });

                while (!asyncGetComercialName.IsCompleted) { Thread.Sleep(10); }
                ProductComercialName = delGetComercialName.EndInvoke(out commercialNameResult, asyncGetComercialName);
                _log.Debug("Nombre comercial: {cntx}", ProductComercialName);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los fondos para venta del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los fondos para venta del contrato " + contractId + ex.Message, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }

            return fundsForSale.Where(x => x.AvailableAmount > 0).ToList();
        }

        private delegate ProductInfo delGetProductInfo(string contractId);
        private delegate string delGetStringParameter(string parameterId, string contractId, string planId, string productType, string contractAttributeType, out OperationResult result);
        public List<FundsForPurchase> GetFundsForPurchases(string contractId, out OperationResult result)
        {
            List<FundsForPurchase> lstFundsPurchase = new List<FundsForPurchase>();
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo la información básica del contratoe {cntx}", contractId);
                delGetContractInfo delGetContractInfo = _retailServiceProxy.GetContractInfo;
                IAsyncResult asyncGetContractInfo = delGetContractInfo.BeginInvoke(contractId, out OperationResult ContractInfoResult, null, null);

                _log.Info("Obteniendo la informacion del tipo de persona fiscal es el contrato.");
                delGetPersonTypeId delGetPersonTypeId = _retailServiceProxy.GetPersonTypeIdByContractId;
                IAsyncResult asyncGetPersonTypeId = delGetPersonTypeId.BeginInvoke(contractId, out OperationResult PersonTypeIdResult, null, null);

                _log.Info("Obteniendo los datos del producto");
                delGetProductInfo delGetProductInfo = _webRetailServiceProxy.GetProductInfo;
                IAsyncResult asyncGetProductInfo = delGetProductInfo.BeginInvoke(contractId, null, null);

                _log.Info("Obteniendo los planes que excluyen fondo puente");
                delGetStringParameter delGetStringParameter = _parametersProxy.GetStringParameter;
                IAsyncResult asyncGetParameter = delGetStringParameter.BeginInvoke("PLNBRGFUND", "", "", "Retail", "Standar", out OperationResult resultParameter, null, null);

                while (!asyncGetContractInfo.IsCompleted || !asyncGetPersonTypeId.IsCompleted
                    || !asyncGetProductInfo.IsCompleted || !asyncGetParameter.IsCompleted) { Thread.Sleep(20); }

                var contract = delGetContractInfo.EndInvoke(out ContractInfoResult, asyncGetContractInfo);
                _log.Debug("{cntx}", contract);

                var personTypeId = delGetPersonTypeId.EndInvoke(out PersonTypeIdResult, asyncGetPersonTypeId);
                _log.Debug("{cntx}", personTypeId);

                var plansBridgeFund = delGetStringParameter.EndInvoke(out resultParameter, asyncGetParameter).Split('|');
                _log.Debug("planes fondo puente: {cntx} ", plansBridgeFund);

                var productInfo = delGetProductInfo.EndInvoke(asyncGetProductInfo);
                _log.Debug("Datos dep producto: {cntx}", productInfo);

                _log.Info("Obteniendo los fondos para compra");
                lstFundsPurchase = _retailServiceProxy.GetFundsForPurchases(contractId, contract.Platform, contract.PlanBasId, personTypeId, out result);

                Array.Sort(plansBridgeFund);
                if (Array.BinarySearch(plansBridgeFund, productInfo.PlanId) < 0) { lstFundsPurchase.RemoveAt(0); }

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los fondos para compra del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los fondos para compra del contrato " + contractId + ex.Message, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }

            return lstFundsPurchase;
        }

        private delegate List<FundForSale> delGetFundSalesContract(string contractId, DateTime? baseDate, out string ProductComercialName, out OperationResult result);
        public OperationResult ApplyFundsTransferManyToMany(string contractId, string userId, FundsTransferValuesReq fundsTransferValues)
        {
            var result = new OperationResult() { Successful = true };

            try
            {
                _log.Info("Obteniendo los datos del producto");
                var productInfo = _retailServiceProxy.GetContractInfo(contractId, out result);
                _log.Debug("{cntx}", productInfo);

                ContractId = contractId;
                Platform = productInfo.Platform;
                PlanBasId = productInfo.PlanBasId;
                DateTime baseDate = DateTime.Now;
                var transactionId = DateTime.Now.ToString().GetHashCode().ToString("x");

                var comercilaName = string.Empty;
                delGetFundSalesContract delGetFundSalesContract = GetFundsforSale;
                IAsyncResult asyncGetFundSalesContract = delGetFundSalesContract.BeginInvoke(contractId, baseDate, out comercilaName, out OperationResult resultFundsSale, null, null);

                delGetPortafolioType delGetPortafolioType = _retailServiceProxy.GetPortafolioType;
                IAsyncResult asyncGetPortafolioType = delGetPortafolioType.BeginInvoke(ContractId, Platform, out int clientType, null, null);

                _log.Info("Obteniendo el listado de ordenes.");
                var listOrders = EvaluateFundsTransferManyToMany(fundsTransferValues, baseDate, out result);
                _log.Debug("Listado de ordenes: {cntx}", listOrders);

                if (result.Successful)
                {
                    //Primero se valida que el contrato tenga un portafolio definido
                    while (!asyncGetPortafolioType.IsCompleted) { Thread.Sleep(10); }
                    var portafolioType = delGetPortafolioType.EndInvoke(out clientType, asyncGetPortafolioType);
                    _log.Info("Obteniendo el tipo de portafolio: {cntx}", portafolioType);
                    _log.Info("Obteniendo el detalle del portafolio.");
                    var portafoliClient = _retailServiceProxy.GetPortafolioDetailfunds(ContractId, portafolioType, clientType, Platform);
                    _log.Info("{cntx}", portafoliClient);
                    FundAllocationDistribution clientPortafolio = FundAllocationDistribution.Create()
                        .SetCurrentAllocation(portafoliClient);
                    _log.Info("{cntx}", clientPortafolio);

                    var transferFundsManyToManyType = 1; //Tipo de transaccion definida para transferencia de muchos a muchos.
                    _log.Info("Generando transacciones");
                    result = _retailServiceProxy.GenerateFundTransaction(ContractId, userId, transactionId, Platform, transferFundsManyToManyType, baseDate);
                    _log.Debug("Transacciones generadas correctamente: {cntx}", result);

                    if (result.Successful)
                    {
                        _log.Info("Aplicando la transferencia en los corrrespondientes repositorios.");
                        result = ApplyFundsTransferSiif(listOrders, transactionId, baseDate, userId);
                        _log.Debug("Transferencia exitosa: {cntx}", result);

                        if (result.Successful)
                        {
                            _log.Info("Genera la nueva distribucion del portafolio.");
                            while (!asyncGetFundSalesContract.IsCompleted) { Thread.Sleep(20); }
                            _log.Info("Obteniendo los fondos para venta.");
                            var fundsSaleContract = delGetFundSalesContract.EndInvoke(out comercilaName, out resultFundsSale, asyncGetFundSalesContract);
                            _log.Info("{cntx}", fundsSaleContract);
                            ApplyDistributionFunds(fundsTransferValues, fundsSaleContract, transactionId, baseDate, clientPortafolio);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al aplicar la transaccion");
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage>() { new SystemMessage() { Message = ex.Message } };
            }

            return result;
        }

        public List<TransferFundOrder> GetOrdersPending(string contractId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var transferOrders = new List<TransferFundOrder>();
            try
            {
                transferOrders = _retailServiceProxy.GetOrdersPending(contractId, platform);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las ordenes pendientes del contrato: " + contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las ordenes pendientes" + ex.Message });
            }

            return transferOrders;
        }

        #region Methods for Sale and Purchase funds
        private delegate List<FundBalanceDetail> delGetFundsBalanceDetail(string contractId, int platform);
        private List<List<FundOrder>> EvaluateFundsTransferManyToMany(FundsTransferValuesReq fundsTransferValuesReq, DateTime baseDate, out OperationResult result)
        {
            List<List<FundOrder>> trasfersList = new List<List<FundOrder>>();
            FundsTranferValues fundsTransferValues = FundsTranferValues.Create();
            fundsTransferValuesReq.SourceInvestmentFunds.ForEach(fundSoruce => fundsTransferValues.AddSourceFund(FundTransferValue.Create(fundSoruce.Id, fundSoruce.Amount)));
            fundsTransferValuesReq.TargetInvestmentFunds.ForEach(fundSoruce => fundsTransferValues.AddTargetFund(FundTransferValue.Create(fundSoruce.Id, fundSoruce.Amount)));

            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo el balace de los fondos por contracto");
                delGetFundsBalanceDetail delGetFundsBalanceDetail = _retailServiceProxy.GetFundsBalanceDetail;
                IAsyncResult asynGetFundsBalanceDetail = delGetFundsBalanceDetail.BeginInvoke(ContractId, Platform, null, null);

                _log.Info("Obteniendo la informacion del tipo de persona fiscal es el contrato.");
                delGetPersonTypeId delGetPersonTypeId = _retailServiceProxy.GetPersonTypeIdByContractId;
                IAsyncResult asyncGetPersonTypeId = delGetPersonTypeId.BeginInvoke(ContractId, out OperationResult PersonTypeIdResult, null, null);

                var sourceFunds = fundsTransferValues.SourceInvestmentFunds.Select(fundTransfer => fundTransfer.Id).ToList();
                var targetFunds = fundsTransferValues.TargetInvestmentFunds.Select(fundTransfer => fundTransfer.Id).ToList();

                _log.Info("Obteniendo el detalle de los fondos de venta");
                var sourceFundsTradingList = _retailServiceProxy.GetFundsTrading(sourceFunds, Platform, baseDate, out result);
                _log.Debug("{cntx}", sourceFundsTradingList);
                if (sourceFundsTradingList.Count <= 0)
                {
                    result.Successful = false;
                    result.SystemMessages = new List<SystemMessage>()
                    {
                        new SystemMessage() { Message = $"Platform({Platform}): No existe el detalle de los fondos {string.Join(",", sourceFunds)} de venta, Fecha: {baseDate}." }
                    };
                    return trasfersList;
                }
                _log.Info("Obteniendo el detalle de los fondos de compra");
                var targetFundsTradingList = _retailServiceProxy.GetFundsTrading(targetFunds, Platform, baseDate, out result);
                _log.Debug("{cntx}", targetFundsTradingList);
                if (targetFundsTradingList.Count <= 0)
                {
                    result.Successful = false;
                    result.SystemMessages = new List<SystemMessage>()
                    {
                        new SystemMessage() { Message = $"Platform({Platform}): No existe el detalle de los fondos {string.Join(",", targetFunds)}  de compra, Fecha: {baseDate}." }
                    };
                    return trasfersList;
                }

                //Ordenar los fondos de venta por fecha de negociación de venta.
                sourceFundsTradingList.OrderBy(fund => fund.Id);
                fundsTransferValues.SourceInvestmentFunds.OrderBy(fund => fund.Id);
                sourceFundsTradingList.ForEach(fundOrder =>
                {
                    fundsTransferValues.SourceInvestmentFunds.Find(x => x.Id.Equals(fundOrder.Id))
                    .SetTradingInformation(fundOrder);
                });

                //ordenar los fondos de compra por fecha de negociación de compra.
                targetFundsTradingList.OrderBy(fund => fund.Id);
                fundsTransferValues.TargetInvestmentFunds.OrderBy(fund => fund.Id);
                targetFundsTradingList.ForEach(fundOrder =>
                {
                    fundsTransferValues.TargetInvestmentFunds.Find(x => x.Id.Equals(fundOrder.Id))
                    .SetTradingInformation(fundOrder);
                });

                fundsTransferValues.DltAmountLTPriceSale();
                fundsTransferValues.DltAmountLTPricePurchase();
                fundsTransferValues.SubstractAmounts();

                while (!asynGetFundsBalanceDetail.IsCompleted || !asyncGetPersonTypeId.IsCompleted) { Thread.Sleep(20); }
                _balanceDetailFunds = delGetFundsBalanceDetail.EndInvoke(asynGetFundsBalanceDetail);
                _log.Debug("BalanceDetail {cntx}", _balanceDetailFunds);
                PersonTypeId = delGetPersonTypeId.EndInvoke(out OperationResult resultGetPersonType, asyncGetPersonTypeId);
                _log.Debug("PersonTypeId {cntx}", PersonTypeId);

                _log.Info("Obteniendo el fondo puente.");
                var bridgeFund = _retailServiceProxy.GetFundBridge(ContractId, Platform, PlanBasId, PersonTypeId, out result).Id;
                BridgeFundTrading = _retailServiceProxy.GetFundsTrading(new List<string>() { bridgeFund }, Platform, baseDate, out result).FirstOrDefault();
                _log.Debug("{cntx}", BridgeFundTrading);

                trasfersList = GeneraListTranfersOrder(_balanceDetailFunds, baseDate, fundsTransferValues, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al validar los fondos de compra y venta. - EvaluateFundsTransferManyToMany");
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage>() { new SystemMessage() { Message = ex.Message + " Error al validar los fondos de compra y venta. - EvaluateFundsTransferManyToMany" } };
            }

            return trasfersList;
        }

        private List<List<FundOrder>> GeneraListTranfersOrder(List<FundBalanceDetail> contractBalanceDetail, DateTime baseDate, FundsTranferValues tranferValues, out OperationResult result)
        {
            var targetFundsTransferList = new List<FundTransferValue>();
            var trasfersList = new List<List<FundOrder>>();
            var listTransferResume = new List<FundsTranferResume>();
            result = new OperationResult() { Successful = true };

            try
            {
                tranferValues.SourceInvestmentFunds.ForEach(sourceFund =>
                {
                    _log.Info("Generando listado de fondos de compra dependiend del fondo de venta.");
                    var fundsTargetValidate = tranferValues.GetTargetFundsTranferValuesBySourceAmount(sourceFund, targetFundsTransferList);
                    _log.Debug("Lista de fondos de venta para fondo {fund} : {cntx}", sourceFund.Id, fundsTargetValidate);

                    //Valida que el monto de los fondos a comprar no sea diferente al monto del fondo a vender. (Regla: por cada fondo a vender => N cantidad de fondos a comprar)
                    sourceFund.ValidateAmountToTargetValue(fundsTargetValidate.Sum(x => x.Amount));

                    //Valida que el monto a vender de cada fondo sea menor que el monto de su saldo actual.
                    var currentBalance = contractBalanceDetail.Find(toSearah => toSearah.Id.Equals(sourceFund.Id));
                    sourceFund.ValidateAmountToBalanceAmount(currentBalance.MakertValueValuation);

                    var sharesAvailable = currentBalance.Shares - currentBalance.CompromisedSharesSales;
                    var amountAvailable = Convert.ToInt32(sharesAvailable) * currentBalance.PriceSale;
                    amountAvailable = Math.Round(amountAvailable, 2);
                    sourceFund.ValidateAmountToAvailableAmount(amountAvailable);

                    listTransferResume.Add(
                        //Se genera una entidad que contiene el resumen de la tranferencia
                        FundsTranferResume.Create(currentBalance, fundsTargetValidate)
                            .SetTranferConfig(sourceFund.Amount, baseDate)
                            .ValidateAndSetAmountType()
                    );

                    targetFundsTransferList.AddRange(fundsTargetValidate);
                });
                _log.Debug("Listado final de dispersion de fondos de compra: {cntx}", listTransferResume);

                //Obtiene el listado de ordenes
                decimal accumSharesSourceOrders = 0;
                listTransferResume.ForEach(fundTransferResume =>
                {
                    // Get orders
                    var sourceTrading = tranferValues.SourceInvestmentFunds.Find(x => x.Id.Equals(fundTransferResume.SourceInvestmentFund.Id)).Trading;
                    var fundTransfersListEvaluated = EvaluateFundsTransfer(fundTransferResume, sourceTrading);

                    //Adjust sale order shares to transfer exactly 100%
                    if (fundTransferResume.AmountType.Equals(ByShares))
                    {
                        accumSharesSourceOrders = 0;
                        fundTransfersListEvaluated.ForEach(investmentFundOrderList =>
                        {
                            accumSharesSourceOrders += investmentFundOrderList[0].Shares;
                        });

                        if (accumSharesSourceOrders > fundTransferResume.SharesAvailable)
                        {
                            var flag = false;
                            var item = 0;
                            while (!flag)
                            {
                                fundTransfersListEvaluated[item][0].RecalculateShares(accumSharesSourceOrders, fundTransferResume.SharesAvailable, out flag);
                                item++;
                            }
                        }
                        else if (accumSharesSourceOrders < fundTransferResume.SharesAvailable)
                        {
                            fundTransfersListEvaluated[0][0].SetShares(fundTransfersListEvaluated[0][0].Shares + ((int)fundTransferResume.SharesAvailable - accumSharesSourceOrders));
                        }
                    }

                    trasfersList.AddRange(fundTransfersListEvaluated);
                });

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un error al generar las listas de ordenes. - GeneraListTranfersOrder | " + ex.Message);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = ex.Message });
                trasfersList = null;
            }

            return trasfersList;
        }

        private List<List<FundOrder>> EvaluateFundsTransfer(FundsTranferResume fundTransferResume, FundTrading saleTrading)
        {
            //HACK: AGREGAR VALIDACIONES MAS VALIDACIONES DE CONTROL SI SON NECESARIAS
            List<List<FundOrder>> trasfersList = new List<List<FundOrder>>();

            fundTransferResume.TargetInvestmentFunds.ForEach(fundToValidate =>
            {

                if (fundTransferResume.AmountType != ByAmount
                    && fundTransferResume.AmountType != ByShares)
                    throw new ApplicationException("Tipo de monto invalido " + fundTransferResume.AmountType + ".");

                if (saleTrading is null) { throw new ApplicationException("Fechas de compra/venta invalidas, no existen fechas de compra/venta para el fondo " + fundToValidate.Id); }

                FundOrder saleOrder = FundOrder.Create(fundTransferResume.SourceInvestmentFund.Id)
                    .SetAmount(fundToValidate.Amount)
                    .SetContractId(ContractId)
                    .SetOrderType(1)
                    .SetSubOrderType(10)
                    .SetTradingDates(saleTrading.SaleTradingDates.RequestDate, saleTrading.SaleTradingDates.OperationDate, saleTrading.SaleTradingDates.LiquidationDate)
                    .SetPlatform(Platform)
                    .SetPrice(saleTrading.Prices.SalesPrice)
                    .ValidateAndSetOrderFee(saleTrading.OperatorCommisionSale, saleTrading.Prices.SalesPrice, saleTrading.OperatorCommisionSaleTax)//order.SetOrderFee(comissionAmount, comissionTaxAmount, 0);
                    .ValidateAmountType(fundTransferResume.SourceInvestmentFund.MarketValueSale)
                    .ValidateAndSetShares(saleTrading.Prices.SalesPrice)
                    .SetContextInfo(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty)
                    .SetOperationType();

                List<FundOrder> ordersCurrent = LinkBuyOrders(saleOrder, saleTrading, fundToValidate, fundTransferResume.BaseDateTime);

                trasfersList.Add(ordersCurrent);
            });

            return trasfersList;
        }

        private List<FundOrder> LinkBuyOrders(FundOrder saleOrder, FundTrading saleTrading,
            FundTransferValue buyInvestmentFund, DateTime baseDateTime)
        {
            List<FundOrder> linkedOrders = new List<FundOrder>();
            List<FundOrder> bridgeOrders = new List<FundOrder>();
            bool isBuyInvestmentFundInternational;
            FundTrading buyTrading;
            FundOrder buyOrder;
            DateTime buyDateToValidate;
            bool bridgeOrdersFlag = false;
            List<string> currentFund = new List<string>();
            List<FundTrading> currentFundTranding = new List<FundTrading>();
            linkedOrders.Add(saleOrder); //add sale order

            //Get buy dates (no matter if they don't match with sale dates)
            buyTrading = MatchSaleTradingDates(saleTrading, buyInvestmentFund.Trading, baseDateTime);

            //transfer amount must be grater or equal than buy investment fund price
            //SS RAMMIG 2009-02-18
            if (saleOrder.Amount < buyTrading.Prices.PurchasePrice)
            {
                //can't buy destination fund, change sale order to cash
                saleOrder.SetSubOrderType(11);
                return linkedOrders;
            }

            isBuyInvestmentFundInternational = buyTrading.BuyAnticipateLiquidation;

            // Get buy date to know if is neccesary to pass for bridge fund
            if (isBuyInvestmentFundInternational)
                buyDateToValidate = buyTrading.BuyTradingDates.OperationDate;
            else
                buyDateToValidate = buyTrading.BuyTradingDates.LiquidationDate;

            //dates doesn't match, create bridge orders
            if (saleTrading.SaleTradingDates.LiquidationDate.Date != buyDateToValidate.Date)
            {
                //SS RAMMIG 2009-02-18 se va a comprar el fondo puente
                if (saleOrder.Amount < BridgeFundTrading.Prices.PurchasePrice)
                {
                    //can't buy destination fund, change sale order to cash
                    saleOrder.SetSubOrderType(11);
                    return linkedOrders;
                }
                else
                {
                    //saleOrder.TipoOrdenId = 2;	//0--> Sale/Buy, 1-->Sale/Cash, 2-->Sale/Buy/Buy/Sale	//FLOLUI - 2009/09/09 -  BAS transfers connector change
                    //bridgeTargetBuyFlag = true;
                    //FLOLUI - 2009/09/09 -  BAS transfers connector change
                    //buyTrading=AdjustTradingDatesToUseBridge(productType,saleTrading,buyTrading); //RAMMIG 2006-03-29

                    bridgeOrders = GetSaleBridgeOrders(saleTrading, buyTrading, saleOrder,
                        baseDateTime, isBuyInvestmentFundInternational);
                    if (bridgeOrders.Count > 0)
                    {
                        //Add buy bridge order
                        linkedOrders.Add(bridgeOrders[0]);
                        bridgeOrdersFlag = true;
                    }
                }
            }
            // Create buy order with general information
            buyOrder = FundOrder.Create(buyInvestmentFund.Id)
                    .SetAmount(saleOrder.Amount)
                    .SetAmountType(ByAmount)
                    .SetContractId(ContractId)
                    .SetOrderType(2)
                    .SetSubOrderType(20)
                    .SetTradingDates(buyTrading.BuyTradingDates.RequestDate, buyTrading.BuyTradingDates.OperationDate, buyTrading.BuyTradingDates.LiquidationDate)
                    .SetPlatform(Platform)
                    .SetOrderFee(0, 0, 0)
                    .SetContextInfo(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty)
                    // Add amounts to buy order
                    .SetBuyOrderDataAmounts(buyTrading)
                    .SetOperationType();

            // Add buy order
            linkedOrders.Add(buyOrder);

            if (bridgeOrdersFlag)
            {
                // Add sale bridge order
                linkedOrders.Add(bridgeOrders[1]);
            }

            return linkedOrders;
        }

        private FundTrading MatchSaleTradingDates(FundTrading saleTrading, FundTrading targetTrading, DateTime baseDate)
        {
            List<FundTrading> fundsTradingNewDate = new List<FundTrading>();
            if (targetTrading == null)
                throw new ApplicationException("Fechas de compra/venta invalidas, no existen fechas de compra/venta para el fondo " + targetTrading.Id);

            var result = new OperationResult();
            //match operation date
            if (targetTrading.BuyAnticipateLiquidation)
            {
                while (targetTrading.BuyTradingDates.OperationDate < saleTrading.SaleTradingDates.LiquidationDate)
                {
                    baseDate = baseDate.AddDays(1);
                    fundsTradingNewDate = _retailServiceProxy.GetFundsTrading(new List<string>() { targetTrading.Id }, Platform, baseDate, out result);
                    targetTrading = fundsTradingNewDate.FirstOrDefault();
                    if (targetTrading == null)
                        throw new ApplicationException("Fechas de compra/venta invalidas, no existen fechas de compra/venta para el fondo " + targetTrading.Id);
                }
            }
            //match liquidation date
            else
            {
                while (targetTrading.BuyTradingDates.LiquidationDate < saleTrading.SaleTradingDates.LiquidationDate)
                {
                    baseDate = baseDate.AddDays(1);
                    fundsTradingNewDate = _retailServiceProxy.GetFundsTrading(new List<string>() { targetTrading.Id }, Platform, baseDate, out result);
                    targetTrading = fundsTradingNewDate.FirstOrDefault();
                    if (targetTrading == null)
                        throw new ApplicationException("Fechas de compra/venta invalidas, no existen fechas de compra/venta para el fondo " + targetTrading.Id);
                }

                //ensure anticipation days for target investment fund RAMMIG 2006-03-27
                if (targetTrading.BuyTradingDates.RequestDate < saleTrading.SaleTradingDates.LiquidationDate &&
                    targetTrading.BuyTradingDates.LiquidationDate > saleTrading.SaleTradingDates.LiquidationDate)
                {
                    baseDate = saleTrading.SaleTradingDates.LiquidationDate;
                    fundsTradingNewDate = _retailServiceProxy.GetFundsTrading(new List<string>() { targetTrading.Id }, Platform, baseDate, out result);
                    targetTrading = fundsTradingNewDate.FirstOrDefault();
                    if (targetTrading == null)
                        throw new ApplicationException("Fechas de compra/venta invalidas, no existen fechas de compra/venta para el fondo " + targetTrading.Id);
                }
            }

            return targetTrading;
        }

        private List<FundOrder> GetSaleBridgeOrders(FundTrading saleTrading, FundTrading buyTrading, FundOrder saleOrder, DateTime baseDate, bool byOperationDate)
        {
            List<FundOrder> bridgeOrders = new List<FundOrder>();
            //FundTrading bridgeTrading;

            bool flagGenerateBridgeOrders = true;
            FundOrder buyBridge, saleBridge;
            TradingDates buyBridgeTradingDates;
            TradingDates saleBridgeTradingDates;

            //validate that source investment fund are not equal to bridge investment fund
            if (!BridgeFundTrading.Id.Equals(saleOrder.Id))
            {
                if (byOperationDate)
                {
                    if (saleTrading.SaleTradingDates.LiquidationDate == buyTrading.BuyTradingDates.OperationDate)
                    {
                        flagGenerateBridgeOrders = false;
                    }
                }
                else
                {
                    if (saleTrading.SaleTradingDates.LiquidationDate == buyTrading.BuyTradingDates.LiquidationDate)
                    {
                        flagGenerateBridgeOrders = false;
                    }
                }
            }

            if (flagGenerateBridgeOrders)
            {
                if (BridgeFundTrading == null)
                    throw new ApplicationException("Fechas de compra/venta invalidas, no existen fechas de compra/venta para el fondo " + BridgeFundTrading.Id);

                // Create buy bridge order with general information
                buyBridgeTradingDates = TradingDates.Create(saleTrading.SaleTradingDates.LiquidationDate, saleTrading.SaleTradingDates.LiquidationDate, saleTrading.SaleTradingDates.LiquidationDate);

                buyBridge = FundOrder.Create(BridgeFundTrading.Id)
                    .SetContractId(ContractId)
                    .SetAmount(saleOrder.Amount)
                    .SetOrderType(2)
                    .SetSubOrderType(20)
                    .SetPlatform(Platform)
                    .SetAmountType(ByAmount)
                    .SetTradingDates(buyBridgeTradingDates.RequestDate, buyBridgeTradingDates.OperationDate, buyBridgeTradingDates.LiquidationDate)
                    .SetContextInfo(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty)
                    .SetOperationType();

                // Add amounts to bridge buy order
                //SS RAMMIG 2009-02-18
                buyBridge.SetPrice(BridgeFundTrading.Prices.PurchasePrice)
                    .SetCalculateShares()
                    .SetCalculateOrderFee(BridgeFundTrading.OperatorCommisionBuy, BridgeFundTrading.OperatorCommisionBuyTax);

                // Create sale bridge order with general information
                if (byOperationDate)
                {
                    saleBridgeTradingDates = TradingDates.Create(buyTrading.BuyTradingDates.OperationDate, buyTrading.BuyTradingDates.OperationDate, buyTrading.BuyTradingDates.OperationDate);
                }
                else
                {
                    saleBridgeTradingDates = TradingDates.Create(buyTrading.BuyTradingDates.LiquidationDate, buyTrading.BuyTradingDates.LiquidationDate, buyTrading.BuyTradingDates.LiquidationDate);
                }

                saleBridge = FundOrder.Create(buyBridge.Id)
                    .SetOrderType(1)
                    .SetSubOrderType(10)
                    .SetContractId(ContractId)
                    .SetAmount(buyBridge.Amount)
                    .SetAmountType(ByAmount)
                    .SetPlatform(Platform)
                    .SetTradingDates(saleBridgeTradingDates.RequestDate, saleBridgeTradingDates.OperationDate, saleBridgeTradingDates.LiquidationDate)
                    .SetContextInfo(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty)
                    .SetOperationType()
                    .SetShares(buyBridge.Shares);
                // Add amounts to bridge sale order
                //SS RAMMIG 2009-02-18
                saleBridge.SetPrice(BridgeFundTrading.Prices.SalesPrice)
                    //SS RAMMIG 2009-03-04 los titulos y el importe de la venta se registran con la misma cantidad de titulos e
                    //importe, el scheduler se encargara de ajustarla venta del puente cuando se carge a SIIF
                    .SetCalculateOrderFee(BridgeFundTrading.OperatorCommisionSale, BridgeFundTrading.OperatorCommisionSaleTax);

                bridgeOrders.Add(buyBridge);
                bridgeOrders.Add(saleBridge);
            }
            return bridgeOrders;
        }

        private OperationResult ApplyFundsTransferSiif(List<List<FundOrder>> fundOrders, string transactionId, DateTime transactionDate, string userId)
        {
            var result = new OperationResult();

            var theProduct = Platform;
            //string transactionId = string.Empty;
            int currentOrderId;
            int orderChainId;
            Guid currOrderLogId = Guid.Empty;
            Guid prevOrderLogId = Guid.Empty;
            bool isLastOrder = false;
            string orderLinage;
            int i, j;

            i = 1;

            fundOrders.ForEach(listOrders =>
            {
                orderLinage = "/" + i.ToString() + "/";
                orderChainId = 0;
                isLastOrder = false;
                currOrderLogId = Guid.Empty;
                prevOrderLogId = Guid.Empty;

                for (j = 0; j < listOrders.Count; j++)
                {
                    orderLinage = orderLinage + (j + 1).ToString() + "/";

                    if (j == listOrders.Count - 1)
                        isLastOrder = true;

                    currOrderLogId = Guid.NewGuid();
                    //Get a Dictionary Object with detail order information for SIIF platform
                    var orderDict = TransferOrder.Create(transactionId, j, orderLinage, orderChainId, isLastOrder, currOrderLogId, prevOrderLogId, transactionDate)
                                                 .SetGenericOrderData(listOrders[j], userId)
                                                 .SetOrderType(listOrders[j].OrderSubType, listOrders[j].OrderType, listOrders.Count);

                    //Insert the transfer order in SIIF platform
                    currentOrderId = _retailServiceProxy.InsertFundTransferOrder(orderDict, Platform);
                    TrackFundTransferOrderAdded(currentOrderId, orderDict);
                    _retailServiceProxy.InsertFundTransferOrderLog(orderDict, currentOrderId);
                    prevOrderLogId = currOrderLogId;
                    if (j == 0)
                        orderChainId = currentOrderId;

                }
                i++;
                orderLinage = string.Empty;
            });

            result.Successful = true;
            result.SystemMessages = new List<SystemMessage>() { new SystemMessage() { Message = transactionId } };
            return result;

        }

        #endregion

        #region Methods for distribution of funds
        /// <summary>
        /// Metodo que realiza la distribucion de fondos despues de realizar la transferencia(compra y venta).
        /// </summary>
        protected virtual void ApplyDistributionFunds(FundsTransferValuesReq fundsTransferValuesReq, List<FundForSale> fundForSales, string transactionId, DateTime baseDate, FundAllocationDistribution clientPortafolio)
        {
            var totalAmountPortafolio = fundForSales.Sum(x => x.AvailableAmount);
            _log.Debug("Total saldo disponible para distribucion de portafolio: {cntx}", totalAmountPortafolio);
            //FundAllocationDistribution clientPortafolio = FundAllocationDistribution.Create();

            _log.Info("Generando nueva distribucion del portafolio con los fondos comprados.");
            fundsTransferValuesReq.TargetInvestmentFunds.ForEach(targetFund =>
            {
                var porcentage = (targetFund.Amount * 100) / decimal.ToDouble(totalAmountPortafolio);
                clientPortafolio.AddFundNewDistribution(FundAllocation.Create(targetFund.Id, (decimal)porcentage));
            });

            _log.Info("Nueva distribucion del portafolio: {cntx}", clientPortafolio.NewDistribution);

            //_log.Info("Obteniendo los datos del perfil del portafolio");
            //var portafolioType = _retailServiceProxy.GetPortafolioType(ContractId, Platform, out int clientType);
            //_log.Debug("Tipo de portafolio: {cntx}", portafolioType);

            //_log.Info("Obteniendo el portafolio actual del contrato");
            //clientPortafolio.SetCurrentAllocation(_retailServiceProxy.GetPortafolioDetailfunds(ContractId, portafolioType, clientType, Platform));
            _log.Debug("Portafolio actual: {cntx}", clientPortafolio.CurrentDistribution);

            fundsTransferValuesReq.SourceInvestmentFunds.ForEach(x =>
            {
                var fund = clientPortafolio.CurrentDistribution.Find(find => find.Id.Equals(x.Id));
                if (fund != null)
                {
                    var percentSale = (x.Amount * 100) / decimal.ToDouble(totalAmountPortafolio);
                    clientPortafolio.AddFundSaleDistribution(FundAllocation.Create(fund.Id, (decimal)percentSale));
                }
            });

            _log.Info("Verifica si exiten fondos a vender dentro de su portafolio actual y calcula el nuevo porcentage");
            clientPortafolio.SubtractPercentSaleToCurrentDistribution();
            _log.Debug("Nuevos porcentajes portafolio actual: {cntx}", clientPortafolio.CurrentDistribution);

            _log.Info("Valida y ajusta el porcentaje del nuevo portafolio para que sea exactamente el 100%");
            clientPortafolio.ValidateAdjustOneHundredPercent();
            _log.Debug("Nuevo portafolio ajustado y validado: {cntx}", clientPortafolio.NewDistribution);

            _log.Info("Inserta el nuevo portafolio en BAS");
            var isApplyDistribution = _retailServiceProxy.SetPortafolioDistribution(ContractId, clientPortafolio.NewDistribution, baseDate, Platform);
            _log.Debug("Insercion del nuevo portafolio exitoso: {cntx}", isApplyDistribution);

            _log.Info("Inserta el log de la distribucion del portafolio.");
            _retailServiceProxy.SetPortafolioDistributionLog(clientPortafolio.CurrentDistribution, clientPortafolio.NewDistribution, ContractId, transactionId);
        }
        #endregion


        private delegate bool delValidateScheduleTransfer(out string initSchedule, out string endSchedule);
        private delegate int delGetPortafolioType(string contractId, int platform, out int clientType);
        private delegate List<TransferFundOrder> delGetOrdersPending(string contractId, int platform);
        public FundsTransferValidate ValidateApplyFundsTransfer(string contractId, out OperationResult result)
        {
            FundsTransferValidate transferValidate = null;
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo los datos del contrato");
                delGetContractInfo delGetContractInfo = _retailServiceProxy.GetContractInfo;
                IAsyncResult asyncGetContractInfo = delGetContractInfo.BeginInvoke(contractId, out OperationResult resultGetContractInfo, null, null);


                _log.Info("Validando el horario para la transferencia");
                delValidateScheduleTransfer delValidateScheduleTransfer = _retailExtServiceProxy.ValidateTransferSchedule;
                IAsyncResult asyncValidateScheduleTransfer = delValidateScheduleTransfer.BeginInvoke(out string initSchedule, out string endSchedule, null, null);

                while (!asyncGetContractInfo.IsCompleted) { Thread.Sleep(20); }
                var contractInfo = delGetContractInfo.EndInvoke(out resultGetContractInfo, asyncGetContractInfo);

                _log.Info("Obteniendo el balance de los fondos por contracto");
                delGetFundsBalanceDetail delGetFundsBalanceDetail = _retailServiceProxy.GetFundsBalanceDetail;
                IAsyncResult asynGetFundsBalanceDetail = delGetFundsBalanceDetail.BeginInvoke(contractId, contractInfo.Platform, null, null);

                _log.Info("Obtiene las transferencias realizadas el dia de hoy");
                delGetOrdersPending delGetOrdersPending = _retailServiceProxy.GetOrdersPending;
                IAsyncResult asyncGetOrdersPendind = delGetOrdersPending.BeginInvoke(contractId, contractInfo.Platform, null, null);

                while (!asynGetFundsBalanceDetail.IsCompleted ||
                    !asyncValidateScheduleTransfer.IsCompleted ||
                    !asyncGetOrdersPendind.IsCompleted) { Thread.Sleep(20); }

                var availableAmount = 0.0;
                var balanceDetailFunds = delGetFundsBalanceDetail.EndInvoke(asynGetFundsBalanceDetail);

                balanceDetailFunds.ForEach(fundBalance =>
                {
                    var availableShares = fundBalance.Shares - fundBalance.compromisedShares;
                    availableAmount += Convert.ToInt32(availableShares) * fundBalance.PriceSale;
                });
                availableAmount = Math.Round(availableAmount, 2);
                _log.Debug("Monto Disponible {cntx}", availableAmount);

                var applySchedule = delValidateScheduleTransfer.EndInvoke(out initSchedule, out endSchedule, asyncValidateScheduleTransfer);
                _log.Debug("Aplica horario para transferencia {cntx}", applySchedule);

                var pendingTransfer = delGetOrdersPending.EndInvoke(asyncGetOrdersPendind);
                _log.Debug("Transferencias pendientes {cntx}", pendingTransfer);

                var applyTransferPending = pendingTransfer != null && (pendingTransfer.Count > 0);

                transferValidate = FundsTransferValidate.Create(initSchedule, endSchedule)
                    .SetAvailableAmount(availableAmount)
                    .SetProductType(contractInfo.ContractType)
                    .SetApplySchedule(applySchedule)
                    .SetApplyTranfersPending(applyTransferPending)
                    .ValidateApplyTransfer();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al validar si aplica transferencias del contrato: " + contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al validar si aplica transferencias" + ex.Message });
            }

            return transferValidate;
        }

        public void SendTransferAppliedEmailAsync(string contractId, out OperationResult result)
        {
            delSendTransferAppliedEmail dSendTransferAppliedEmail = SendTransferAppliedEmail;
            IAsyncResult asyncRSendTransferAppliedEmail = dSendTransferAppliedEmail.BeginInvoke(contractId, out result, null, null);

            result = new OperationResult { Successful = true };
        }

        public void SendTransferAppliedEmail(string contractId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            try
            {
                _log.Info("Obteniendo el identificador del cliente para el contrato : {cntx}", contractId);
                var clientIdentifier = _retailServiceProxy.GetClientIdByContract(contractId, out OperationResult resultClientId);
                _log.Debug("Identificador de cliente obtenido; contexto: {cntx}", new { contractId, clientIdentifier });

                _log.Info("Obteniendo los datos de contacto para el cliente: {cntx}", clientIdentifier);
                var contactData = _clientFundWebRetailAuthPrxy.GetContactData(clientIdentifier, out OperationResult resultContactData);
                _log.Debug("Datos de contacto obtenidos; contexto: {cntx}", new { clientIdentifier, contactData });

                _log.Info("Obteniendo los datos del cliente del proxy RetailServicePrxy.", contractId);
                var clientInfo = _retailServiceProxy.GetClientByContractId(contractId, out OperationResult resultClientInfo);
                _log.Debug("Datos del cliente obtenidos; contexto: {cntx}", new { contractId, clientInfo });


                var email = contactData.Email;
                var parameters = new Dictionary<string, string>() { { "name", (clientInfo.Name + " ").TrimStart(' ') + (clientInfo.LastNameOne + " ").TrimStart(' ') + (clientInfo.LastNameTwo + " ").TrimStart(' ') } };

                string htmlTemplateToken = _parametersProxy.GetBinaryParameter("TRNSOKTMPL", "", "", ProductType.Retail.ToString(), ContractAttributeType.Standar.ToString(), out OperationResult resTemplateParam);
                string configurationToken = _parametersProxy.GetStringParameter("TRNSOKTMPLC", "", "", ProductType.Retail.ToString(), ContractAttributeType.Standar.ToString(), out OperationResult resConfigurationParam);

                var tokenEmailConfig = JsonConvert.DeserializeObject<EmailConfig>(configurationToken);
                var request = new Dictionary<string, object>(){
                    { "emailConfig", tokenEmailConfig},
                    { "htmlTemplate", htmlTemplateToken },
                    { "email", email },
                    { "templateData", parameters }
                };

                _notificationsPrxy.SingleOrDefault(x => x.Key == tokenEmailConfig.Provider).SendNotificationsAppSync(request);
            }
            catch (Exception ex)
            {
                var errMsg = $"Error al enviar el correo de confirmación de la transferencia para el contrato: {contractId}";
                _log.Error(ex, errMsg);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = $"{errMsg} - {ex.Message}" + ex.Message, MessageType = SystemMessageTypes.Error });
            }
        }

        protected virtual void TrackFundTransferOrderAdded(int orderId, TransferOrder transferOrder)
        {
            _log.Info($"Registrando FundTransferOrder: OrderId/{orderId}-EmisionId/{transferOrder.EmisionId}-ContractId/{transferOrder.ContractId}-Shares/{transferOrder.Shares}");
            _log.Info($"Registrando FundTransferOrder: OrderId/{orderId}-ProcessDate/{transferOrder.ProcessDate}-LiquidationDate/{transferOrder.LiquidationDate}-OperationDate/{transferOrder.OperationDate}");
            _log.Debug("{CNTX}", transferOrder);
        }
    }
}
