﻿using ClientFundTransfer.Domain.TransferFundOrderAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientFundTransfer.Messages
{
    public class GetFundOrdersPendingRequest
    {
        public string ContractId;
        public int Platform;
    }

    public class GetFundOrdersPendingResponse
    {
        public List<TransferFundOrder> TransferOrders;
        public OperationResult Result;
    }
}
