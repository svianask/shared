﻿using ClientFundTransfer.Domain.FundsForSaleAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientFundTransfer.Messages
{
    public class FundsforSaleResponse
    {
        public string ProductComercialName;
        public List<FundForSale> FundsForSale;
        public OperationResult Result;
    }
}
