﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using Common.Domain;

namespace ClientFundTransfer.Messages
{

    public abstract class ValidateTransferResponse
    {
        public OperationResult Result { get; set; }
    }

    public sealed class ValidateTransferScheduleResponse : ValidateTransferResponse
    {
        public FundProcessValidate ValidateTransfers { get; set; }
    }
}
