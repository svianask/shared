﻿using ClientFundTransfer.Domain.FundTransferValueAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Messages
{
    public class FundsTradingRequest
    {
        public List<string> ListFunds { get; set; }
        public int Platform { get; set; }
        public DateTime? BaseDate { get; set; }
    }

    public class FundsTradingResponse
    {
        public List<FundTrading> FundTradings { get; set; } = new List<FundTrading>();
        public OperationResult Result { get; set; } = new OperationResult();
    }
}
