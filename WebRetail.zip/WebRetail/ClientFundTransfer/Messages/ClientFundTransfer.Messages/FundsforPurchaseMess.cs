﻿using ClientFundTransfer.Domain.FundsForPurchaseAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Messages
{
    public class FundsforPurchaseResponse
    {
        public List<FundsForPurchase> FundsForPurchase;
        public OperationResult Result;
    }

    public class FundsforPurchaseRequest
    {
        public string ContractId;
    }
}
