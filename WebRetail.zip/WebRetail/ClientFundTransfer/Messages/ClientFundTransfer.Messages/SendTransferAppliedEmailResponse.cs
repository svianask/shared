﻿using Common.Domain;

namespace ClientFundTransfer.Messages
{
    public class SendTransferAppliedEmailResponse
    {
        private OperationResult _result;

        public SendTransferAppliedEmailResponse()
        {
            Result = new OperationResult { Successful = false };
        }

        public OperationResult Result { get => _result; set => _result = value; }
    }
}
