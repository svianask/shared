﻿using ClientFundTransfer.Domain.FundTransferValueAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Messages
{
    public class ApplyFundsTransferManyToManyResponse
    {
        public OperationResult Result;

        public ApplyFundsTransferManyToManyResponse() { Result = new OperationResult(); }
    }

    public class ApplyFundsTransferManyToManyRequest
    {
        public FundsTransferValuesReq FundsTransfer;
        public string ContractId;
        public string UserId;
    }

    public class FundsTransferValuesReq
    {
        public List<FundTransferMess> SourceInvestmentFunds;
        public List<FundTransferMess> TargetInvestmentFunds;
    }

    public class FundTransferMess
    {
        public double Amount;
        public string Id;
    }
}
