﻿namespace ClientFundTransfer.Messages
{
    public class SendTransferAppliedEmailRequest
    {
        public string ContractId;
    }
}
