﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Messages
{
    public class FundsforSaleRequest
    {
        public string ContractId;
        public DateTime? BaseDate;
    }
}
