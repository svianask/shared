﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Messages
{
    public abstract class BaseResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();
    }

    public abstract class ApplyFundProcessResponse : BaseResponse
    {
        public short ProcessTypeId { get; set; }
        public FundProcess FundProcess { get; set; } = FundProcess.Empty();
    }

    public class ApplyFundProcessTransferResponse : ApplyFundProcessResponse
    {
        public ApplyFundProcessTransferResponse()
        {
            ProcessTypeId = (short)FundProcessType.Transfer;
        }
    }

    public class ApplyFundProcessReinvestmentResponse : ApplyFundProcessResponse
    {
        public ApplyFundProcessReinvestmentResponse()
        {
            ProcessTypeId = (short)FundProcessType.Reinvestment;
        }
    }

    public abstract class ApplyFundProcessRequest
    {
        public int Platform { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string FundSourceId { get; set; } = string.Empty;
        public string FundTargetId { get; set; } = string.Empty;
    }

    public class ApplyFundProcessTransferRequest : ApplyFundProcessRequest
    {
        public string FundReinvestmentId { get; set; } = string.Empty;
    }

    public class ApplyFundProcessReinvestmentRequest : ApplyFundProcessRequest
    {
        public string FundPreviousId { get; set; } = string.Empty;
        public int NoDaysBefore { get; set; } = 0;
    }

    public abstract class FundProcessRequestByDaysBefore
    {
        public int NoDaysBefore { get; set; } = 0;
    }

    public class FundProcessTransferRequest : FundProcessRequestByDaysBefore
    {
        public short ProcessTypeId { get; set; }
    }

    public class FundProcessReinvestmentRequest : FundProcessRequestByDaysBefore { }

    public abstract class CavFundsToMovementResponse : BaseResponse
    {
        public short ProcessTypeId { get; set; }
        public List<FundProcess> FundProcesses { get; set; } = new List<FundProcess>();
    }

    public class CavFundsToReprocessResponse : CavFundsToMovementResponse
    {
        public CavFundsToReprocessResponse()
        {
            ProcessTypeId = (short)FundProcessType.Transfer;
        }
    }

    public class CavFundsToReinvestmentResponse : CavFundsToMovementResponse
    {
        public CavFundsToReinvestmentResponse()
        {
            ProcessTypeId = (short)FundProcessType.Reinvestment;
        }
    }

    public class FundClientAdministration
    {
        public string FundSource { get; set; }
        public string ContractId { get; set; }
        public bool IsReinvestment { get; set; }
        public string UserId { get; set; }
    }

    public class FundClientAdministrationUpdateRequest
    {
        public List<FundClientAdministration> FundClientAdministrations { get; set; }
    }

    public class FundClientAdministrationUpdateResponse : BaseResponse
    {
        public List<FundAdministration> FundAdministrations { get; set; } = new List<FundAdministration>();
    }

    public class FundClientAdministrationRequest
    {
        public List<string> Funds { get; set; } = new List<string>();
    }

    public class FundClientAdministrationResponse : BaseResponse
    {
        public List<FundAdministration> FundAdministrations { get; set; } = new List<FundAdministration>();
    }

    public class BusinessDateDaysBeforeRequest
    {
        public int NoDaysBefore { get; set; }
        public DateTime CurrentDate { get; set; }
    }

    public class BusinessDateDaysBeforeResponse : BaseResponse
    {
        public DateTime BusinessDate { set; get; }
    }

    public class FundsAdministrationConfigRequest
    {
        public int NoMonthsLater { get; set; }
    }

    public class FundsAdministrationConfigResponse : BaseResponse
    {
        public List<FundAdministrationConfig> FundsAdministrationConfig { get; set; } = new List<FundAdministrationConfig>();
    }
}
