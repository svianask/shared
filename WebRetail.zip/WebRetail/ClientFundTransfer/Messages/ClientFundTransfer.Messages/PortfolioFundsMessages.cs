﻿using ClientFundTransfer.Domain.PortfolioFundAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientFundTransfer.Messages
{

    public class PortfolioFundsRequest
    {
        public string FundId { get; set; }
        public int Platform { get; set; } = 10;
    }

    public abstract class PortfolioFundsResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class PortfolioFundsTransferResponse : PortfolioFundsResponse
    {
        public List<PortfolioFundTransfer> PortfolioFunds { get; set; } = new List<PortfolioFundTransfer>();
    }

}
