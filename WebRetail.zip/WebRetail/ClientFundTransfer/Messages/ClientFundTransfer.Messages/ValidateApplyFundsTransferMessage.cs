﻿using ClientFundTransfer.Domain.FundsTransferValidateAggregate;

namespace ClientFundTransfer.Messages
{
    public class ValidateApplyFundsTransferRequest
    {
        public string ContractId { get; set; }
    }

    public sealed class ValidateApplyFundsTransferResponse : ValidateTransferResponse
    {
        public FundsTransferValidate ValidateTransfers { get; set; }
    }
}
