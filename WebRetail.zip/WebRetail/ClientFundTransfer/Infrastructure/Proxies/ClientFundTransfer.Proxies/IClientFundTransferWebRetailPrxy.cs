﻿using ClientFundTransfer.Domain.ProductInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies
{
    public interface IClientFundTransferWebRetailPrxy
    {
        ProductInfo GetProductInfo(string contractId);
    }
}
