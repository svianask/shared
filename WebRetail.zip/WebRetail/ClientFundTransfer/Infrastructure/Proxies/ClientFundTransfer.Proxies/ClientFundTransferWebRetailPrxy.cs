﻿using ClientFundTransfer.Domain.ProductInfoAggregate;
using ClientFundTransfer.Proxies.WebRetailMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClientFundTransfer.Proxies.ClientFundTransferWebRetailPrxyTypes;

namespace ClientFundTransfer.Proxies
{
    public class ClientFundTransferWebRetailPrxy : IClientFundTransferWebRetailPrxy
    {
        private readonly ProxyEngine _proxyEngine;

        public ClientFundTransferWebRetailPrxy(ProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ProductInfo GetProductInfo(string contractId)
        {
            ProductInfoRequestPrxy request = new ProductInfoRequestPrxy() { ContractId = contractId };
            ProductInfo productInfo;

            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"] + "ClientContracts/GetProductInfoByContractId";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                ProductInfoResponsePrxy response = JsonConvert.DeserializeObject<ProductInfoResponsePrxy>(JsonResult);
                productInfo = ProductInfoMapp.Mapp(response.ProductInfo);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else
                {
                    throw new ApplicationException("Error al consumir el servicio " + url);
                }
            }

            return productInfo;
        }
    }
}
