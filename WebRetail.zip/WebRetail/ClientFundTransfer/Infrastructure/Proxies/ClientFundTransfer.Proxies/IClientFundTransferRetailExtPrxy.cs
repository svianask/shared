﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientFundTransfer.Domain.PlanAggregate;
using Common.Domain;

namespace ClientFundTransfer.Proxies
{
    public interface IClientFundTransferRetailExtPrxy
    {
        List<Plan> GetPlansById(List<short> basPlanIds, out OperationResult result);
        string GetCommercialName(string contractId, out OperationResult result);
        bool ValidateTransferSchedule(out string initSchedule, out string endSchedule);
    }
}
