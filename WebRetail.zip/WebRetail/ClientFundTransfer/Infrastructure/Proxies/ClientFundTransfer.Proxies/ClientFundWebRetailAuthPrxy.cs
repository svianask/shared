﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientFundTransfer.Domain.ContactDataValueAggregate;
using ClientFundTransfer.Proxies.WebRetailAuth;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;

namespace ClientFundTransfer.Proxies
{
    public class ClientFundWebRetailAuthPrxy : IClientFundWebRetailAuthPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientFundWebRetailAuthPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ContactData GetContactData(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            GetContactDataRequestPrxy request = new GetContactDataRequestPrxy();
            GetContactDataResponsePrxy response = new GetContactDataResponsePrxy();

            ContactData contactData = ContactData.Create("", "", "");

            string url = ConfigurationManager.AppSettings["WebRetailAuth:Url"].ToString() + "Solvency/GetContactData";
            request.UserName = rfc;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetContactDataResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                contactData = contactDataMapp.Mapp(response.ContactInformation);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return contactData;
        }
    }
}
