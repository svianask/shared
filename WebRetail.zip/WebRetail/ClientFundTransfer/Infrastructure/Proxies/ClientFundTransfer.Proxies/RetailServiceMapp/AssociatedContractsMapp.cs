﻿using ClientFundTransfer.Domain.ContractInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class AssociatedContractsMapp
    {
        public static List<AssociatedContract> Mapp(List<PrxyAssociatedContract> lstPrxyAssociatedContracts)
        {
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();

            lstPrxyAssociatedContracts.ForEach(a =>
               associatedContracts.Add(
                   AssociatedContract.Create(a.ContractId, a.AssociatedContractId, a.AssociatedType)
                    )
                );

            return associatedContracts;
        }
    }
}
