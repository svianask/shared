﻿using ClientFundTransfer.Domain.FundsForSaleAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class FundBalanceForSaleMapp
    {
        public static List<FundBalanceForSale> Mapp(List<PrxyFund> prxyFunds)
        {
            List<FundBalanceForSale> funds = new List<FundBalanceForSale>();

            prxyFunds.ForEach(f =>
                funds.Add(
                    FundBalanceForSale.Create(f.Id, f.Name)
                        .SetMarketValues(f.MarketValues.MarketValue, f.MarketValues.MarketPurchaseValue, f.MarketValues.MarketSalesValue, f.MarketValues.DistributionPercent)
                        .SetContract(f.ContractId)
                        .SetPrices(f.Prices.Price, f.Prices.PurchasePrice, f.Prices.SalesPrice)
                        .SetShares(f.Shares.AvailableShares, f.Shares.CommittedShares, f.Shares.CommittedSharesSales)
                )
            );
            return funds;
        }


    }
}
