﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using System.Collections.Generic;
using System.Linq;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{

    public static class FundAdministrationConfigMapp
    {
        public static List<FundAdministrationConfig> Mapp(List<FundAdministrationConfigPrxy> administrationConfigPrxies)
        {
            var administrationConfigs = new List<FundAdministrationConfig>();

            foreach (var configPrxy in administrationConfigPrxies)
            {
                administrationConfigs.Add(FundAdministrationConfig.Create(configPrxy.FundOrigin, configPrxy.FundTarget, configPrxy.FundReinvestment).SetDates(configPrxy.LiquidationDate));
            }

            return administrationConfigs.OrderBy(o => o.LiquidationDate).ToList();
        }

    }
}
