﻿using ClientFundTransfer.Domain.FundProcessAggregate;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public static class FundProcessTransferMapp
    {
        public static FundProcessMovement Mapp(FundProcessTransferPrxy fundProcessTransferPrxy)
        {
            return FundProcessMovement.Create(fundProcessTransferPrxy.Id, fundProcessTransferPrxy.ProcessId, fundProcessTransferPrxy.ContractId, fundProcessTransferPrxy.UserId)
                .SetPorfolio(fundProcessTransferPrxy.PortfolioTitImp, fundProcessTransferPrxy.PortfolioCommitted)
                .SetPortfolioTransferred(fundProcessTransferPrxy.PortfolioTransferred, fundProcessTransferPrxy.PortfolioOrderId)
                .SetSourcePortfolioTransferred(fundProcessTransferPrxy.SourcePortfolioTransferred, fundProcessTransferPrxy.SourcePortfolioOrderId)
                .SetStatus(fundProcessTransferPrxy.StatusId)
                .SetTransferDates(fundProcessTransferPrxy.CreationDate, fundProcessTransferPrxy.UpdateDate);
        }
    }
}
