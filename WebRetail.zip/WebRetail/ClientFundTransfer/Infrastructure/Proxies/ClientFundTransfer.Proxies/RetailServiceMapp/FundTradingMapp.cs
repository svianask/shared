﻿using ClientFundTransfer.Domain.FundTransferValueAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class FundTradingMapp
    {
        public static List<FundTrading> Mapp(List<FundTradingPrxy> fundTradingPrxies)
        {
            List<FundTrading> fundTradings = new List<FundTrading>();

            fundTradingPrxies.ForEach(
                fundPrxie =>
                {
                    var fundTrading =
                    FundTrading.Create(fundPrxie.Id)
                    .SetSalesConfig(
                        fundPrxie.AnticipationDaysSale,
                        fundPrxie.CountAnticipationDaysSaleLabor,
                        fundPrxie.AnticipationDaysBuy,
                        fundPrxie.CountAnticipationDaysBuyLabor)
                    .SetLiquidationConfig(
                        fundPrxie.LiquidationDaysSale,
                        fundPrxie.CountLiquidationDaysSaleLabor,
                        fundPrxie.LiquidationDaysBuy,
                        fundPrxie.CountLiquidationDaysBuyLabor)
                    .SetOperationConfig(
                        fundPrxie.OperatorCommisionSale,
                        fundPrxie.OperatorCommisionBuy,
                        fundPrxie.OperatorCommisionSaleTax,
                        fundPrxie.OperatorCommisionBuyTax)
                    .SetLiquidConfig(
                        fundPrxie.BuyAnticipateLiquidation,
                        fundPrxie.IsLiquidSale,
                        fundPrxie.IsLiquidBuy,
                        fundPrxie.LastSobSubDate)
                    .SetFundConfig(
                        fundPrxie.BuyAvailable,
                        fundPrxie.SaleAvailable,
                        fundPrxie.IsFundOfFund)
                    .SetSaleTradingDates(
                        fundPrxie.SaleTradingDates.RequestDate,
                        fundPrxie.SaleTradingDates.OperationDate,
                        fundPrxie.SaleTradingDates.LiquidationDate)
                    .SetBuyTradingDates(
                        fundPrxie.BuyTradingDates.RequestDate,
                        fundPrxie.BuyTradingDates.OperationDate,
                        fundPrxie.BuyTradingDates.LiquidationDate)
                    .SetPricesConfig(
                        fundPrxie.Price.Price,
                        fundPrxie.Price.PurchasePrice,
                        fundPrxie.Price.SalesPrice,
                        fundPrxie.Price.PriceDate);

                    fundTradings.Add(fundTrading);
                }
            );

            return fundTradings;
        }
    }
}
