﻿using ClientFundTransfer.Domain.TransferFundOrderAggregate;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class TransferOrderMapp
    {
        public static List<TransferFundOrder> ListMapp(List<TransferOrderPrxy> orderPrxies)
        {
            var tranfersOrders = new List<TransferFundOrder>();

            var getDate = DateTime.Now.ToString("yyyy-MM-dd");
            orderPrxies.ForEach(order =>
            {
                var orderDay = order.ProcessDate.ToString("yyyy-MM-dd");
                if (orderDay.Equals(getDate))
                {
                    TransferFundOrder transferOrder =
                        TransferFundOrder.Create(order.Id)
                                     .OrderDetails(order.Shares, order.Price, order.Amount)
                                     .DatesDetails(order.OperationDate, order.LiquidationDate, order.ProcessDate)
                                     .SetFundId(order.EmisionId)
                                     .SetStatus(order.StatusId);

                    tranfersOrders.Add(transferOrder);
                }
            });
            return tranfersOrders;
        }
    }
}
