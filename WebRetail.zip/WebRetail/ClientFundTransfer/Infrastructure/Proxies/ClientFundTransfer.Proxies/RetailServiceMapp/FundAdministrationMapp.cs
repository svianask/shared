﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using System.Collections.Generic;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{

    public static class FundAdministrationMapp
    {
        public static FundAdministration Mapp(FundAdministrationPrxy fundAdministrationPrxy)
        {
            return FundAdministration.Create(fundAdministrationPrxy.Id, fundAdministrationPrxy.FundSource, fundAdministrationPrxy.ContractId, fundAdministrationPrxy.UserId)
                .SetFundTarget(fundAdministrationPrxy.FundTarget)
                .SetFundReinvestment(fundAdministrationPrxy.FundReinvestment)
                .SetStatus(fundAdministrationPrxy.StatusId)
                .SetTransferProcessLogId(fundAdministrationPrxy.TransferProcessLogId)
                .SetReinvestmentProcessLogId(fundAdministrationPrxy.ReinvestmentProcessLogId);
        }

        public static List<FundAdministration> Mapp(List<FundAdministrationPrxy> fundAdministrationPrxies)
        {
            var fundAdministrations = new List<FundAdministration>();
            foreach (var fundAdministrationPrxy in fundAdministrationPrxies)
            {
                fundAdministrations.Add(FundAdministration.Create(fundAdministrationPrxy.Id, fundAdministrationPrxy.FundSource, fundAdministrationPrxy.ContractId, fundAdministrationPrxy.UserId)
                    .SetFundTarget(fundAdministrationPrxy.FundTarget)
                    .SetFundReinvestment(fundAdministrationPrxy.FundReinvestment)
                    .SetStatus(fundAdministrationPrxy.StatusId)
                    .SetTransferProcessLogId(fundAdministrationPrxy.TransferProcessLogId)
                    .SetReinvestmentProcessLogId(fundAdministrationPrxy.ReinvestmentProcessLogId));
            }

            return fundAdministrations;
        }
    }
}
