﻿using ClientFundTransfer.Domain.FundSalesInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class FundsSalesInfoMapp
    {
        public static List<FundSalesInfo> Mapp(List<PrxyFundSalesInfo> prxyTradesInfo)
        {
            List<FundSalesInfo> tradesInfo = new List<FundSalesInfo>();

            foreach (PrxyFundSalesInfo prxyTradeInfo in prxyTradesInfo)
            {
                tradesInfo.Add(
                    FundSalesInfo.Create(prxyTradeInfo.Id)
                    .SetAvailableOperations(
                        prxyTradeInfo.BuyAvailable
                    )
                    .SetDaysSalesOperation(
                        prxyTradeInfo.AnticipationDaysSale,
                        prxyTradeInfo.LiquidationDaysSale
                    )
                    .SetSalesComision(
                        prxyTradeInfo.OperatorCommisionSale,
                        prxyTradeInfo.OperatorCommisionSaleTax
                    )
                    .SetSalesConfiguration(
                        prxyTradeInfo.CountAnticipationDaysSaleLabor,
                        prxyTradeInfo.CountLiquidationDaysSaleLabor,
                        prxyTradeInfo.IsLiquidSale
                    )
                    .SetSaleTradeDates(
                        prxyTradeInfo.SaleTradeDates.RequestDate,
                        prxyTradeInfo.SaleTradeDates.OperationDate,
                        prxyTradeInfo.SaleTradeDates.LiquidationDate
                    )
                    .SetLastSobSubDate(prxyTradeInfo.LastSobSubDate)
                );
            }

            return tradesInfo;
        }
    }
}
