﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientFundTransfer.Domain.ClientInfoAggregate;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class ClientInformationMapp
    {
        internal static ClientInfo Mapp(PrxyClientByContractIdResponse response)
        {
            ClientInfo clientInfo = ClientInfo.Create(response.ClientInfo.Id, response.ClientInfo.Name, response.ClientInfo.LastNameOne, response.ClientInfo.LastNameTwo);
            return clientInfo;
        }
    }
}
