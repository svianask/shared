﻿using ClientFundTransfer.Domain.PortfolioFundAggregate;
using System.Collections.Generic;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public static class PortfolioFundMapp
    {
        public static List<PortfolioFundTransfer> Mapp(List<PortfolioFundTransferPrxy> portfolioFundPrxies)
        {
            var portfolioFunds = new List<PortfolioFundTransfer>();

            portfolioFundPrxies.ForEach(f =>
            {
                portfolioFunds.Add(
                    PortfolioFundTransfer.Create(f.EmisionId, f.ContractId)
                        .SetFundValue(f.FundValue)
                        .SetStatus(f.StatusId, f.Status)
                        .SetEmision(f.EmisionId, f.EmisionName)
                        .SetPortfolio(f.PortfolioTitImp, f.PortfolioCommitted, f.PortfolioNoCommitted)
                        .SetFund(f.PriceFundAmount, f.PriceFundDate)
                );
            });

            return portfolioFunds;
        }

        public static List<PortfolioFundReinvestment> Mapp(List<PortfolioFundReinvestmentPrxy> portfolioFundPrxies)
        {
            var portfolioFunds = new List<PortfolioFundReinvestment>();

            portfolioFundPrxies.ForEach(f =>
            {
                portfolioFunds.Add(
                    PortfolioFundReinvestment.Create(f.EmisionId, f.ContractId)
                        .SetEmision(f.EmisionId, f.EmisionName)
                        .SetPortfolio(f.PortfolioTitImp, f.PortfolioCommitted, f.PortfolioNoCommitted)
                        .SetFund(f.PriceFundAmount, f.PriceFundDate)
                    );
            });

            return portfolioFunds;
        }
    }
}
