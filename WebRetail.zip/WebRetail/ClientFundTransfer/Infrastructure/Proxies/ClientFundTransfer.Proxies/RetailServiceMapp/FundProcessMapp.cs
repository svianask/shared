﻿using ClientFundTransfer.Domain.FundProcessAggregate;
using System.Collections.Generic;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public static class FundProcessMapp
    {
        public static FundProcess Mapp(FundProcessPrxy fundProcessPrxy)
        {
            return FundProcess.Create(fundProcessPrxy.Id, fundProcessPrxy.UserId, (FundProcessType)fundProcessPrxy.ProcessTypeId)
                .SetFund(fundProcessPrxy.FundSource, fundProcessPrxy.FundTarget, fundProcessPrxy.FundReinvestment)
                .SetStatus(fundProcessPrxy.StatusId)
                .SetProcessDates(fundProcessPrxy.StartDate, fundProcessPrxy.EndDate);
        }

        public static List<FundProcess> Mapp(List<FundProcessPrxy> fundProcessPrxies)
        {
            var fundProcesses = new List<FundProcess>();

            foreach (var fundProcessPrxy in fundProcessPrxies)
            {
                fundProcesses.Add(FundProcess.Create(fundProcessPrxy.Id, fundProcessPrxy.UserId, (FundProcessType)fundProcessPrxy.ProcessTypeId)
                    .SetFund(fundProcessPrxy.FundSource, fundProcessPrxy.FundTarget, fundProcessPrxy.FundReinvestment)
                    .SetStatus(fundProcessPrxy.StatusId)
                    .SetProcessDates(fundProcessPrxy.StartDate, fundProcessPrxy.EndDate));
            }

            return fundProcesses;
        }
    }
}
