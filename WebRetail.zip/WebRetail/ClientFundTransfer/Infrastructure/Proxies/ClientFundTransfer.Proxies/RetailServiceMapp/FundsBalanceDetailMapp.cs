﻿using ClientFundTransfer.Domain.FundOrderAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class FundsBalanceDetailMapp
    {
        public static List<FundBalanceDetail> Mapp(InvestmentsPrxy investments)
        {
            List<FundBalanceDetail> funds = new List<FundBalanceDetail>();

            investments.Funds.ForEach(fundDetail =>
            {
                FundBalanceDetail fundBalance = FundBalanceDetail.Create(fundDetail.Id)
                .SetFundPriceConfig(fundDetail.Prices.Price, fundDetail.Prices.PurchasePrice, fundDetail.Prices.SalesPrice, fundDetail.Prices.PriceDate)
                .SetMaketValue(fundDetail.MarketValues.MarketValue, fundDetail.MarketValues.MarketPurchaseValue, fundDetail.MarketValues.MarketSalesValue)
                .SetFundSharesConfig(fundDetail.Shares.AvailableShares, fundDetail.Shares.CommittedShares, fundDetail.Shares.CommittedSharesSales);

                funds.Add(fundBalance);
            });

            return funds;
        }
    }
}
