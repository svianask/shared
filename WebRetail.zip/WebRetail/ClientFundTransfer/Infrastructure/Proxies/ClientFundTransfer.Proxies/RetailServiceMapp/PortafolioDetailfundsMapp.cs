﻿using ClientFundTransfer.Domain.FundAllocationAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class PortafolioDetailfundsMapp
    {
        public static List<FundAllocation> Mapp(List<FundAllocationPrxy> fundsAllocation)
        {
            var lstFunds = new List<FundAllocation>();
            fundsAllocation.ForEach(fund => { lstFunds.Add(FundAllocation.Create(fund.Id, fund.Percentage)); });
            return lstFunds;
        }
    }
}
