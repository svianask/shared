﻿using ClientFundTransfer.Domain.FundsForPurchaseAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies.RetailServiceMapp
{
    public class FundsForPurchaseMapp
    {
        public static List<FundsForPurchase> Mapp(List<FundPurchaseInfo> fundPurchaseInfo)
        {
            List<FundsForPurchase> lstFundsPurchase = new List<FundsForPurchase>();

            fundPurchaseInfo.Where(x => !x.Id.StartsWith("CAV")).ToList().ForEach(fund =>
            {
                lstFundsPurchase.Add(
                    FundsForPurchase.Create(fund.Id)
                    .SetAvailableOperation(fund.BuyAvailable, fund.SaleAvailable)
                    .SetCurrency(fund.CurrencyTypeId, fund.CurrencyTypeName)
                    .SetOperator(fund.OperatorId, fund.OperatorName)
                    .SetPersonConfiguration(fund.PersonTypeId, fund.PersonTypeName)
                    .SetPurchaseConfiguration(fund.TypeId, fund.TypeName, fund.ClasificationId, fund.ClasificationName)
                );
            });

            return lstFundsPurchase;
        }

        public static FundsForPurchase MappFundBridge(FundPurchaseInfo fund)
        {
            FundsForPurchase fundBrige = FundsForPurchase.Create(fund.Id)
                    .SetAvailableOperation(fund.BuyAvailable, fund.SaleAvailable)
                    .SetCurrency(fund.CurrencyTypeId, fund.CurrencyTypeName)
                    .SetOperator(fund.OperatorId, fund.OperatorName)
                    .SetPersonConfiguration(fund.PersonTypeId, fund.PersonTypeName)
                    .SetPurchaseConfiguration(fund.TypeId, fund.TypeName, fund.ClasificationId, fund.ClasificationName);

            return fundBrige;
        }
    }
}
