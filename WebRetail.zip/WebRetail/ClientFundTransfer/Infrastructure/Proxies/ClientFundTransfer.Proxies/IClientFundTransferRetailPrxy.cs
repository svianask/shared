﻿using ClientFundTransfer.Domain.ClientInfoAggregate;
using ClientFundTransfer.Domain.ContractInfoAggregate;
using ClientFundTransfer.Domain.FundAllocationAggregate;
using ClientFundTransfer.Domain.FundOrderAggregate;
using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.FundSalesInfoAggregate;
using ClientFundTransfer.Domain.FundsForPurchaseAggregate;
using ClientFundTransfer.Domain.FundsForSaleAggregate;
using ClientFundTransfer.Domain.FundTransferValueAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using ClientFundTransfer.Domain.TransferFundOrderAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Proxies
{
    public interface IClientFundTransferRetailPrxy
    {
        List<FundBalanceForSale> GetFundBalanceByContract(int platform, List<string> contracts, out OperationResult result);

        ContractInfo GetContractInfo(string contractId, out OperationResult result);
        string GetClientIdByContract(string contractId, out OperationResult result);
        List<AssociatedContract> GetAssociatedContracts(string clientIdentifier, out OperationResult result);
        List<FundSalesInfo> GetFundSalesInfo(List<string> fundsId, int platform, DateTime? baseDate, out OperationResult result);
        List<FundsForPurchase> GetFundsForPurchases(string contractId, int platform, int planId, int personTypeId, out OperationResult result);
        int GetPersonTypeIdByContractId(string contractId, out OperationResult result);
        List<FundTrading> GetFundsTrading(List<string> fundsId, int platform, DateTime? baseDate, out OperationResult result);
        List<FundBalanceDetail> GetFundsBalanceDetail(string contractId, int platform);
        OperationResult GenerateFundTransaction(string contractId, string userId, string transactionId, int platform, int transactionType, DateTime date);
        int InsertFundTransferOrder(TransferOrder transferOrder, int platform);
        void InsertFundTransferOrderLog(TransferOrder orderLog, int orderId);
        int GetPortafolioType(string contractId, int platform, out int clientType);
        List<FundAllocation> GetPortafolioDetailfunds(string contract, int portafolioType, int clientType, int platform);
        OperationResult SetPortafolioDistribution(string contractId, List<FundAllocation> funds, DateTime baseDate, int platform);
        void SetPortafolioDistributionLog(List<FundAllocation> currentPortafolio, List<FundAllocation> newPortafolio, string contractId, string transacionId);
        List<TransferFundOrder> GetOrdersPending(string contractId, int platform);
        FundsForPurchase GetFundBridge(string contractId, int platform, int planId, int personTypeId, out OperationResult result);
        ClientInfo GetClientByContractId(string contractId, out OperationResult result);

        List<PortfolioFundTransfer> GetPortfolioFunds(string fundId, int platform, out OperationResult result);
        FundProcess GenerateCavProcess(FundProcess fundProcess, out OperationResult result);
        FundProcess UpdateCavProcess(FundProcess fundProcess, out OperationResult result);
        FundProcessMovement GenerateCavProcessTransfer(FundProcessMovement fundProcessTransfer, out OperationResult result);
        FundProcessMovement UpdateCavProcessTransfer(FundProcessMovement fundProcessTransfer, out OperationResult result);
        List<FundProcess> GetCavFundsToReprocess(short processTypeId, int nDaysBefore, out OperationResult result);
        FundProcessMovement GenerateCavProcessReinvestment(FundProcessMovement fundProcessReinvestment, out OperationResult result);
        FundProcessMovement UpdateCavProcessReinvestment(FundProcessMovement fundProcessReinvestment, out OperationResult result);
        List<FundProcess> GetCavFundsToReinvestment(int nDaysBefore, out OperationResult result);
        List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore, out OperationResult result);
        FundAdministration GenerateCavAdministration(FundAdministration fundAdministration, out OperationResult result);
        FundAdministration UpdateCavAdministration(FundAdministration fundAdministration, out OperationResult result);
        List<FundAdministration> GetClientAdministration(List<string> funds, out OperationResult result);
        FundAdministration UpdateCavClientAdministration(FundAdministration fundAdministration, out OperationResult result);
        DateTime GetBusinessDateDaysBefore(int nDaysBefore, DateTime currentDate, out OperationResult result);
        List<FundAdministrationConfig> GetFundsAdministrationConfig(DateTime baseDate, int nMonthsLater, out OperationResult result);
    }
}
