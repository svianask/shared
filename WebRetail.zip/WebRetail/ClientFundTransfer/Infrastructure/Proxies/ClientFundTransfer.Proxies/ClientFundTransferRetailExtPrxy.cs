﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientFundTransfer.Domain.PlanAggregate;
using ClientFundTransfer.Domain.ProductInfoAggregate;
using ClientFundTransfer.Proxies.RetailServiceMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using static ClientFundTransfer.Proxies.IClientFundTransferRetailExtPrxyTypes;

namespace ClientFundTransfer.Proxies
{
    public class ClientFundTransferRetailExtPrxy : IClientFundTransferRetailExtPrxy
    {
        private readonly ProxyEngine _proxyEngine;

        public ClientFundTransferRetailExtPrxy(ProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<Plan> GetPlansById(List<short> basPlanIds, out OperationResult result)
        {
            PrxyPlansRequest request = new PrxyPlansRequest();
            PrxyPlansResponse response = new PrxyPlansResponse();
            List<Plan> Plans = new List<Plan>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetPlansById"; //Controller/Action

            request.PlanIds = basPlanIds;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyPlansResponse>(JsonResult);
                Plans = PlansMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else
                {
                    throw new ApplicationException("Error al consumir el servicio " + url);
                }
            }

            return Plans;
        }

        public string GetCommercialName(string contractId, out OperationResult result)
        {
            GetComercialNameRequestPrxy request = new GetComercialNameRequestPrxy() { ContractId = contractId };
            string comercialName = string.Empty;
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetProductComercialNameByContractId"; //Controller/Action

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GetComercialNameResponsePrxy>(JsonResult);
                comercialName = response.ComercialName;
            }
            else
            {
                result.Successful = false;
                if (result.SystemMessages.Count > 0)
                {
                    throw new ApplicationException("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
                }
                else
                {
                    throw new ApplicationException("Error al consumir el servicio " + url);
                }
            }

            return comercialName;
        }

        public bool ValidateTransferSchedule(out string initSchedule, out string endSchedule)
        {
            initSchedule = string.Empty;
            endSchedule = string.Empty;
            var response = new ValidateScheduleTransferResponsePxy();
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/ValidateScheduleTransfer";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, "", out OperationResult result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ValidateScheduleTransferResponsePxy>(JsonResult);
                initSchedule = response.TransferSchedule.InitSchedule;
                endSchedule = response.TransferSchedule.EndSchedule;
            }

            return response.Result.Successful;
        }

    }
}
