﻿using ClientFundTransfer.Domain.ProductInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClientFundTransfer.Proxies.ClientFundTransferWebRetailPrxyTypes;

namespace ClientFundTransfer.Proxies.WebRetailMapp
{
    public class ProductInfoMapp
    {
        public static ProductInfo Mapp(ProductInfoPrxy productInfoPrxy)
        {
            return ProductInfo.Create(productInfoPrxy.Id, productInfoPrxy.PlanBasId, productInfoPrxy.PlanId, productInfoPrxy.Platform, 0);
        }
    }
}
