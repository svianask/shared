﻿using ClientFundTransfer.Domain.ClientInfoAggregate;
using ClientFundTransfer.Domain.ContractInfoAggregate;
using ClientFundTransfer.Domain.FundAllocationAggregate;
using ClientFundTransfer.Domain.FundOrderAggregate;
using ClientFundTransfer.Domain.FundProcessAggregate;
using ClientFundTransfer.Domain.FundSalesInfoAggregate;
using ClientFundTransfer.Domain.FundsForPurchaseAggregate;
using ClientFundTransfer.Domain.FundsForSaleAggregate;
using ClientFundTransfer.Domain.FundTransferValueAggregate;
using ClientFundTransfer.Domain.PortfolioFundAggregate;
using ClientFundTransfer.Domain.TransferFundOrderAggregate;
using ClientFundTransfer.Proxies.RetailServiceMapp;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientFundTransfer.Proxies
{
    public class ClientFundTransferRetailPrxy : IClientFundTransferRetailPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientFundTransferRetailPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<FundBalanceForSale> GetFundBalanceByContract(int platform, List<string> contracts, out OperationResult result)
        {
            PrxyContractBalanceDetailRequest request = new PrxyContractBalanceDetailRequest();
            PrxyContractBalanceDetailResponse response = new PrxyContractBalanceDetailResponse();
            List<FundBalanceForSale> fundTransfer = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBalanceDetail";

            request.Contracts = contracts;
            request.Platform = platform;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractBalanceDetailResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fundTransfer = FundBalanceForSaleMapp.Mapp(response.Investments.Funds);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fundTransfer;
        }

        public ContractInfo GetContractInfo(string contractId, out OperationResult result)
        {
            PrxyContractInfoRequest request = new PrxyContractInfoRequest();
            PrxyContractInfoResponse response = new PrxyContractInfoResponse();
            ContractInfo contractDetail = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractInfo";
            request.ContractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractInfoResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }
                contractDetail = ContractInfoMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return contractDetail;
        }

        public string GetClientIdByContract(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            PrxyClientIdByContractRequest request = new PrxyClientIdByContractRequest();
            PrxyClientIdByContractResponse response = new PrxyClientIdByContractResponse();
            string clientIdentifier = string.Empty;

            request.ContractId = contractId;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetClientIdByContract";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientIdByContractResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                clientIdentifier = response.ClientIdentifier;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return clientIdentifier;
        }

        public int GetPersonTypeIdByContractId(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            PrxyClientByContractIdRequest request = new PrxyClientByContractIdRequest();
            PrxyClientByContractIdResponse response = new PrxyClientByContractIdResponse();
            int personTypeId = 0;

            request.contractId = contractId;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/GetClientByContractId";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientByContractIdResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                personTypeId = response.ClientInfo.PersonTypeId;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return personTypeId;
        }

        public List<AssociatedContract> GetAssociatedContracts(string clientIdentifier, out OperationResult result)
        {
            PrxyAssociateContractsRequest request = new PrxyAssociateContractsRequest();
            PrxyAssociateContractsResponse response = new PrxyAssociateContractsResponse();
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetAssociateContracts";

            request.ClientIdentifier = clientIdentifier;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyAssociateContractsResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                associatedContracts = AssociatedContractsMapp.Mapp(response.LstAssociatedContracts);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return associatedContracts;
        }

        public List<FundSalesInfo> GetFundSalesInfo(List<string> fundsId, int platform, DateTime? baseDate, out OperationResult result)
        {
            PrxyFundSalesInfoRequestRequest request = new PrxyFundSalesInfoRequestRequest();
            PrxyFundSalesInfoResponseResponse response = new PrxyFundSalesInfoResponseResponse();
            List<FundSalesInfo> fundsSalesInfo = new List<FundSalesInfo>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Funds/GetFundsForSale";

            request.FundIdentifiers = fundsId;
            request.Platform = platform;
            request.BaseDate = baseDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyFundSalesInfoResponseResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fundsSalesInfo = FundsSalesInfoMapp.Mapp(response.FundsForSale);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fundsSalesInfo;
        }

        public List<FundsForPurchase> GetFundsForPurchases(string contractId, int platform, int planId, int personTypeId, out OperationResult result)
        {
            PrxyFundsForPurchaseRequest request = new PrxyFundsForPurchaseRequest();
            PrxyFundsForPurchaseResponse response = new PrxyFundsForPurchaseResponse();
            List<FundsForPurchase> fundsForPurchase = new List<FundsForPurchase>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientFunds/GetFundsForPurchase";

            request.ContractId = contractId;
            request.Platform = platform;
            request.PlanId = planId;
            request.PersontypeId = personTypeId;
            string jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyFundsForPurchaseResponse>(jsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fundsForPurchase = FundsForPurchaseMapp.Mapp(response.FundsPurchase);
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fundsForPurchase;
        }

        public List<FundTrading> GetFundsTrading(List<string> fundsId, int platform, DateTime? baseDate, out OperationResult result)
        {
            PrxyFundTradingRequest request = new PrxyFundTradingRequest();
            List<FundTrading> fundTradings = new List<FundTrading>();
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Funds/GetFundsTradings";

            request.ListFunds = fundsId;
            request.Platform = platform;
            request.BaseDate = baseDate;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PrxyFundTradingResponse>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fundTradings = FundTradingMapp.Mapp(response.FundTradings);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fundTradings;
        }

        public List<FundBalanceDetail> GetFundsBalanceDetail(string contractId, int platform)
        {
            ContractBalanceDetailRequestPrxy request = new ContractBalanceDetailRequestPrxy() { Contracts = new List<string>() { contractId }, Platform = platform };
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetContractBalanceDetail";
            List<FundBalanceDetail> fundsBlanace = new List<FundBalanceDetail>();

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<ContractBalanceDetailResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fundsBlanace = FundsBalanceDetailMapp.Mapp(response.Investments);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fundsBlanace;
        }

        public OperationResult GenerateFundTransaction(string contractId, string userId, string transactionId, int platform, int transactionType, DateTime date)
        {
            var request = new GeneraFundTransactionRequestPxy
            {
                ContractId = contractId,
                UserId = userId
            };
            request.TransactionData.TransactionDate = date;
            request.TransactionData.TransactionType = transactionType;
            request.TransactionData.TransctionId = transactionId;
            request.TransactionData.Platform = platform;

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientTransfer/GeneraTransferTransaction";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GeneraFundTransactionResponsePxy>(JsonResult);
                result = response.Result;
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return result;
        }

        public int InsertFundTransferOrder(TransferOrder transferOrder, int platform)
        {
            var orderPrxy = new TransferOrderPxy()
            {
                ContractId = transferOrder.ContractId,
                EmisionId = transferOrder.EmisionId,
                Shares = transferOrder.Shares,
                Price = transferOrder.Price,
                Amount = transferOrder.Amount,
                OperationDate = transferOrder.OperationDate,
                LiquidationDate = transferOrder.LiquidationDate,
                ComissionAmount = transferOrder.ComissionAmount,
                ComissionTaxAmount = transferOrder.ComissionTaxAmount,
                AmountType = transferOrder.AmountType,
                OperationType = transferOrder.OperationType,
                OrderChainId = transferOrder.OrderChainId,
                NotValidateSalePos = transferOrder.NotValidateSalePos,
                NotValidateCompromisedPos = transferOrder.NotValidateCompromisedPos,
                Comment = transferOrder.Comment,
                OrderType = transferOrder.OrderType,
                IsLastOrder = Convert.ToInt32(transferOrder.IsLastOrder)
            };

            var request = new InsertFundTransferOrderRequestPrxy()
            {
                OrderData = orderPrxy,
                Platform = platform
            };

            var response = new InsertFundTransferOrderResponsePrxy();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientTransfer/InsertTransferOrder";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<InsertFundTransferOrderResponsePrxy>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return response.OrderId;
        }

        public void InsertFundTransferOrderLog(TransferOrder orderLog, int orderId)
        {
            var fundOrder = new TransferOrderLog()
            {
                ProcessDate = orderLog.ProcessDate,
                LiquidationType = orderLog.LiquidationType,
                TransactionId = orderLog.TransactionId,
                OrderLogId = orderLog.OrderLogId.ToString(),
                OrderLogFatherId = orderLog.OrderLogFatherId,
                OrderLoadDate = orderLog.OrderLoadDate,
                OrderLogDepth = orderLog.OrderLogDepth,
                OrderLogLinage = orderLog.OrderLogLinage,
                OrderTypeLog = orderLog.OrderTypeLog,
                ContractId = orderLog.ContractId,
                OperationType = orderLog.OperationType,
                EmisionId = orderLog.EmisionId,
                Shares = orderLog.Shares,
                Price = orderLog.Price,
                Amount = orderLog.Amount,
                ComissionAmount = orderLog.ComissionAmount,
                ComissionTaxAmount = orderLog.ComissionTaxAmount,
                OperationDate = orderLog.OperationDate,
                LiquidationDate = orderLog.LiquidationDate,
                Comment = orderLog.Comment
            };
            var request = new FundTransferOrderLogRequest()
            {
                OrderId = orderId,
                OrderLog = fundOrder
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientTransfer/InsertTransferOrderLog";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundTransferOrderLogResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

        }

        public int GetPortafolioType(string contractId, int platform, out int clientType)
        {
            int portafolioType = 0;
            clientType = 0;
            var request = new PortfolioProfileRequestPrxy()
            {
                Platform = platform,
                ContractId = contractId
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetPortfolioProfile";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PortfolioProfileResponsePrxy>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                portafolioType = response.PortfolioType.Id;
                clientType = response.PortfolioType.ClientType.Id;
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return portafolioType;
        }

        public List<FundAllocation> GetPortafolioDetailfunds(string contract, int portafolioType, int clientType, int platform)
        {
            var lstPortafolioFunds = new List<FundAllocation>();
            var request = new GetPortafolioDetailRequestPrxy()
            {
                ContractId = contract,
                PortafolioType = portafolioType,
                ClientType = clientType,
                Platform = platform
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/GetPortafolioDetailFunds";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GetPortafolioDetailResponsePxry>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                lstPortafolioFunds = PortafolioDetailfundsMapp.Mapp(response.PortafolioDetailFunds);
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return lstPortafolioFunds;
        }

        public OperationResult SetPortafolioDistribution(string contractId, List<FundAllocation> funds, DateTime baseDate, int platform)
        {
            var request = new SetPortafolioDistributionReqPrxy()
            {
                ContractId = contractId,
                BaseDate = baseDate,
                NewFundsDistribution = funds,
                Platform = platform
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/SetPortafolioDistribution";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<SetPortafolioDistributionResPrxy>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                result = response.Result;
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return result;
        }

        public void SetPortafolioDistributionLog(List<FundAllocation> currentPortafolio, List<FundAllocation> newPortafolio, string contractId, string transacionId)
        {
            var request = new SetPortafolioDistributionLogReqPrxy()
            {
                ContractId = contractId,
                TransactionId = transacionId,
                CurrentPortafolio = currentPortafolio,
                NewPortafolio = newPortafolio
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientProfile/SetPortafolioDistributionLog";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<SetPortafolioDistributionResPrxy>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
        }

        public List<TransferFundOrder> GetOrdersPending(string contractId, int platform)
        {
            var tranfersOrder = new List<TransferFundOrder>();
            var request = new GetOrdersPendingRequestPrxy()
            {
                ContractId = contractId,
                Platform = platform
            };

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientTransfer/GetTransfersPending";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out OperationResult result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<GetOrdersPendingResponsePry>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                tranfersOrder = TransferOrderMapp.ListMapp(response.FundOrders);
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return tranfersOrder;
        }

        public FundsForPurchase GetFundBridge(string contractId, int platform, int planId, int personTypeId, out OperationResult result)
        {
            GetFundBridgeRequestPrxy request = new GetFundBridgeRequestPrxy();
            GetFundBridgeResponsePrxy response = new GetFundBridgeResponsePrxy();
            FundsForPurchase fundBridge = null;
            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientFunds/GetFundBridge";

            request.ContractId = contractId;
            request.Platform = platform;
            request.PlanId = planId;
            request.PersontypeId = personTypeId;
            string jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetFundBridgeResponsePrxy>(jsonResult);
                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fundBridge = FundsForPurchaseMapp.MappFundBridge(response.FundBridge);
            }
            else
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fundBridge;
        }

        public ClientInfo GetClientByContractId(string contractId, out OperationResult result)
        {
            PrxyClientByContractIdRequest request = new PrxyClientByContractIdRequest();
            PrxyClientByContractIdResponse response = new PrxyClientByContractIdResponse();
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "Client/GetClientByContractId";
            request.contractId = contractId;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            ClientInfo clientInfo;

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientByContractIdResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                clientInfo = ClientInformationMapp.Mapp(response);

            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return clientInfo;
        }

        public List<PortfolioFundTransfer> GetPortfolioFunds(string fundId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var portfolioFunds = new List<PortfolioFundTransfer>();
            var request = new PortfolioFundsRequestPrxy() { FundId = fundId, Platform = platform };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetPortfolioFunds";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PortfolioFundsTransferResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                portfolioFunds = PortfolioFundMapp.Mapp(response.PortfolioFunds);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return portfolioFunds;
        }

        public FundProcess GenerateCavProcess(FundProcess fundProcess, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fpResult = FundProcess.Empty();
            var request = new FundProcessCreateRequestPrxy()
            {
                ProcessId = fundProcess.Id,
                UserId = fundProcess.UserId,
                FundSource = fundProcess.FundSource,
                FundTarget = fundProcess.FundTarget,
                FundReinvestment = fundProcess.FundReinvestment,
                ProcessTypeId = fundProcess.ProcessTypeId
            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GenerateCavProcess";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fpResult = FundProcessMapp.Mapp(response.FundProcess);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fpResult;
        }

        public FundProcess UpdateCavProcess(FundProcess fundProcess, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fpResult = FundProcess.Empty();
            var request = new FundProcessUpdateRequestPrxy()
            {
                ProcessId = fundProcess.Id,
                UserId = fundProcess.UserId,
                FundSource = fundProcess.FundSource,
                FundTarget = fundProcess.FundTarget,
                FundReinvestment = fundProcess.FundReinvestment,
                StatusId = fundProcess.StatusId,
                ErrorDescription = fundProcess.ErrorDescription,
                ProcessTypeId = fundProcess.ProcessTypeId
            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/UpdateCavProcess";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fpResult = FundProcessMapp.Mapp(response.FundProcess);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return fpResult;
        }

        public FundProcessMovement GenerateCavProcessTransfer(FundProcessMovement fundProcessTransfer, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundProcessMovement.Empty();
            var request = new FundProcessTransferCreateRequestPrxy()
            {
                Id = fundProcessTransfer.Id,
                ProcessId = fundProcessTransfer.ProcessId,
                ContractId = fundProcessTransfer.ContractId,
                PortfolioTitImp = fundProcessTransfer.PortfolioTitImp,
                PortfolioCommitted = fundProcessTransfer.PortfolioCommitted,
                UserId = fundProcessTransfer.UserId

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GenerateCavProcessTransfer";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessTransferResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundProcessTransferMapp.Mapp(response.FundProcessTransfer);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public FundProcessMovement UpdateCavProcessTransfer(FundProcessMovement fundProcessTransfer, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundProcessMovement.Empty();
            var request = new FundProcessTransferUpdateRequestPrxy()
            {
                Id = fundProcessTransfer.Id,
                ProcessId = fundProcessTransfer.ProcessId,
                ContractId = fundProcessTransfer.ContractId,
                PortfolioTitImp = fundProcessTransfer.PortfolioTitImp,
                PortfolioCommitted = fundProcessTransfer.PortfolioCommitted,
                PortfolioTransferred = fundProcessTransfer.PortfolioTransferred,
                PortfolioOrderId = fundProcessTransfer.PortfolioOrderId,
                SourcePortfolioTransferred = fundProcessTransfer.SourcePortfolioTransferred,
                SourcePortfolioOrderId = fundProcessTransfer.SourcePortfolioOrderId,
                UserId = fundProcessTransfer.UserId,
                StatusId = fundProcessTransfer.StatusId,
                Comment = fundProcessTransfer.Comment

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/UpdateCavProcessTransfer";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessTransferResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundProcessTransferMapp.Mapp(response.FundProcessTransfer);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public List<FundProcess> GetCavFundsToReprocess(short processTypeId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = new List<FundProcess>();
            var request = new FundProcessTransferRequestPrxy()
            {
                ProcessTypeId = processTypeId,
                NoDaysBefore = nDaysBefore
            };

            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetCavFundsToReprocess";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessToReprocessResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundProcessMapp.Mapp(response.FundProcesses);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public FundProcessMovement GenerateCavProcessReinvestment(FundProcessMovement fundProcessReinvestment, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundProcessMovement.Empty();
            var request = new FundProcessTransferCreateRequestPrxy()
            {
                Id = fundProcessReinvestment.Id,
                ProcessId = fundProcessReinvestment.ProcessId,
                ContractId = fundProcessReinvestment.ContractId,
                PortfolioTitImp = fundProcessReinvestment.PortfolioTitImp,
                PortfolioCommitted = fundProcessReinvestment.PortfolioCommitted,
                UserId = fundProcessReinvestment.UserId

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GenerateCavProcessReinvestment";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessTransferResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundProcessTransferMapp.Mapp(response.FundProcessTransfer);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public FundProcessMovement UpdateCavProcessReinvestment(FundProcessMovement fundProcessReinvestment, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundProcessMovement.Empty();
            var request = new FundProcessTransferUpdateRequestPrxy()
            {
                Id = fundProcessReinvestment.Id,
                ProcessId = fundProcessReinvestment.ProcessId,
                ContractId = fundProcessReinvestment.ContractId,
                PortfolioTitImp = fundProcessReinvestment.PortfolioTitImp,
                PortfolioCommitted = fundProcessReinvestment.PortfolioCommitted,
                PortfolioTransferred = fundProcessReinvestment.PortfolioTransferred,
                PortfolioOrderId = fundProcessReinvestment.PortfolioOrderId,
                SourcePortfolioTransferred = fundProcessReinvestment.SourcePortfolioTransferred,
                SourcePortfolioOrderId = fundProcessReinvestment.SourcePortfolioOrderId,
                UserId = fundProcessReinvestment.UserId,
                StatusId = fundProcessReinvestment.StatusId,
                Comment = fundProcessReinvestment.Comment

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/UpdateCavProcessReinvestment";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessTransferResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundProcessTransferMapp.Mapp(response.FundProcessTransfer);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public List<FundProcess> GetCavFundsToReinvestment(int nDaysBefore, out OperationResult result)
        {

            result = new OperationResult() { Successful = true };
            var fptResult = new List<FundProcess>();
            var request = new FundProcessReinvestmentRequestPrxy()
            {
                NoDaysBefore = nDaysBefore,
            };

            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetCavFundsToReinvestment";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundProcessToReinvestmentResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundProcessMapp.Mapp(response.FundProcesses);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var portfolioFunds = new List<PortfolioFundReinvestment>();
            var request = new PortfolioFundsReinvestmentRequestPrxy() { FundBridge = fundBridge, FundReinvestment = fundReinvestment, FundPreviousId = fundPreviousId, NoDaysBefore = nDaysBefore };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetPortfolioFundsToReinvestment";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<PortfolioFundsReinvestmentResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                portfolioFunds = PortfolioFundMapp.Mapp(response.PortfolioFunds);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return portfolioFunds;
        }

        public FundAdministration GenerateCavAdministration(FundAdministration fundAdministration, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundAdministration.Empty();
            var request = new FundAdministrationCreateRequestPrxy()
            {
                FundSource = fundAdministration.FundSource,
                FundTarget = fundAdministration.FundTarget,
                FundReinvestment = fundAdministration.FundReinvestment,
                ContractId = fundAdministration.ContractId,
                UserId = fundAdministration.UserId,
                TransferProcessLogId = fundAdministration.TransferProcessLogId,

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GenerateCavAdministration";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundAdministrationResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundAdministrationMapp.Mapp(response.FundAdministration);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public FundAdministration UpdateCavAdministration(FundAdministration fundAdministration, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundAdministration.Empty();
            var request = new FundAdministrationUpdateRequestPrxy()
            {
                FundSource = fundAdministration.FundSource,
                FundReinvestment = fundAdministration.FundReinvestment,
                ContractId = fundAdministration.ContractId,
                UserId = fundAdministration.UserId,
                ReinvestmentProcessLogId = fundAdministration.ReinvestmentProcessLogId,

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/UpdateCavAdministration";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundAdministrationResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundAdministrationMapp.Mapp(response.FundAdministration);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public List<FundAdministration> GetClientAdministration(List<string> funds, out OperationResult result)
        {

            result = new OperationResult() { Successful = true };
            var fptResult = new List<FundAdministration>();
            var request = new FundClientAdministrationRequestPrxy()
            {
                Funds = funds
            };

            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetClientAdministration";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundClientAdministrationResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundAdministrationMapp.Mapp(response.FundAdministrations);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public FundAdministration UpdateCavClientAdministration(FundAdministration fundAdministration, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var fptResult = FundAdministration.Empty();
            var request = new FundClientAdministrationUpdateRequestPrxy()
            {
                FundSource = fundAdministration.FundSource,
                ContractId = fundAdministration.ContractId,
                UserId = fundAdministration.UserId,
                StatusId = fundAdministration.StatusId,

            };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/UpdateCavClientAdministration";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundClientAdministrationUpdateResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                fptResult = FundAdministrationMapp.Mapp(response.FundAdministration);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }
            return fptResult;
        }

        public DateTime GetBusinessDateDaysBefore(int nDaysBefore, DateTime currentDate, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var businessDate = currentDate.Date;
            var request = new BusinessDateDaysBeforeRequestPrxy() { NoDaysBefore = nDaysBefore, CurrentDate = currentDate };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetBusinessDateDaysBefore";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<BusinessDateDaysBeforeResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                businessDate = response.BusinessDate;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return businessDate;
        }

        public List<FundAdministrationConfig> GetFundsAdministrationConfig(DateTime baseDate, int nMonthsLater, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var cavFundConfigs = new List<FundAdministrationConfig>();
            var request = new FundsAdministrationConfigRequestPrxy() { BaseDate = baseDate, NoMonthsLater = nMonthsLater };
            var url = ConfigurationManager.AppSettings["RetailService:URLService"] + "Funds/GetFundsAdministrationConfig";
            var jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                var response = JsonConvert.DeserializeObject<FundsAdministrationConfigResponsePrxy>(jsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.ToMessage()); }

                cavFundConfigs = FundAdministrationConfigMapp.Mapp(response.FundsAdministrationConfig);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.ToMessage());
            }

            return cavFundConfigs;
        }
    }
}
