﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies
{
    public class ClientFundTransferWebRetailPrxyTypes
    {
        #region ProductInfo
        public class ProductInfoPrxy
        {
            public short PlanBasId;
            public string PlanId;
            public int Platform;
            public string ComercialName;
            public string Id;
        }

        public class ProductInfoResponsePrxy
        {
            public OperationResult Result;
            public ProductInfoPrxy ProductInfo;
        }

        public class ProductInfoRequestPrxy
        {
            public string ContractId;
        }
        #endregion
    }
}
