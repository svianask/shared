﻿using ClientFundTransfer.Domain.FundAllocationAggregate;
using ClientFundTransfer.Domain.FundProcessAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Proxies
{
    #region Investments services

    public class PrxyContractBalanceDetailRequest
    {
        public int Platform;
        public List<string> Contracts;
    }

    public class PrxyContractBalanceDetailResponse
    {
        public PrxyInvestments Investments;
        public OperationResult Result;
    }

    public class PrxyInvestments
    {
        public List<PrxyFund> Cash;
        public List<PrxyFund> Funds;
    }

    public class PrxyFund
    {
        public string Id;
        public string ContractId;
        public string Name;
        public PrxyShares Shares;
        public PrxyPrices Prices;
        public PrxMarketValues MarketValues;
    }

    public class PrxMarketValues
    {
        public decimal MarketValue;
        public decimal MarketPurchaseValue;
        public decimal MarketSalesValue;
        public decimal DistributionPercent;
    }

    public class PrxyShares
    {
        public decimal AvailableShares;
        public decimal CommittedShares;
        public decimal CommittedSharesSales;
    }

    public class PrxyPrices
    {
        public decimal Price;
        public decimal PurchasePrice;
        public decimal SalesPrice;
        public DateTime PriceDate;
    }
    #endregion

    #region ContractInfo
    public class PrxyContractInfoResponse
    {
        public PrxyContractInfo ContractInfo;
        public OperationResult Result;

        public PrxyContractInfoResponse()
        {
            Result = new OperationResult();
        }
        public class PrxyContractInfo
        {
            public string Id;
            public short PlanBasId;
            public int Platform;
            public short GoalId;
            public string ContratoAgrupa;
            public DateTime AfiliationDate;
            public string GoalDescription;
            public int ContractType;
        }

    }

    public class PrxyContractInfoRequest
    {
        public string ContractId;
    }
    #endregion

    #region ClientIdentifier

    public class PrxyClientIdByContractRequest
    {
        public string ContractId;
    }

    public class PrxyClientIdByContractResponse
    {
        public OperationResult Result;
        public string ClientIdentifier;
    }
    #endregion

    #region Associated contracts
    public class PrxyAssociateContractsResponse
    {
        public OperationResult Result;
        public List<PrxyAssociatedContract> LstAssociatedContracts;
    }
    public class PrxyAssociateContractsRequest
    {
        public string ClientIdentifier;
    }

    public class PrxyAssociatedContract
    {
        public string ContractId;
        public string AssociatedContractId;
        public int AssociatedType;
    }
    #endregion

    #region FundSalesInfo
    public class PrxyFundSalesInfoRequestRequest
    {
        public List<string> FundIdentifiers;
        public DateTime? BaseDate;
        public int Platform;
    }

    public class PrxyFundSalesInfoResponseResponse
    {
        public OperationResult Result;
        public List<PrxyFundSalesInfo> FundsForSale;
    }

    public class PrxyFundSalesInfo
    {
        public int AnticipationDaysSale;
        public bool CountAnticipationDaysSaleLabor;
        public int LiquidationDaysSale;
        public bool CountLiquidationDaysSaleLabor;
        public double OperatorCommisionSale;
        public double OperatorCommisionSaleTax;
        public bool IsLiquidSale;
        public bool BuyAvailable;
        public PrxySaleTradeDates SaleTradeDates;
        public DateTime LastSobSubDate;
        public string Id;
    }

    public class PrxySaleTradeDates
    {
        public DateTime RequestDate;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
    }
    #endregion

    #region FundPurchaseInfo
    public class PrxyFundsForPurchaseResponse
    {
        public OperationResult Result;
        public List<FundPurchaseInfo> FundsPurchase;
    }

    public class FundPurchaseInfo
    {
        public bool BuyAvailable;
        public bool SaleAvailable;
        public int OperatorId;
        public string OperatorName;
        public int ClasificationId;
        public string ClasificationName;
        public int TypeId;
        public string TypeName;
        public int PersonTypeId;
        public string PersonTypeName;
        public int CurrencyTypeId;
        public string CurrencyTypeName;
        public string Id;
    }

    public class PrxyFundsForPurchaseRequest
    {
        public string ContractId;
        public int PlanId;
        public int PersontypeId;
        public int Platform;
    }
    #endregion

    #region ClientInfo
    public class PrxyClientByContractIdResponse
    {
        public OperationResult Result;
        public PrxyClientInfo ClientInfo;
    }

    public class PrxyClientInfo
    {

        public string Name;
        public string LastNameOne;
        public string LastNameTwo;
        public string RFC;
        public string CURP;
        public string Gender;
        public DateTime Birthday;
        public string Id;
        public int PersonTypeId;
    }

    public class PrxyClientByContractIdRequest
    {
        public string contractId;
    }
    #endregion

    #region FundTrading
    public class PrxyFundTradingRequest
    {
        public List<string> ListFunds;
        public int Platform;
        public DateTime? BaseDate;
    }

    public class PrxyFundTradingResponse
    {
        public List<FundTradingPrxy> FundTradings;
        public OperationResult Result;

        public PrxyFundTradingResponse() { FundTradings = new List<FundTradingPrxy>(); Result = new OperationResult(); }
    }

    public class FundTradingPrxy
    {
        public int AnticipationDaysSale;
        public bool CountAnticipationDaysSaleLabor;
        public int AnticipationDaysBuy;
        public bool CountAnticipationDaysBuyLabor;
        public int LiquidationDaysSale;
        public int LiquidationDaysBuy;
        public bool CountLiquidationDaysSaleLabor;
        public bool CountLiquidationDaysBuyLabor;
        public double OperatorCommisionSale;
        public double OperatorCommisionBuy;
        public double OperatorCommisionSaleTax;
        public double OperatorCommisionBuyTax;
        public bool BuyAnticipateLiquidation;
        public bool IsLiquidBuy;
        public bool IsLiquidSale;
        public DateTime LastSobSubDate;
        public bool BuyAvailable;
        public bool SaleAvailable;
        public bool IsFundOfFund;
        public TradingDatesPrxy BuyTradingDates;
        public TradingDatesPrxy SaleTradingDates;
        public PricesTradingPrxy Price;
        public string Id;
    }

    public class TradingDatesPrxy
    {
        public DateTime RequestDate;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
    }

    public class PricesTradingPrxy
    {
        public double Price;
        public double PurchasePrice;
        public double SalesPrice;
        public DateTime PriceDate;
    }
    #endregion

    #region BalanceDetail
    public class ContractBalanceDetailResponsePrxy
    {
        public InvestmentsPrxy Investments;
        public OperationResult Result;
    }

    public class ContractBalanceDetailRequestPrxy
    {
        public int Platform;
        public List<string> Contracts;
    }

    public class InvestmentsPrxy
    {
        public List<FundPrxy> Funds;
        public List<FundPrxy> Cash;
    }

    public class FundPrxy
    {
        public string Id;
        public string ContractId;
        public string Name;
        public SharesPxy Shares;
        public PricesPrxy Prices;
        public MarketValuesPrxy MarketValues;
    }

    public class SharesPxy
    {
        public decimal AvailableShares;
        public decimal CommittedShares;
        public decimal CommittedSharesSales;
    }

    public class PricesPrxy
    {
        public double Price;
        public double PurchasePrice;
        public double SalesPrice;
        public DateTime PriceDate;
    }

    public class MarketValuesPrxy
    {
        public double MarketValue;
        public double MarketPurchaseValue;
        public double MarketSalesValue;
        public double DistributionPercent;
    }
    #endregion

    #region GeneraTransaccionSIIF
    public class GeneraFundTransactionResponsePxy
    {
        public OperationResult Result;
    }

    public class GeneraFundTransactionRequestPxy
    {
        public string ContractId;
        public string UserId;
        public FundTransactionDataPxy TransactionData;
        public GeneraFundTransactionRequestPxy() { TransactionData = new FundTransactionDataPxy(); }
    }

    public class FundTransactionDataPxy
    {
        public int Platform;
        public int TransactionType;
        public string TransctionId;
        public DateTime TransactionDate;
    }
    #endregion

    #region InsertFundTransferOrder
    public class InsertFundTransferOrderResponsePrxy
    {
        public OperationResult Result;
        public int OrderId;
    }

    public class InsertFundTransferOrderRequestPrxy
    {
        public TransferOrderPxy OrderData;
        public int Platform;

    }

    public class TransferOrderPxy
    {
        public string ContractId;
        public int OperationType;
        public int AmountType;
        public string EmisionId;
        public decimal Shares;
        public double Price;
        public double Amount;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public double ComissionAmount;
        public double ComissionTaxAmount;
        public string Comment;
        public int OrderChainId;
        public int IsLastOrder;
        public int OrderType;
        public int NotValidateSalePos;
        public int NotValidateCompromisedPos;
    }

    public class FundTransferOrderLogResponse
    {
        public OperationResult Result;
    }

    public class FundTransferOrderLogRequest
    {
        public int OrderId;
        public TransferOrderLog OrderLog;
    }

    public class TransferOrderLog
    {
        public DateTime ProcessDate;
        public string LiquidationType;
        public string TransactionId;
        public string OrderLogId;
        public Guid OrderLogFatherId;
        public DateTime OrderLoadDate;
        public int OrderLogDepth;
        public string OrderLogLinage;
        public int OrderTypeLog;
        public string ContractId;
        public int OperationType;
        public string EmisionId;
        public decimal Shares;
        public double Price;
        public double Amount;
        public double ComissionAmount;
        public double ComissionTaxAmount;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public string Comment;
    }
    #endregion

    #region GetPortafoliioType
    public class PortfolioProfileRequestPrxy
    {
        public string ContractId;
        public int Platform;
    }

    public class PortfolioProfileResponsePrxy
    {
        public PortfolioProfileResponsePrxy()
        {
            Result = new OperationResult();
        }

        public SalesPractPortfolioTypePrxy PortfolioType;
        public OperationResult Result;
    }

    public class SalesPractPortfolioTypePrxy
    {

        public string Description;
        public ClientTypePrxy ClientType;
        public int Id;

        public SalesPractPortfolioTypePrxy() { ClientType = new ClientTypePrxy(); }
    }

    public class ClientTypePrxy
    {
        public int Id;
        public string Description;
    }
    #endregion

    #region GetPortafolioDetailfunds
    public class GetPortafolioDetailResponsePxry
    {
        public List<FundAllocationPrxy> PortafolioDetailFunds;
        public OperationResult Result;
    }

    public class GetPortafolioDetailRequestPrxy
    {
        public string ContractId;
        public int ClientType;
        public int PortafolioType;
        public int Platform;
    }

    public class FundAllocationPrxy
    {
        public string Id;
        public decimal Percentage;
    }
    #endregion

    #region SetPortafolioDistribution
    public class SetPortafolioDistributionResPrxy
    {
        public OperationResult Result;
    }

    public class SetPortafolioDistributionReqPrxy
    {
        public List<FundAllocation> NewFundsDistribution;
        public string ContractId;
        public DateTime BaseDate;
        public int Platform;
    }

    public class SetPortafolioDistributionLogReqPrxy
    {
        public List<FundAllocation> CurrentPortafolio;
        public List<FundAllocation> NewPortafolio;
        public string ContractId;
        public string TransactionId;
    }
    #endregion

    #region GetOrdersPending
    public class GetOrdersPendingResponsePry
    {
        public List<TransferOrderPrxy> FundOrders;
        public OperationResult Result;
    }

    public class TransferOrderPrxy
    {
        public int Id;
        public string EmisionId;
        public int Shares;
        public double Price;
        public double Amount;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public DateTime ProcessDate;
        public int StatusId;
    }

    public class GetOrdersPendingRequestPrxy
    {
        public string ContractId;
        public int Platform;
    }
    #endregion

    #region GetFundBridge
    public class GetFundBridgeResponsePrxy
    {
        public OperationResult Result;
        public FundPurchaseInfo FundBridge;
    }

    public class GetFundBridgeRequestPrxy
    {
        public string ContractId;
        public int PlanId;
        public int PersontypeId;
        public int Platform;
    }
    #endregion


    #region PortfolioFunds

    public class PortfolioFundsRequestPrxy
    {
        public int Platform { get; set; } = 10;
        public string FundId { get; set; } = string.Empty;
    }

    public class PortfolioFundsReinvestmentRequestPrxy
    {
        public string FundBridge { get; set; }
        public string FundReinvestment { get; set; }
        public string FundPreviousId { get; set; }
        public int NoDaysBefore { get; set; }
    }

    public abstract class PortfolioFundsResponsePrxy
    {
        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class PortfolioFundsTransferResponsePrxy : PortfolioFundsResponsePrxy
    {
        public List<PortfolioFundTransferPrxy> PortfolioFunds { get; set; } = new List<PortfolioFundTransferPrxy>();
    }

    public class PortfolioFundsReinvestmentResponsePrxy : PortfolioFundsResponsePrxy
    {
        public List<PortfolioFundReinvestmentPrxy> PortfolioFunds { get; set; } = new List<PortfolioFundReinvestmentPrxy>();
    }

    public abstract class PortfolioFundPrxy
    {
        public string ContractId { get; set; }

        public string EmisionId { get; set; }
        public string EmisionName { get; set; }

        public double PortfolioTitImp { get; set; }
        public double PortfolioCommitted { get; set; }
        public double PortfolioNoCommitted { get; set; }

        public double PriceFundAmount { get; set; }
        public DateTime PriceFundDate { get; set; }
    }

    public class PortfolioFundTransferPrxy : PortfolioFundPrxy
    {
        public double FundValue { get; set; }

        public short StatusId { get; set; }
        public string Status { get; set; }

        public short StatusReinvestmentId { get; set; }
        public string StatusReinvestment { get; set; }
    }

    public class PortfolioFundReinvestmentPrxy : PortfolioFundPrxy { }

    #endregion

    #region AdmonFundTransfer

    public abstract class BaseResponsePrxy
    {
        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class FundProcessCreateRequestPrxy
    {
        public string ProcessId { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string FundSource { get; set; } = string.Empty;
        public string FundTarget { get; set; } = string.Empty;
        public string FundReinvestment { get; set; } = string.Empty;
        public short ProcessTypeId { get; set; } = 0;
    }

    public class FundProcessUpdateRequestPrxy : FundProcessCreateRequestPrxy
    {
        public short StatusId { get; set; } = 0;
        public string ErrorDescription { get; set; } = string.Empty;
    }

    public class FundProcessResponsePrxy : BaseResponsePrxy
    {
        public FundProcessPrxy FundProcess { get; set; } = new FundProcessPrxy();
    }

    public class FundProcessPrxy
    {
        public string Id { get; set; } = string.Empty;
        public DateTime? StartDate { get; set; } = DateTime.MinValue;
        public DateTime? EndDate { get; set; } = DateTime.MinValue;
        public string FundSource { get; set; } = string.Empty;
        public string FundTarget { get; set; } = string.Empty;
        public string FundReinvestment { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public short StatusId { get; set; } = 0;
        public short ProcessTypeId { get; set; } = 0;
    }


    public class FundProcessTransferCreateRequestPrxy
    {
        public string Id { get; set; } = string.Empty;
        public string ProcessId { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
        public double PortfolioTitImp { get; set; } = 0;
        public double PortfolioCommitted { get; set; } = 0;
        public string UserId { get; set; } = string.Empty;
    }

    public class FundProcessTransferUpdateRequestPrxy : FundProcessTransferCreateRequestPrxy
    {
        public double PortfolioTransferred { get; set; } = 0;
        public int PortfolioOrderId { get; set; } = 0;
        public double SourcePortfolioTransferred { get; set; } = 0;
        public int SourcePortfolioOrderId { get; set; } = 0;
        public short StatusId { get; set; }
        public string Comment { get; set; }
    }

    public class FundProcessTransferResponsePrxy : BaseResponsePrxy
    {
        public FundProcessTransferPrxy FundProcessTransfer { get; set; } = new FundProcessTransferPrxy();
    }

    public class FundProcessTransferPrxy
    {
        public string Id { get; set; } = string.Empty;
        public string ProcessId { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;

        public double PortfolioTitImp { get; set; }
        public double PortfolioCommitted { get; set; }
        public double PortfolioTransferred { get; set; }
        public int PortfolioOrderId { get; set; }
        public double SourcePortfolioTransferred { get; set; }
        public int SourcePortfolioOrderId { get; set; }

        public string UserId { get; set; } = string.Empty;
        public short StatusId { get; set; } = 0;
        public DateTime? CreationDate { get; set; } = DateTime.MinValue;
        public DateTime? UpdateDate { get; set; } = DateTime.MinValue;
    }

    public abstract class FundProcessRequestByDaysBeforePrxy
    {
        public int NoDaysBefore { get; set; }
    }

    public class FundProcessTransferRequestPrxy : FundProcessRequestByDaysBeforePrxy
    {
        public short ProcessTypeId { get; set; }
    }

    public class FundProcessReinvestmentRequestPrxy : FundProcessRequestByDaysBeforePrxy { }

    public abstract class FundToMovementResponsePrxy : BaseResponsePrxy
    {
        public short ProcessTypeId { get; set; }
        public List<FundProcessPrxy> FundProcesses { get; set; } = new List<FundProcessPrxy>();
    }

    public class FundProcessToReprocessResponsePrxy : FundToMovementResponsePrxy
    {
        public FundProcessToReprocessResponsePrxy()
        {
            ProcessTypeId = (short)FundProcessType.Transfer;
        }
    }

    public class FundProcessToReinvestmentResponsePrxy : FundToMovementResponsePrxy
    {
        public FundProcessToReinvestmentResponsePrxy()
        {
            ProcessTypeId = (short)FundProcessType.Reinvestment;
        }
    }

    public abstract class FundAdministrationRequestPrxy
    {
        public string FundSource { get; set; }
        public string FundReinvestment { get; set; }
        public string ContractId { get; set; }
        public string UserId { get; set; }
    }

    public class FundAdministrationCreateRequestPrxy : FundAdministrationRequestPrxy
    {
        public string FundTarget { get; set; }
        public string TransferProcessLogId { get; set; }
    }

    public class FundAdministrationUpdateRequestPrxy : FundAdministrationRequestPrxy
    {
        public string ReinvestmentProcessLogId { get; set; }
    }

    public class FundAdministrationResponsePrxy : BaseResponsePrxy
    {
        public FundAdministrationPrxy FundAdministration { get; set; }
    }

    public class FundAdministrationPrxy
    {
        public int Id { get; set; }
        public string FundSource { get; set; }
        public string FundTarget { get; set; }
        public string FundReinvestment { get; set; }
        public string ContractId { get; set; }
        public short StatusId { get; set; }
        public string UserId { get; set; }
        public string TransferProcessLogId { get; set; }
        public string ReinvestmentProcessLogId { get; set; }
    }

    public class FundClientAdministrationUpdateRequestPrxy
    {
        public string FundSource { get; set; }
        public string ContractId { get; set; }
        public short StatusId { get; set; }
        public string UserId { get; set; }
    }

    public class FundClientAdministrationRequestPrxy
    {
        public List<string> Funds { get; set; } = new List<string>();
    }

    public class FundClientAdministrationUpdateResponsePrxy : BaseResponsePrxy
    {
        public FundAdministrationPrxy FundAdministration { get; set; }
    }

    public class FundClientAdministrationResponsePrxy : BaseResponsePrxy
    {
        public List<FundAdministrationPrxy> FundAdministrations { get; set; }
    }


    public class BusinessDateDaysBeforeRequestPrxy
    {
        public int NoDaysBefore { get; set; }
        public DateTime CurrentDate { get; set; }
    }

    public class BusinessDateDaysBeforeResponsePrxy : BaseResponsePrxy
    {
        public DateTime BusinessDate { set; get; }
    }


    public class FundsAdministrationConfigRequestPrxy
    {
        public DateTime BaseDate { get; set; }
        public int NoMonthsLater { get; set; }
    }

    public class FundsAdministrationConfigResponsePrxy : BaseResponsePrxy
    {
        public List<FundAdministrationConfigPrxy> FundsAdministrationConfig { get; set; } = new List<FundAdministrationConfigPrxy>();
    }

    public class FundAdministrationConfigPrxy
    {
        public string FundOrigin { get; set; }
        public string FundTarget { get; set; }
        public string FundReinvestment { get; set; }
        public DateTime LiquidationDate { get; set; }

    }

    #endregion
}
