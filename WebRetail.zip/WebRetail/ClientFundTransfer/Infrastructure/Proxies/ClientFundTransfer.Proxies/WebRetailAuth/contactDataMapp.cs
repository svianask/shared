﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientFundTransfer.Domain.ContactDataValueAggregate;

namespace ClientFundTransfer.Proxies.WebRetailAuth
{
    public class contactDataMapp
    {
        internal static ContactData Mapp(ContactInformationPrxy contactInformation)
        {
            ContactData clientContactData = null;
            clientContactData = ContactData.Create(contactInformation.Email, contactInformation.MobilePhone, contactInformation.CountryDialCode);
            clientContactData.SetSetUpdateDate(contactInformation.LastUpdateDate);
            return clientContactData;
        }


    }
}
