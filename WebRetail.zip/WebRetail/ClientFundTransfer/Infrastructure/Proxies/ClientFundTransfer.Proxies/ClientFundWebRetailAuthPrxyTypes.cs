﻿using Common.Domain;
using System;

namespace ClientFundTransfer.Proxies
{
    public class GetContactDataRequestPrxy
    {
        public string UserName;
    }

    public class GetContactDataResponsePrxy
    {
        public ContactInformationPrxy ContactInformation;
        public OperationResult Result;
    }

    public class ContactInformationPrxy
    {
        public string Email;
        public string MobilePhone;
        public string CountryDialCode;
        public DateTime LastUpdateDate;
    }
}
