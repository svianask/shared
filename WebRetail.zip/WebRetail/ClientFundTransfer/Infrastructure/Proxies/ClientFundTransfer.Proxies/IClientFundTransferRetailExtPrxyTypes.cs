﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies
{
    public class IClientFundTransferRetailExtPrxyTypes
    {
        #region Plans
        public class PrxyPlansRequest
        {
            public List<short> PlanIds;
        }
        public class PrxyPlansResponse
        {
            public List<PrxyPlan> Plans;
            public OperationResult Result;
        }

        public class PrxyPlan
        {
            public string Id;
            public string Name;
            public string ShortName;
            public string BasPlanId;
            public PrxyPlanClasification PlanClasification;
            public PrxyComercialInfo ComercialInfo;
        }
        public class PrxyComercialInfo
        {
            public short ComercialPlanId;
            public string ComercialName;
        }

        public class PrxyPlanClasification
        {
            public int Platform;
            public int ProductType;
        }

        public class GetComercialNameRequestPrxy
        {
            public string ContractId;
        }

        public class GetComercialNameResponsePrxy
        {
            public OperationResult Result;
            public string ComercialName;
        }
        #endregion

        #region Schedule Transfers
        public class ValidateScheduleTransferResponsePxy
        {
            public OperationResult Result;
            public ScheduleOperationPrxy TransferSchedule;
        }
        public class ScheduleOperationPrxy
        {
            public string InitSchedule;
            public string EndSchedule;
        }
        #endregion
    }
}
