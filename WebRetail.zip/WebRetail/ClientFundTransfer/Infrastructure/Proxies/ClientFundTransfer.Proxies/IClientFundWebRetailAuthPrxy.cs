﻿using ClientFundTransfer.Domain.ContactDataValueAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Proxies
{
    public interface IClientFundWebRetailAuthPrxy
    {
        ContactData GetContactData(string rfc, out OperationResult result);
    }
}
