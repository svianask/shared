﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundAllocationAggregate
{
    public class FundAllocation : Entity<string>, IRootAggregate
    {
        private decimal _percentage;
        private FundAllocation(string fundId, decimal percent)
        {
            Id = fundId;
            _percentage = Math.Round(percent, 2);
        }

        public decimal Percentage => _percentage;
        public static FundAllocation Create(string fundId, decimal percent)
        {
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El ID del fondo no puede ser nulo."); }
            return new FundAllocation(fundId, percent);
        }

        public FundAllocation PercentageAllocation(decimal newPercent)
        {
            _percentage = (Math.Round(newPercent, 2));
            return this;
        }

        public FundAllocation AddPercent(decimal add)
        {
            var newPercent = _percentage + add;
            PercentageAllocation(newPercent);
            return this;
        }

        public FundAllocation SubtractPercent(decimal sub)
        {
            var newPercent = _percentage - sub;
            PercentageAllocation(newPercent);
            return this;
        }
    }
}
