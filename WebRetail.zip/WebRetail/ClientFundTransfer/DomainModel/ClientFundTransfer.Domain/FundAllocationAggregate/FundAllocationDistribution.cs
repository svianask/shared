﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundAllocationAggregate
{
    public class FundAllocationDistribution : ValueObject<FundAllocationDistribution>
    {
        private List<FundAllocation> _currentDistribution;
        private List<FundAllocation> _newDistribution;
        private List<FundAllocation> _saleDistribution; 

        private FundAllocationDistribution()
        {
            _currentDistribution = new List<FundAllocation>();
            _newDistribution = new List<FundAllocation>();
            _saleDistribution = new List<FundAllocation>();
        }

        public static FundAllocationDistribution Create()
        {
            return new FundAllocationDistribution();
        }

        public FundAllocationDistribution SetCurrentAllocation(List<FundAllocation> currentDistribution)
        {
            if (currentDistribution.Count <= 0) { throw new ArgumentException("La distribucion actual del portafolio debe de contener al menos un elemento."); }
            _currentDistribution = currentDistribution;
            return this;
        }

        public FundAllocationDistribution SetNewDistribution(List<FundAllocation> newDistribution)
        {
            if(newDistribution.Count <= 0) { throw new ArgumentException("La nueva distribucion del portafolio debe de contener al menos un elemento."); }
            _newDistribution = newDistribution;
            return this;
        }

        public FundAllocationDistribution AddFundNewDistribution(FundAllocation addToFund)
        {
            _newDistribution.Add(addToFund);
            return this;
        }

        public FundAllocationDistribution AddFundSaleDistribution(FundAllocation addFund)
        {
            _saleDistribution.Add(addFund);
            return this;
        }

        public FundAllocationDistribution SubtractPercentSaleToCurrentDistribution()
        {
            _saleDistribution.ForEach(saleFund => {
                _currentDistribution.Find(currentFund => currentFund.Id.Equals(saleFund.Id)).SubtractPercent(saleFund.Percentage);
            });

            _currentDistribution.RemoveAll(x => x.Percentage <= 0); //elimina los fondos que tengan un porcentaje igual o menor a 0.
            return this;
        }

        public FundAllocationDistribution ValidateAdjustOneHundredPercent()
        {
            var currentPercent = _newDistribution.Sum(x => x.Percentage);
            var remainderPercent = 100 - currentPercent;
            if (remainderPercent > 0) //Valida si la suma de los fundos que se compraron son el 100%
            {
                //EL dado caso que no sea el 100% agrega los fondos de su portafolio actual con el % que falte
                _currentDistribution.OrderBy(x => x.Percentage).ToList().ForEach(fund =>
                {
                    if (remainderPercent <= 0) { return; }
                    var existFundInNewPortafolio = _newDistribution.Find(getFund => getFund.Id.Equals(fund.Id));
                    if (existFundInNewPortafolio is null)
                    {
                        if (remainderPercent <= fund.Percentage) { currentPercent = remainderPercent; }
                        else { currentPercent = fund.Percentage; }

                        _newDistribution.Add(FundAllocation.Create(fund.Id, currentPercent));
                    }
                    else
                    {
                        if (remainderPercent <= existFundInNewPortafolio.Percentage) { currentPercent = remainderPercent; }
                        else { currentPercent = existFundInNewPortafolio.Percentage; }
                        _newDistribution.Find(getFund => getFund.Id.Equals(fund.Id)).PercentageAllocation(currentPercent);
                    }

                    remainderPercent -= currentPercent;
                });
            }

            currentPercent = _newDistribution.Sum(x => x.Percentage);
            if (currentPercent != 100) //Valida que la suma del porcentaje de la nueva distribucion sea diferente del 100%
            {
                //En dado caso de que sea diferente del 100% se ajusta para que no falte o exceda el 100
                decimal percentAjust = 0;
                switch (currentPercent)
                {
                    case decimal n when (n < 100): //Si es menor agrega la diferencia.
                        percentAjust = 100 - currentPercent;
                        _newDistribution.FirstOrDefault().AddPercent(percentAjust);
                        break;
                    case decimal n when (n > 100): //Si es mayor quita la direncia.
                        percentAjust = currentPercent - 100;
                        _newDistribution.Find(x => x.Percentage >= percentAjust).SubtractPercent(percentAjust);
                        break;
                }
            }
            return this;
        }

        public List<FundAllocation> CurrentDistribution => _currentDistribution;
        public List<FundAllocation> NewDistribution => _newDistribution;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
