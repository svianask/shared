﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.TransferFundOrderAggregate
{
    public class TransferFundOrder : Entity<int>, IRootAggregate
    {
        private string _emision_Id;
        private int _shares;
        private double _price;
        private double _amount;
        private DateTime _processDate;
        private DateTime _operationDate;
        private DateTime _liquidationDate;
        private int _statusId;

        private TransferFundOrder(int orderId)
        {
            Id = orderId;
        }

        public static TransferFundOrder Create(int orderId)
        {
            if (orderId <= 0) { throw new ArgumentException("El Id de la orden es incorrecta."); }
            return new TransferFundOrder(orderId);
        }

        public TransferFundOrder OrderDetails(int shares, double price, double amount)
        {
            _shares = shares;
            _price = price;
            _amount = amount;
            return this;
        }

        public TransferFundOrder DatesDetails(DateTime operation, DateTime liquidation, DateTime process)
        {
            _operationDate = operation;
            _liquidationDate = liquidation;
            _processDate = process;
            return this;
        }

        public TransferFundOrder SetFundId(string fundId)
        {
            _emision_Id = fundId;
            return this;
        }

        public TransferFundOrder SetStatus(int statusId)
        {
            _statusId = statusId;
            return this;
        }

        public string EmisionId => _emision_Id;
        public int Shares => _shares;
        public double Price => _price;
        public double Amount => _amount;
        public DateTime OperationDate => _operationDate;
        public DateTime LiquidationDate => _liquidationDate;
        public DateTime ProcessDate => _processDate;
        public int StatusId => _statusId;
    }
}
