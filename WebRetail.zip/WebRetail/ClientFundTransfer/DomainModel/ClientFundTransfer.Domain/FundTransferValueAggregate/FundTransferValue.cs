﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundTransferValueAggregate
{
    public class FundTransferValue : Entity<string>
    {
        private double _amount;
        private FundTrading _fundTrading;

        private FundTransferValue(string idFund, double amount)
        {
            Id = idFund;
            _amount = amount;
        }

        public double Amount => _amount;
        public FundTrading Trading => _fundTrading;

        public static FundTransferValue Create(string idFund, double amount)
        {
            if (string.IsNullOrEmpty(idFund)) { throw new ArgumentException("El id del fondo no puede ser nulo."); }

            return new FundTransferValue(idFund, amount);
        }

        public bool SubtractsAmount(double amount)
        {
            var success = false;
            if (Math.Round(amount, 2) <= Math.Round(_amount, 2))
            {
                _amount -= amount;
                success = true;
            }
            return success;
        }

        public FundTransferValue SetNewAmount(double amount)
        {
            _amount = amount;
            return this;
        }

        /// <summary>
        /// Valida que el monto del fondo a vender sea igual al monto a comprar, en caso contrario verifica que el sobrante + monto a vender sea igual a monto a comprar
        /// y setea el saldo nuevo.
        /// </summary>
        /// <param name="leftoverAmount"></param>
        /// <param name="sourceAmount"></param>
        /// <returns></returns>
        public FundTransferValue ValidateLeftOverAmount(double leftoverAmount, double sourceAmount, double totalFunds)
        {
            var newAmount = _amount + leftoverAmount;
            var totalAmount = totalFunds + leftoverAmount;
            if (Math.Round(totalFunds, 2) < Math.Round(sourceAmount, 2) && Math.Round(totalAmount, 2) == Math.Round(sourceAmount, 2))
            {
                SetNewAmount(newAmount);
            }
            return this;
        }

        /// <summary>
        /// Valida que el monto de los fondos a comprar no sea diferente al monto del fondo a vender. (Regla: por cada fondo a vender => N cantidad de fondos a comprar)
        /// </summary>
        /// <param name="targetValue"></param>
        public void ValidateAmountToTargetValue(double targetValue)
        {
            if(Math.Round(_amount, 2) != Math.Round(targetValue, 2)) { throw new Exception("Monto de transferencia invalido, el monto del fondo a vender es diferente del monto total de los fondos a comprar."); }
        }

        /// <summary>
        /// Valida que el monto a vender de cada fondo sea menor que el monto de su saldo actual.
        /// </summary>
        /// <param name="currentBalanceAmount"></param>
        public void ValidateAmountToBalanceAmount(double currentBalanceAmount)
        {
            if(_amount > Math.Round(currentBalanceAmount, 2)) { throw new Exception("Monto transferencia invalido, el monto a transferir de un fondo no puede ser mayor que su valuacion a la venta."); }
        }

        /// <summary>
        /// Valida que el monto del fondo a vender sea menor al monto disponible
        /// </summary>
        /// <param name="amountAvailable">Monto disponible => (titulos - titulos comprometidos) * precio de venta </param>
        public void ValidateAmountToAvailableAmount(double amountAvailable)
        {
            if(_amount > amountAvailable) { throw new Exception("Monto transferencia invalido, el monto a transferir de un fondo no puede ser mayor que el monto disponible."); }
        }

        public FundTransferValue SetTradingInformation(FundTrading fundTrading)
        {
            if (fundTrading is null) { throw new ArgumentException("El Trading Fund no puede ser nulo."); }
            _fundTrading = fundTrading;
            return this;
        }
    }
}
