﻿using ClientFundTransfer.Domain.FundsForSaleAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundTransferValueAggregate
{
    public class FundTrading : Entity<string>, IRootAggregate
    {
        //InvestmentFundDetail _investmentFund;
        private TradingDates _buyTradingDates;
        private TradingDates _saleTradingDates;
        private PricesTrading _price;

        private int _anticipationDaysSale;
        private bool _countAnticipationDaysSaleLabor;
        private int _anticipationDaysBuy;
        private bool _countAnticipationDaysBuyLabor;

        private int _liquidationDaysSale;
        private bool _countLiquidationDaysSaleLabor;
        private int _liquidationDaysBuy;
        private bool _countLiquidationDaysBuyLabor;

        private double _operatorCommisionSale;
        private double _operatorCommisionBuy;
        private double _operatorCommisionSaleTax;
        private double _operatorCommisionBuyTax;

        private bool _buyAnticipateLiquidation;
        private bool _isLiquidBuy;
        private bool _isLiquidSale;
        private DateTime _lastSobSubDate;

        private bool _buyAvailable;
        private bool _saleAvailable;
        private bool _isFundOfFund;

        private FundTrading(string fundId)
        {
            Id = fundId;

            _anticipationDaysSale = int.MinValue;
            _countAnticipationDaysSaleLabor = false;
            _anticipationDaysBuy = int.MinValue;
            _countAnticipationDaysBuyLabor = false;
            _liquidationDaysSale = int.MinValue;
            _liquidationDaysBuy = int.MinValue;
            _countLiquidationDaysSaleLabor = false;
            _countLiquidationDaysBuyLabor = false;
            _operatorCommisionSale = double.MinValue;
            _operatorCommisionBuy = double.MinValue;
            _operatorCommisionSaleTax = double.MinValue;
            _operatorCommisionBuyTax = double.MinValue;
            _buyAnticipateLiquidation = false;
            _isLiquidBuy = false;
            _isLiquidSale = false;
            _lastSobSubDate = DateTime.MinValue;
            _buyAvailable = false;
            _saleAvailable = false;
            _isFundOfFund = false;
        }

        public static FundTrading Create(string fundId)
        {
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El id del fondo no puede ser nulo."); }

            return new FundTrading(fundId);
        }

        public FundTrading SetSalesConfig(int anticipationDays, bool countAnticipationDays, int anticipationDaysBuy, bool conutAnticipationDaysBuy)
        {
            _anticipationDaysSale = anticipationDays;
            _countAnticipationDaysSaleLabor = countAnticipationDays;
            _anticipationDaysBuy = anticipationDaysBuy;
            _countAnticipationDaysBuyLabor = conutAnticipationDaysBuy;

            return this;
        }

        public FundTrading SetLiquidationConfig(int liquidationDaysSale, bool countLiquidationDaysSale, int liquidationDaysBuy, bool countLiquidationDaysBuy)
        {
            _liquidationDaysSale = liquidationDaysSale;
            _liquidationDaysBuy = liquidationDaysBuy;
            _countLiquidationDaysSaleLabor = countLiquidationDaysSale;
            _countLiquidationDaysBuyLabor = countLiquidationDaysBuy;
            return this;
        }

        public FundTrading SetOperationConfig(double comisionSale, double comisionBuy, double comisionSaleTax, double comisionBuyTax)
        {
            _operatorCommisionSale = comisionSale;
            _operatorCommisionBuy = comisionBuy;
            _operatorCommisionSaleTax = comisionSaleTax;
            _operatorCommisionBuyTax = comisionBuyTax;
            return this;
        }

        public FundTrading SetLiquidConfig(bool buyAnticipate, bool isLiquidSale, bool isLiquidBuy, DateTime lastSobSubDate)
        {
            _buyAnticipateLiquidation = buyAnticipate;
            _isLiquidSale = isLiquidSale;
            _isLiquidBuy = isLiquidBuy;
            _lastSobSubDate = lastSobSubDate;
            return this;
        }

        public FundTrading SetFundConfig(bool buyAvaulable, bool saleAvailable, bool isFundOfFund)
        {
            _buyAvailable = buyAvaulable;
            _saleAvailable = saleAvailable;
            _isFundOfFund = isFundOfFund;
            return this;
        }

        public FundTrading SetSaleTradingDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            _saleTradingDates = TradingDates.Create(requestDate, operationDate, liquidationDate);
            return this;
        }

        public FundTrading SetBuyTradingDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            _buyTradingDates = TradingDates.Create(requestDate, operationDate, liquidationDate);
            return this;
        }

        public FundTrading SetPricesConfig(double price, double purchasePrice, double salesPrice, DateTime priceDate)
        {
            _price = PricesTrading.Create(price, purchasePrice, salesPrice);
            return this;
        }

        public int AnticipationDaysSale => _anticipationDaysSale;
        public bool CountAnticipationDaysSaleLabor => _countAnticipationDaysSaleLabor;
        public int AnticipationDaysBuy => _anticipationDaysBuy;
        public bool CountAnticipationDaysBuyLabor => _countAnticipationDaysBuyLabor;
        public int LiquidationDaysSale => _liquidationDaysSale;
        public int LiquidationDaysBuy => _liquidationDaysBuy;
        public bool CountLiquidationDaysSaleLabor => _countLiquidationDaysSaleLabor;
        public bool CountLiquidationDaysBuyLabor => _countLiquidationDaysBuyLabor;
        public double OperatorCommisionSale => _operatorCommisionSale;
        public double OperatorCommisionBuy => _operatorCommisionBuy;
        public double OperatorCommisionSaleTax => _operatorCommisionSaleTax;
        public double OperatorCommisionBuyTax => _operatorCommisionBuyTax;
        public bool BuyAnticipateLiquidation => _buyAnticipateLiquidation;
        public bool IsLiquidBuy => _isLiquidBuy;
        public bool IsLiquidSale => _isLiquidSale;
        public DateTime LastSobSubDate => _lastSobSubDate;
        public bool BuyAvailable => _buyAvailable;
        public bool SaleAvailable => _saleAvailable;
        public bool IsFundOfFund => _isFundOfFund;
        public TradingDates SaleTradingDates => _saleTradingDates;
        public TradingDates BuyTradingDates => _buyTradingDates;
        public PricesTrading Prices => _price;
    }
}
