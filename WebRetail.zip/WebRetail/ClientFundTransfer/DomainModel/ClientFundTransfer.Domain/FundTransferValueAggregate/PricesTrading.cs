﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundTransferValueAggregate
{
    public class PricesTrading : ValueObject<PricesTrading>
    {
        private readonly double _price;
        private readonly double _purchasePrice;
        private readonly double _salesPrice;
        private DateTime _priceDate;
        private PricesTrading(double price, double purchasePrice, double salesPrice)
        {
            _price = price;
            _purchasePrice = purchasePrice;
            _salesPrice = salesPrice;
        }

        public double Price => _price;

        public double PurchasePrice => _purchasePrice;

        public double SalesPrice => _salesPrice;

        public DateTime PriceDate => _priceDate;

        internal static PricesTrading Create(double price, double purchasePrice, double salesPrice)
        {
            return new PricesTrading(price, purchasePrice, salesPrice);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Price,
                PurchasePrice,
                SalesPrice,
                PriceDate
            };
        }

        internal void SetPriceDate(DateTime priceDate)
        {
            _priceDate = priceDate;
        }
    }
}
