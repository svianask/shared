﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundTransferValueAggregate
{
    public class TradingDates : ValueObject<TradingDates>
    {
        DateTime _request;
        DateTime _operation;
        DateTime _liquidation;

        public DateTime RequestDate => _request;
        public DateTime OperationDate => _operation;
        public DateTime LiquidationDate => _liquidation;

        private TradingDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            _request = requestDate;
            _operation = operationDate;
            _liquidation = liquidationDate;
        }

        public static TradingDates Create(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            return new TradingDates(requestDate, operationDate, liquidationDate);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
