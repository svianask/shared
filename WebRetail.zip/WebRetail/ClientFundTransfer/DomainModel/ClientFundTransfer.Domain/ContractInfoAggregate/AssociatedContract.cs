﻿using Ddd;
using System.Collections.Generic;

namespace ClientFundTransfer.Domain.ContractInfoAggregate
{
    public class AssociatedContract : ValueObject<AssociatedContract>
    {
        private readonly string _contractId;
        private readonly string _associatedContractId;
        private readonly int _associatedType;

        private AssociatedContract(string contractId, string associatedContractId, int associatedType)
        {
            _contractId = contractId;
            _associatedContractId = associatedContractId;
            _associatedType = associatedType;
        }

        public string ContractId => _contractId;

        public string AssociatedContractId => _associatedContractId;

        public int AssociatedType => _associatedType;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                AssociatedContractId,
                AssociatedType
            };
        }

        public static AssociatedContract Create(string contractId, string associatedContractId, int associatedType)
        {
            return new AssociatedContract(contractId, associatedContractId, associatedType);
        }
    }
}
