﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.ContractInfoAggregate
{
    public class ContractInfo : Entity<string>
    {
        private readonly short _planBasId;
        private readonly int _platform;
        private readonly short _goalId;
        private int _contractType;
       
       
        private string _groupingContractId;
        private List<AssociatedContract> _associatedContracts;
        

        private ContractInfo(string contractId, short planBasId, int platform, short goalId, string groupingContractId)
        {
            Id = contractId;
            _planBasId = planBasId;
            _platform = platform;
            _goalId = goalId;
            _groupingContractId = groupingContractId;
            _associatedContracts = new List<AssociatedContract>();
        }

        public short PlanBasId => _planBasId;
        public int Platform => _platform;
        public short GoalId => _goalId;
        public int ContractType => _contractType;
        public string GroupingContractId => _groupingContractId;
        public List<AssociatedContract> AssociatedContracts => _associatedContracts;

        public static ContractInfo Create(string contractId, short planBasId, int platform, short goalId, string groupingContractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(groupingContractId)) { throw new ArgumentException("groupingContractId no puede ser nulo ni vacío"); }
            if (planBasId < 0) { throw new ArgumentException("El valor de planId no es válido"); }
            if (platform != 5 && platform != 10) { throw new ArgumentException("El tipo de producto es inválido"); }
            if (goalId < 0) { throw new ArgumentException("el id de la meta es inválido"); }

            return new ContractInfo(contractId, planBasId, platform, goalId, groupingContractId);
        }
        private void SetContractType(int contractType)
        {
            _contractType = contractType;
        }
    }
}
