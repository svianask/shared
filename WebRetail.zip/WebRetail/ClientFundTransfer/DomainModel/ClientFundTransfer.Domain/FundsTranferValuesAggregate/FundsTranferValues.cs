﻿using ClientFundTransfer.Domain.FundTransferValueAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundsTranferValuesAggregate
{
    public class FundsTranferValues : ValueObject<FundsTranferValues>
    {
        private List<FundTransferValue> _sourceInvestmentFunds;
        private List<FundTransferValue> _targetInvestmentFunds;

        public List<FundTransferValue> SourceInvestmentFunds => _sourceInvestmentFunds;
        public List<FundTransferValue> TargetInvestmentFunds => _targetInvestmentFunds;

        private List<FundTransferValue> _targetFunds; //se usa en la oobtencion de la distribucion de montos en GetTargetFundsTranferValuesBySourceAmount

        private FundsTranferValues()
        {
            _sourceInvestmentFunds = new List<FundTransferValue>();
            _targetInvestmentFunds = new List<FundTransferValue>();
        }

        public static FundsTranferValues Create()
        {
            return new FundsTranferValues();
        }

        public FundsTranferValues AddSourceFund(FundTransferValue newFund)
        {
            _sourceInvestmentFunds.Add(newFund);
            return this;
        }

        public FundsTranferValues AddTargetFund(FundTransferValue newFund)
        {
            _targetInvestmentFunds.Add(newFund);
            return this;
        }

        public void DltAmountLTPriceSale()
        {
            _sourceInvestmentFunds.RemoveAll(fundTranfer => fundTranfer.Amount < Math.Round(fundTranfer.Trading.Prices.SalesPrice, 2));
        }

        public void DltAmountLTPricePurchase()
        {
            _targetInvestmentFunds.RemoveAll(fundTranfer => fundTranfer.Amount < Math.Round(fundTranfer.Trading.Prices.PurchasePrice, 2));
        }

        public void SubstractAmounts()
        {
            //elimando fondos de la venta que son menores a SalesPrice
            _sourceInvestmentFunds.ForEach(fund =>
            {
                if (fund.Amount < Math.Round(fund.Trading.Prices.SalesPrice, 2)) { fund.SubtractsAmount(fund.Amount); }
            });
            _sourceInvestmentFunds.RemoveAll(fund => fund.Amount.Equals(0.0));

            //restando el monto de la compra del monto de venta 
            _targetInvestmentFunds.ForEach(fund => {
                var success = _sourceInvestmentFunds.Exists(x => x.Id.Equals(fund.Id)) ? _sourceInvestmentFunds.Find(x => x.Id.Equals(fund.Id)).SubtractsAmount(fund.Amount) : false;
                if (success) { fund.SubtractsAmount(fund.Amount); }
            });
            _sourceInvestmentFunds.RemoveAll(fund => fund.Amount.Equals(0.0));

            //elimando fondos de la venta que son menores a SalesPrice
            _sourceInvestmentFunds.ForEach(fund =>
            {
                if (fund.Amount < Math.Round(fund.Trading.Prices.SalesPrice, 2)) { fund.SubtractsAmount(fund.Amount); }
            });
            _sourceInvestmentFunds.RemoveAll(fund => fund.Amount.Equals(0.0));

            //Restando el monto de la venta del monto de la compra
            _sourceInvestmentFunds.ForEach(fund => {
                var success = _targetInvestmentFunds.Exists(x => x.Id.Equals(fund.Id)) ? _targetInvestmentFunds.Find(x => x.Id.Equals(fund.Id)).SubtractsAmount(fund.Amount) : false;
                if (success) { fund.SubtractsAmount(fund.Amount); }
            });
            _targetInvestmentFunds.RemoveAll(fund => fund.Amount.Equals(0.0));

            //Eliminando los fondos de la compra que son menores a PurchasePrice
            _targetInvestmentFunds.ForEach(fund =>
            {
                if (fund.Amount < Math.Round(fund.Trading.Prices.PurchasePrice, 2)) { fund.SubtractsAmount(fund.Amount); }
            });
            _sourceInvestmentFunds.RemoveAll(fund => fund.Amount.Equals(0.0));

        }

        public List<FundTransferValue> GetTargetFundsTranferValuesBySourceAmount(FundTransferValue sourceFund, List<FundTransferValue> targetFundscuurent)
        {
            _targetFunds = new List<FundTransferValue>();
            var missingValue = 0.0;
            var leftoverAmount = 0.0;
            FundTransferValue lasttargetFund = null;
            _targetInvestmentFunds.ForEach(targetFund =>
            {
                if (_targetFunds.Sum(x => x.Amount) == sourceFund.Amount) { return; }

                if (targetFund.Amount == targetFundscuurent.Where(fund => fund.Id.Equals(targetFund.Id)).Sum(x => x.Amount)) { return; }

                var amountSource = leftoverAmount > 0 ? leftoverAmount : sourceFund.Amount;
                if (targetFundscuurent.Count > 0)
                {
                    missingValue = targetFundscuurent.Exists(searchFund => searchFund.Id.Equals(targetFund.Id)) ?
                    targetFundscuurent.Where(fund => fund.Id.Equals(targetFund.Id)).Sum(x => x.Amount) == targetFund.Amount ? 0.0 : targetFundscuurent.Where(fund => fund.Id.Equals(targetFund.Id)).Sum(x => x.Amount) : 0.0;
                }

                ValidateTargetFundAmount(targetFund, amountSource, sourceFund.Trading.Prices.SalesPrice, missingValue, out leftoverAmount);
                lasttargetFund = targetFund;
            });

            //validacion para el restante si es que algun fondo se vende en su totalidad.
            if(leftoverAmount > 0) 
            {
                var totalCurrentFunds = _targetFunds.Sum(x => x.Amount);
                _targetFunds.Where(x => x.Id.Equals(lasttargetFund.Id)).FirstOrDefault().ValidateLeftOverAmount(leftoverAmount, sourceFund.Amount, totalCurrentFunds);
            }
            return _targetFunds;
        }

        private void ValidateTargetFundAmount(FundTransferValue targetFund, double soucerAmount, double salesPrice, double missingAmount, out double leftoverAmount)
        {
            var amountTarget = missingAmount > 0 ? targetFund.Amount - missingAmount : targetFund.Amount;
            leftoverAmount = 0;
            missingAmount = 0.0;
            FundTransferValue fundTargetTransferValue;
            if (soucerAmount > 0)
            {
                if (salesPrice > targetFund.Amount) { amountTarget = salesPrice; }

                if (soucerAmount >= amountTarget)
                {
                    //leftover amount is minor than source investment fund price or sale and buy amount are equal
                    //SS RAMMIG 2009-02-26
                    if ((soucerAmount - amountTarget) < salesPrice || (soucerAmount - amountTarget) == 0)
                    {
                        fundTargetTransferValue = FundTransferValue.Create(targetFund.Id, soucerAmount);
                        leftoverAmount = 0; missingAmount = 0.0;
                    }
                    else
                    {
                        //is the last target investment fund							
                        if (amountTarget >= soucerAmount)
                        {
                            //SS RAMMIG 2009-03-03
                            fundTargetTransferValue = FundTransferValue.Create(targetFund.Id, soucerAmount);
                        }
                        else
                        {
                            //SS RAMMIG 2009-03-03
                            fundTargetTransferValue = FundTransferValue.Create(targetFund.Id, amountTarget);
                            leftoverAmount = soucerAmount - amountTarget;
                            missingAmount = 0;
                        }
                    }
                }
                else
                {
                    //missing amount is minor than target investment fund price	//SS RAMMIG 2009-02-26
                    if ((amountTarget - soucerAmount) < targetFund.Trading.Prices.PurchasePrice)
                    {
                        //SS RAMMIG 2009-02-26
                        fundTargetTransferValue = FundTransferValue.Create(targetFund.Id, soucerAmount);
                        leftoverAmount = 0; missingAmount = 0;
                    }
                    else
                    {
                        //SS RAMMIG 2009-02-26
                        fundTargetTransferValue = FundTransferValue.Create(targetFund.Id, soucerAmount);
                        missingAmount = amountTarget - soucerAmount;
                    }
                }

                fundTargetTransferValue.SetTradingInformation(targetFund.Trading);
                _targetFunds.Add(fundTargetTransferValue);

                if (missingAmount > 0) { ValidateTargetFundAmount(targetFund, leftoverAmount, salesPrice, missingAmount, out leftoverAmount); }
            }
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
