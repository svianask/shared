﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.ProductInfoAggregate
{
    public class ProductInfo : Entity<string>
    {
        private readonly int _contractType;
        private readonly short _planBasId;
        private readonly int _platform;
        private string _comercialName;
        private readonly string _planId;

        private ProductInfo(string contractId, short planBasId, string planId, int platform, int contractType)
        {
            Id = contractId;
            _planBasId = planBasId;
            _platform = platform;
            _contractType = contractType;
            _planId = planId;
        }

        public short PlanBasId => _planBasId;
        public string PlanId => _planId;
        public int Platform => _platform;
        public string ComercialName => _comercialName;

        public static ProductInfo Create(string contractId, short planBasId, string planId, int platform, int contractType)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío"); }
            if (planBasId < 0) { throw new ArgumentException("El valor de planId no es válido"); }
            if (platform != 5 && platform != 10) { throw new ArgumentException("El tipo de producto es inválido"); }

            return new ProductInfo(contractId, planBasId, planId, platform, contractType);
        }

        public void SetComercialName(string comercialName)
        {
            _comercialName = comercialName;
        }
    }
}
