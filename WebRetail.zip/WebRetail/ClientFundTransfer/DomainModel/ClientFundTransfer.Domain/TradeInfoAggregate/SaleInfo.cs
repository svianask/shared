﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Domain.TradeInfoAggregate
{
    public class SaleInfo : ValueObject<SaleInfo>
    {
        //DaysSalesOperation
        private int _anticipationDaysForSales;
        private int _liquidationDaysForSales;

        //SalesConfiguration
        private bool _countAnticipationDaysBySaleLabor;
        private bool _countLiquidationDaysBySaleLabor;
        private bool _isLiquidSale;

        //SalesComision
        private double _operatorCommissionPerSale;
        private double _operatorCommissionTaxPerSale;

        private SaleInfo()
        {
            _anticipationDaysForSales = int.MinValue;
            _liquidationDaysForSales = int.MinValue;
            _operatorCommissionPerSale = double.MinValue;
            _operatorCommissionTaxPerSale = double.MinValue;
        }

        public int AnticipationDaysSale => _anticipationDaysForSales;

        public bool CountAnticipationDaysSaleLabor => _countAnticipationDaysBySaleLabor;

        public int LiquidationDaysSale => _liquidationDaysForSales;

        public bool CountLiquidationDaysSaleLabor => _countLiquidationDaysBySaleLabor;

        public double OperatorCommisionSale => _operatorCommissionPerSale;

        public double OperatorCommisionSaleTax => _operatorCommissionTaxPerSale;

        public bool IsLiquidSale => _isLiquidSale;

        internal static SaleInfo Create()
        {
            return new SaleInfo();
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                _anticipationDaysForSales,
                _liquidationDaysForSales,
                _countAnticipationDaysBySaleLabor,
                _countLiquidationDaysBySaleLabor,
                _isLiquidSale,
                _operatorCommissionPerSale,
                _operatorCommissionTaxPerSale,
            };
        }

        internal SaleInfo SetDaysSalesOperation(int anticipationDaysForSales, int liquidationDaysForSales)
        {
            if (anticipationDaysForSales < 0) { throw new ArgumentException("Los días de anticipación para la venta no deben ser menores a 0"); }
            if (liquidationDaysForSales < 0) { throw new ArgumentException("Los días de anticipación para la liquidación de la venta no deben ser menores a 0"); }

            this._anticipationDaysForSales = anticipationDaysForSales;
            this._liquidationDaysForSales = liquidationDaysForSales;
            return this;
        }

        internal SaleInfo SetSalesConfiguration(bool countAnticipationDaysBySaleLabor, bool countLiquidationDaysBySaleLabor, bool isLiquidSale)
        {
            this._countAnticipationDaysBySaleLabor = countAnticipationDaysBySaleLabor;
            this._countLiquidationDaysBySaleLabor = countLiquidationDaysBySaleLabor;
            this._isLiquidSale = isLiquidSale;
            return this;
        }

        internal SaleInfo SetSalesComision(double operatorCommissionPerSale, double operatorCommissionTaxPerSale)
        {
            if (operatorCommissionPerSale < 0) { throw new ArgumentException("El monto de la comisión por ventas no puede ser menor a 0 "); }
            if (operatorCommissionTaxPerSale < 0 || operatorCommissionTaxPerSale > 99.99) { throw new ArgumentException("El porcentaje de los impuestos por ventas no puede ser menor a 0 y mayor a 99.99 "); }

            this._operatorCommissionPerSale = operatorCommissionPerSale;
            this._operatorCommissionTaxPerSale = operatorCommissionTaxPerSale;
            return this;
        }
    }
}
