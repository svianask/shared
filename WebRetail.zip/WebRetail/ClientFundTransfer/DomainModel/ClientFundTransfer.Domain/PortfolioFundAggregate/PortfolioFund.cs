﻿using Ddd;
using System;

namespace ClientFundTransfer.Domain.PortfolioFundAggregate
{
    public abstract class PortfolioFund : Entity<string>, IRootAggregate
    {
        public string ContractId { get; }

        public string EmisionId { get; private set; }
        public string EmisionName { get; private set; }

        public double PortfolioTitImp { get; private set; }
        public double PortfolioCommitted { get; private set; }
        public double PortfolioNoCommitted { get; private set; }

        public double PriceFundAmount { get; private set; }
        public DateTime PriceFundDate { get; private set; }

        protected PortfolioFund(string fundId, string contractId)
        {
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El id del fondo no puede ser nulo."); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato del fondo no puede ser nulo."); }
            Id = fundId;
            ContractId = contractId;
        }

        protected void SetEmision(string emisionId, string emisionName)
        {
            EmisionId = emisionId;
            EmisionName = emisionName;
        }

        protected void SetPortfolio(double portfolioTitImp, double portfolioCommitted, double portfolioNoCommitted)
        {
            PortfolioTitImp = portfolioTitImp;
            PortfolioCommitted = portfolioCommitted;
            PortfolioNoCommitted = portfolioNoCommitted;
        }

        protected void SetFund(double priceFundAmount, DateTime priceFundDate)
        {
            PriceFundAmount = priceFundAmount;
            PriceFundDate = priceFundDate;
        }
    }
}
