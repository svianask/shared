﻿using System;

namespace ClientFundTransfer.Domain.PortfolioFundAggregate
{
    public class PortfolioFundTransfer : PortfolioFund
    {
        public double FundValue { get; private set; }

        public short StatusId { get; private set; }
        public string Status { get; private set; }

        protected PortfolioFundTransfer(string fundId, string contractId) : base(fundId, contractId) { }

        public static PortfolioFundTransfer Create(string fundId, string contractId)
        {
            return new PortfolioFundTransfer(fundId, contractId);
        }

        public new PortfolioFundTransfer SetEmision(string emisionId, string emisionName)
        {
            base.SetEmision(emisionId, emisionName);
            return this;
        }
        public new PortfolioFundTransfer SetPortfolio(double portfolioTitImp, double portfolioCommitted, double portfolioNoCommitted)
        {
            base.SetPortfolio(portfolioTitImp, portfolioCommitted, portfolioNoCommitted);
            return this;
        }

        public new PortfolioFundTransfer SetFund(double priceFundAmount, DateTime priceFundDate)
        {
            base.SetFund(priceFundAmount, priceFundDate);
            return this;
        }

        public PortfolioFundTransfer SetFundValue(double fundValue)
        {
            FundValue = fundValue;
            return this;
        }

        public PortfolioFundTransfer SetStatus(short statusId, string status)
        {
            StatusId = statusId;
            Status = status;
            return this;
        }
    }
}