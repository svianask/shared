﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundOrderAggregate
{
    public class FundOrderFee : ValueObject<FundOrderFee>
    {
        private double _feeAmount;
        private double _feeTax1;
        private double _feeTax2;

        private FundOrderFee(double feeAmount)
        {
            _feeAmount = feeAmount;
        }

        public static FundOrderFee Create(double feeAmount)
        {
            return new FundOrderFee(feeAmount);
        }

        public FundOrderFee SetFeeTax(double feeTax1, double feeTax2)
        {
            _feeTax1 = feeTax1;
            _feeTax2 = feeTax2;
            return this;
        }

        public double FeeAmount => _feeAmount;
        public double FeeTax1 => _feeTax1;
        public double FeeTax2 => _feeTax2;
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
