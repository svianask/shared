﻿using ClientFundTransfer.Domain.FundTransferValueAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundOrderAggregate
{
    public class FundOrder : Entity<string>, IRootAggregate
    {
        private int _orderType;
        private int _orderSubType;

        private string _contractIdentifier;

        private TradingDates _tradingDates;

        private double _price;
        private decimal _shares;

        private double _amount;
        private int _amountType;

        private FundOrderFee _orderFee;

        private string _contextInfoStr1;
        private string _contextInfoStr2;
        private string _contextInfoStr3;
        private string _contextInfoStr4;
        private string _contextInfoStr5;
        private string _contextInfoStr6;
        private string _contextInfoStr7;

        private int _productPlatform;

        private string _tipoOperacion;
        private string _tiempoOperacion;

        private int _operationType;

        private FundOrder(string fundId)
        {
            Id = fundId;
        }

        public static FundOrder Create(string fundId)
        {
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El id del fondo no puede ser nulo."); }
            return new FundOrder(fundId);
        }

        public FundOrder SetOrderType(int type)
        {
            _orderType = type;
            return this;
        }

        public FundOrder SetSubOrderType(int subType)
        {
            _orderSubType = subType;
            return this;
        }

        public FundOrder SetContractId(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }
            _contractIdentifier = contractId;
            return this;
        }

        public FundOrder SetTradingDates(DateTime request, DateTime operation, DateTime liquidation)
        {
            if (request < DateTime.Today || operation < DateTime.Today || liquidation < DateTime.Today)
            {
                throw new ArgumentException("Fechas de compra/venta invalidas, las fechas no pueden ser posteriores a la fecha actual");
            }
            _tradingDates = TradingDates.Create(request, operation, liquidation);
            return this;
        }

        public FundOrder SetPrice(double price)
        {
            if (price <= 0) { throw new ArgumentException("Orden precio invalido, el precio de la orden debe ser mayor que 0."); }
            _price = price;
            return this;
        }

        public FundOrder SetCalculateShares()
        {
            var shares = Convert.ToInt32(_amount / _price);
            if (shares <= 0) { throw new ArgumentException("Orden titulos invalidos, el numero de titulos debe ser mayor que 0."); }
            _shares = shares;
            return this;
        }

        public FundOrder SetShares(decimal shares)
        {
            if (shares <= 0) { throw new ArgumentException("Orden titulos invalidos, el numero de titulos debe ser mayor que 0."); }
            _shares = shares;
            return this;
        }

        public FundOrder RecalculateShares(decimal accumSharesSourceOrders, decimal sharesAvailable, out bool flag)
        {
            flag = true;
            var sharesAdjust = accumSharesSourceOrders - (int)sharesAvailable;
            if (_shares < sharesAdjust)
            {
                flag = false;
            }
            else
            {
                _shares -= sharesAdjust;
            }

            return this;
        }

        public FundOrder SetAmount(double amount)
        {
            if (amount <= 0) { throw new ArgumentException("Orden monto invalido, el monto de la orden debe ser mayor que 0."); }
            _amount = amount;
            return this;
        }

        public FundOrder SetAmountType(int amountType)
        {
            _amountType = amountType;
            return this;
        }

        public FundOrder SetOrderFee(double feeAmount, double feeTax1, double feeTax2)
        {
            if (feeAmount < 0) { throw new ArgumentException("Orden monto invalido, el monto de los cargos debe ser mayor o igual que 0."); }
            if (feeTax1 < 0 || feeTax2 < 0) { throw new ArgumentException("Orden monto invalido, el monto de los cargos debe ser mayoy o igual que 0."); }
            _orderFee = FundOrderFee.Create(feeAmount).SetFeeTax(feeTax1, feeTax2);
            return this;
        }

        public FundOrder SetCalculateOrderFee(double bridgetComissionBuy, double bridgetComissionBuyTax)
        {
            var feeAmount = Convert.ToInt32(_shares) * (bridgetComissionBuy / 100);
            var feeTax = Convert.ToInt32(_shares) * (bridgetComissionBuyTax / 100);

            return SetOrderFee(feeAmount, feeTax, 0);
        }

        public FundOrder ValidateAndSetOrderFee(double operatorCommisionSale, double salesPrice, double operatorCommisionSaleTax)
        {
            double comissionAmount = 0, comissionTaxAmount = 0;

            if (operatorCommisionSale > 0)
            {
                double saleShares;
                //SS RAMMIG 2009-02-18
                if ((_amount % salesPrice) > 0)//RAMLAU, precio tenia ceros
                    saleShares = (int)(_amount / salesPrice + 1); //RAMLAU: modificado para que tome enteros
                else
                    //SS RAMMIG 2009-02-18
                    saleShares = (int)(_amount / salesPrice);	////RAMLAU: modificado para que tome enteros
                comissionAmount = (saleShares * salesPrice) * (operatorCommisionSale / 100);//RAMLAU: modificado para que calcule bien la comision
                comissionTaxAmount = comissionAmount * (operatorCommisionSaleTax / 100);
            }

            return SetOrderFee(comissionAmount, comissionTaxAmount, 0);
        }

        public FundOrder ValidateAmountType(double marketValueSale)
        {
            //if total order amount is greater or equal than the total investment fund value
            //order is by shares
            //SS RAMMIG 2009-02-18
            if ((_orderFee.FeeAmount + _orderFee.FeeTax1 + _amount) > marketValueSale)
            {
                return SetAmountType(1);
            }

            return this;
        }

        /// <summary>
        /// Para este metodo primero se tiene que validar OrderFee y AmountType 
        /// </summary>
        /// <param name="salesPrice"></param>
        /// <returns></returns>
        public FundOrder ValidateAndSetShares(double salesPrice)
        {
            int sharesAmount = 0;

            //order by amount
            if (_amountType == 0)
            {
                sharesAmount = Convert.ToInt32(Math.Round(_amount, 6) / Math.Round(salesPrice, 6));

                if (Math.Round(_amount, 6) / Math.Round(salesPrice, 6) > sharesAmount)
                    sharesAmount += 1;
            }
            //order by shared
            else if (_amountType == 1)
            {
                Double realAmount;
                realAmount = _amount - (_orderFee.FeeAmount + _orderFee.FeeTax1);
                //SS RAMMIG 2009-02-18
                sharesAmount = (int)Math.Round(realAmount / salesPrice);
            }

            SetShares(sharesAmount); 
            return this;
        }

        public FundOrder SetPlatform(int platform)
        {
            _productPlatform = platform;
            return this;
        }

        public FundOrder SetContextInfo(string contextInfo1, string contextInfo2, string contextInfo3, string contextInfo4, string contextInfo5, string contextInfo6)
        {
            _contextInfoStr1 = contextInfo1;
            _contextInfoStr2 = contextInfo2;
            _contextInfoStr3 = contextInfo3;
            _contextInfoStr4 = contextInfo4;
            _contextInfoStr5 = contextInfo5;
            _contextInfoStr6 = contextInfo6;
            return this;
        }

        public FundOrder SetOperationConfig(string operationType, string operationTime)
        {
            _tipoOperacion = operationType;
            _tiempoOperacion = operationTime;
            return this;
        }

        public FundOrder SetBuyOrderDataAmounts(FundTrading investmentFundTrading)
        {
            int sharesAmount;
            double comissionAmount, comissionTaxAmount;

            //investment fund must be the same
            if (!Id.Equals(investmentFundTrading.Id))
                throw new ApplicationException("Fondo de inversion invalido, el fondo de inversion a transferir no es igual a la informacion de fondo de compra/venta.");

            //calculate comission and comission tax
            if (investmentFundTrading.OperatorCommisionBuy > 0)
            {
                double buyShares;
                //SS RAMMIG 2009-02-18
                if ((_amount % investmentFundTrading.Prices.PurchasePrice) > 0)
                    buyShares = (int)(_amount / investmentFundTrading.Prices.PurchasePrice + 1);
                else
                    //SS RAMMIG 2009-02-18
                    buyShares = (int)(_amount / investmentFundTrading.Prices.PurchasePrice);
                comissionAmount = (buyShares * investmentFundTrading.Prices.PurchasePrice) * (investmentFundTrading.OperatorCommisionBuy / 100);
                comissionTaxAmount = comissionAmount * (investmentFundTrading.OperatorCommisionBuyTax / 100);
            }
            else
            {
                comissionAmount = 0;
                comissionTaxAmount = 0;
            }

            if ((comissionAmount + comissionTaxAmount) == 0)
            {
                //SS RAMMIG 2009-02-18
                sharesAmount = Convert.ToInt32(_amount / investmentFundTrading.Prices.PurchasePrice);
            }
            else
            {
                double adjustedPrice;

                //SS RAMMIG 2009-02-18
                adjustedPrice = investmentFundTrading.Prices.PurchasePrice * (1 + (investmentFundTrading.OperatorCommisionBuy / 100) * (1 + (investmentFundTrading.OperatorCommisionBuyTax / 100)));
                sharesAmount = Convert.ToInt32(_amount / adjustedPrice);

                //recalculate comission
                //SS RAMMIG 2009-02-18
                comissionAmount = (sharesAmount * investmentFundTrading.Prices.PurchasePrice) * (investmentFundTrading.OperatorCommisionBuy / 100);
                comissionTaxAmount = comissionAmount * (investmentFundTrading.OperatorCommisionBuyTax / 100);
            }


            SetPrice(investmentFundTrading.Prices.PurchasePrice);
            SetShares(sharesAmount);
            SetOrderFee(comissionAmount, comissionTaxAmount, 0);

            return this;
        }

        public string GetOrderCommentInfo(string userId)
        {
            StringBuilder orderComment = new StringBuilder();
            switch (_orderType)
            {
                case 1://SaleFund
                    switch (_orderSubType)
                    {
                        case 10://SaleFundToBuyFund
                            //JAMC 03/07/2019, se agrega para agregar leyenda del requerimiento MX01-218063
                            orderComment.Append("Venta Origen - ");
                            break;
                        case 11:
                            orderComment.Append("VE Venta Efectivo - ");
                            break;
                        default:
                            throw new ApplicationException("Tipo de orden invalido.");
                    }
                    break;
                case 2://BuyFund
                    switch (_orderSubType)
                    {
                        case 20://BuyFundFromSaleFund
                            orderComment.Append("Compra Destino - ");
                            break;
                        default:
                            throw new ApplicationException("Tipo de orden invalido.");
                    }
                    break;
                case 5://ChargeCash
                    switch (_orderSubType)
                    {
                        case 50://ChargeCash
                            orderComment.Append("DC " + _contextInfoStr3 + " - ");
                            break;
                        default:
                            throw new ApplicationException("Tipo de orden invalido.");
                    }
                    break;
                default:
                    throw new ApplicationException("Tipo de orden invalido.");
            }

            orderComment.Append(userId);

            return orderComment.ToString();
        }

        public FundOrder SetOperationType()
        {
            switch(_orderType)
            {
                case 1:
                    _operationType = 10;
                    break;
                case 2:
                    _operationType = 5;
                    break;
            }

            return this;
        }

        public int OrderType => _orderType;
        public int OrderSubType => _orderSubType;
        public string ContractIdentifier => _contractIdentifier;
        public TradingDates TradingDates => _tradingDates;
        public double Price => _price;
        public decimal Shares => _shares;
        public double Amount => _amount;
        public int AmountType => _amountType;
        public FundOrderFee OrderFee => _orderFee;
        public string ContextInfoStr1 => _contextInfoStr1;
        public string ContextInfoStr2 => _contextInfoStr2;
        public string ContextInfoStr3 => _contextInfoStr3;
        public string ContextInfoStr4 => _contextInfoStr4;
        public string ContextInfoStr5 => _contextInfoStr5;
        public string ContextInfoStr6 => _contextInfoStr6;
        public string ContextInfoStr7 => _contextInfoStr7;
        public int ProductPlatform => _productPlatform;
        public string TipoOperacion => _tipoOperacion;
        public string TiempoOperacion => _tiempoOperacion;
        public int OperationType => _operationType;
    }
}
