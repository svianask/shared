﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundOrderAggregate
{
    public class TransactionTypes : ValueObject<TransactionTypes>
    {
        private int _tipo_Mercado;
        private int _tipo_Operacion;
        private int _tipo_orden;

        private TransactionTypes()
        {

        }

        public static TransactionTypes Create()
        {
            return new TransactionTypes();
        }

        public int Tipo_Mercado => _tipo_Mercado;
        public int Tipo_Operacion => _tipo_Operacion;
        public int Tipo_Orden => _tipo_orden;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
