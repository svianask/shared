﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundOrderAggregate
{
    public class TransferOrder : ValueObject<TransferOrder>
    {
        public string ContractId;
        public string EmisionId;
        public decimal Shares;
        public double Price;
        public double Amount;
        public DateTime ProcessDate;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public double ComissionAmount;
        public double ComissionTaxAmount;
        public string LiquidationType;
        //Specific platform order data
        public string TransactionId;
        public Guid OrderLogId;
        public Guid OrderLogFatherId;
        public DateTime OrderLoadDate;
        public int OrderLogEstatus;
        public DateTime OrderApplicationDate;
        public int OrderLogDepth;
        public string OrderLogLinage;
        public int AmountType;
        public int OperationType;
        public int OrderChainId;
        public bool IsLastOrder;
        public int NotValidateSalePos;
        public int NotValidateCompromisedPos;
        public string Comment;

        public int OrderType;
        public int OrderTypeLog;
        public string OrderLogContractId;
        public string OrderContractId;

        private TransferOrder(string transactionId,
            int orderNumber, string orderLinage, int orderChainId, bool isLastOrder, Guid orderLogId,
            Guid prevOrderLogId, DateTime transactionDate)
        {
            TransactionId = transactionId;
            OrderLogId = orderLogId;
            OrderLogFatherId = prevOrderLogId;
            OrderLoadDate = transactionDate;
            OrderLogEstatus = 2; //load online
            OrderApplicationDate = transactionDate;
            OrderLogDepth = orderNumber + 1;
            OrderLogLinage = orderLinage;
            OrderChainId = orderChainId; //the first order of chain must be 0
            IsLastOrder = isLastOrder;
            NotValidateSalePos = 1; //always validate sale position
            NotValidateCompromisedPos = orderChainId.Equals(string.Empty) ? 1 : 0; //never validate compromised position for source sale fund
        }

        public static TransferOrder Create(string transactionId,int orderNumber, string orderLinage, int orderChainId, bool isLastOrder, Guid orderLogId,
            Guid prevOrderLogId, DateTime transactionDate)
        {
            return new TransferOrder(transactionId, orderNumber, orderLinage, orderChainId, isLastOrder, orderLogId, prevOrderLogId, transactionDate);
        }

        public TransferOrder SetGenericOrderData(FundOrder order, string userId)
        {
            ContractId = order.ContractIdentifier;
            EmisionId = order.Id;
            Shares = order.Shares;
            Price = order.Price;
            Amount = order.Amount;
            ProcessDate = order.TradingDates.RequestDate;
            OperationDate = order.TradingDates.OperationDate;
            LiquidationDate = order.TradingDates.LiquidationDate;
            ComissionAmount = order.OrderFee.FeeAmount;
            ComissionTaxAmount = order.OrderFee.FeeTax1;
            LiquidationType = DBNull.Value.ToString();
            AmountType = order.AmountType;
            OperationType = order.OperationType;
            OrderLogContractId = order.ContractIdentifier;
            OrderContractId = order.ContractIdentifier;
            Comment = order.GetOrderCommentInfo(userId);
            return this;
        }

        public TransferOrder SetOrderType(int orderSubType, int orderType, int transferNumOrders)
        {
            if (orderSubType != 11)//dif to SaleFundToBuyCash
            {
                switch (transferNumOrders)
                {
                    case 1:
                        OrderType = 1; //Sale to buy cash
                        OrderTypeLog = 55;//SaleCash
                        break;
                    case 2:
                        OrderType = 0; //Sale to buy fund direct 
                        break;
                    case 4:
                        OrderType = 2; //sale to buy fund distributed
                        break;
                    default:
                        if (orderType.Equals(1))
                            OrderTypeLog = 51;//SaleTransfer
                        else
                            OrderTypeLog = 7;//BuyTransfer
                        break;
                }
            }
            else
            {
                OrderType = 1; //Sale to buy cash
                OrderTypeLog = 55;
            }

            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
