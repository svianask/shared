﻿using ClientFundTransfer.Domain.FundTransferValueAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundOrderAggregate
{
    public class FundsTranferResume : ValueObject<FundsTranferResume>
    {
        private FundBalanceDetail _sourceInvestmentFund;
        private List<FundTransferValue> _targetInvestmentFunds;
        private double _transferAmount;
        private int _amountType;
        private DateTime _baseDateTime;
        private double _availableAmount;
        private decimal _sharesAvailable;
        private FundsTranferResume(FundBalanceDetail balanceDetail, List<FundTransferValue> fundsPurchase)
        {
            _sourceInvestmentFund = balanceDetail;
            _targetInvestmentFunds = fundsPurchase;

            _sharesAvailable = _sourceInvestmentFund.Shares - _sourceInvestmentFund.CompromisedSharesSales;
            _availableAmount = Convert.ToInt32(_sharesAvailable) * _sourceInvestmentFund.PriceSale;
            _availableAmount = Math.Round(_availableAmount, 2);
        }

        public static FundsTranferResume Create(FundBalanceDetail balanceDetail, List<FundTransferValue> targetFunds)
        {
            if(balanceDetail is null) { throw new ArgumentException("El balance del contrato no puede ser nulo."); }
            if(targetFunds is null || targetFunds.Count < 1) { throw new ArgumentException("La lista de fondos a vender no puede ser nula o vacia."); }

            return new FundsTranferResume(balanceDetail, targetFunds);
        }

        public FundsTranferResume SetTranferConfig(double tranferAmount, DateTime baseDate)
        {
            _transferAmount = tranferAmount;
            _baseDateTime = baseDate;
            return this;
        }

        public FundsTranferResume ValidateAndSetAmountType()
        {
            _amountType = 0;
            if (Math.Round(_transferAmount, 2) == Math.Round(_availableAmount, 2))
            {
                _amountType = 1; 
            }
            else
            {
                var amountAvailbleAfterTransfer = _availableAmount - _transferAmount;
                if (amountAvailbleAfterTransfer < _sourceInvestmentFund.PriceSale)
                {
                    _amountType = 1;
                    _transferAmount = Math.Round(_availableAmount, 2);
                    // adjust last target
                    var lastTarget = _targetInvestmentFunds.Last();
                    var newAmount = Math.Round(lastTarget.Amount + amountAvailbleAfterTransfer, 2);
                    _targetInvestmentFunds.Last().SetNewAmount(newAmount);
                }
            }
            return this;
        }

        public FundBalanceDetail SourceInvestmentFund => _sourceInvestmentFund;
        public List<FundTransferValue> TargetInvestmentFunds => _targetInvestmentFunds;
        public double TransferAmount => _transferAmount;
        public int AmountType => _amountType;
        public DateTime BaseDateTime => _baseDateTime;
        public decimal SharesAvailable => _sharesAvailable;


        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
