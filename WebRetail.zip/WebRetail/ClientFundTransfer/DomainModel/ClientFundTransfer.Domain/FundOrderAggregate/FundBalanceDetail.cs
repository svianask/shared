﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundOrderAggregate
{
    public class FundBalanceDetail : Entity<string>, IRootAggregate
    {
        decimal _shares;
        decimal _compromisedShares;
        decimal _compromisedSharesSales;

        decimal _compromisedAmount;
        decimal _compromisedAmountSales;

        double _priceValuation;
        double _priceBuy;
        double _priceSale;
        DateTime _priceDate;
        string _priceIdentifier;

        double _makertValueValuation;
        double _marketValueBuy;
        double _marketValueSale;

        private FundBalanceDetail(string fundId)
        {
            Id = fundId;
        }

        public static FundBalanceDetail Create(string fundId)
        {
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El id del fondo no puede ser nulo."); }
            return new FundBalanceDetail(fundId);
        }

        public FundBalanceDetail SetFundSharesConfig(decimal shares, decimal compromisedShares, decimal compromisedSharesSales)
        {
            _shares = shares;
            _compromisedShares = compromisedShares;
            _compromisedSharesSales = compromisedSharesSales;
            
            return this;
        }

        public FundBalanceDetail SetCompromisedAmounts(decimal compromisedAmount, decimal compromisedAmountSales)
        {
            _compromisedAmount = compromisedAmount;
            _compromisedAmountSales = compromisedAmountSales;
            return this;
        }

        public FundBalanceDetail SetFundPriceConfig(double valuation, double buy, double sale, DateTime date)
        {
            _priceValuation = valuation;
            _priceBuy = buy;
            _priceSale = sale;
            _priceDate = date;
            return this;
        }

        public FundBalanceDetail SetMaketValue(double valuation, double buy, double sale)
        {
            _makertValueValuation = valuation;
            _marketValueBuy = buy;
            _marketValueSale = sale;
            return this;
        }

        public decimal Shares => _shares;
        public decimal compromisedShares => _compromisedShares;
        public decimal CompromisedSharesSales =>_compromisedSharesSales;
        public decimal CompromisedAmount => _compromisedAmount;
        public decimal CompromisedAmountSales => _compromisedAmountSales;

        public double PriceValuation => _priceValuation;
        public double PriceBuy => _priceBuy;
        public double PriceSale => _priceSale;
        public DateTime PriceDate => _priceDate;
        public string PriceIdentifier => _priceIdentifier;

        public double MakertValueValuation => _makertValueValuation;
        public double MarketValueBuy => _marketValueBuy;
        public double MarketValueSale => _marketValueSale;
    }
}
