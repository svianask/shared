﻿using Ddd;

namespace ClientFundTransfer.Domain.FundsForSaleAggregate
{
    public class FundBalanceForSale : Entity<string>
    {
        private Shares _shares;
        private Prices _prices;
        private MarketValues _marketValues;
        private string _contractId;
        private readonly string _name;

        private FundBalanceForSale(string identifier, string name)
        {
            Id = identifier;
            _name = name;
        }

        public string ContractId => _contractId;

        public string Name => _name;

        public Shares Shares => _shares;

        public Prices Prices => _prices;

        public MarketValues MarketValues => _marketValues;



        public static FundBalanceForSale Create(string id, string name)
        {
            return new FundBalanceForSale(id, name);
        }

        public FundBalanceForSale SetMarketValues(decimal marketValue, decimal marketPurchaseValue, decimal marketSalesValue, decimal distributionPercent)
        {
            _marketValues = MarketValues.Create(marketValue, marketPurchaseValue, marketSalesValue, distributionPercent);
            return this;
        }

        public FundBalanceForSale SetContract(string contractId)
        {
            _contractId = contractId;
            return this;
        }

        public FundBalanceForSale SetPrices(decimal price, decimal purchasePrice, decimal salesPrice)
        {
            _prices = Prices.Create(price, purchasePrice, salesPrice);
            return this;
        }

        public FundBalanceForSale SetShares(decimal availableShares, decimal committedShares, decimal committedSharesSales)
        {
            _shares = Shares.Create(availableShares, committedShares, committedSharesSales);
            return this;
        }
    }
}
