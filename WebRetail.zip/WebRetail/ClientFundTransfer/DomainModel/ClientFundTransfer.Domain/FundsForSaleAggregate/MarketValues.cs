﻿using Ddd;
using System.Collections.Generic;

namespace ClientFundTransfer.Domain.FundsForSaleAggregate
{
    public class MarketValues : ValueObject<MarketValues>
    {
        private readonly decimal _marketValue;
        private readonly decimal _marketPurchaseValue;
        private readonly decimal _marketSalesValue;
        private readonly decimal _distributionPercent;

        private MarketValues(decimal marketValue, decimal marketPurchaseValue, decimal marketSalesValue, decimal distributionPercent)
        {
            _marketValue = marketValue;
            _marketPurchaseValue = marketPurchaseValue;
            _marketSalesValue = marketSalesValue;
            _distributionPercent = distributionPercent;
        }

        

        public decimal MarketPurchaseValue => _marketPurchaseValue;

        public decimal MarketSalesValue => _marketSalesValue;

        public decimal DistributionPercent => _distributionPercent;

        public decimal MarketValue => _marketValue;

        internal static MarketValues Create(decimal marketValue, decimal marketPurchaseValue, decimal marketSalesValue, decimal distributionPercent)
        {
            return new MarketValues(marketValue, marketPurchaseValue, marketSalesValue, distributionPercent);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                MarketValue,
                MarketPurchaseValue,
                MarketSalesValue,
                DistributionPercent
            };
        }
    }
}