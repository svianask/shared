﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundsForSaleAggregate
{
    public class FundForSale : Entity<string>, IRootAggregate
    {
        private decimal _salesPrice = 0;
        private decimal _salesMarketValue = 0;
        private decimal _availableAmount = 0;
        private decimal _shares = 0;
        private decimal _committedShares = 0;
        private decimal _availableShares = 0;
                
        public FundForSale(string FundIdentifier)
        {
            Id = FundIdentifier;
        }

        public decimal SalesPrice => _salesPrice;

        public decimal SalesMarketValue => _salesMarketValue;

        public decimal AvailableAmount => _availableAmount;

        public decimal Shares => _shares;

        public decimal AvailableShares => _availableShares;

        public decimal CommittedShares => _committedShares;

        public FundForSale SetInformationForSales(decimal salesPrice, decimal shares, decimal commitedShares, decimal salesMarketValue)
        {
            _salesPrice = salesPrice;
            _shares = shares;
            _salesMarketValue = salesMarketValue;
            _committedShares = commitedShares;

            _availableShares = shares - commitedShares;
            _availableAmount = Math.Round(_availableShares * salesPrice, 2);

            return this;
        }
    }
}
