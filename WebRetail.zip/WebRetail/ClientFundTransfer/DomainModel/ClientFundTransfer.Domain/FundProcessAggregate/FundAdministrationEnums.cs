﻿namespace ClientFundTransfer.Domain.FundProcessAggregate
{
    public enum FundAdministrationStatus
    {
        Reinvertir = 1,
        NoReinvertirXMovimientos = 2,
        NoReinvertirXCliente = 3,
    }
}
