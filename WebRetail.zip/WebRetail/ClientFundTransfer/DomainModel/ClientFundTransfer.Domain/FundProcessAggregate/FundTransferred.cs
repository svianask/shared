﻿using Ddd;
using System.Collections.Generic;

namespace ClientFundTransfer.Domain.FundProcessAggregate
{
    public sealed class FundTransferredOrder : ValueObject<FundTransferredOrder>
    {
        public int OrderId { get; private set; }
        public string EmisionId { get; private set; }
        public string ContractId { get; private set; }
        public double Shares { get; private set; }

        private FundTransferredOrder(int orderId, string emisionId, string contractId, double shares)
        {
            OrderId = orderId;
            EmisionId = emisionId;
            ContractId = contractId;
            Shares = shares;
        }

        public static FundTransferredOrder Create(int orderId, string emisionId, string contractId, double shares)
        {
            return new FundTransferredOrder(orderId, emisionId, contractId, shares);
        }

        public static FundTransferredOrder Empty()
        {
            return new FundTransferredOrder(0, "0", "0", 0);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                OrderId,
                EmisionId,
                ContractId,
                Shares
            };
        }
    }
}
