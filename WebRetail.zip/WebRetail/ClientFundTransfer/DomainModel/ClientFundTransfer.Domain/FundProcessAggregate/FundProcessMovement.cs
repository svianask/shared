﻿using Ddd;
using System;

namespace ClientFundTransfer.Domain.FundProcessAggregate
{
    public class FundProcessMovement : Entity<string>, IRootAggregate
    {
        public string ProcessId { get; }
        public string ContractId { get; }

        public double PortfolioTitImp { get; private set; }
        public double PortfolioCommitted { get; private set; }
        public double PortfolioTransferred { get; private set; }
        public int PortfolioOrderId { get; private set; }
        public double SourcePortfolioTransferred { get; private set; }
        public int SourcePortfolioOrderId { get; private set; }

        public string UserId { get; private set; }
        public DateTime? CreationDate { get; private set; }
        public DateTime? UpdateDate { get; private set; }
        public short StatusId { get; private set; }
        public string Comment { get; private set; }

        protected FundProcessMovement(string transferId, string processId, string contractId, string userId)
        {
            Id = transferId;
            ProcessId = processId;
            ContractId = contractId;
            UserId = userId;
        }

        public static FundProcessMovement Create(string transferId, string processId, string contractId, string userId)
        {
            if (string.IsNullOrEmpty(transferId)) { throw new ArgumentException("El id no puede ser nulo."); }
            if (string.IsNullOrEmpty(processId)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El usuario no puede ser nulo."); }
            return new FundProcessMovement(transferId, processId, contractId, userId);
        }

        public FundProcessMovement SetPorfolio(double portfolioTitImp, double portfolioCommitted)
        {
            PortfolioTitImp = portfolioTitImp;
            PortfolioCommitted = portfolioCommitted;
            return this;
        }

        public FundProcessMovement SetPortfolioTransferred(double portfolioTransferred, int portfolioOrderId)
        {
            PortfolioTransferred = portfolioTransferred;
            PortfolioOrderId = portfolioOrderId;
            return this;
        }

        public FundProcessMovement SetSourcePortfolioTransferred(double sourcePortfolioTransferred, int sourcePortfolioOrderId)
        {
            SourcePortfolioTransferred = sourcePortfolioTransferred;
            SourcePortfolioOrderId = sourcePortfolioOrderId;
            return this;
        }

        public FundProcessMovement SetStatus(short statusId, string comment = "")
        {
            StatusId = statusId;
            Comment = comment;
            return this;
        }

        public FundProcessMovement SetTransferDates(DateTime? creationDate = null, DateTime? updateDate = null)
        {
            CreationDate = creationDate;
            UpdateDate = updateDate;
            return this;
        }

        public FundProcessMovement InitMovement()
        {
            StatusId = (short)FundProcessMovementStatus.EnProceso;
            return this;
        }

        public FundProcessMovement EndMovement(string comment)
        {
            Comment = comment;
            StatusId = string.IsNullOrEmpty(Comment) ? (short)FundProcessMovementStatus.Terminado : (short)FundProcessMovementStatus.Error;
            UpdateDate = DateTime.Now;
            return this;
        }

        public static FundProcessMovement Empty()
        {
            return new FundProcessMovement(Guid.Empty.ToString(), Guid.Empty.ToString(), string.Empty, string.Empty);
        }
    }
}
