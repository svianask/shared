﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientFundTransfer.Domain.FundProcessAggregate
{
    public class FundAdministrationConfig : ValueObject<FundAdministrationConfig>
    {
        public string FundOrigin { get; private set; }
        public string FundTarget { get; private set; }
        public string FundReinvestment { get; private set; }
        public DateTime LiquidationDate { get; private set; }
        private FundAdministrationConfig(string fundOrigin, string fundTarget, string fundReinvestment)
        {
            FundOrigin = fundOrigin;
            FundTarget = fundTarget;
            FundReinvestment = fundReinvestment;
        }

        public static FundAdministrationConfig Create(string fundOrigin, string fundTarget, string fundReinvestment)
        {
            return new FundAdministrationConfig(fundOrigin, fundTarget, fundReinvestment);
        }

        public FundAdministrationConfig SetDates(DateTime liquidationDate)
        {
            LiquidationDate = liquidationDate;
            return this;
        }

        public static FundAdministrationConfig Empty()
        {
            return new FundAdministrationConfig("", "", "");
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                FundOrigin,
                FundTarget,
                FundReinvestment,
                LiquidationDate
            };
        }
    }
}
