﻿namespace ClientFundTransfer.Domain.FundProcessAggregate
{
    public enum FundProcessStatus
    {
        Pendiente = 1,
        EnProceso = 2,
        Terminado = 3,
        Error = 4
    }

    public enum FundProcessMovementStatus
    {

        EnProceso = 1,
        Terminado = 2,
        Error = 3
    }

    public enum FundProcessType
    {
        Transfer = 1,
        Reinvestment = 2,
    }
}
