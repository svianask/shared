﻿using Ddd;
using System.Collections.Generic;

namespace ClientFundTransfer.Domain.FundProcessAggregate
{
    public class FundProcessValidate : ValueObject<FundProcessValidate>
    {
        private readonly string _initSchedule;
        private readonly string _endSchedule;
        private bool ApplySchedule { get; set; }

        public bool IsTransferValidate { get; private set; }
        public string MessageMotive { get; private set; }

        private FundProcessValidate(string initSchedule, string endSchedule)
        {
            _initSchedule = initSchedule;
            _endSchedule = endSchedule;
        }

        public static FundProcessValidate Create(string initSchedule, string endSchedule)
        {
            return new FundProcessValidate(initSchedule, endSchedule);
        }

        private void SetMessage(int typeMotive)
        {
            switch (typeMotive)
            {
                case 1://Fuera de horario.
                    MessageMotive = $"El servicio de transferencias no está disponible. El horario para hacer transferencias es de las {_initSchedule}hrs a las {_endSchedule}hrs";
                    break;
                default:
                    MessageMotive = string.Empty;
                    break;

            }
        }

        public FundProcessValidate SetApplySchedule(bool applySchedule)
        {
            ApplySchedule = applySchedule;
            return this;
        }

        public FundProcessValidate ValidateApplyTransfer()
        {
            var motiveType = 0;
            IsTransferValidate = false;

            if (!ApplySchedule)
            {
                motiveType = 1;
            }
            else
            {
                IsTransferValidate = true;
            }

            SetMessage(motiveType);
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                IsTransferValidate,
                MessageMotive
            };
        }
    }
}
