﻿using Ddd;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace ClientFundTransfer.Domain.FundSalesInfoAggregate
{
    public class SaleTradeDates : ValueObject<SaleTradeDates>
    {
        private DateTime _requestDate;
        private DateTime _operationDate;
        private DateTime _liquidationDate;

        public DateTime RequestDate => _requestDate;

        public DateTime OperationDate => _operationDate;

        public DateTime LiquidationDate => _liquidationDate;

        private SaleTradeDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            SetRequestDate(requestDate);
            SetOperationDate(operationDate);
            SetLiquidationDate(liquidationDate);
        }

        internal static SaleTradeDates Create(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            return new SaleTradeDates(requestDate, operationDate, liquidationDate);
        }

        private void SetRequestDate(DateTime requestDate)
        {
            if (requestDate.ComparableDate() < DateTime.Now.ComparableDate()) { throw new ArgumentException("La fecha de solicitud no puede ser menor a la fecha actual"); }

            _requestDate = requestDate;
        }


        private void SetOperationDate(DateTime operationDate)
        {
            if (operationDate.ComparableDate() < RequestDate.ComparableDate()) { throw new ArgumentException("La fecha de operación no puede ser menor a la fecha de solicitud"); }

            _operationDate = operationDate;
        }


        private void SetLiquidationDate(DateTime liquidationDate)
        {
            if (liquidationDate.ComparableDate() < OperationDate.ComparableDate()) { throw new ArgumentException("La fecha de liquidación no puede ser menor a la fecha de operación"); }

            _liquidationDate = liquidationDate;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }

}
