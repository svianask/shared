﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.ContactDataValueAggregate
{
    public class ContactData : ValueObject<ContactData>
    {
        private readonly string _email;
        private readonly string _mobilePhone;
        private readonly string _countryDialCode;
        private DateTime _lastUpdateDate;

        private ContactData(string email, string mobilePhone, string countryDialCode)
        {
            _email = email;
            _mobilePhone = mobilePhone;
            _countryDialCode = countryDialCode;
            _lastUpdateDate = DateTime.Now;
        }

        public string Email => _email;

        public string MobilePhone => _mobilePhone;

        public string CountryDialCode => _countryDialCode;

        public DateTime LastUpdateDate { get => _lastUpdateDate; }

       
        public static ContactData Create(string email, string mobilePhone, string countryDialCode)
        {
            mobilePhone = StandarizePhone(mobilePhone);
            countryDialCode = StandarizeCountryDialCode(countryDialCode);

            return new ContactData(email, mobilePhone, countryDialCode);
        }

        private static string StandarizeCountryDialCode(string countryDialCode)
        {
            countryDialCode = countryDialCode.Replace(" ", "").Trim();
            if (countryDialCode.Length < 1) { countryDialCode = "+52"; }
            return countryDialCode;
        }

        private static string StandarizePhone(string phone)
        {
            phone = phone.Replace(" ", "").Trim();
            if (phone.Length != 10) { phone = string.Empty; }
            return phone;
        }

        public ContactData SetSetUpdateDate(DateTime? lastUpdateDate)
        {
            var currentDate = DateTime.Now;
            if (lastUpdateDate == null) { lastUpdateDate = currentDate; }

            _lastUpdateDate = Convert.ToDateTime(lastUpdateDate);

            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new object[]
            {
                Email,
                MobilePhone,
                CountryDialCode,
                LastUpdateDate
            };
        }
    }
}
