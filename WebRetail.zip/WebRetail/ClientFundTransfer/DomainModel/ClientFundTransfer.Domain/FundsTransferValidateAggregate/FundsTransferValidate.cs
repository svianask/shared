﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFundTransfer.Domain.FundsTransferValidateAggregate
{
    public class FundsTransferValidate : ValueObject<FundsTransferValidate>
    {
        private bool _isTransferValidate;
        private string _messageMotive;

        private readonly List<string> _applyPortafolioTypes;
        private readonly List<string> _applyProductTypes;

        private readonly string _initSchedule;
        private readonly string _endSchedule;
        private double _availableAmount;
        private string _typePortafolio;
        private string _productType;
        private bool _applySchedule;
        private bool _transfersPending;

        private FundsTransferValidate(string initSchedule, string endSchedule)
        {
            _initSchedule = initSchedule;
            _endSchedule = endSchedule;
            _applyPortafolioTypes = ConfigurationManager.AppSettings["ApplyTranferTypePortafolio"].Split(',').ToList();
            _applyProductTypes = ConfigurationManager.AppSettings["ApplyTransferProductTypes"].Split(',').ToList();
        }

        public bool IsTransferValidate => _isTransferValidate;
        public string MessageMotive => _messageMotive;

        public static FundsTransferValidate Create(string initSchedule, string endSchedule)
        {
            return new FundsTransferValidate(initSchedule, endSchedule);
        }

        private void SetMessage(int typeMotive)
        {
            switch(typeMotive)
            {
                case 1: //El portafolio o el tipo de producto no corresponden.
                    _messageMotive = "Tu contrato no cuenta con la opción de transferencia de fondos ya que invierte en un portafolio premium Skandia.";
                    break;
                case 2://No cuenta con saldo disponible
                    _messageMotive = "No cuentas con saldo en fondos disponibles para venta.";
                    break;
                case 3://ya tiene una transferencia en el dia actual
                    _messageMotive = "Sólo puedes hacer una transferencia al día, intentalo mañana.";
                    break;
                case 4://Fuera de horario.
                    _messageMotive = 
                        string.Format("El servicio de transferencias no está disponible. El horario para hacer transferencias es de las {0}hrs a las {1}hrs", _initSchedule, _endSchedule);
                    break;
                default:
                    _messageMotive = "";
                    break;
                   
            }
        }

        public FundsTransferValidate SetAvailableAmount(double amount)
        {
            _availableAmount = amount;
            return this;
        }

        public FundsTransferValidate SetPortafolioType(int portafolioType)
        {
            _typePortafolio = portafolioType.ToString();
            return this;
        }

        public FundsTransferValidate SetProductType(int productType)
        {
            _productType = productType.ToString();
            return this;
        }

        public FundsTransferValidate SetApplySchedule(bool valSchedule)
        {
            _applySchedule = valSchedule;
            return this;
        }

        public FundsTransferValidate SetApplyTranfersPending(bool transferPending)
        {
            _transfersPending = transferPending;
            return this;
        }

        public FundsTransferValidate ValidateApplyTransfer()
        {
            int motiveType = 0;
            _isTransferValidate = false;

            if (_availableAmount <= 0)
            {
                motiveType = 2;
            }
            else if(_transfersPending)
            {
                motiveType = 3;
            }
            else if (!_applySchedule)
            {
                motiveType = 4;
            }
            else
            {
                _isTransferValidate = true;
            }

            SetMessage(motiveType);
            return this;
        }



        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
