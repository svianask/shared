﻿using Ddd;
using System;

namespace ClientSamiNotificationsDomain.ClientSamiNotificationsAgreggate
{
    public class SamiNotification : Entity<string>
    {
        private readonly string _textHeader;
        private readonly string _textSubheader;
        private readonly string _labelButtonAction;
        private readonly string _urlButtonAction;

        private SamiNotification( string id, string textHeader, string textSubheader, string labelButtonAction, string urlButtonAction)
        {
            Id = id;
            _textHeader = textHeader;
            _textSubheader = textSubheader;
            _labelButtonAction = labelButtonAction;
            _urlButtonAction = urlButtonAction;
        }


        public string IdNotification => Id;
        public string TextHeader => _textHeader;
        public string TextSubheader => _textSubheader;
        public string LabelButtonAction => _labelButtonAction;
        public string UrlButtonAction => _urlButtonAction;

        public static SamiNotification Create(string id, string textHeader, string textSubheader, string labelButtonAction, string urlButtonAction)
        {
            if (string.IsNullOrEmpty(id)) { throw new ArgumentException("id can't be NULL"); }
           // if (string.IsNullOrEmpty(textHeader)) { throw new ArgumentException("textHeader can't be NULL"); }
            if (string.IsNullOrEmpty(textSubheader)) { throw new ArgumentException("textSubheader can't be NULL"); }
            if (string.IsNullOrEmpty(labelButtonAction)) { throw new ArgumentException("labelButtonAction can't be NULL"); }
            if (string.IsNullOrEmpty(urlButtonAction)) { throw new ArgumentException("urlButtonAction can't be NULL"); }

            if (string.IsNullOrEmpty(urlButtonAction))
            {
                urlButtonAction = Uri.EscapeDataString(urlButtonAction);
            }
            return new SamiNotification(id, textHeader, textSubheader, labelButtonAction, urlButtonAction);
        }
    }
}
