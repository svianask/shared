﻿using Ddd;

namespace ClientSamiNotificationsDomain.CampaingsAggregate
{
    public class CampaignData : Entity<string>
    {
        public CampaignData(string id, string qView, string tsView, string campaignid, string persID,
                            string personidcampaignid, string name, string cluster, bool control,
                            string detailsCTA, string cta1Response, string cta1ResponseTs,
                            string clickUrlConteo, string clickUrlUltimoclickTs, CampaignDetails campaignDetails)

        {
            Id = id;
            QView = qView;
            TsView = tsView;
            Campaignid = campaignid;
            PersID = persID;
            Personidcampaignid = personidcampaignid;
            Name = name;
            Cluster = cluster;
            Control = control;
            DetailsCTA = detailsCTA;
            Cta1Response = cta1Response;
            Cta1ResponseTs = cta1ResponseTs;
            ClickUrlConteo = clickUrlConteo;
            ClickUrlUltimoclickTs = clickUrlUltimoclickTs;
            CampaignDetails = campaignDetails;
        }

        public string QView { get; }
        public string TsView { get; }
        public string Campaignid { get; }
        public string PersID { get; }
        public string Personidcampaignid { get; }
        public string Name { get; }
        public string Cluster { get; }
        public bool Control { get; }
        public string DetailsCTA { get; }
        public string Cta1Response { get; }
        public string Cta1ResponseTs { get; }
        public string ClickUrlConteo { get; }
        public string ClickUrlUltimoclickTs { get; }
        public CampaignDetails CampaignDetails { get; }

        public static CampaignData Create(string id, string qView, string tsView, string campaignid, string persID,
                            string personidcampaignid, string name, string cluster, bool control,
                            string detailsCTA, string cta1Response, string cta1ResponseTs,
                            string clickUrlConteo, string clickUrlUltimoclickTs, CampaignDetails campaignDetails)
        {
            /*if (string.IsNullOrEmpty(name)) { throw new ArgumentException("Name can't be NULL"); }*/

            return new CampaignData(id, qView, tsView, campaignid, persID, personidcampaignid, name, cluster, control, detailsCTA, cta1Response, cta1ResponseTs, clickUrlConteo, clickUrlUltimoclickTs, campaignDetails);
        }

    }
}
