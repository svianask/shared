﻿using Ddd;
using System.Collections.Generic;

namespace ClientSamiNotificationsDomain.CampaingsAggregate
{
    public class CampaignDetails : ValueObject<CampaignDetails>
    {
        public CampaignDetails(string cta1AbiertoTipo, string campaignName, string detailsCta,
                                  string header, string icono, string location, string medioAudiovisual,
                                  string requestLog, string subheader, string area, string alcance,
                                  string type, string urlCta, string version, string campaignid,
                                  string desde, string hasta, string id)
        {
            Cta1AbiertoTipo = cta1AbiertoTipo;
            CampaignName = campaignName;
            DetailsCta = detailsCta;
            Header = header;
            Icono = icono;
            Location = location;
            MedioAudiovisual = medioAudiovisual;
            RequestLog = requestLog;
            Subheader = subheader;
            Area = area;
            Alcance = alcance;
            Type = type;
            UrlCta = urlCta;
            Version = version;
            Campaignid = campaignid;
            Desde = desde;
            Hasta = hasta;
            Id = id;
        }
        public string Cta1AbiertoTipo { get; }
        public string CampaignName { get; }
        public string DetailsCta { get; }
        public string Header { get; }
        public string Icono { get; }
        public string Location { get; }
        public string MedioAudiovisual { get; }
        public string RequestLog { get; }
        public string Subheader { get; }
        public string Area { get; }
        public string Alcance { get; }
        public string Type { get; }
        public string UrlCta { get; }
        public string Version { get; }
        public string Campaignid { get; }
        public string Desde { get; }
        public string Hasta { get; }
        public string Id { get; }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Cta1AbiertoTipo,
                CampaignName,
                DetailsCta,
                Header,
                Icono,
                Location,
                MedioAudiovisual,
                RequestLog,
                Subheader,
                Area,
                Alcance,
                Type,
                UrlCta,
                Version,
                Campaignid,
                Desde,
                Hasta,
                Id
            };
        }
    }
}
