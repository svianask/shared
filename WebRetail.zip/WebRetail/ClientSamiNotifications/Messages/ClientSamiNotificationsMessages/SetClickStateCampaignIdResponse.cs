﻿

using Common.Domain;

namespace ClientSamiNotificationsMessages
{
    public class SetClickStateCampaignIdResponse
    {
        public OperationResult Result;
    }
}
