﻿
namespace ClientSamiNotificationsMessages
{
    public class GetSamiNotificationsRequest
    {
        public string RFC { get; set; }
    }
}
