﻿using System;

namespace ClientSamiNotificationsMessages
{
    public class SetClickStateCampaignIdRequest
    {
        public String Rfc { get; set; }
        public String CampaingId { get; set; }
    }
}
