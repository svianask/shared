﻿
namespace ClientSamiNotificationsMessages
{
    public class GetNotificationCountByClientRequest
    {
        public string Rfc { get; set; }
    }
}
