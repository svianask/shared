﻿using ClientSamiNotificationsDomain.ClientSamiNotificationsAgreggate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientSamiNotificationsMessages
{
    public class GetSamiNotificationsResponse
    {
        public List<SamiNotification> Notifications;
        public OperationResult Result;
    }
}
