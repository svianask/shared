﻿
using Common.Domain;

namespace ClientSamiNotificationsMessages
{
    public class GetNotificationCountByClientResponse
    {
        public int TotalNotifications;
        public OperationResult Result;
    }
}
