﻿using ClientSamiNotificationsDomain.ClientSamiNotificationsAgreggate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientSamiNotifications.Application
{
    public interface IClientSamiNotificationsApp
    {
        List<SamiNotification> GetNotifications(string rfc, out OperationResult result);
        int GetNotificationsCountByClient(string rfc, out OperationResult result);
        void SetClickStateCampaignId(string rfc, string campaingId, out OperationResult result);
    }
}
