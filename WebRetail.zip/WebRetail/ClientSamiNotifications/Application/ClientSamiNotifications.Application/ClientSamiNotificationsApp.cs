﻿using ClientSamiNotificationsDomain.CampaingsAggregate;
using Common.Domain;
using Common.Proxy;
using DataWarehouseProxy;
using SeriLogH;
using System.Collections.Generic;
using ClientSamiNotificationsDomain.ClientSamiNotificationsAgreggate;
using System.Linq;
using ClientSamiNotificationsProxy.WebRetailServiceStoriesMapp;

namespace ClientSamiNotifications.Application
{
    public class ClientSamiNotificationsApp : IClientSamiNotificationsApp
    {
         private readonly IWebRetailServiceSamiNotificationsProxy _webRetailServiceStoriesProxy;
         private readonly ISeriLogHelper _log;
         private readonly IParametersProxy _parametersProxy;
         public ClientSamiNotificationsApp(ISeriLogHelper log,   IParametersProxy parametersProxy,
             IWebRetailServiceSamiNotificationsProxy webRetailServiceStoriesProxy)
        {
            _log = log;
            _parametersProxy = parametersProxy;
            _webRetailServiceStoriesProxy = webRetailServiceStoriesProxy;
        }

        public List<SamiNotification> GetNotifications(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            _log.Info("Getting  Sami Notifications Information");
            rfc = rfc.ToUpper();
            _log.Info("Rfc Parameter: {cntx}", rfc);
            List<CampaignData> campaings = _webRetailServiceStoriesProxy.GetAllCampaingsByRFC(rfc, out result).Where(o => o.CampaignDetails.Type == "Sami_Notificaciones").ToList();
            _log.Debug("Campañas encontradas: {cntx}", campaings);

            List<SamiNotification> notifications = SamiNotificationMapp.Mapp(campaings);
            _log.Debug("Result Notifications {cntx}", notifications);
            return notifications;
        }

        public int GetNotificationsCountByClient(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            _log.Info("Getting Total  Sami Notifications Information");
            rfc = rfc.ToUpper();
            _log.Info("Rfc Parameter: {cntx}", rfc);
            int countNotifications = _webRetailServiceStoriesProxy.GetAllCampaingsByRFC(rfc, out result).Where(o => o.CampaignDetails.Type == "Sami_Notificaciones").Count();
            _log.Debug("Total de notifications: {cntx}", countNotifications);

            return countNotifications;
        }

        public void SetClickStateCampaignId(string rfc, string campaingId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            _log.Info("Recording Click State ");
            rfc = rfc.ToUpper();
            _log.Info("Rfc Parameter: {cntx}", rfc);
            _log.Info("CampaingId Parameter: {cntx}", campaingId);

            _webRetailServiceStoriesProxy.RegisterClickStateCampaignId(rfc, campaingId, out result);
            _log.Info("Recorded Click State ");
        }
    }
}
