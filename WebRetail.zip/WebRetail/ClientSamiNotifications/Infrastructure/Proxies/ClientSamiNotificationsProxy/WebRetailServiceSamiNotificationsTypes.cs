﻿using ClientSamiNotificationsDomain.CampaingsAggregate;
using Common.Domain;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace ClientSamiNotificationsProxy
{
    public class GetAllCampaingsByRFCResponse
    {
        [JsonProperty(PropertyName = "campaings")]

        public List<CampaignData> Campaigns { get; set; }
        public OperationResult Result { get; set; }
    }

    public class GetAllCampaingsByRFCRequest
    {
        public string RFC { get; set; }
    }

    public class InsertItemToContainerRequest
    {
        public string PersonIdCampaingId { get; set; }
        public string PersID { get; set; }
        public string CampaignId { get; set; }
        public int ClickURLFlag { get; set; }
        public string ClickURLClickTs { get; set; }
        public int ViewsCount { get; set; }
        public string ViewsTs { get; set; }
    }

    public class InsertItemToContainerResponse
    {
        public bool SuccessResponse { get; set; }
        public OperationResult Result;
    }

    public class CampaingDetailTypesPrxy
    {
        public string Cta1AbiertoTipo { get; set; }
        public string CampaignName { get; set; }
        public string DetailsCta { get; set; }
        public string Header { get; set; }
        public string Icono { get; set; }
        public string Location { get; set; }
        public string MedioAudiovisual { get; set; }
        public string RequestLog { get; set; }
        public string Subheader { get; set; }
        public string Area { get; set; }
        public string Alcance { get; set; }
        public string Type { get; set; }
        public string UrlCta { get; set; }
        public string Version { get; set; }
        public string Campaignid { get; set; }
        public string Desde { get; set; }
        public string Hasta { get; set; }
        public string Id { get; set; }
    }

    public class CampaingHeaderTypesPrxy
    {
        public string Id { get; set; }
        public string QView { get; set; } // Changed from q_view
        public string TsView { get; set; } // Changed from ts_view
        public string Campaignid { get; set; }
        public string PersId { get; set; } // Changed from PersID
        public string Personidcampaignid { get; set; }
        public string Name { get; set; }
        public string Cluster { get; set; }
        public bool Control { get; set; }
        public string DetailsCta { get; set; }
        public string Cta1Response { get; set; } // Changed from CTA1_Response
        public string Cta1ResponseTs { get; set; }  // Changed from CTA1_Response_ts
        public string ClickUrlConteo { get; set; } // Changed from ClickURL_Conteo
        public string ClickUrlUltimoclickTs { get; set; } // Changed from ClickURL_ultimoclick_ts
        public CampaingDetailTypesPrxy CampaignDetails { get; set; } // Changed from campaign_Details
    }
}
