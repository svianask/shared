﻿using ClientSamiNotificationsDomain.CampaingsAggregate;
using System;
using System.Collections.Generic;

namespace ClientSamiNotificationsProxy.WebRetailServiceStoriesMapp
{
    public class CampaingsDataMapp
    {
        public static List<CampaignData> Mapp(List<CampaingHeaderTypesPrxy> campaingsPrxy)
        {
            List<CampaignData> campaignsData = new List<CampaignData>();

            if (campaingsPrxy != null && campaingsPrxy.Count > 0)
            {
                campaingsPrxy.ForEach(o =>
                {
                    CampaignDetails campaignDetails = null;
                    if (o.CampaignDetails != null)
                    {
                        campaignDetails = new CampaignDetails(o.CampaignDetails.Cta1AbiertoTipo, o.CampaignDetails.CampaignName,
                            o.CampaignDetails.DetailsCta, o.CampaignDetails.Header, o.CampaignDetails.Icono, o.CampaignDetails.Location,
                            o.CampaignDetails.MedioAudiovisual, o.CampaignDetails.RequestLog, o.CampaignDetails.Subheader, o.CampaignDetails.Area,
                            o.CampaignDetails.Alcance, o.CampaignDetails.Type, o.CampaignDetails.UrlCta, o.CampaignDetails.Version, o.CampaignDetails.Campaignid,
                            o.CampaignDetails.Desde, o.CampaignDetails.Hasta, o.CampaignDetails.Id);
                    }
                    CampaignData campaignDataTemp = CampaignData.Create(o.Id, o.QView, o.TsView, o.Campaignid, o.PersId, o.Personidcampaignid, o.Name, o.Cluster, o.Control, o.DetailsCta, o.Cta1Response, o.Cta1ResponseTs, o.ClickUrlConteo, o.ClickUrlUltimoclickTs, campaignDetails);
                    campaignsData.Add(campaignDataTemp);
                });
            }

            return campaignsData;
        }
    }
}
