﻿using ClientSamiNotificationsDomain.ClientSamiNotificationsAgreggate;
using ClientSamiNotificationsDomain.CampaingsAggregate;
using System.Collections.Generic;


namespace ClientSamiNotificationsProxy.WebRetailServiceStoriesMapp
{
    public class SamiNotificationMapp
    {
        public static List<SamiNotification> Mapp(List<CampaignData> campaings)
        {
            List<SamiNotification> notifications = new List<SamiNotification>();
            if( campaings != null )
            {
                campaings.ForEach(c =>
                {
                    SamiNotification tmpNotification = SamiNotification.Create(c.Id, c.CampaignDetails.Header, c.CampaignDetails.Subheader, c.CampaignDetails.DetailsCta, c.CampaignDetails.UrlCta );
                    notifications.Add(tmpNotification);
                });
            }
            return notifications;
         }
    }
}
