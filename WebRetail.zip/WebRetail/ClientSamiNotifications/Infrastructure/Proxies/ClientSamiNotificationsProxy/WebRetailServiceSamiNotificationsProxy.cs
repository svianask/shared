﻿using ClientSamiNotificationsDomain.CampaingsAggregate;
using Common.Domain;
using DataWarehouseProxy;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ClientSamiNotificationsProxy
{
    public class WebRetailServiceSamiNotificationsProxy:IWebRetailServiceSamiNotificationsProxy
    {
        private readonly IProxyEngine _proxyEngine;

        public WebRetailServiceSamiNotificationsProxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<CampaignData> GetAllCampaingsByRFC(string RFC, out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "DataWarehouse/GetAllCampaingsByRFC";
            var response = new GetAllCampaingsByRFCResponse();
            var request = new GetAllCampaingsByRFCRequest()
            {
                RFC = RFC
            };

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetAllCampaingsByRFCResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.Campaigns;
        }

        public void RegisterClickStateCampaignId(string rfc, string campaingId, out OperationResult result)
        {
            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["WebRetailApi:URLService"].ToString() + "DataWarehouse/InsertItemToContainer";
            var response = new InsertItemToContainerResponse();
            var request = new InsertItemToContainerRequest()
            {
                PersonIdCampaingId = $"{rfc}{campaingId}",
                PersID = rfc,
                CampaignId = campaingId,
                ClickURLFlag = 0,
                ClickURLClickTs = "",
                ViewsCount = 1,
                ViewsTs = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss7Z")
            };
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<InsertItemToContainerResponse>(JsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url);
            }

        }

    }
}
