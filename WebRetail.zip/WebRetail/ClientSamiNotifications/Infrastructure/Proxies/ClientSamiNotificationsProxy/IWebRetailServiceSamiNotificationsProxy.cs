﻿
using ClientSamiNotificationsDomain.CampaingsAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace DataWarehouseProxy
{
    public interface IWebRetailServiceSamiNotificationsProxy
    {
        List<CampaignData> GetAllCampaingsByRFC(string RFC, out OperationResult result);
        void RegisterClickStateCampaignId(string rfc, string campaingId, out OperationResult result);
    }
}
