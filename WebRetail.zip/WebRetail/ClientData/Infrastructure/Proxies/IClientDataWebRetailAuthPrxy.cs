﻿using ClientDataDomain.ClientDataInformationAggregate;
using Common.Domain;

namespace ClientDataProxy
{
    public interface IClientDataWebRetailAuthPrxy
    {
        ClientContactData GetContactData(string rfc, out OperationResult result);
        void UpdateClientContactData(string clientId, string email, string phone, out OperationResult result);
    }
}
