﻿using ClientDataDomain.ClientDataAddressAggregate;
using ClientDataDomain.DTO.Response.TownshipAddress;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientDataProxy.TownshipAddressPrxyTypes
{
    public class GetTownshipAddressRequestPrxy
    {
        public string ZipCode = String.Empty;
    }

    public class GetTownshipAddressResponsePrxy
    {
        public List<TownshipAddressPrxyDto> townships;
        public OperationResult Result;
    }


    public class TownshipAddressPrxyDto
    {
        public int Id;
        public String TownshipName;
        public CityAddressPrxyDTO City;
        public StateAddressPrxyDTO State;
    }

    public class StateAddressPrxyDTO
    {
        public int Id;
        public String Name;
    }

    public class CityAddressPrxyDTO
    {
        public int Id;
        public String Name;
    }
}
