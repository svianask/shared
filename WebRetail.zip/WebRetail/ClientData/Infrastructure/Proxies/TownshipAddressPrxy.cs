﻿using ClientDataDomain.ClientDataAddressAggregate;
using ClientDataMessages;
using ClientDataProxy.ClientDataMapping;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Collections.Generic;
using System.Configuration;
using ClientDataProxy.TownshipAddressPrxyTypes;
using ClientDataDomain.DTO.Response.TownshipAddress;

namespace ClientDataProxy
{
    public class TownshipAddressPrxy : ITownshipAddressPrxy
    {
        private readonly IProxyEngine _proxyEngine;
        
        public TownshipAddressPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public List<TownshipAddressDTO> GetTownshipsByZipCode(string zipCode, out OperationResult result)
        {
            GetTownshipAddressRequestPrxy request = new GetTownshipAddressRequestPrxy();
            GetTownshipAddressResponsePrxy response = new GetTownshipAddressResponsePrxy();

            List<TownshipAddressDTO> townships = null;

            result = new OperationResult();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientFiscalData/GetTownshipsByZipCode";
            request.ZipCode = zipCode;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetTownshipAddressResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                townships = TownshipAddressMapp.Mapp(response.townships);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]); 
            }

            return townships;

        }
    }
}
