﻿using System;
using System.Configuration;

using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataProxy.ClientDataMapping;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;

namespace ClientDataProxy
{
    public class ClientDataRetailExtPrxy : IClientDataRetailExtPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientDataRetailExtPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }


        public ClientBehaviorData GetClientBehaviorData(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            ClientBehaviorDataRequestPrxy request = new ClientBehaviorDataRequestPrxy();
            ClientBehaviorDataResponsePrxy response = new ClientBehaviorDataResponsePrxy();

            ClientBehaviorData clientBehaviorData = ClientBehaviorData.CreateEmpty("");

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientBehavior/GetClientBehaviorData";
            request.RFC = rfc;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<ClientBehaviorDataResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                clientBehaviorData = ClientBehaviorMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientBehaviorData;
        }

        public void UpdateClientBehaviorData(string clientId, string motivation, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            UpdateClientBehaviorDataRequestPrxy request = new UpdateClientBehaviorDataRequestPrxy();
            UpdateClientBehaviorDataResponsePrxy response = new UpdateClientBehaviorDataResponsePrxy();

            ClientBehaviorData clientBehaviorData = ClientBehaviorData.Create(motivation);

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientBehavior/UpdateClientBehaviorData";
            request.ClientId = clientId;
            request.Motivation = motivation;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<UpdateClientBehaviorDataResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
        }
    }
}
