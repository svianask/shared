using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataMessages;
using ClientDataProxy.ClientDataMapping;
using Common.Domain;
using ClientDataProxy.FiscalDataProxyTypes;
using Newtonsoft.Json;
using Proxy;
using System;
using System.Configuration;

namespace ClientDataProxy
{
    public class ClientFiscalDataPrxy : IClientFiscalDataPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientFiscalDataPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public void UpdateClientFiscalDataSIIF(ClientFiscalData fiscalData, out OperationResult result)
        {
            UpdateClientFiscalDataRequest request = new UpdateClientFiscalDataRequest();
            UpdateClientDataResponse response = new UpdateClientDataResponse();

            result = new OperationResult();
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientFiscalData/UpdateFiscalData";
            request.Curp = fiscalData.PersonalFiscalData.CURP;
            request.Names = fiscalData.PersonalFiscalData.Names;
            request.PaternalSurname = fiscalData.PersonalFiscalData.PaternalSurname;
            request.MaternalSurname = fiscalData.PersonalFiscalData.MaternalSurname;
            request.RoadNameType = fiscalData.PersonalFiscalData.RoadNameType;
            request.InnerNumber = fiscalData.PersonalFiscalData.InnerNumber;
            request.OuterNumber = fiscalData.PersonalFiscalData.OuterNumber;
            request.Location = fiscalData.PersonalFiscalData.Location;
            request.BetweenStreet = fiscalData.PersonalFiscalData.BetweenStreet;
            request.ZipCode = fiscalData.FiscalAddress.ZipCode;
            request.StateName = fiscalData.FiscalAddress.Township.State.Name;
            request.StateId = fiscalData.FiscalAddress.Township.State.Id; ;
            request.CityId = fiscalData.FiscalAddress.Township.City.Id;
            request.CityName = fiscalData.FiscalAddress.Township.City.Name;
            request.TownshipId = fiscalData.FiscalAddress.Township.Id;
            request.TownshipName = fiscalData.FiscalAddress.Township.TownshipName;
            request.RoadName = fiscalData.PersonalFiscalData.RoadName;
            request.ClientId = fiscalData.ClientId;
            request.Channel = fiscalData.Channel;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (!result.Successful)
            {
                throw new Exception("An error to consume the service" + url + " - " + result.SystemMessages[0]);
            }

            response = JsonConvert.DeserializeObject<UpdateClientDataResponse>(JsonResult);
            if (!response.Result.Successful) { throw new Exception("An error has ocurred to consume the  ClientFiscalData service: " + url + " - " + response.Result.SystemMessages[0]); }

        }

        public void UpdateClientFiscalDataStore(ClientFiscalData fiscalData, out OperationResult result)
        {
            result = new OperationResult();

            if ((fiscalData.Channel.Equals("WHATSAPP") || fiscalData.Channel.Equals("WHATSAPP-VENDEDOR")) && fiscalData.FiscalAddress.Township.Id == 0)
            {
                result.Successful = true;
                result.SystemMessages.Add(new SystemMessage { Message = "No se puede guardar colonia sin id (Base Intermedia)" });
            }
            else
            {
                UpdateClientFiscalDataRequest request = new UpdateClientFiscalDataRequest();
                UpdateClientDataResponse response = new UpdateClientDataResponse();
                string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientFiscalData/UpdateFiscalData";
                request.Curp = fiscalData.PersonalFiscalData.CURP;
                request.Names = fiscalData.PersonalFiscalData.Names;
                request.PaternalSurname = fiscalData.PersonalFiscalData.PaternalSurname;
                request.MaternalSurname = fiscalData.PersonalFiscalData.MaternalSurname;
                request.RoadName = fiscalData.PersonalFiscalData.RoadName;
                request.RoadNameType = fiscalData.PersonalFiscalData.RoadNameType;
                request.InnerNumber = fiscalData.PersonalFiscalData.InnerNumber;
                request.OuterNumber = fiscalData.PersonalFiscalData.OuterNumber;
                request.Location = fiscalData.PersonalFiscalData.Location;
                request.BetweenStreet = fiscalData.PersonalFiscalData.BetweenStreet;
                request.ZipCode = fiscalData.FiscalAddress.ZipCode;
                request.StateName = fiscalData.FiscalAddress.Township.State.Name;
                request.StateId = fiscalData.FiscalAddress.Township.State.Id; ;
                request.CityId = fiscalData.FiscalAddress.Township.City.Id;
                request.CityName = fiscalData.FiscalAddress.Township.City.Name;
                request.TownshipId = fiscalData.FiscalAddress.Township.Id;
                request.TownshipName = fiscalData.FiscalAddress.Township.TownshipName;
                request.ClientId = fiscalData.ClientId;
                request.Channel = fiscalData.Channel;

                string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

                if (!result.Successful)
                {
                    throw new Exception("An error to consume the service" + url + " - " + result.SystemMessages[0]);
                }

                response = JsonConvert.DeserializeObject<UpdateClientDataResponse>(JsonResult);
                if (!response.Result.Successful) { throw new Exception("An error has ocurred to consume the  ClientFiscalData service: " + url + " - " + response.Result.SystemMessages[0]); }
            }




        }

        public ClientFiscalData GetClientFiscalDataSIIF(string clientId, out OperationResult result)
        {

            GetFiscalDataRequestPrxy request = new GetFiscalDataRequestPrxy();
            GetFiscalDataResponsePrxy response = new GetFiscalDataResponsePrxy();
            result = new OperationResult();
            ClientFiscalData fiscalData = null;
            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientFiscalData/GetFiscalData";
            request.ClientId = clientId;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (!result.Successful)
            {
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            response = JsonConvert.DeserializeObject<GetFiscalDataResponsePrxy>(JsonResult);
            if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            fiscalData = ClientFiscalDataMapp.Mapp(response.fiscalData);
            return fiscalData;
        }

        public ClientFiscalData GetClientFiscalDataStore(string clientId, out OperationResult result)
        {
            GetFiscalDataRequestPrxy request = new GetFiscalDataRequestPrxy();
            GetFiscalDataResponsePrxy response = new GetFiscalDataResponsePrxy();

            result = new OperationResult();
            ClientFiscalData fiscalData = null;
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientFiscalData/GetFiscalData";
            request.ClientId = clientId;

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            response = JsonConvert.DeserializeObject<GetFiscalDataResponsePrxy>(JsonResult);
            if (response.fiscalData != null)
            {
                fiscalData = ClientFiscalDataMapp.Mapp(response.fiscalData);
            }
            //            if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            return fiscalData;
        }


    }
}
