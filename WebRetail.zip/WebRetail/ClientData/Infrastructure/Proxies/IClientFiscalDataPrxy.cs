using ClientDataDomain.ClientDataInformationAggregate;
using Common.Domain;

namespace ClientDataProxy
{
    public interface IClientFiscalDataPrxy
    {
        void UpdateClientFiscalDataSIIF(ClientFiscalData clientFiscalData, out OperationResult result);
        void UpdateClientFiscalDataStore(ClientFiscalData clientFiscalData, out OperationResult result);
        ClientFiscalData GetClientFiscalDataSIIF( string clientId, out OperationResult result);
        ClientFiscalData GetClientFiscalDataStore(string clientId, out OperationResult result); 
    }
}
