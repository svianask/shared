﻿using Common.Domain;
using System;

namespace ClientDataProxy.FiscalDataProxyTypes
{
    public class GetFiscalDataRequestPrxy
    {
        public string ClientId = String.Empty;
    }

    public class GetFiscalDataResponsePrxy
    {
        public FiscalDataPrxyDto fiscalData;
        public OperationResult Result;
    }

    public class UpdateFiscalDataRequestPrxy : FiscalDataPrxyDto
    {

    }

    public class UpdateFiscalDataResponsePrxy
    {
        public FiscalDataPrxyDto fiscalData;
        public OperationResult Result;
    }

    public class FiscalDataPrxyDto
    {
        public FiscalPersonalDataPrxyDto PersonalData;
        public String ZipCode;
        public int CityId;
        public String CityName;
        public int StateId;
        public String StateName;
        public String TownshipName;
        public String RoadName;
        public DateTime UpdatedDate;
        public String Channel;
    }

    public class FiscalPersonalDataPrxyDto
    {
        public String RFC;
        public String CURP;
        public string Names;
        public string PaternalSurname;
        public string MaternalSurname;
        public string RoadName;
        public string RoadNameType;
        public string InnerNumber;
        public string OuterNumber;
        public string Location;
        public string BetweenStreet;
    }

}
