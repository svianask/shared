﻿using ClientDataDomain.ClientDataInformationAggregate;
using Common.Domain;

namespace ClientDataProxy
{
    public interface IClientDataRetailExtPrxy
    {
        ClientBehaviorData GetClientBehaviorData(string rfc, out OperationResult result);
        void UpdateClientBehaviorData(string clientId, string motivation, out OperationResult result);
    }
}
