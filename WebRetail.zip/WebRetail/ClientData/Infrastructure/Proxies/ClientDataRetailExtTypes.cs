﻿using Common.Domain;
using System;

namespace ClientDataProxy
{
    public class ClientBehaviorDataRequestPrxy
    {
        public string RFC;
    }

    public class ClientBehaviorDataResponsePrxy
    {
        public OperationResult Result;
        public ClientBehaviorDataPrxy ClientBehaviorData;
    }

    public class ClientBehaviorDataPrxy
    {
        public string Motivation;
        public DateTime LastUpdateDate;
    }

    public class UpdateClientBehaviorDataRequestPrxy
    {
        public string ClientId;
        public string Motivation;
    }

    public class UpdateClientBehaviorDataResponsePrxy
    {
        public OperationResult Result;
    }
}
