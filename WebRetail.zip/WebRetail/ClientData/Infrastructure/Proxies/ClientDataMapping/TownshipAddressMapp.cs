﻿using ClientDataDomain.ClientDataAddressAggregate;
using ClientDataProxy.TownshipAddressPrxyTypes;
using System.Collections.Generic;
using ClientDataDomain.DTO.Response.TownshipAddress;

namespace ClientDataProxy.ClientDataMapping
{
    public class TownshipAddressMapp
    {
        internal static List<TownshipAddressDTO> Mapp(List<TownshipAddressPrxyDto> objs)
        {
            List<TownshipAddressDTO> townnships = null;
            if( objs != null) {
                townnships = new List<TownshipAddressDTO>();
                objs.ForEach(o =>
                {
                    TownshipAddressDTO townshipDTO = new TownshipAddressDTO();
                    StateAddressDTO stateAddressDTO = new StateAddressDTO();
                    stateAddressDTO.Id = o.State.Id;
                    stateAddressDTO.Name = o.State.Name;
                    CityAddressDTO cityAddressDTO = new CityAddressDTO();
                    cityAddressDTO.Id = o.City.Id;
                    cityAddressDTO.Name = o.City.Name;

                    townshipDTO.Id = o.Id;
                    townshipDTO.TownshipName = o.TownshipName;
                    townshipDTO.State = stateAddressDTO;
                    townshipDTO.City = cityAddressDTO;
                    townnships.Add(townshipDTO);
                });
            }
            return townnships;
        }
    }
}
