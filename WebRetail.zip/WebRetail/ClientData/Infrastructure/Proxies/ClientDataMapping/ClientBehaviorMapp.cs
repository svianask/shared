﻿
using ClientDataDomain.ClientDataInformationAggregate;

namespace ClientDataProxy.ClientDataMapping
{
    public static class ClientBehaviorMapp
    {
        public static ClientBehaviorData Mapp(ClientBehaviorDataResponsePrxy clientBehavior)
        {
            return (!string.IsNullOrEmpty(clientBehavior.ClientBehaviorData.Motivation)) ? ClientBehaviorData.Create(clientBehavior.ClientBehaviorData.Motivation) : ClientBehaviorData.CreateEmpty() ;
        }
    }
}
