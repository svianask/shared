﻿using ClientDataDomain.ClientDataAddressAggregate;
using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataDomain.DTO.Response.ClientBehavior;
using ClientDataDomain.DTO.Response.ClientContactData;
using ClientDataDomain.DTO.Response.ClientFiscalData;
using ClientDataDomain.DTO.Response.ClientPersonalData;

namespace ClientDataProxy.ClientDataMapping
{
    public class ClientPersonalDataMapp
    {
        public static ClientPersonalDataDTO Mapp(ClientDataInformation obj)
        {
            ClientContactDataDTO contactDataDTO = new ClientContactDataDTO();
            contactDataDTO.Email = obj.ClientContactData.Email;
            contactDataDTO.MobilePhone =   obj.ClientContactData.MobilePhone;
            ClientBehaviorDTO behaviorDTO = new ClientBehaviorDTO();
            behaviorDTO.Motivation = obj.ClientBehaviorData.Motivation;
            ClientFiscalDataDTO fiscalDataDTO = new ClientFiscalDataDTO();
            FiscalAddress fiscalAddress = obj.ClientFiscalData.FiscalAddress;

            fiscalDataDTO.PersonalFiscalData = new ClientFiscalPersonalDataDTO();
            fiscalDataDTO.PersonalFiscalData.CURP = obj.ClientFiscalData.PersonalFiscalData.CURP;
            fiscalDataDTO.PersonalFiscalData.RFC = obj.ClientFiscalData.PersonalFiscalData.RFC;
            fiscalDataDTO.PersonalFiscalData.Names = obj.ClientFiscalData.PersonalFiscalData.Names;
            fiscalDataDTO.PersonalFiscalData.PaternalSurname = obj.ClientFiscalData.PersonalFiscalData.PaternalSurname;
            fiscalDataDTO.PersonalFiscalData.MaternalSurname = obj.ClientFiscalData.PersonalFiscalData.MaternalSurname;
            fiscalDataDTO.PersonalFiscalData.RoadName = obj.ClientFiscalData.PersonalFiscalData.RoadName;
            fiscalDataDTO.PersonalFiscalData.RoadNameType = obj.ClientFiscalData.PersonalFiscalData.RoadNameType;
            fiscalDataDTO.PersonalFiscalData.InnerNumber = obj.ClientFiscalData.PersonalFiscalData.InnerNumber;
            fiscalDataDTO.PersonalFiscalData.OuterNumber = obj.ClientFiscalData.PersonalFiscalData.OuterNumber;
            fiscalDataDTO.PersonalFiscalData.Location = obj.ClientFiscalData.PersonalFiscalData.Location;
            fiscalDataDTO.PersonalFiscalData.BetweenStreet = obj.ClientFiscalData.PersonalFiscalData.BetweenStreet;

            fiscalDataDTO.ZipCode = fiscalAddress.ZipCode;
            fiscalDataDTO.CityName = fiscalAddress.Township.City.Name;
            fiscalDataDTO.StateName = fiscalAddress.Township.State.Name;
            fiscalDataDTO.TownshipName = fiscalAddress.Township.TownshipName;
            

            ClientPersonalDataDTO personalDataDTO = new ClientPersonalDataDTO();
            personalDataDTO.ClientFiscalData = fiscalDataDTO;
            personalDataDTO.ClientContactData = contactDataDTO;
            personalDataDTO.ClientBehaviorData = behaviorDTO;
            personalDataDTO.LastUpdateDate = obj.LastUpdateDate.ToString("dd-MM-yyyy");

            personalDataDTO.CountFiscalMissing = 0;
            personalDataDTO.CountPersonalData = 0;

            personalDataDTO.CountPersonalData += ( string.IsNullOrEmpty(contactDataDTO.Email)) ? 1 : 0;
            personalDataDTO.CountPersonalData += ( string.IsNullOrEmpty(contactDataDTO.MobilePhone)) ? 1 : 0;

            personalDataDTO.CountFiscalMissing += ( string.IsNullOrEmpty(fiscalDataDTO.PersonalFiscalData.CURP)) ? 1 : 0;
            personalDataDTO.CountFiscalMissing += ( string.IsNullOrEmpty(fiscalDataDTO.ZipCode)) ? 1 : 0;
            personalDataDTO.CountFiscalMissing += ( string.IsNullOrEmpty(fiscalDataDTO.PersonalFiscalData.RoadName)) ? 1 : 0;

            return personalDataDTO;
        }

    }
}
