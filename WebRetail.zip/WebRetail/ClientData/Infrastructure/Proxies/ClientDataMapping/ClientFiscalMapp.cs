﻿using ClientDataDomain.ClientDataAddressAggregate;
using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataMessages;
using ClientDataProxy.FiscalDataProxyTypes;

namespace ClientDataProxy.ClientDataMapping
{
    public class ClientFiscalDataMapp
    {
        public static ClientFiscalData Mapp(FiscalDataPrxyDto obj)
        {
            ClientFiscalData clientFiscalData = null;


            TownshipAddress township = TownshipAddress.CreateEmpty(obj.TownshipName, StateAddress.Create(obj.StateId, obj.StateName), CityAddress.Create(obj.CityId, obj.CityName));

            FiscalAddress fiscalAddress = FiscalAddress.Create(obj.ZipCode, township);

            PersonalFiscalData personalData = PersonalFiscalData.Create(obj.PersonalData.RFC, obj.PersonalData.CURP, obj.PersonalData.Names, obj.PersonalData.PaternalSurname, obj.PersonalData.MaternalSurname, obj.PersonalData.RoadName, obj.PersonalData.RoadNameType, obj.PersonalData.InnerNumber, obj.PersonalData.OuterNumber, obj.PersonalData.Location, obj.PersonalData.BetweenStreet);

            clientFiscalData = ClientFiscalData.CreateEntry(obj.PersonalData.RFC, personalData, fiscalAddress, obj.UpdatedDate, obj.Channel);
            return clientFiscalData;
        }

        public static ClientFiscalData Mapp(UpdateClientFiscalDataRequest obj)
        {
            ClientFiscalData clientFiscalData = null;
            clientFiscalData = ClientFiscalData.Create(obj.ClientId);

            CityAddress city = CityAddress.Create(obj.CityId, obj.CityName);
            StateAddress state = StateAddress.Create(obj.StateId, obj.StateName);
            TownshipAddress township = TownshipAddress.Create(obj.TownshipId, obj.TownshipName, state, city);

            FiscalAddress fiscalAddress = FiscalAddress.Create(obj.ZipCode, township);

            PersonalFiscalData personalData = PersonalFiscalData.Create(obj.ClientId, obj.Curp, obj.Names, obj.PaternalSurname, obj.MaternalSurname, obj.RoadName, obj.RoadNameType, obj.InnerNumber, obj.OuterNumber, obj.Location, obj.BetweenStreet);

            clientFiscalData.SetAddress(fiscalAddress, obj.Channel);
            clientFiscalData.SetPersonalFiscalData(personalData);
            //clientFiscalData.SetCurp(obj.Curp).SetEmptyAddress(fiscalAddress);
            return clientFiscalData;
        }

    }
}
