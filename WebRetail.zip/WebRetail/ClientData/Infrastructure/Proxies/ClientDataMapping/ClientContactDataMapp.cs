﻿using ClientDataDomain.ClientDataInformationAggregate;

namespace ClientDataProxy.ClientDataMapping
{
    public static class ClientContactDataMapp
    {
        public static ClientContactData Mapp(ContactInformationPrxy contactInformation)
        {
            ClientContactData clientContactData = null;
            clientContactData = ClientContactData.Create(contactInformation.Email, contactInformation.MobilePhone, contactInformation.CountryDialCode);
            clientContactData.SetSetUpdateDate(contactInformation.LastUpdateDate);
            return clientContactData;
        }
    }
}
