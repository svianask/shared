﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientDataProxy
{
    public class GetContactDataRequestPrxy
    {
        public string UserName;
    }

    public class GetContactDataResponsePrxy
    {
        public ContactInformationPrxy ContactInformation;
        public OperationResult Result;
    }

    public class ContactInformationPrxy
    {
        public string Email;
        public string MobilePhone;
        public string CountryDialCode;
        public DateTime LastUpdateDate;
    }

    public class UpdateSolvencyDataResponsePrxy
    {
        public OperationResult Result;
    }

    public class UpdateSolvencyDataRequestPrxy
    {
        public string UserName;
        public PocoUserContactDataPrxy ContactData;

        public UpdateSolvencyDataRequestPrxy()
        {
            ContactData = new PocoUserContactDataPrxy();
        }
    }

    public class PocoUserContactDataPrxy
    {
        public string Alias;
        public string Email;
        public string MobilePhone;
        public string CountryPhoneCode;
    }
}
