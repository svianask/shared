﻿using System;
using System.Configuration;
using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataProxy.ClientDataMapping;
using Common.Domain;
using Newtonsoft.Json;
using Proxy;

namespace ClientDataProxy
{
    public class ClientDataWebRetailAuthPrxy : IClientDataWebRetailAuthPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public ClientDataWebRetailAuthPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public ClientContactData GetContactData(string rfc, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            GetContactDataRequestPrxy request = new GetContactDataRequestPrxy();
            GetContactDataResponsePrxy response = new GetContactDataResponsePrxy();

            ClientContactData clientContactData = ClientContactData.Create("","","");

            string url = ConfigurationManager.AppSettings["WebRetailAuth:Url"].ToString() + "Solvency/GetContactData";
            request.UserName = rfc;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<GetContactDataResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
                clientContactData = ClientContactDataMapp.Mapp(response.ContactInformation);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return clientContactData;
        }

        public void UpdateClientContactData(string clientId, string email, string phone, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            UpdateSolvencyDataRequestPrxy request = new UpdateSolvencyDataRequestPrxy();
            UpdateSolvencyDataResponsePrxy response = new  UpdateSolvencyDataResponsePrxy();

            ClientContactData clientContactData = ClientContactData.CreateNormalized(email, phone, "");

            string url = ConfigurationManager.AppSettings["WebRetailAuth:Url"].ToString() + "Solvency/UpdateSolvencyData";
            request.UserName = clientId;
            request.ContactData.Email = clientContactData.Email;
            request.ContactData.MobilePhone = clientContactData.MobilePhone;
            request.ContactData.CountryPhoneCode = clientContactData.CountryDialCode;
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<UpdateSolvencyDataResponsePrxy>(JsonResult);

                if (!response.Result.Successful) { throw new Exception("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
        }
    }
}
