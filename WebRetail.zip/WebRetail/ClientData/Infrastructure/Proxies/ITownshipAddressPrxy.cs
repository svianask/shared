﻿using ClientDataDomain.DTO.Response.TownshipAddress;
using Common.Domain;
using System;
using System.Collections.Generic;


namespace ClientDataProxy
{
    public  interface ITownshipAddressPrxy
    {
        List<TownshipAddressDTO> GetTownshipsByZipCode(String zipCode, out OperationResult result);
    }
}
