using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataDomain.DTO.Response.ClientPersonalData;
using ClientDataDomain.DTO.Response.TownshipAddress;
using ClientDataMessages;
using ClientDataProxy;
using ClientDataProxy.ClientDataMapping;
using ClientInfoApplication;
using ClientInfoDomain.ContactInformationAggregate;
using ClientNotifications.Domain.TemplateAggregate;
using ClientNotificationsProxy;
using Common.Domain;
using CRMSalesForceApplication;
using CRMSalesForceMessages;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Threading;
using Common.Proxy;
using System.Linq;
using ClientDataDomain.ClientDataAddressAggregate;
using System.Configuration;

namespace ClientDataApplication
{
    public class ClientDataApp : IClientDataApp
    {
        delegate List<TownshipAddressDTO> delGetTownshipsByZipCode(string zipCode, out OperationResult result);
        /*Delegates for update SIIF and FiscalDataStore*/
        delegate void delUpdtClientFiscalDataSIIF(ClientFiscalData clientFiscalData, out OperationResult result);
        delegate void delUpdtClientFiscalDataStore(ClientFiscalData clientFiscalData, out OperationResult result);

        /*Delegates for get information from SIIF and FiscalDataStore*/
        delegate ClientDataInformation delGetClientDataInfo(string rfc, out OperationResult result);
        delegate ClientFiscalData delGetClientFiscalDataSIIF(string clientId, out OperationResult result);
        delegate ClientFiscalData delGetClientFiscalDataStore(string clientId, out OperationResult result);
        /*Delegates for get information from SIIF and Global*/
        delegate ClientBehaviorData delGetClientBehaviorData(string rfc, out OperationResult result);
        delegate ClientContactData delGetClientContactData(string rfc, out OperationResult result);

        //http:///localhost/WebRetailAuthentication/api/Solvency/GetContactData

        private readonly ISeriLogHelper _log;
        private readonly ITownshipAddressPrxy _townshipAddressProxy;
        private readonly IClientFiscalDataPrxy _clientFiscalDataProxy;
        private readonly IClientNotificationsPrxy _clientNotificationsPrxy;
        private readonly IRetailServiceProxy _retailServicePrxy;
        private readonly IClientDataRetailExtPrxy _retailExtendedPrxy;
        private readonly IClientDataWebRetailAuthPrxy _clientDataWebRetailAuthPrxy;
        private readonly IParametersPrxy _parametersPrxy;
        private readonly IParametersProxy _businessParametersPrxy;
        private readonly IClientInfoApp _client;
        private readonly ICRMSalesforceApp _crmSalesForceApp;



        public ClientDataApp(ISeriLogHelper log,
                ITownshipAddressPrxy townshipAddressProxy,
                IClientFiscalDataPrxy clientFiscalDataProxy,
                IClientNotificationsPrxy notificationsPrxy,
                IRetailServiceProxy retailServicePrxy,
                IParametersPrxy parametersPrxy,
                IClientDataRetailExtPrxy retailExtendedPrxy,
                IClientDataWebRetailAuthPrxy clientDataWebRetailAuthPrxy,
                IClientInfoApp client,
                ICRMSalesforceApp crmSalesForceApp,
                IParametersProxy businessParametersPrxy

            )
        {

            _log = log;
            _townshipAddressProxy = townshipAddressProxy;
            _clientFiscalDataProxy = clientFiscalDataProxy;
            _clientNotificationsPrxy = notificationsPrxy;
            _retailServicePrxy = retailServicePrxy;
            _parametersPrxy = parametersPrxy;
            _client = client;
            _crmSalesForceApp = crmSalesForceApp;
            _retailExtendedPrxy = retailExtendedPrxy;
            _clientDataWebRetailAuthPrxy = clientDataWebRetailAuthPrxy;
            _businessParametersPrxy = businessParametersPrxy;
        }

        public List<TownshipAddressDTO> GetTownshipsByZipCode(string zipCode, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            List<TownshipAddressDTO> townships = null;
            _log.Info("Intentando obtener el catálogo Ciudades de la bd");
            try
            {
                _log.Info("Llamando a servicio para obtener Ciudades...");
                delGetTownshipsByZipCode dGetTownshipsByZipCode = _townshipAddressProxy.GetTownshipsByZipCode;
                IAsyncResult rGetTownshipsProfile = dGetTownshipsByZipCode.BeginInvoke(zipCode, out result, null, null);

                _log.Info("Esperando  del catálogo Ciudades");
                while (!rGetTownshipsProfile.IsCompleted) { Thread.Sleep(20); }

                townships = dGetTownshipsByZipCode.EndInvoke(out result, rGetTownshipsProfile);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error obtener el catálogo de Ciudades");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error obtener el catálogo de Ciudades " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            _log.Debug("{cntx}", townships);
            return townships;
        }

        public void UpdateFiscalData(UpdateClientFiscalDataRequest req, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            _log.Info("Starting ClientFiscalData Update {cntx}", req);
            _log.Debug("Parameter UpdateClientFiscalDataRequest: {cntx} ", req);
            string origen = "Cambio en datos fiscales por portal";
            try
            {
                if (req.Channel == "")
                {
                    req.Channel = "Portal";
                }

                ClientFiscalData clientFiscalDataSaved = null;
                delGetClientFiscalDataSIIF dGetClientFiscalDataSIIF = _clientFiscalDataProxy.GetClientFiscalDataSIIF;
                delGetClientFiscalDataStore dGetClientFiscalDataStore = _clientFiscalDataProxy.GetClientFiscalDataStore;

                /*Se obtiene el valor en BD para compararlo con el entrante, comparar cambios  y cargarlo a la entidad para almacenarlo en FiscalDataStore*/
                _log.Info("Obteniendo datos fiscales en FiscalDataStore para el cliente: {cntx}", req.ClientId);
                IAsyncResult rGetClientFiscalDataStore = dGetClientFiscalDataStore.BeginInvoke(req.ClientId, out result, null, null);

                while (!rGetClientFiscalDataStore.IsCompleted) { Thread.Sleep(20); }


                clientFiscalDataSaved = dGetClientFiscalDataStore.EndInvoke(out result, rGetClientFiscalDataStore);
                _log.Debug(string.Concat("[FiscalDataStore] Datos fiscales del cliente ", req.ClientId, ": {cntx}"), clientFiscalDataSaved);

                if (clientFiscalDataSaved == null)
                {
                    _log.Info("Obteniendo datos fiscales en SIIF para el cliente: {cntx}", req.ClientId);
                    IAsyncResult rGetClientFiscalDataSIIF = dGetClientFiscalDataSIIF.BeginInvoke(req.ClientId, out result, null, null);
                    while (!rGetClientFiscalDataSIIF.IsCompleted) { Thread.Sleep(20); }

                    clientFiscalDataSaved = dGetClientFiscalDataSIIF.EndInvoke(out result, rGetClientFiscalDataSIIF);
                    _log.Debug(string.Concat("[SIIF] Datos fiscales del cliente ", req.ClientId, ": {cntx}"), clientFiscalDataSaved);
                }


                delUpdtClientFiscalDataSIIF dUpdateClientFiscalData = _clientFiscalDataProxy.UpdateClientFiscalDataSIIF;
                IAsyncResult rUpdateClientDataSIIF = dUpdateClientFiscalData.BeginInvoke(GetFiscalDataChanged(req, clientFiscalDataSaved, out result), out result, null, null);

                

                delUpdtClientFiscalDataStore dUpdateClientFiscalDataStore = _clientFiscalDataProxy.UpdateClientFiscalDataStore;
                /*Se comparan los datos de SIIF(Si no hay datos en Store) o de Fiscal Store para mandar los no editados a la entidad y actualizarlos completamente en FiscalStore*/
                IAsyncResult rUpdateClientDataStore = dUpdateClientFiscalDataStore.BeginInvoke(GetFiscalDataChanged(req, clientFiscalDataSaved, out result), out result, null, null);

                while (!rUpdateClientDataSIIF.IsCompleted && !rUpdateClientDataStore.IsCompleted) { Thread.Sleep(20); }

                if (result.SystemMessages != null)
                {
                    if (result.SystemMessages.Count > 0)
                    {
                        result.SystemMessages.Add(new SystemMessage() { Message = "ERROR SIIF INTERMEDIA" + result.SystemMessages[0].Message, MessageType = SystemMessageTypes.Error });
                    }
                }

                _log.Info("Starting updating in ");
                dUpdateClientFiscalData.EndInvoke(out result, rUpdateClientDataSIIF);
                dUpdateClientFiscalDataStore.EndInvoke(out result, rUpdateClientDataStore);
                _log.Info("End updating ");

                OperationResult resultCRM = new OperationResult() { Successful = true };
                FiscalAddress fAddressSaved = clientFiscalDataSaved.FiscalAddress;
                Dictionary<String, String> fields = new Dictionary<String, String>() {
                        { "Nombre", req.Names},
                        { "Apellido Paterno", req.PaternalSurname},
                        { "Apellido Materno", req.MaternalSurname},
                        { "Vialidad", req.RoadName},
                        { "Tipo de Vialidad", req.RoadNameType},
                        { "Número Interior", req.InnerNumber},
                        { "Número Exterior", req.OuterNumber},
                        { "Localidad", req.Location},
                        { "Entre Calle", req.BetweenStreet},
                        { "CURP", req.Curp },
                        { "Código Postal", !fAddressSaved.ZipCode.Equals(req.ZipCode)? req.ZipCode:"" },
                        { "Calle", req.RoadName},
                        { "Estado",  !fAddressSaved.Township.State.Name.Equals(req.StateName)?req.StateName:""},
                        { "Ciudad", !fAddressSaved.Township.City.Name.Equals(req.CityName)?req.CityName:""},
                        { "Asentamiento", !fAddressSaved.Township.TownshipName.Equals(req.TownshipName)?req.TownshipName:""}
                    };

                if (result.Successful)
                {
                    _log.Info($"Enviando Correo de Confirmación de Actualización de datos del cliente: {req.ClientId} ");
                    ExecuteSendMail(req.ClientId, fields, false, out resultCRM);
                    _log.Info($"Creando Caso SalesForce de cliente: {req.ClientId}");

                    ExecuteCreateSalesForceCase(req.ClientId, fields, req.Channel, req.URLDocument,origen, out resultCRM);
                }
                if (!resultCRM.Successful)
                {
                    _log.Info($"Falló el envío a SalesForce para la actualización de la información, {req.ClientId}");
                    ExecuteSendMail(req.ClientId, fields, true, out resultCRM);

                    if (resultCRM.SystemMessages != null)
                    {
                        if (resultCRM.SystemMessages.Count > 0)
                        {
                            result.SystemMessages.Add(new SystemMessage() { Message = "ERROR SALESFORCE: " + resultCRM.SystemMessages[0].Message, MessageType = SystemMessageTypes.Error });
                        }
                    }
                }

                result.SystemMessages.AddRange(resultCRM.SystemMessages);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "An error ocurred to update FiscalData");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error to update FiscalData in  UpdateFiscal (WebRetailService) " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

        }

        public ClientPersonalDataDTO GetClientPersonalData(String clientId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            ClientPersonalDataDTO clientPersonalDataDTO = null;
            ClientFiscalData clientFiscalData = null;
            ClientBehaviorData clientBehaviorData = null;
            ClientContactData clientContactData = null;

            ClientDataInformation clientInfo = ClientDataInformation.Create(clientId);
            try
            {
                delGetClientFiscalDataSIIF dGetClientFiscalDataSIIF = _clientFiscalDataProxy.GetClientFiscalDataSIIF;
                delGetClientFiscalDataStore dGetClientFiscalDataStore = _clientFiscalDataProxy.GetClientFiscalDataStore;
                delGetClientBehaviorData dGetClientBehaviorData = _retailExtendedPrxy.GetClientBehaviorData;
                delGetClientContactData dGetClientContactData = _clientDataWebRetailAuthPrxy.GetContactData;
                delGetTownshipsByZipCode dGetTownshipsByZipCode = _townshipAddressProxy.GetTownshipsByZipCode;

                _log.Info("Obteniendo datos fiscales en FiscalDataStore para el cliente: {cntx}", clientId);
                IAsyncResult rGetClientFiscalDataStore = dGetClientFiscalDataStore.BeginInvoke(clientId, out result, null, null);

                while (!rGetClientFiscalDataStore.IsCompleted) { Thread.Sleep(20); }

                clientFiscalData = dGetClientFiscalDataStore.EndInvoke(out result, rGetClientFiscalDataStore);
                _log.Debug(string.Concat("[FiscalDataStore] Datos fiscales del cliente ", clientId, ": {cntx}"), clientFiscalData);

                if (clientFiscalData == null)
                {
                    _log.Info("Obteniendo datos fiscales en SIIF para el cliente: {cntx}", clientId);
                    IAsyncResult rGetClientFiscalDataSIIF = dGetClientFiscalDataSIIF.BeginInvoke(clientId, out result, null, null);

                    while (!rGetClientFiscalDataSIIF.IsCompleted) { Thread.Sleep(20); }
                    clientFiscalData = dGetClientFiscalDataSIIF.EndInvoke(out result, rGetClientFiscalDataSIIF);
                    _log.Debug(string.Concat("[SIIF] Datos fiscales del cliente ", clientId, ": {cntx}"), clientFiscalData);
                }

                String zipCode = clientFiscalData.FiscalAddress.ZipCode;
                List<TownshipAddressDTO> townships = null;
                _log.Info("Llamando al catálogo de ciudades por CP {cntx}:", zipCode);
                IAsyncResult rGetTownshipsProfile = dGetTownshipsByZipCode.BeginInvoke(clientFiscalData.FiscalAddress.ZipCode, out result, null, null);
                _log.Info("Esperando  el catálogo Ciudades por CP {cntx}: ", zipCode);
                while (!rGetTownshipsProfile.IsCompleted) { Thread.Sleep(20); }
                townships = dGetTownshipsByZipCode.EndInvoke(out result, rGetTownshipsProfile);
                _log.Debug("Lista de ciudades obtenidas por {cntx}", townships);
                if (townships != null && townships.Count > 0)
                {
                    clientFiscalData.SetStateName(townships.First().State.Name);
                }


                _log.Info("Obteniendo datos de compportamiento para el cliente: {cntx}", clientId);
                IAsyncResult asyncResultClientBehaviorData = dGetClientBehaviorData.BeginInvoke(clientId, out result, null, null);

                _log.Info("Obteniendo datos de Contacto para el cliente: {cntx}", clientId);
                IAsyncResult asyncResultClientContactData = dGetClientContactData.BeginInvoke(clientId, out result, null, null);

                while (!asyncResultClientBehaviorData.IsCompleted && !asyncResultClientContactData.IsCompleted) { Thread.Sleep(20); }

                clientBehaviorData = dGetClientBehaviorData.EndInvoke(out result, asyncResultClientBehaviorData);
                _log.Debug(string.Concat("Datos de comportamiento del cliente ", clientId, ": {cntx}"), clientBehaviorData);

                clientContactData = dGetClientContactData.EndInvoke(out result, asyncResultClientContactData);
                _log.Debug(string.Concat("Datos de contacto del cliente ", clientId, ": {cntx}"), clientContactData);

                clientInfo.SetClientBehaviorData(clientBehaviorData);
                clientInfo.SetClientContactData(clientContactData);
                clientInfo.SetClientFiscalData(clientFiscalData);

                var lstDateTimes = new List<DateTime> { clientBehaviorData.LastUpdateDate, clientContactData.LastUpdateDate, clientFiscalData.LastUpdateDate };
                _log.Info("Determinando fecha de última actualización: {cntx}", lstDateTimes);
                clientInfo.SetLastUpdate(lstDateTimes);
                _log.Debug("fecha de última actualización: {cntx}", new { clientInfo.LastUpdateDate });

                clientPersonalDataDTO = ClientPersonalDataMapp.Mapp(clientInfo);
                _log.Debug("DTO ClientPersonalData: {cntx}", clientPersonalDataDTO);
                clientPersonalDataDTO.CountFiscalMissing += (townships != null && townships.Count > 0) ? 0 : 1;

            }
            catch (Exception ex)
            {
                var errMsg = $"Error al obtener la información del perfil del cliente: {clientId}";
                _log.Error(ex, errMsg);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = $"{errMsg} - {ex.Message}" + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return clientPersonalDataDTO;
        }

        private ClientFiscalData GetFiscalDataChanged(UpdateClientFiscalDataRequest req, ClientFiscalData fiscalData, out OperationResult result)
        {
            _log.Info("Ejecutando GetFiscalDataChanged...");
            result = new OperationResult() { Successful = true };


            PersonalFiscalData personalData = PersonalFiscalData.Create(fiscalData.PersonalFiscalData.RFC, fiscalData.PersonalFiscalData.CURP, fiscalData.PersonalFiscalData.Names,
                fiscalData.PersonalFiscalData.PaternalSurname, fiscalData.PersonalFiscalData.MaternalSurname, fiscalData.PersonalFiscalData.RoadName, fiscalData.PersonalFiscalData.RoadNameType,
                fiscalData.PersonalFiscalData.InnerNumber, fiscalData.PersonalFiscalData.OuterNumber, fiscalData.PersonalFiscalData.Location, fiscalData.PersonalFiscalData.BetweenStreet);

            ClientFiscalData fiscalDataTmp = ClientFiscalData.CreateEntry(fiscalData.ClientId, fiscalData.PersonalFiscalData, fiscalData.FiscalAddress, fiscalData.LastUpdateDate, (string.IsNullOrEmpty(req.Channel)) ? fiscalData.Channel : req.Channel);

            if (!String.IsNullOrEmpty(req.Curp) && !req.Curp.ToUpper().Equals(fiscalData.PersonalFiscalData.CURP))
            {
                fiscalDataTmp.PersonalFiscalData.SetCurp(req.Curp);
            }

            if (!String.IsNullOrEmpty(req.Names) && !req.Names.ToUpper().Equals(fiscalData.PersonalFiscalData.Names))
            {
                fiscalDataTmp.PersonalFiscalData.SetNames(req.Names);
            }

            if (!String.IsNullOrEmpty(req.PaternalSurname) && !req.PaternalSurname.ToUpper().Equals(fiscalData.PersonalFiscalData.PaternalSurname))
            {
                fiscalDataTmp.PersonalFiscalData.SetLastName(req.PaternalSurname);
            }

            fiscalDataTmp.PersonalFiscalData.SetSurname(req.MaternalSurname);

            if (!String.IsNullOrEmpty(req.RoadName) && !req.RoadName.ToUpper().Equals(fiscalData.PersonalFiscalData.RoadName))
            {
                fiscalDataTmp.PersonalFiscalData.SetRoadName(req.RoadName);
            }

            if (!String.IsNullOrEmpty(req.RoadNameType) && !req.RoadNameType.ToUpper().Equals(fiscalData.PersonalFiscalData.RoadNameType))
            {
                fiscalDataTmp.PersonalFiscalData.SetRoadNameType(req.RoadNameType);
            }

            if (!String.IsNullOrEmpty(req.InnerNumber) && !req.InnerNumber.ToUpper().Equals(fiscalData.PersonalFiscalData.InnerNumber))
            {
                fiscalDataTmp.PersonalFiscalData.SetInnerNumber(req.InnerNumber);
            }

            if (!String.IsNullOrEmpty(req.OuterNumber) && !req.OuterNumber.ToUpper().Equals(fiscalData.PersonalFiscalData.OuterNumber))
            {
                fiscalDataTmp.PersonalFiscalData.SetOuterNumber(req.OuterNumber);
            }

            if (!String.IsNullOrEmpty(req.Location) && !req.Location.ToUpper().Equals(fiscalData.PersonalFiscalData.Location))
            {
                fiscalDataTmp.PersonalFiscalData.SetLocation(req.Location);
            }

            if (!String.IsNullOrEmpty(req.BetweenStreet) && !req.BetweenStreet.ToUpper().Equals(fiscalData.PersonalFiscalData.BetweenStreet))
            {
                fiscalDataTmp.PersonalFiscalData.SetBetweenStreet(req.BetweenStreet);
            }


            delGetTownshipsByZipCode dGetTownshipsByZipCode = _townshipAddressProxy.GetTownshipsByZipCode;
            List<TownshipAddressDTO> townships = null;
            bool IsValidZipCode = true;
            if (!String.IsNullOrEmpty(req.ZipCode))
            {
                _log.Info("Llamando al catálogo de ciudades por CP {cntx}:", req.ZipCode);
                IAsyncResult rGetTownshipsProfile = dGetTownshipsByZipCode.BeginInvoke(req.ZipCode, out result, null, null);
                _log.Info("Esperando  el catálogo Ciudades por CP {cntx}: ", req.ZipCode);
                while (!rGetTownshipsProfile.IsCompleted) { Thread.Sleep(20); }
                townships = dGetTownshipsByZipCode.EndInvoke(out result, rGetTownshipsProfile);
                _log.Debug("Lista de ciudades obtenidas por {cntx}", townships);
                IsValidZipCode = !(townships == null || (townships != null && townships.Count < 1));
            }


            if (!String.IsNullOrEmpty(req.ZipCode) && !IsValidZipCode)
            {
                throw new Exception("Código postal no dado de alta en sistema.");
            }

            if (!String.IsNullOrEmpty(req.ZipCode)
                    && (!req.ZipCode.Equals(fiscalData.FiscalAddress.ZipCode)
                        || req.TownshipId != fiscalData.FiscalAddress.Township.Id
                        || !req.RoadName.Equals(req.RoadName)
                    ))
            {

                fiscalDataTmp.SetAddress(ClientFiscalDataMapp.Mapp(req).FiscalAddress, req.Channel);
            }
            fiscalDataTmp.SetClientId(req.ClientId);

            return fiscalDataTmp;
        }
        private void SendMailUpdatedFields(String clientFullName, String subject, List<String> mails, String changedFields, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo el template");
                String template = _businessParametersPrxy.GetBinaryParameter("MIPUPDTMPL", "", "", "Retail", "Standar", out result);
                _log.Debug("Template obtenido: {cntx}", template);
                Template templateInfo = new Template("MIPUPDTMPL", template);
                PrxySenderData senderData = _parametersPrxy.GetSenderData(out result);
                List<string> toEmails = mails;
                Dictionary<String, String> paramsTmpl = new Dictionary<string, string>
                                                            {
                                                                { "Not_Nombre", $"{clientFullName}"},
                                                                { "Not_Campo", $"{changedFields}" },
                                                                { "Not_Transaccion_Fecha", DateTime.Now.ToShortDateString() }
                                                            };
                List<AttachmentFile> attachments = null;
                string encodedTemplate = templateInfo.EncodedTemplate;
                if (string.IsNullOrEmpty(encodedTemplate))
                {
                    throw new Exception($"No se ha encontrado plantilla la actualización de datos.");
                }

                _log.Info("Enviando notificación");
                _log.Debug("Subject: {subject} - SenderData :{senderData}- toEmails: {toEmails} - ParamsTmpl: {paramsTmpl}", subject, senderData, toEmails, paramsTmpl);
                _log.Debug("Template: {cntx} ", encodedTemplate);
                _clientNotificationsPrxy.SendNotification(subject, senderData, toEmails, null, paramsTmpl, encodedTemplate, attachments, out result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al enviar el correo de actualización de datos");
                result.Successful = true; // Se forza para no generar excepción hacía el front
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al enviar el correo de actualización de datos " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
        }

        private void ExecuteSendMail(String clientId, Dictionary<String, String> fields, bool errorUpdate, out OperationResult result)
        {
            ContactInformation clientInfo = _client.GetContactInformationByClientId(clientId, out result);
            String fullName = $"{clientInfo.Name} {clientInfo.LastName} {clientInfo.SecondLastName}";
            List<String> mails = new List<String>() { clientInfo.Email };
            String fieldsUpdated = "";
            int countFields = 1;
            foreach (KeyValuePair<String, String> entry in fields)
            {
                String row = String.Empty;
                if (!String.IsNullOrEmpty(entry.Value))
                {
                    row += $"<br />{entry.Key}: <b>{entry.Value}{((countFields < fields.Count) ? "</b><br /> " : "")}";
                    fieldsUpdated += row;

                }
                countFields++;

            }

            String subject = $"Notificación de actualización de datos personales y/o fiscales";
            if (errorUpdate)
            {
                String mailSupportIT = ConfigurationManager.AppSettings["CRMITSupportMail"].ToString();
                String mailSupportITBK = ConfigurationManager.AppSettings["CRMITSupportMailBK"].ToString();
                mails = new List<string> { mailSupportIT, mailSupportITBK };
                subject = $"Error al guardar datos Mi Perfil en el CRM del cliente {clientId}";
            }

            if (!String.IsNullOrEmpty(fieldsUpdated))
            {
                this.SendMailUpdatedFields(fullName, subject, mails, fieldsUpdated, out result);
            }
        }

        private void ExecuteCreateSalesForceCase(String clientId, Dictionary<String, String> fields, string canal, string UrlDoc,string origen, out OperationResult result)
        {
            result = new OperationResult();
            var ClientContracts = _retailServicePrxy.GetContracts(clientId, out result);
            string dataInformation = "[";
            //Se extraen los campos y los valores del diccionario
            foreach (KeyValuePair<String, String> entry in fields)
            {
                String dataRow = String.Empty;
                if (!String.IsNullOrEmpty(entry.Value))
                {
                    dataRow = $"{entry.Key}: {entry.Value} | ";
                }
                dataInformation += dataRow;
            }
            dataInformation += "]";

            // Se recorren los contratos para generar un caso por contrato
            foreach (var contrato in ClientContracts.Contracts)
            {
                var TempResult = new OperationResult();
                var request = new CRMSalesForceCreateCaseUpdateDataClientRequest()
                {
                    ContractId = contrato.Id,
                    PlatformId = contrato.Platform,
                    RFC = clientId,
                    DataPayload = dataInformation,
                    UrlDoc = (string.IsNullOrEmpty(UrlDoc) ? string.Empty : UrlDoc),
                    origen = origen
                };
                // Solicitar la creacion del caso

                _crmSalesForceApp.CreateCases(request, canal, out TempResult);
                result.SystemMessages.AddRange(TempResult.SystemMessages);
                result.Successful = TempResult.Successful;
            }
        }

        public void UpdateClientContactData(string clientId, string email, string phone, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            string origen = "Cambio en datos de contacto por portal";

            try
            {
                _log.Info("Actualizando los datos de contacto en SecurityGlobalApp para el cliente: {cntx}", clientId);
                _clientDataWebRetailAuthPrxy.UpdateClientContactData(clientId, email, phone, out result);
                _log.Debug("Actualización exitosa en SecurityGlobalApp para el cliente: {cntx}", clientId);

                _log.Info("Actualizando los datos de contacto en SIIF para el cliente: {cntx}", clientId);
                _retailServicePrxy.UpdateClientContactData(clientId, email, phone, out result);
                _log.Debug("Actualización exitosa en SIIF para el cliente: {cntx}", clientId);

                OperationResult resultCRM = new OperationResult() { Successful = true };
                Dictionary<String, String> fields = new Dictionary<String, String>() { { "Correo", email }, { "Teléfono", phone } };

                if (result.Successful)
                {
                    _log.Info($"Enviando Correo de Confirmación de Actualización de datos del cliente: {clientId} ");
                    ExecuteSendMail(clientId, fields, false, out resultCRM);
                    _log.Info($"Creando Caso SalesForce de cliente: {clientId}");
                    ExecuteCreateSalesForceCase(clientId, fields, string.Empty, string.Empty,origen, out resultCRM);

                }
                if (!resultCRM.Successful)
                {
                    _log.Info($"Falló el envío a SalesForce para la actualización de la información, {clientId}");
                    ExecuteSendMail(clientId, fields, true, out resultCRM);
                }
            }
            catch (Exception ex)
            {
                var errMsg = $"Error al actualizar los datos de contacto para el cliente: {clientId}";
                _log.Error(ex, errMsg);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = $"{errMsg} - {ex.Message}", MessageType = SystemMessageTypes.Error });
            }
        }

        public void UpdateClientBehaviorData(string clientId, string motivation, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            string origen = "Cambio en datos fiscales";

            try
            {
                _log.Info("Actualizando los datos de comportamiento para el cliente: {cntx}", clientId);
                _retailExtendedPrxy.UpdateClientBehaviorData(clientId, motivation, out result);
                _log.Debug("Datos de comportamiento actualizados para el cliente: {cntx}", clientId);

                OperationResult resultCRM = new OperationResult() { Successful = true };
                Dictionary<String, String> fields = new Dictionary<string, string>() { { "Motivación", motivation } };
                if (result.Successful)
                {
                    _log.Info($"Enviando Correo de Confirmación de Actualización de datos del cliente: {clientId} ");
                    ExecuteSendMail(clientId, fields, false, out resultCRM);
                    _log.Info($"Creando Caso SalesForce de cliente: {clientId}");
                    ExecuteCreateSalesForceCase(clientId, fields, string.Empty, string.Empty, origen, out resultCRM);
                }

                if (!resultCRM.Successful)
                {
                    _log.Info($"Falló el envío a SalesForce para la actualización de la información, {clientId}");
                    ExecuteSendMail(clientId, fields, true, out resultCRM);
                }

            }
            catch (Exception ex)
            {
                var errMsg = $"Error al actualizar los datos de comportamiento para el cliente: {clientId}";
                _log.Error(ex, errMsg);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = $"{errMsg} - {ex.Message}", MessageType = SystemMessageTypes.Error });
            }

        }
    }
}
