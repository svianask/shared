using ClientDataDomain.ClientDataAddressAggregate;
using ClientDataDomain.ClientDataInformationAggregate;
using ClientDataDomain.DTO.Response.ClientFiscalData;
using ClientDataDomain.DTO.Response.ClientPersonalData;
using ClientDataDomain.DTO.Response.TownshipAddress;
using ClientDataMessages;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientDataApplication
{
    public interface IClientDataApp
     {
        List<TownshipAddressDTO> GetTownshipsByZipCode(string zipCode, out OperationResult result);
        void UpdateFiscalData( UpdateClientFiscalDataRequest req, out OperationResult result);
        ClientPersonalDataDTO GetClientPersonalData(String rfc, out OperationResult result);
        void UpdateClientContactData(string clientId, string email, string phone, out OperationResult result);
        void UpdateClientBehaviorData(string clientId, string motivation, out OperationResult result);
    }
}
