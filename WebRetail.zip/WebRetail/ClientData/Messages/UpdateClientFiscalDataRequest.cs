﻿using System;

namespace ClientDataMessages
{
    public class UpdateClientFiscalDataRequest
    {
        public string Curp = String.Empty;
        public string Names = String.Empty;
        public string PaternalSurname = String.Empty;
        public string MaternalSurname = String.Empty;
        public string RoadName = String.Empty;
        public string RoadNameType = String.Empty;
        public string InnerNumber = String.Empty;
        public string OuterNumber = String.Empty;
        public string Location = String.Empty;
        public string BetweenStreet = String.Empty;
        public string ZipCode = String.Empty;
        public string StateName = String.Empty;
        public int? StateId = null;
        public string CityName = String.Empty;
        public int? CityId = null;
        public string TownshipName = String.Empty;
        public int? TownshipId = null;
        public string ClientId = String.Empty;
        public string Channel = String.Empty;
        public string URLDocument = String.Empty;
    }
}
