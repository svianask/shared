﻿using System;

namespace ClientDataMessages
{
    public class GetTownshipRequest
    {
        public string ZipCode = String.Empty;
    }
}
