﻿namespace ClientDataMessages
{
    public class UpdateClientContactDataRequest
    {
        public string ClientId;
        public string Email;
        public string Phone;
    }
}
