﻿using ClientDataDomain.DTO.Response.TownshipAddress;
using Common.Domain;
using System.Collections.Generic;

namespace ClientDataMessages
{
    public class GetTownshipResponse
    {
        public List<TownshipAddressDTO> Townships;
        public OperationResult Result;
    }
}
