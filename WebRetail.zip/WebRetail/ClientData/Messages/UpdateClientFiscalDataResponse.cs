﻿using Common.Domain;

namespace ClientDataMessages
{
    public class UpdateClientFiscalDataResponse
    {
        public UpdateClientFiscalDataResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result;
    }
}
