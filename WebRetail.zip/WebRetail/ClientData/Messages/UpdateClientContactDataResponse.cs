﻿using Common.Domain;

namespace ClientDataMessages
{
    public class UpdateClientContactDataResponse
    {
        public OperationResult Result;
    }
}
