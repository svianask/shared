﻿using ClientDataDomain.DTO.Response.ClientPersonalData;
using Common.Domain;


namespace ClientDataMessages
{
    public class GetClientPersonalDataResponse
    {
        public GetClientPersonalDataResponse()
        {
            Result = new OperationResult();
        }
        public ClientPersonalDataDTO Data;
        public OperationResult Result;
    }
}
