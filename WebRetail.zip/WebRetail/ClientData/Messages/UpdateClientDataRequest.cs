﻿namespace ClientDataMessages
{
    public class UpdateClientDataRequest
    {

    }
}
