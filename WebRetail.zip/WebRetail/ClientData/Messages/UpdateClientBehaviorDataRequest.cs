﻿namespace ClientDataMessages
{
    public class UpdateClientBehaviorDataRequest
    {
        public string ClientId;
        public string Motivation;
    }
}
