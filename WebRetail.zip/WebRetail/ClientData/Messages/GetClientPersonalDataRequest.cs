﻿using System;

namespace ClientDataMessages
{
    public class GetClientPersonalDataRequest
    {
        public string ClientId { get; set; } = String.Empty;
    }
}
