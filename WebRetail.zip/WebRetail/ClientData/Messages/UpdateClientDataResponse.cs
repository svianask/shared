﻿using Common.Domain;

namespace ClientDataMessages
{
    public class UpdateClientDataResponse
    {
        public UpdateClientDataResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result;
    }
}
