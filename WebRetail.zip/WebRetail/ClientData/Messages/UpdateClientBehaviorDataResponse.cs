﻿using Common.Domain;

namespace ClientDataMessages
{
    public class UpdateClientBehaviorDataResponse
    {
        public OperationResult Result;
    }
}
