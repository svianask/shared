﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ClientDataDomain.ClientDataAddressAggregate
{
    public class StateAddress:Entity<int>
    {
        private StateAddress(int Id, String Name)
        {
            this.Id = Id;
            this.Name = Name;
        }

        public static StateAddress Create(int Id, String Name)
        {
            return new StateAddress(Id, Name);
        }

        public static StateAddress Create(int? Id, String Name) {
            var index = Id == null ? 0 : Convert.ToInt32(Id);
            return new StateAddress( index, Name);
        }


        public static StateAddress CreateEmpty( String Name)
        {
            return new StateAddress(0, Name);
        }

        public  string Name ;

    }
}
