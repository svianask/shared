﻿using Ddd;
using System;

namespace ClientDataDomain.ClientDataAddressAggregate
{
    public class CityAddress:Entity<int>
    {
        private CityAddress(int Id, string Name) { 
            this.Id = Id;
            this.Name = Name;
        }
        public static CityAddress Create(int Id, string Name)
        {
            return new CityAddress(Id, Name);
        }

        public static CityAddress Create(int? Id, string Name)
        {
            var index = Id  == null ? 0 : Convert.ToInt32( Id);
            return new CityAddress(index, Name);
        }

        public static CityAddress CreateEmpty(string Name) {
            return new CityAddress(0, Name);   
        }

        public  string Name = string.Empty;

    }
}
