﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ClientDataDomain.ClientDataAddressAggregate
{
    public class TownshipAddress:Entity<int>
    {
        private TownshipAddress() { }
        private TownshipAddress(int Id, String TownshipName, StateAddress State, CityAddress City) { 
            this.Id = Id;
            this.TownshipName = TownshipName;
            this.State = State;
            this.City = City;
        }
        
        public static TownshipAddress Create(int Id, String TownshipName, StateAddress State, CityAddress City)
        {
            return new TownshipAddress(Id, TownshipName, State, City);
        }

        public static TownshipAddress Create( int? Id, String TownshipName, StateAddress State, CityAddress City)
        {
            var index = Id == null ? 0 : Convert.ToInt32(Id);
            return new TownshipAddress(index, TownshipName, State, City);
        }

        public static TownshipAddress CreateEmpty(String TownshipName, StateAddress State, CityAddress City)
        {
            return new TownshipAddress(0, TownshipName, State, City);
        }

        public string TownshipName;
        public StateAddress State;
        public CityAddress City;

    }
}


