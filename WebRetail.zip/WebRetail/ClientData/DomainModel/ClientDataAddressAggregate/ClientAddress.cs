﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientDataDomain.ClientDataAddressAggregate
{
    public class FiscalAddress : ValueObject<FiscalAddress>
    {
        private readonly string _zipCode = String.Empty;
        private readonly TownshipAddress _township = null;
        public String ZipCode { get => _zipCode; }
        public TownshipAddress Township => _township;

        private FiscalAddress(String zipCode, TownshipAddress township ) {
            _zipCode = zipCode;
            _township = township;
        }

        public static FiscalAddress Create(String zipCode,TownshipAddress township) { 
            return new FiscalAddress(zipCode, township);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ZipCode,
                Township
            };
        }
    }
}
