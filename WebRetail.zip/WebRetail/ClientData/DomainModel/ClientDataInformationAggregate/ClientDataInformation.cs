﻿using ClientDataDomain.ClientDataAddressAggregate;
using Ddd;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ClientDataDomain.ClientDataInformationAggregate
{
    public class ClientDataInformation : Entity<string>
    {

        private ClientBehaviorData _clientBehaviorData;
        private ClientContactData _clientContactData;
        private ClientFiscalData _clientFiscalData;
        private DateTime _lastUpdateDate;



        public ClientBehaviorData ClientBehaviorData { get => _clientBehaviorData; }
        public ClientContactData ClientContactData { get => _clientContactData; }
        public ClientFiscalData ClientFiscalData { get => _clientFiscalData; }
        public DateTime LastUpdateDate { get => _lastUpdateDate; }

        private ClientDataInformation(String clientId)
        {
            Id = clientId;
        }

        public static ClientDataInformation Create(String clientId)
        {
            return new ClientDataInformation(clientId);
        }

        public ClientDataInformation SetClientBehaviorData(ClientBehaviorData clientBehaviorData)
        {
            _clientBehaviorData = clientBehaviorData;
            return this;
        }

        public ClientDataInformation SetClientContactData(ClientContactData clientContactData)
        {
            _clientContactData = clientContactData;
            return this;
        }

        public ClientDataInformation SetClientFiscalData( ClientFiscalData clientFiscalData)
        {
            _clientFiscalData = clientFiscalData;
            return this;
        }

        /*public void SetMail(String mail)
        {
            string pattern = @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$";
            Regex regexMail = new Regex(pattern);

            if (String.IsNullOrEmpty(mail)) { throw new ArgumentException("No se permiten valores nulos o vacíos."); }
            if (!regexMail.IsMatch(mail)) { throw new ArgumentException("El valor recibido no corresponde con un correo electrónico."); }
            if (mail.Length > 50) { throw new ArgumentException("El correo electrónico no debe tener más de 50 carácteres de longitud."); }
        }

        public void SetPhone(String phone)
        {
            string pattern = @"^([0-9]{10})$";
            Regex regexPhone = new Regex(pattern);

            if (String.IsNullOrEmpty(phone)) { throw new ArgumentException("No se permiten valores nulos o vacíos."); }
            if (!regexPhone.IsMatch(phone)) { throw new ArgumentException("El valor recibido no corresponde a un teléfono."); }
            if (phone.Length > 10) { throw new ArgumentException("El teléfono no debe tener más de 10 carácteres de longitud."); }
        }*/

        public void SetLastUpdate(List<DateTime> dateTimes)
        {
            DateTime maxLastUpdate = dateTimes[0];

            for (int idxTime = 1; idxTime < dateTimes.Count; idxTime++)
            {
                if (dateTimes[idxTime] > maxLastUpdate) { maxLastUpdate = dateTimes[idxTime]; }
            }

            _lastUpdateDate = maxLastUpdate;
        }
    }
}
