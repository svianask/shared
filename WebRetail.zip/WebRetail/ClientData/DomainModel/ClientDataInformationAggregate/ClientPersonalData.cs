﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text.RegularExpressions;

namespace ClientDataDomain.ClientDataInformationAggregate
{
    public class PersonalFiscalData : ValueObject<PersonalFiscalData>
    {
        private  string _rfc = String.Empty;
        private  string _curp = String.Empty;
        private  string _names = String.Empty;
        private  string _paternalSurname = String.Empty;
        private  string _maternalSurname = String.Empty;
        private  string _roadName = String.Empty;
        private  string _roadNameType = String.Empty;
        private  string _innerNumber;
        private  string _outerNumber;
        private  string _location = String.Empty;
        private  string _betweenStreet = String.Empty;

        public String CURP { get => _curp; }
        public String RFC { get => _rfc; }
        public String Names { get => _names; }
        public String PaternalSurname { get => _paternalSurname; }
        public String MaternalSurname { get => _maternalSurname; }
        public String RoadName { get => _roadName; }
        public String RoadNameType { get => _roadNameType; }
        public String InnerNumber { get => _innerNumber; }
        public String OuterNumber { get => _outerNumber; }
        public String Location { get => _location; }
        public String BetweenStreet { get => _betweenStreet; }

        private PersonalFiscalData(string rfc, string curp, string names, string paternalSurname, string maternalSurname, string roadName, string roadNameType, string innerNumber, string outerNumber, string location, string betweenStreet)
        {
            _rfc = rfc;
            _curp = curp;
            _names = names;
            _paternalSurname = paternalSurname;
            _maternalSurname = maternalSurname;
            _roadName = roadName;
            _roadNameType = roadNameType;
            _innerNumber = innerNumber;
            _outerNumber = outerNumber;
            _location = location;
            _betweenStreet = betweenStreet;

        }

        public static PersonalFiscalData Create(string rfc, string curp, string names, string paternalSurname, string maternalSurname, string roadName, string roadNameType, string innerNumber, string outerNumber, string location, string betweenStreet)
        {
            curp = String.IsNullOrEmpty(curp) ? "" : curp;
            names = String.IsNullOrEmpty(names) ? "" : names;
            paternalSurname = String.IsNullOrEmpty(paternalSurname) ? "" : paternalSurname;
            maternalSurname = String.IsNullOrEmpty(maternalSurname) ? "" : maternalSurname;
            roadName = String.IsNullOrEmpty(roadName) ? "" : roadName;
            roadNameType = String.IsNullOrEmpty(roadNameType) ? "" : roadNameType;
            innerNumber = String.IsNullOrEmpty(innerNumber) ? "" : innerNumber;
            outerNumber = String.IsNullOrEmpty(outerNumber) ? "" : outerNumber;
            location = String.IsNullOrEmpty(location) ? "" : location;
            betweenStreet = String.IsNullOrEmpty(betweenStreet) ? "" : betweenStreet;

            return new PersonalFiscalData(rfc, curp, names, paternalSurname, maternalSurname, roadName, roadNameType, innerNumber, outerNumber, location, betweenStreet);
        }

        public PersonalFiscalData SetRfc(String rfc)
        {
            string pattern = @"^[A-Z&Ñ]{3,4}[0-9]{2}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[A-Z0-9]{2}[0-9A]$";
            Regex regexRfc = new Regex(pattern);
            if (!String.IsNullOrEmpty(rfc) && !regexRfc.IsMatch(rfc)) { throw new ArgumentException("El RFC ingresado no es válido."); }
            this._rfc = rfc;
            return this;
        }


        public PersonalFiscalData SetCurp(String curp)
        {
            string pattern = @"^([A-Z][AEIOUX][A-Z]{2}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[HM](?:AS|B[CS]|C[CLMSH]|D[FG]|G[TR]|HG|JC|M[CNS]|N[ETL]|OC|PL|Q[TR]|S[PLR]|T[CSL]|VZ|YN|ZS)[B-DF-HJ-NP-TV-Z]{3}[A-Z\d])(\d)$";
            Regex regexCurp = new Regex(pattern);
            if (!String.IsNullOrEmpty(curp) && !regexCurp.IsMatch(curp)) { throw new ArgumentException("La CURP ingresada no es válida."); }
            this._curp = curp;
            return this;
        }

        public PersonalFiscalData SetNames(String names)
        {
            if(!String.IsNullOrEmpty(names) )
            this._names = names;
            return this;
        }

        public PersonalFiscalData SetLastName(String lastName)
        {
            if (String.IsNullOrEmpty(lastName)) { throw new ArgumentException("El Apellido Paterno es requerido");  }
            if (!String.IsNullOrEmpty(lastName) && lastName.Length > 50) { throw new ArgumentException("El Apellido Paterno debe ser menor o igual a 50 carácteres");  }
            this._paternalSurname = lastName;
            return this;
        }

        public PersonalFiscalData SetSurname(String surname)
        {
            if (!String.IsNullOrEmpty(surname) && surname.Length > 50) { throw new ArgumentException("El Apellido Materno debe ser menor o igual a 50 carácteres"); }
            this._maternalSurname = surname;
            return this;
        }


        public PersonalFiscalData SetRoadName(String roadname)
        {
            if (String.IsNullOrEmpty(roadname)) { throw new ArgumentException("La Calle es requerida"); }
            if (!String.IsNullOrEmpty(roadname) && roadname.Length > 250) { throw new ArgumentException("La calle debe ser menor o igual a 250 carácteres"); }//BD -> 240 Carácteres

            this._roadName = roadname;
            return this;
        }

        public PersonalFiscalData SetRoadNameType(String roadnameType)
        {
            if (!String.IsNullOrEmpty(roadnameType) && roadnameType.Length > 50) { throw new ArgumentException("El Tipo de Calle debe ser menor o igual a 50 carácteres"); }
            this._roadNameType = roadnameType;
            return this;
        }

        public PersonalFiscalData SetInnerNumber(String innerNumber)
        {
            if (!String.IsNullOrEmpty(innerNumber) && innerNumber.Length > 40) { throw new ArgumentException("El ´Número Interior    debe ser menor o igual a 40 carácteres"); }

            this._innerNumber = innerNumber;
            return this;
        }

        public PersonalFiscalData SetOuterNumber(String outerNumber)
        {
            if (String.IsNullOrEmpty(outerNumber)) { throw new ArgumentException("El Número Exterior es requerido"); }
            if (!String.IsNullOrEmpty(outerNumber) && outerNumber.Length > 40) { throw new ArgumentException("El ´Número Exterior debe ser menor o igual a 40 carácteres"); }

            this._outerNumber = outerNumber;
            return this;
        }

        public PersonalFiscalData SetLocation(String location)
        {
            if (String.IsNullOrEmpty(location)) { throw new ArgumentException("La Localidad es requerida"); }
            if (!String.IsNullOrEmpty(location) && location.Length > 50) { throw new ArgumentException("La Localidad debe ser menor o igual a 50 carácteres"); }

            this._location = location;
            return this;
        }

        public PersonalFiscalData SetBetweenStreet(String betweenStreet)
        {

            if (String.IsNullOrEmpty(betweenStreet)) { throw new ArgumentException("La Entre Calle es requerida"); }
            if (!String.IsNullOrEmpty(betweenStreet) && betweenStreet.Length > 50) { throw new ArgumentException("La Entre calle debe ser menor o igual a 50 carácteres"); }

            this._betweenStreet = betweenStreet;
            return this;
        }


        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                CURP,
                RFC,
                Names,
                PaternalSurname,
                MaternalSurname,
                RoadName,
                RoadNameType,
                InnerNumber,
                OuterNumber,
                Location,
                BetweenStreet
            };
        }
    }
}
