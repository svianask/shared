﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientDataDomain.ClientDataInformationAggregate
{
    public class RegisterClientProfileRequest
    {
        public string RFC { get; set; }
        public string ContractID { get; set; } 
        public string ChangedField { get; set; }
        public string NewValue { get; set; }
        
        //public string BankAccount { get; set; }
        //public string BankName { get; set; }
    }
}
