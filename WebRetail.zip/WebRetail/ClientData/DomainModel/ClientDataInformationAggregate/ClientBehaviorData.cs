﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientDataDomain.ClientDataInformationAggregate
{
    public class ClientBehaviorData : ValueObject<ClientBehaviorData>
    {
        private readonly string _motivation;
        private DateTime _lastUpdateDate;

        private ClientBehaviorData(string motivation)
        {
            _motivation = motivation;
            _lastUpdateDate = DateTime.Now;
        }

        public string Motivation => _motivation;

        public DateTime LastUpdateDate { get => _lastUpdateDate; }

        public static ClientBehaviorData Create(string motivation)
        {
            if (string.IsNullOrEmpty(motivation)) { throw new ArgumentException("El parámetro no puede estar vacío o nulo", nameof(motivation)); }
            if (motivation.Trim().Length > 140) { throw new ArgumentException("El parámetro no excede la longitud permitida de 140 caracteres", nameof(motivation)); }

            return new ClientBehaviorData(motivation);
        }

        public static ClientBehaviorData CreateEmpty(string motivation)
        {
            return new ClientBehaviorData("");
        }

        public static ClientBehaviorData CreateEmpty()
        {
            return new ClientBehaviorData("");
        }

        public ClientBehaviorData SetUpdateDate(DateTime? lastUpdateDate)
        {
            var currentDate = DateTime.Now;
            if (lastUpdateDate == null) { lastUpdateDate = currentDate; }

            _lastUpdateDate = Convert.ToDateTime(lastUpdateDate);

            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Motivation
            };
        }
    }
}
