﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ClientDataDomain.ClientDataInformationAggregate
{
    public class ClientContactData : ValueObject<ClientContactData>
    {
        private readonly string _email;
        private readonly string _mobilePhone;
        private readonly string _countryDialCode;
        private DateTime _lastUpdateDate;

        private ClientContactData(string email, string mobilePhone, string countryDialCode)
        {
            _email = email;
            _mobilePhone = mobilePhone;
            _countryDialCode = countryDialCode;
            _lastUpdateDate = DateTime.Now;
        }

        public string Email => _email;

        public string MobilePhone => _mobilePhone;

        public string CountryDialCode => _countryDialCode;

        public DateTime LastUpdateDate { get => _lastUpdateDate; }

        public static ClientContactData CreateNormalized(string email, string mobilePhone, string countryDialCode)
        {
            string emailPattern = @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$";
            Regex regexMail = new Regex(emailPattern);


            if (!string.IsNullOrEmpty(email) && !regexMail.IsMatch(email)) { throw new ArgumentException("El valor recibido no corresponde con un correo electrónico."); }
            if (email.Length > 60) { throw new ArgumentException("El correo electrónico no debe tener más de 60 carácteres de longitud."); }


            string phonePattern = @"^([0-9]{10})$";
            Regex regexPhone = new Regex(phonePattern);


            if (!string.IsNullOrEmpty(mobilePhone) && !regexPhone.IsMatch(mobilePhone)) { throw new ArgumentException("El valor recibido no corresponde a un teléfono."); }
            if (mobilePhone.Length > 10) { throw new ArgumentException("El teléfono no debe tener más de 10 carácteres de longitud."); }

            mobilePhone = StandarizePhone(mobilePhone);
            countryDialCode = StandarizeCountryDialCode(countryDialCode);

            return new ClientContactData(email, mobilePhone, countryDialCode);
        }


        public static ClientContactData Create(string email, string mobilePhone, string countryDialCode)
        {
            mobilePhone = StandarizePhone(mobilePhone);
            countryDialCode = StandarizeCountryDialCode(countryDialCode);

            return new ClientContactData(email, mobilePhone, countryDialCode);
        }

        public ClientContactData SetSetUpdateDate(DateTime? lastUpdateDate)
        {
            var currentDate = DateTime.Now;
            if (lastUpdateDate == null) { lastUpdateDate = currentDate; }

            _lastUpdateDate = Convert.ToDateTime(lastUpdateDate);

            return this;
        }

        private static string StandarizeCountryDialCode(string countryDialCode)
        {
            countryDialCode = countryDialCode.Replace(" ", "").Trim();
            if (countryDialCode.Length < 1) { countryDialCode = "+52"; }
            return countryDialCode;
        }

        private static string StandarizePhone(string phone)
        {
            phone = phone.Replace(" ", "").Trim();
            if (phone.Length != 10) { phone = string.Empty; }
            return phone;
        }
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new object[]
            {
                Email,
                MobilePhone,
                CountryDialCode,
                LastUpdateDate
            };
        }
    }
}
