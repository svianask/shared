﻿using ClientDataDomain.ClientDataAddressAggregate;
using Ddd;
using System;
using System.Collections.Generic;


namespace ClientDataDomain.ClientDataInformationAggregate
{

    public class ClientFiscalData : ValueObject<ClientFiscalData>
    {
        private string _clientId;
        private PersonalFiscalData _personalFiscalData;
        private FiscalAddress _fiscalAddress;
        private DateTime _lastUpdateDate;
        private string _channel;

        public PersonalFiscalData PersonalFiscalData { get => _personalFiscalData; }

        public FiscalAddress FiscalAddress => _fiscalAddress;

        public String ClientId { get => _clientId; }

        public DateTime LastUpdateDate { get => _lastUpdateDate; }
        public String Channel { get => _channel; }


        private ClientFiscalData(String clientId, PersonalFiscalData personalFiscalData, FiscalAddress fiscalAddres, DateTime lastUpdate, string channel)
        {
            /* string pattern = @"^[A-Z&Ñ]{3,4}[0-9]{2}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[A-Z0-9]{2}[0-9A]$";
             Regex regexRfc = new Regex(pattern);
             if (!String.IsNullOrEmpty(rfc) && !regexRfc.IsMatch(rfc)) { throw new ArgumentException("El RFC ingresado no es válido."); }
             this._rfc = rfc;*/
            this._clientId = clientId;
            if (personalFiscalData == null) { throw new ArgumentException("PersonalFiscalData no puede ser nulo."); }
            _personalFiscalData = personalFiscalData;
            this._fiscalAddress = fiscalAddres;
            this._lastUpdateDate = lastUpdate;
            this._channel = channel;
        }

        private ClientFiscalData(String clientId)
        {
            this._clientId = clientId;
        }


        public static ClientFiscalData Create(String clientId)
        {
            return new ClientFiscalData(clientId);
        }

        public static ClientFiscalData CreateEntry(String clientId, PersonalFiscalData PersonalFiscalData, FiscalAddress fiscalAddress, DateTime lastUdapte, string channel)
        {
            return new ClientFiscalData(clientId, PersonalFiscalData, fiscalAddress, lastUdapte, channel);
        }

        public ClientFiscalData SetUpdateDate(DateTime? lastUpdateDate)
        {
            var currentDate = DateTime.Now;
            if (lastUpdateDate == null) { lastUpdateDate = currentDate; }

            _lastUpdateDate = Convert.ToDateTime(lastUpdateDate);

            return this;
        }

        public ClientFiscalData SetAddress(FiscalAddress fiscalAddress, string channel)
        {
            if (fiscalAddress == null) { throw new ArgumentException("No se permiten valores nulos o vacíos"); }
            if (!String.IsNullOrEmpty(fiscalAddress.ZipCode)
                    && fiscalAddress.Township.State.Id == 0) { throw new ArgumentException("No se ha seleccionado el estado"); }
            if (!String.IsNullOrEmpty(fiscalAddress.ZipCode)
                    && fiscalAddress.Township.City.Id == 0) { throw new ArgumentException("No se ha seleccionado la ciudad"); }
            if (!String.IsNullOrEmpty(fiscalAddress.ZipCode)
                                && fiscalAddress.Township.Id == 0 && (channel != "WHATSAPP" || channel != "WHATSAPP-VENDEDOR")) { throw new ArgumentException("No se ha seleccionado el asentamiento"); }

            if ((fiscalAddress.Township.Id > 0
                    || fiscalAddress.Township.State.Id > 0
                    || fiscalAddress.Township.City.Id > 0) && String.IsNullOrEmpty(fiscalAddress.ZipCode)) { throw new ArgumentException("El código postal es necesario si se elige Asentamiento, Ciudad o Estado"); }


            this._fiscalAddress = fiscalAddress;
            return this;
        }

        public ClientFiscalData SetPersonalFiscalData(PersonalFiscalData personaFiscalData)
        {

            this._personalFiscalData = personaFiscalData;
            return this;
        }

        public ClientFiscalData SetClientId(String clientId)
        {
            this._clientId = clientId;
            return this;
        }

        public ClientFiscalData SetEmptyAddress(FiscalAddress fiscalAddress)
        {
            this._fiscalAddress = fiscalAddress;
            return this;
        }

        public ClientFiscalData SetStateName(String stateName)
        {

            if (String.IsNullOrEmpty(stateName)) { throw new ArgumentException("No se permiten valores nulos o vacíos."); }
            if (this.FiscalAddress != null && this.FiscalAddress.Township != null)
            {
                this.FiscalAddress.Township.State.Name = stateName;
            }
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new object[]
            {
                PersonalFiscalData,
                FiscalAddress,
                LastUpdateDate
            };
        }
    }
}
