﻿using System;

namespace ClientDataDomain.DTO.Response.ClientContactData
{
    public class ClientContactDataDTO
    {
        public String Email = String.Empty;
        public String MobilePhone = String.Empty;
    }
}
