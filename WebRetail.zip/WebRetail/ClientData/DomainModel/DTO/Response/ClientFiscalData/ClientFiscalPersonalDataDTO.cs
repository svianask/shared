﻿
namespace ClientDataDomain.DTO.Response.ClientFiscalData
{
    public class ClientFiscalPersonalDataDTO
    {
        public string RFC;
        public string CURP;
        public string Names;
        public string PaternalSurname;
        public string MaternalSurname;
        public string RoadName;
        public string RoadNameType;
        public string InnerNumber;
        public string OuterNumber;
        public string Location;
        public string BetweenStreet;
    }
}
