﻿using System;

namespace ClientDataDomain.DTO.Response.ClientFiscalData
{
    public class ClientFiscalDataDTO
    {
        public ClientFiscalPersonalDataDTO PersonalFiscalData;
        public String ZipCode = String.Empty;
        public String CityName = String.Empty;
        public String StateName = String.Empty;
        public String TownshipName = String.Empty;

    }
}
