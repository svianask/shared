﻿using ClientDataDomain.DTO.Response.ClientBehavior;
using ClientDataDomain.DTO.Response.ClientContactData;
using ClientDataDomain.DTO.Response.ClientFiscalData;
using System;

namespace ClientDataDomain.DTO.Response.ClientPersonalData
{
    public class ClientPersonalDataDTO
    {
        public ClientBehaviorDTO ClientBehaviorData;
        public ClientContactDataDTO ClientContactData;
        public ClientFiscalDataDTO ClientFiscalData;
        public String LastUpdateDate;
        public int CountPersonalData;
        public int CountFiscalMissing;
    }
}
