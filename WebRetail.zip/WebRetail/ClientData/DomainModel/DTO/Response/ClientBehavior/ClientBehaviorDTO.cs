﻿using System;

namespace ClientDataDomain.DTO.Response.ClientBehavior
{
    public class ClientBehaviorDTO
    {
        public String Motivation;

    }
}
