﻿using System;

namespace ClientDataDomain.DTO.Response.TownshipAddress
{
    public class TownshipAddressDTO
    {
        public int Id;
        public String TownshipName;
        public CityAddressDTO City;
        public StateAddressDTO State;
    }
}
