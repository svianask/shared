﻿using System;

namespace ClientDataDomain.DTO.Response.TownshipAddress
{
    public class CityAddressDTO
    {
        public int Id;
        public String Name;
    }
}
