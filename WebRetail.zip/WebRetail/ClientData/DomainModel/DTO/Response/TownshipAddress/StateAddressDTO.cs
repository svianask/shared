﻿using System;

namespace ClientDataDomain.DTO.Response.TownshipAddress
{
    public class StateAddressDTO
    {
        public int Id;
        public String Name;
    }
}
