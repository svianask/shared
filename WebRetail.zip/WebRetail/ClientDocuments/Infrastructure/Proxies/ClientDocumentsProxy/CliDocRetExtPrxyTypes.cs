﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientDocumentsProxy
{
    #region "DocumentFile"
    public class PrxyDocumentFileRequest {
        public string UserName;
        public string DocumentId;
        public string DocumentName;
    }

    public class PrxyDocumentFileResponse
    {
        public OperationResult Result;
        public byte[] FileDocument;
    }
    #endregion

    #region "ContractDocuments"
    public class PrxyDocumentsOfContractRequest
    {
        public String ContractId;
    }
        
    public class PrxyDocumentsOfContractResponse
    {
        public PrxyDocumentsOfContract ListDocuments;
        public OperationResult Result;
    }

    public class PrxyDocumentsOfContract
    {
        public List<PrxyDocument> DocumentsProduct = new List<PrxyDocument>();
    }

    public class PrxyDocument
    {
        public string Id;
        public string DocumentName;
        public string DocumentDesc;
        public string DocumentMimeType;
        public int DocumentType;
        public DateTime EmssionDate;
    }
    #endregion

    #region "EncryptedDocument"
    public class PrxyPasswordPdfDocumentRequest
    {
        public string EncodedFile;
        public string Password;
    }

    public class PrxyPasswordPdfDocumentResponse
    {
        public byte[] FileEncrypted;
        public OperationResult Result;
    }
    #endregion

    #region "Solvencia"
    public class PrxySolvenciaBasicInfoRequest
    {
        public string UserId;
        public int PortalId;
    }

    public class PrxySolvenciaBasicInfoResponse
    {
        public OperationResult Result;
        public PrxySolvenciaData SolvenciaInfo;
    }

    public class PrxySolvenciaData
    {
        public string User;
        public string Email;
        public string CellPhone;
        public string FullName;
    }
    #endregion

    #region "Product"
    public class PrxyProductoComercialNameRequest
    {
        public string ContractId;
    }

    public class PrxyProductoComercialNameResponse
    {
        public OperationResult Result;
        public string ComercialName;
    }

    #endregion

    #region "SendDocument"
    public class PrxyContractDocumentRequest
    {
        public string RFC;
        public string DocumentId;
        public string DocumentName;
        public string DocumentDesc;
        public string DocType;
        public string ProductName;
    }

    public class PrxyContractDocumentResponse
    {
        public OperationResult Result;
    }
    #endregion

}
