﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Newtonsoft.Json;
using Proxy;
using Common.Domain;

namespace ClientDocumentsProxy
{
    public class CliDocRetPrxy : ICliDocRetPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public CliDocRetPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public string GetClientRFCByContract(string contractId, out OperationResult result)
        {
            PrxyClientRFCByContractResquest request = new PrxyClientRFCByContractResquest() { ContractId = contractId };
            PrxyClientRFCByContractResponse response = new PrxyClientRFCByContractResponse();
            result = new OperationResult();
            string clientRFC;

            string url = ConfigurationManager.AppSettings["RetailService:URLService"].ToString() + "ClientContracts/GetClientRFCByContract";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyClientRFCByContractResponse>(JsonResult);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.ClientRFC;
        }
    }
}
