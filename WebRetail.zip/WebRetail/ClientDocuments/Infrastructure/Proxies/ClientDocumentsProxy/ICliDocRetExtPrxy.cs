﻿using System;
using ClientDocumentsDomain.DocumentAggregate;
using ClientDocumentsDomain.SolvenciaAggregate;
using Common.Domain;

namespace ClientDocumentsProxy
{
    public interface ICliDocRetExtPrxy
    {
        DocumentsOfContract GetDocumentsByContractId(string contractId, out OperationResult result);
        byte[] GetDocumentFileByUserDocumentId(string userName, string documentId, string documentName, out OperationResult result);
        byte[] SetPasswordPdfDocument(string encondedFile, string password, out OperationResult result);
        OperationResult SendContractDocument(string rfc, string documentId, string documentName, string documentDesc, int docType, string productName);
        SolvenciaData GetClientSolvenciaBasicInfo(string userId, int portalId, out OperationResult result);
        string GetProductComercialName(string contractId, out OperationResult result);

    }
}
