﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientDocumentsProxy
{
    #region "Contracts"
    public class PrxyClientRFCByContractResquest
    {
        public string ContractId;
    }

    public class PrxyClientRFCByContractResponse
    {
        public OperationResult Result;
        public string ClientRFC;
    }
    #endregion
}
