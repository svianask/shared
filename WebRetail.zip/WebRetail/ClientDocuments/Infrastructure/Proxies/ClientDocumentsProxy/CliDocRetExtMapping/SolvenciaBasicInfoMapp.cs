﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientDocumentsDomain.SolvenciaAggregate;

namespace ClientDocumentsProxy.CliDocRetExtMapping
{
    public class SolvenciaBasicInfoMapp
    {
        internal static SolvenciaData Mapp(PrxySolvenciaBasicInfoResponse response)
        {
            string user = response.SolvenciaInfo.User;
            string email = response.SolvenciaInfo.Email;
            string fullName = response.SolvenciaInfo.FullName;
            string cellPhone = response.SolvenciaInfo.CellPhone;
            return SolvenciaData.Create(user, email, fullName, cellPhone);
        }
    }
}
