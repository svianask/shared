﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientDocumentsDomain.DocumentAggregate;

namespace ClientDocumentsProxy.CliDocRetExtMapping
{
    public class DocumentsByContractIdMapp
    {
        internal static DocumentsOfContract Mapp(DocumentsOfContract docs, PrxyDocumentsOfContractResponse response)
        {
            response.ListDocuments.DocumentsProduct.ForEach(dc => docs
             .AddDocument(
                new Document(dc.Id, dc.DocumentName, dc.DocumentDesc, dc.DocumentMimeType, dc.DocumentType, dc.EmssionDate)
                )
             );

            return docs;
        }
    }
}
