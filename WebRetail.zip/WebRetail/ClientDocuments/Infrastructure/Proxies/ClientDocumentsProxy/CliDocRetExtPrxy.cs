﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Proxy;
using ClientDocumentsDomain.DocumentAggregate;
using ClientDocumentsProxy.CliDocRetExtMapping;
using Common.Domain;
using ClientDocumentsDomain.SolvenciaAggregate;

namespace ClientDocumentsProxy
{
    public class CliDocRetExtPrxy : ICliDocRetExtPrxy
    {
        private readonly IProxyEngine _proxyEngine;

        public CliDocRetExtPrxy(IProxyEngine proxyEngine)
        {
            _proxyEngine = proxyEngine;
        }

        public SolvenciaData GetClientSolvenciaBasicInfo(string userId, int portalId, out OperationResult result)
        {
            PrxySolvenciaBasicInfoRequest request = new PrxySolvenciaBasicInfoRequest() { UserId = userId, PortalId = portalId };
            PrxySolvenciaBasicInfoResponse response = new PrxySolvenciaBasicInfoResponse();

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientSolvencia/GetClientSolvenciaBasicInfo";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            SolvenciaData solvenciaData = null;
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxySolvenciaBasicInfoResponse>(JsonResult);
                solvenciaData = SolvenciaBasicInfoMapp.Mapp(response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return solvenciaData;

        }

        public byte[] GetDocumentFileByUserDocumentId(string userName, string documentId, string documentName, out OperationResult result)
        {
            PrxyDocumentFileRequest request = new PrxyDocumentFileRequest();
            PrxyDocumentFileResponse response = new PrxyDocumentFileResponse();
            request.UserName = userName;
            request.DocumentId = documentId;
            request.DocumentName = documentName;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientDocuments/GetDocumentFileByDocumentId";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            response.FileDocument = null;
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyDocumentFileResponse>(JsonResult);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return response.FileDocument;

        }

        public DocumentsOfContract GetDocumentsByContractId(string contractId, out OperationResult result)
        {
            PrxyDocumentsOfContractRequest request = new PrxyDocumentsOfContractRequest();
            PrxyDocumentsOfContractResponse response = new PrxyDocumentsOfContractResponse();
            result = new OperationResult();
            DocumentsOfContract documentsOfContract = new DocumentsOfContract(contractId);
            request.ContractId = contractId;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientDocuments/GetDocumentsContract";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyDocumentsOfContractResponse>(JsonResult);
                documentsOfContract = DocumentsByContractIdMapp.Mapp(documentsOfContract, response);
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return documentsOfContract;
        }

        public string GetProductComercialName(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            PrxyProductoComercialNameRequest request = new PrxyProductoComercialNameRequest() { ContractId = contractId };
            PrxyProductoComercialNameResponse response = new PrxyProductoComercialNameResponse();
            string comercialName = String.Empty;
            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "Products/GetProductComercialNameByContractId";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyProductoComercialNameResponse>(JsonResult);
                comercialName = response.ComercialName;
                result = response.Result;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
            return comercialName;
        }

        public OperationResult SendContractDocument(string rfc, string documentId, string documentName, string documentDesc, int docType, string productName)
        {
            OperationResult result = new OperationResult();
            PrxyContractDocumentResponse response = new PrxyContractDocumentResponse();
            String docTypeDesc = string.Empty;
            switch(docType) {
                case 1:
                    docTypeDesc = "Estado de cuenta";
                    break;
                case 2:
                    docTypeDesc = "Constancia";
                    break;
                case 4:
                    docTypeDesc = "Póliza";
                    break;
            }
            PrxyContractDocumentRequest request = new PrxyContractDocumentRequest()
            {
                RFC = rfc,
                DocumentId = documentId,
                DocumentName = documentName,
                DocumentDesc = documentDesc,
                DocType = docTypeDesc,
                ProductName = productName
            };

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientDocuments/SendContractDocument";
            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyContractDocumentResponse>(JsonResult);
            }
            else
            {
                response.Result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
         
            return response.Result;
        }

        public byte[] SetPasswordPdfDocument(string encondedFile, string password, out OperationResult result)
        {
            result = new OperationResult();
            PrxyPasswordPdfDocumentRequest request = new PrxyPasswordPdfDocumentRequest();
            PrxyPasswordPdfDocumentResponse response = new PrxyPasswordPdfDocumentResponse();
            request.EncodedFile = encondedFile;
            request.Password = password;

            string url = ConfigurationManager.AppSettings["RetailExtendedService:URLService"].ToString() + "ClientDocuments/SetPasswordPdfDocument";

            string JsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyPasswordPdfDocumentResponse>(JsonResult);
                return response.FileEncrypted;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }
        }
    }
}
