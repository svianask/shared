﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientDocumentsProxy
{
    public interface ICliDocRetPrxy
    {
        string GetClientRFCByContract(string contractId, out OperationResult result);
    }
}
