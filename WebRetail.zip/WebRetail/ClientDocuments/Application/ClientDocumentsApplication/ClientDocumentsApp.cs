﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;
using iTextSharp.text.pdf;
using Common.Domain;
using ClientDocumentsDomain.DocumentAggregate;
using ClientDocumentsDomain.SolvenciaAggregate;
using ClientDocumentsProxy;
using SeriLogH;

namespace ClientDocumentsApplication
{
    public class ClientDocumentsApp : IClientDocumentsApp
    {
        private readonly ISeriLogHelper _log;
        public readonly ICliDocRetExtPrxy _retailExtServiceProxy;
        public readonly ICliDocRetPrxy _retailServiceProxy;

        public ClientDocumentsApp(ISeriLogHelper log, ICliDocRetExtPrxy retailExtServiceProxy, ICliDocRetPrxy cliDocRetPrxy)
        {
            _log = log;
            _retailExtServiceProxy = retailExtServiceProxy;
            _retailServiceProxy = cliDocRetPrxy;
        }

        public byte[] GetDocumentFileByUserDocumentId(string userName, string documentId, string documentName, out OperationResult result)
        {
           
            result = new OperationResult();
            var documentFile = new byte[0];
            try
            {
                if (string.IsNullOrEmpty(userName)) { throw new NullReferenceException("El userName no puede ir nulo o vacío."); }
                if (string.IsNullOrEmpty(documentId)) { throw new NullReferenceException("El documentId no puede ir nulo o vacío."); }
                if (string.IsNullOrEmpty(documentName)) { throw new NullReferenceException("El documentName no puede ir nulo o vacío."); }

                documentFile = _retailExtServiceProxy.GetDocumentFileByUserDocumentId(userName, documentId, documentName, out result);
                if (documentFile != null && documentFile.Length > 0)
                {
                    result.Successful = true;
                }
                else result.Successful = false;
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al obtener el documento GetDocumentFileByUserDocumentId {cntx}", new { documentName });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el documento " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                result.Exception = ex;
            }
            return documentFile; 

        }

        public DocumentsOfContract GetDocumentsByContractId(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            try
            {
                if (string.IsNullOrEmpty(contractId)) { throw new NullReferenceException("El uscontractId no puede ir nulo o vacío."); }

                result.Successful = true;
                DocumentsOfContract documentsOfContract = null;
                documentsOfContract = _retailExtServiceProxy.GetDocumentsByContractId(contractId, out result);
                string clientRFC = _retailServiceProxy.GetClientRFCByContract(contractId, out result);
                string comercialName = _retailExtServiceProxy.GetProductComercialName(contractId, out result);
                documentsOfContract.AddComercialName(comercialName);
                int portalId = Convert.ToInt16(ConfigurationManager.AppSettings["PortalId"].ToString());
                SolvenciaData solvenciaData = _retailExtServiceProxy.GetClientSolvenciaBasicInfo(clientRFC, portalId, out result);
                documentsOfContract.AddEmail(solvenciaData.Email);
                documentsOfContract.AddRFC(clientRFC);

                return documentsOfContract;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los documentos del contrato GetDocumentsByContractId {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los documentos del contrato " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
                return null;
            }
        }
        private delegate OperationResult delSendContractDocument(string userName, string documentId, string documentName, string documentDesc, int docType, string productName);
        public void SendClientDocument(string userName, string documentId, string documentName, string documentDesc, int docType, string productName, out OperationResult result)
        {
            result = new OperationResult();
            try
            {
                if (string.IsNullOrEmpty(userName)) { throw new NullReferenceException("El userName no puede ir nulo o vacío."); }
                result = _retailExtServiceProxy.SendContractDocument(userName, documentId, documentName, documentDesc, docType, productName);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al enviar el documento SendEncryptedDocument {cntx}", new { documentName });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el documento " + ex.Message + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
        }
    }
}
