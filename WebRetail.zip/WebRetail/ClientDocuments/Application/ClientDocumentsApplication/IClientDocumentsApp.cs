﻿using System;
using ClientDocumentsDomain.DocumentAggregate;
using Common.Domain;

namespace ClientDocumentsApplication
{
    public interface IClientDocumentsApp
    {
        DocumentsOfContract GetDocumentsByContractId(string contractId, out OperationResult result);
        byte[] GetDocumentFileByUserDocumentId(string userName, string documentId, string documentName, out OperationResult result);
        void SendClientDocument(string userName, string documentId, string documentName, string documentDesc, int docType, string productName, out OperationResult result);
    }
}
