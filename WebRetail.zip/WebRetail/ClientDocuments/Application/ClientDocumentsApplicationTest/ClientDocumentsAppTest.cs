﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using ClientDocumentsProxy;
using ClientDocumentsApplication;
using ClientDocumentsDomain.DocumentAggregate;
using ClientDocumentsDomain.SolvenciaAggregate;
using Common.Domain;

namespace ClientDocumentsApplicationTest
{
    [TestClass]
    public class ClientDocumentsAppTest
    {
        private readonly ISeriLogHelper _seriloHelper;
        private readonly Mock<ICliDocRetExtPrxy> _retailExtServiceProxy;
        private readonly Mock<ICliDocRetPrxy> _retailServiceProxy;
        private readonly ClientDocumentsApp _clientDocumentsBL;

        public ClientDocumentsAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = "C:\\Files\\TestWebRetail-.txt";

            _seriloHelper = new SeriLogHelper();

            _retailServiceProxy = new Mock<ICliDocRetPrxy>();
            _retailExtServiceProxy = new Mock<ICliDocRetExtPrxy>();

            _clientDocumentsBL = new ClientDocumentsApp(_seriloHelper, _retailExtServiceProxy.Object, _retailServiceProxy.Object);
        }

        private string successUserName;
        private string successDocumentId;
        private string successDocumentName;
        private string contractId;

        [TestInitialize]
        public void Initialize()
        {
            successUserName = "MEAJ720808J25";
            successDocumentId = "C32D7735-9277-49D5-B0DD-FD0EFF954AA9";
            successDocumentName = "599500.pdf";
            contractId = "599500";
        }

        #region GetDocumentFileByUserDocumentId
        [TestMethod, TestCategory("ProcessSuccessFul")]
        public void GetDocumentFileByUserDocumentIdSuccessful()
        {
            OperationResult result = new OperationResult();
            PrxyGetDocumentFileByUserDocumentIdOk();
            var documentFile = _clientDocumentsBL.GetDocumentFileByUserDocumentId(successUserName, successDocumentId, successDocumentName, out result);
            Assert.IsTrue(documentFile.Length > 0);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void GetDocumentFileByUserDocumentIdFail() 
        {
            OperationResult result = new OperationResult();
            PrxyGetDocumentFileByUserDocumentIdFail();
            var documentFile = _clientDocumentsBL.GetDocumentFileByUserDocumentId(successUserName, successDocumentId, successDocumentName, out result);
            Assert.IsFalse(result.Successful);
            Assert.IsFalse(documentFile.Length>0);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        [DataRow("", "C32D7735-9277-49D5-B0DD-FD0EFF954AA9", "599500.pdf")]
        [DataRow("MEAJ720808j25", "", "599500.pdf")]
        [DataRow("MEAJ720808j25", "C32D7735-9277-49D5-B0DD-FD0EFF954AA9", "")]
        public void GetDocumentFileByUserDocumentIdFailByNull(string userName, string documentId, string documentName)
        {
            OperationResult result = new OperationResult();
            var documentFile = _clientDocumentsBL.GetDocumentFileByUserDocumentId(userName, documentId, documentName, out result);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }
        #endregion

        #region GetDocumentsByContractId
        [TestMethod, TestCategory("ProcessSuccessFul")]
        public void GetDocumentsByContractIdSuccessful()
        {
            OperationResult result = new OperationResult();
            ConfigurationManager.AppSettings["PortalId"] = "1";
            PrxyGetGetDocumentsByContractIdOk();
            PrxyGetClientRFCByContractOk();
            PrxyGetProductComercialNameOk();
            PrxyGetClientSolvenciaBasicInfoOk();
            var documents = _clientDocumentsBL.GetDocumentsByContractId(contractId, out result);
            Assert.IsNotNull(documents);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
          public void GetDocumentsByContractIdFail()
          {
            OperationResult result = new OperationResult();
            ConfigurationManager.AppSettings["PortalId"] = "1";
            //PrxyGetGetDocumentsByContractIdOk();
            PrxyGetClientRFCByContractOk();
            PrxyGetProductComercialNameOk();
            PrxyGetClientSolvenciaBasicInfoOk();
            var documents = _clientDocumentsBL.GetDocumentsByContractId(contractId, out result);
            Assert.IsFalse(result.Successful);
            Assert.IsNull(documents);
          }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void GetDocumentsByContractIdByNull()
        {
            OperationResult result = new OperationResult();
            var documentFile = _clientDocumentsBL.GetDocumentsByContractId("", out result);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }
        #endregion

        #region SendClientDocument
        [TestMethod, TestCategory("ProcessSuccessFul")]
        public void SendClientDocumentSuccessful()
        {
            OperationResult result = new OperationResult();
            PrxySendContractDocument();
            _clientDocumentsBL.SendClientDocument(successUserName, successDocumentId, successDocumentName, "Estado de Cuenta", 1, "SKANDIA CREA", out result);
            Assert.IsTrue(result.Successful);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendClientDocumentFail()
        {
            OperationResult result = new OperationResult();
            _clientDocumentsBL.SendClientDocument(successUserName, successDocumentId, successDocumentName, "Estado de Cuenta", 1, "SKANDIA CREA", out result);
            Assert.IsTrue(result == null || !result.Successful);
        }

        [TestMethod, TestCategory("SendNotificationFail")]
        public void SendClientDocumentFailByNull()
        {
            OperationResult result = new OperationResult();
            _clientDocumentsBL.SendClientDocument("", successDocumentId, successDocumentName, "Estado de Cuenta", 1, "SKANDIA CREA", out result);
            Assert.ThrowsException<NullReferenceException>(() => { throw result.Exception; });
        }
        #endregion

        #region RetailExtendedProxy
        private void PrxyGetDocumentFileByUserDocumentIdOk()
        {
            var resultGetDocumentFile = new OperationResult();
            byte[] documentFile = CreateSpecialByteArray(7000);
            _retailExtServiceProxy
               .Setup(s => s.GetDocumentFileByUserDocumentId(successUserName, successDocumentId, successDocumentName,  out resultGetDocumentFile))
               .Callback(() => { resultGetDocumentFile.Successful = true; resultGetDocumentFile.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetDocumentFileByUserDocumentId" } }; })
               .Returns(documentFile).Verifiable();
        }

        private void PrxyGetDocumentFileByUserDocumentIdFail()
        {
            var resultGetDocumentFile = new OperationResult();
            byte[] documentFile = CreateSpecialByteArray(0);
            _retailExtServiceProxy
               .Setup(s => s.GetDocumentFileByUserDocumentId(successUserName, successDocumentId, successDocumentName, out resultGetDocumentFile))
               .Callback(() => { resultGetDocumentFile.Successful = false; resultGetDocumentFile.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error" } }; })
               .Returns(documentFile).Verifiable();
        }

        private void PrxyGetGetDocumentsByContractIdOk()
        {
            var resultGetDocuments = new OperationResult();
            var documents = PrxyDocumentsOfContract();
            _retailExtServiceProxy
               .Setup(s => s.GetDocumentsByContractId(contractId, out resultGetDocuments))
               .Callback(() => { resultGetDocuments.Successful = true; resultGetDocuments.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetGetDocumentsByContractId" } }; })
               .Returns(documents).Verifiable();
        }

        private void PrxyGetProductComercialNameOk()
        {
            var resultGetDocumentFile = new OperationResult();
            _retailExtServiceProxy
               .Setup(s => s.GetProductComercialName(contractId, out resultGetDocumentFile))
               .Callback(() => { resultGetDocumentFile.Successful = true; resultGetDocumentFile.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetProductComercialName" } }; })
               .Returns("SKANDIA CREA").Verifiable();
        }

        private void PrxySendContractDocument()
        {
            var result = new OperationResult() { Successful = true };
            _retailExtServiceProxy
               .Setup(s => s.SendContractDocument(successUserName, successDocumentId, successDocumentName, "Estado de Cuenta", 1, "SKANDIA CREA"))
               .Returns(result).Verifiable();
        }
        private void PrxyGetClientSolvenciaBasicInfoOk()
        {
            var resultGetDocumentFile = new OperationResult();
            SolvenciaData solvenciaData = PrxyGetClientSolvenciaBasicInfo();
            _retailExtServiceProxy
               .Setup(s => s.GetClientSolvenciaBasicInfo(successUserName, 1, out resultGetDocumentFile))
               .Callback(() => { resultGetDocumentFile.Successful = true; resultGetDocumentFile.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetClientSolvenciaBasicInfo" } }; })
               .Returns(solvenciaData).Verifiable();
        }


        #endregion

        #region RetailServiceProxy
        private void PrxyGetClientRFCByContractOk()
        {
            var resultGetDocuments = new OperationResult();
            _retailServiceProxy
               .Setup(s => s.GetClientRFCByContract(contractId, out resultGetDocuments))
               .Callback(() => { resultGetDocuments.Successful = true; resultGetDocuments.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Sin errores GetGetDocumentsByContractId" } }; })
               .Returns("MEAJ720808J25").Verifiable();
        }
        #endregion

        #region DataProxy
        private byte[] CreateSpecialByteArray(int length)
        {
            var arr = new byte[length];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = 0x20;
            }
            return arr;
        }

        private DocumentsOfContract PrxyDocumentsOfContract()
        {
            DocumentsOfContract documentsOfContract = new DocumentsOfContract("599500");
            Document document = new Document("C32D7735-9277-49D5-B0DD-FD0EFF954AA9", "599500.pdf", "2do Trimestre 2020", "application/pdf", 1, new DateTime());
            documentsOfContract.AddDocument(document);

            return documentsOfContract;

        }

        private SolvenciaData PrxyGetClientSolvenciaBasicInfo()
        {
            return SolvenciaData.Create(successUserName, "xxx@gmail.com", "Nombre prueba", "5548504112");
        }
        #endregion
    }

}
