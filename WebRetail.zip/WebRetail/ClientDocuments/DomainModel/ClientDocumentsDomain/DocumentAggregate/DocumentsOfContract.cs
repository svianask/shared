﻿using System;
using System.Collections.Generic;
using Ddd;

namespace ClientDocumentsDomain.DocumentAggregate
{
    public class DocumentsOfContract : Entity<string>
    {
        private string _email;
        private string _rfc;
        private string _comercialName;
        private List<Document> _documentsProduct;

        public DocumentsOfContract(string productId)
        {
            if (string.IsNullOrEmpty(productId)) { throw new ArgumentException(nameof(productId)); }

            Id = productId;
            _documentsProduct = new List<Document>();
        }

        public string RFC => _rfc;
        public string EMail => _email;
        public string ComercialName => _comercialName;
        public IEnumerable<Document> DocumentsProduct => _documentsProduct.AsReadOnly();

        public DocumentsOfContract AddDocument(Document doc)
        {
            if (doc is null) { throw new ArgumentException(nameof(doc)); }

            _documentsProduct.Add(doc);
            return this;
        }

        public void AddEmail(string email)
        {
            _email = email;
        }

        public void AddRFC(string rfc)
        {
            _rfc = rfc;
        }

        public void AddComercialName(string comercialName)
        {
            _comercialName = comercialName;
        }
    }
}
