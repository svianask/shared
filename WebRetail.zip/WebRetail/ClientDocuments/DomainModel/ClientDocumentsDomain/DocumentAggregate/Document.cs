﻿using System;
using Ddd;

namespace ClientDocumentsDomain.DocumentAggregate
{
    public class Document : Entity<string>
    {
        private string _documentName;
        private string _documentDesc;
        private string _documentMimeType;
        private int _documentType;
        private DateTime _emissionDate;

        public Document(string docId, string docName, string docDesc, string docMimeType, int docType, DateTime emssionDate)
        {
            if (string.IsNullOrEmpty(docId)) { throw new ArgumentException("El docId no puede ser nulio"); }
            if (string.IsNullOrEmpty(docName)) { throw new ArgumentException("El nombre no puede ser nulo"); }
            if (string.IsNullOrEmpty(docDesc)) { throw new ArgumentException(nameof(docDesc)); }
            if (docType < 1) { throw new ArgumentException(nameof(docType)); }

            Id = docId;
            _documentName = docName;
            _documentDesc = docDesc;
            _documentMimeType = docMimeType;
            _documentType = docType;
            _emissionDate = emssionDate;
        }

        public string DocumentName => _documentName;
        public string DocumentDesc => _documentDesc;
        public string DocumentMimeType => _documentMimeType;
        public int DocumentType => _documentType;
        public DateTime EmssionDate => _emissionDate;
    }
}
