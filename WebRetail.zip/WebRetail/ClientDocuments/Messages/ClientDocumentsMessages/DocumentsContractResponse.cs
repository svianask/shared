﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;
using ClientDocumentsDomain.DocumentAggregate;

namespace ClientDocumentsMessages
{
    public class DocumentsContractResponse
    {
        public OperationResult Result { get; set; }
        public DocumentsOfContract ListDocuments { get; set; }
        public DocumentsContractResponse() { Result = new OperationResult(); }
    }
}
