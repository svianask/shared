﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientDocumentsMessages
{
    public class SendClientDocumentRequest
    {
        public string RFC { get; set; }
        public string DocumentId { get; set; }
        public string DocumentName { get; set; }
        public string DocumentDesc { get; set; }
        public int DocType { get; set; }
        public string ProductName { get; set; }
    }
}
