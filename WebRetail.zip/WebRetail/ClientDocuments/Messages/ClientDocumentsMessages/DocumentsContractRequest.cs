﻿using System;

namespace ClientDocumentsMessages
{
    public class DocumentsContractRequest
    {
        public string ContractId { get; set; }
    }
}
