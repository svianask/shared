﻿using System;
using Common.Domain; 


namespace ClientDocumentsMessages
{
    public class DocumentFileResponse
    {
        public OperationResult Result { get; set; }
        public byte[] FileDocument { get; set; }
        public DocumentFileResponse() { Result = new OperationResult(); FileDocument = default(byte[]); }
    }
}
