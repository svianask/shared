﻿using System;
using Common.Domain;

namespace ClientDocumentsMessages
{
    public class SendClientDocumentResponse
    {
        public OperationResult Result;
    }
}
