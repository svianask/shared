﻿using System;

namespace ClientDocumentsMessages
{
    public class DocumentFileRequest
    {
        public string DocumentName { get; set; }
        public string DocumentId { get; set; }
        public string UserName { get; set; }
    }
}
