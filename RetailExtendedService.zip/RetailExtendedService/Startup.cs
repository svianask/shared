﻿using Microsoft.Owin;
using Owin;
using System.Web.Http;


[assembly: OwinStartup(typeof(RetailExtendedService.Startup))]
namespace RetailExtendedService
{
    /// <summary>
    /// startup orchestator
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Configurations the specified application.
        /// </summary>
        /// <param name="app"></param>
        public void Configuration(IAppBuilder app)
        {
            var config = new HttpConfiguration();

            WebApiConfig.Register(config);
            UnityConfig.Register(config);
            SwaggerConfig.Register(config);


            app.UseWebApi(config);
        }

    }
}