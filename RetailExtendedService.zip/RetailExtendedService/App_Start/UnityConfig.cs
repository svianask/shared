using ClientBehaviorApplication;
using ClientBehaviorRepository;
using ClientContractsApplication;
using ClientDocumentsApplication;
using ClientDomiciliationApplication;
using ClientFiscalData.Repository;
using ClientFullSurrenderApplication;
using ClientProfile.Repository;
using ClientProfileApplication;
using ClientSolvenciaApplication;
using ClientSurveyNPSApplication;
using ClientWithdrawalsApplication;
using Common.Proxy;
using Contracts.Application;
using Contracts.Repository;
using FiscalDataApplication;
using InsuranceContractApplication;
using NotificationsApplication;
using NotificationsProxy;
using ProductsApplication;
using Proxy;
using RetailExtendedRepository;
using SeriLogH;
using SqlClientH;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Http;
using Unity;
using Unity.Lifetime;
using Unity.WebApi;
using Utilities;

namespace RetailExtendedService
{
    /// <summary>
    /// Unity configuration
    /// </summary>
    public static class UnityConfig
    {
        /// <summary>
        /// Register the components
        /// </summary>
        /// <returns></returns>
        private static IUnityContainer RegisterComponents(this IUnityContainer container)
        {

            if (container != null)
            {
                //Register database
                container.RegisterDatabase("RA", "RA");
                container.RegisterDatabase("SOC_Core", "SOC_Core");
                container.RegisterDatabase("DOMICILIACION", "DOMICILIACION");
                container.RegisterDatabase("PracticasVenta", "PracticasVenta");
                container.RegisterDatabase("SecurityGlobalApp", "SecurityGlobalApp");
                container.RegisterDatabase("SkandiaGoP", "SkandiaGoP");
                container.RegisterDatabase("RAWRAPSIIF", "RAWRAPSIIF");
                container.RegisterDatabase("FiscalInfo", "FiscalInfo");
                container.RegisterDatabase("OfertaDeValor", "OfertaDeValor");
                container.RegisterDatabase("VinculacionDigital", "VinculacionDigital");
                container.RegisterDatabase("SkandiaCRMSF", "SkandiaCRMSF");

                //Register BL
                container.RegisterType<IClientContractsApp, ClientContractsApp>();
                container.RegisterType<IProductsApp, ProductsApp>();
                container.RegisterType<INotificationsApp, NotificationsApp>();
                container.RegisterType<ITransform, Transform>();
                container.RegisterType<IClientWithdrawalsApp, ClientWithdrawalsApp>();
                container.RegisterType<IClientDocumentsApp, ClientDocumentsApp>();
                container.RegisterType<IClientProfileApp, ClientProfileApp>();
                container.RegisterType<IClientSolvenciaApp, ClientSolvenciaApp>();
                container.RegisterType<IClientFullSurrenderApp, ClientFullSurrenderApp>();
                container.RegisterType<IClientSurveyNPSApp, ClientSurveyNPSApp>();
                container.RegisterType<IContractsApp, ContractsApp>();
                container.RegisterType<IClientDomiciliationApp, ClientDomiciliationApp>();
                container.RegisterType<IParametersPrxy, ParametersPrxy>();
                container.RegisterType<IProxyEngine, ProxyEngine>();
                container.RegisterType<IClientBehaviorApp, ClientBehaviorApp>();
                container.RegisterType<IFiscalDataApp, FiscalDataApp>();
                container.RegisterType<IInsuranceContractApp, InsuranceContractApp>();

                //Register DA
                container.RegisterType<IRADa, RADa>();
                container.RegisterType<ClientProfile_IRADa, ClientProfile_RADa>();
                container.RegisterType<ISOC_CoreDa, SOC_CoreDa>();
                container.RegisterType<IDOMICILIACIONDa, DOMICILIACIONDa>();
                container.RegisterType<ClientProfile_IPracticaVentas, ClientProfile_PracticaVentas>();
                container.RegisterType<IWCFDocumentsProxy, WCFDocumentsProxy>();
                container.RegisterType<ISecurityGlobalAppDa, SecurityGlobalAppDa>();
                container.RegisterType<IContractRepository, ContractRepository>();
                container.RegisterType<IFiscalAddressRepository, FiscalAddressRepository>();
                container.RegisterType<IClientBehavior_RADa, ClientBehavior_RADa>();
                container.RegisterType<IFiscalDataRepository, FiscalDataStoreRepository>();
                container.RegisterType<IOfertaDeValorDa, OfertaDeValorDa>();
                container.RegisterType<IVinculacionDigitalDa, VinculacionDigitalDa>();
                container.RegisterType<ISkandiaCrmSfDa, SkandiaCrmSfDa>();

                //register Proxies
                container.RegisterType<IParametersProxy, ParametersProxy>();


                //Register Helpers
                container.RegisterType<ISeriLogHelper, SeriLogHelper>();
                container.RegisterFactory<SeriLogHelper>("SeriLog", c => new SeriLogHelper(), new HierarchicalLifetimeManager());
                container.RegisterType<ISqlClientHelper, SqlClientHelper>();

            }
            return container;
        }

        /// <summary>
        /// Register the configuration
        /// </summary>
        /// <param name="config"></param>
        public static void Register(HttpConfiguration config)
        {
            if (config != null)
            {
                var container = new UnityContainer().RegisterComponents();
                config.DependencyResolver = new UnityDependencyResolver(container);
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <param name="connection"></param>
        /// <returns></returns>
        public static IUnityContainer RegisterDatabase(this IUnityContainer container, string name, string connection)
        {
            if (container != null)
            {
                container.RegisterFactory<SqlConnection>(name, c => new SqlConnection(ConfigurationManager.ConnectionStrings[connection].ConnectionString), new HierarchicalLifetimeManager());
            }

            return container;

        }
    }

}
