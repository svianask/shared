﻿using Swashbuckle.Application;
using Swashbuckle.Examples;
using System;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.Http;

namespace RetailExtendedService
{
    /// <summary>
    /// Swagger configuration
    /// </summary>
    public static class SwaggerConfig
    {
        /// <summary>
        /// Registers the specified configuration.
        /// </summary>
        /// <param name="config">The configuration.</param>
        public static void Register(HttpConfiguration config)
        {
            if(config != null)
            {
                var baseDirectory = AppDomain.CurrentDomain.BaseDirectory + @"\bin\";
                var commentsFileName = Assembly.GetExecutingAssembly().GetName().Name + ".xml";
                var commentsFile = Path.Combine(baseDirectory, commentsFileName);

                config.EnableSwagger(c =>
                {
                    c.OperationFilter<ExamplesOperationFilter>();
                    c.SingleApiVersion("v1", "RetailExtendedService API");
                    c.IncludeXmlComments(commentsFile);
                    c.RootUrl(req => new Uri(req.RequestUri, HttpContext.Current.Request.ApplicationPath ?? string.Empty).ToString());
                }).EnableSwaggerUi();
            }
        }
    }
}