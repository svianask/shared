﻿using NotificationsMessages;
using Swashbuckle.Examples;

namespace RetailExtendedService.Models.Examples
{
    /// <summary>
    /// Ejemplo de parámetros para la actualización de los registros de notificación
    /// </summary>
    public class UpdateNotificationRecordExample : IExamplesProvider
    {
        /// <summary>
        /// Return examples
        /// </summary>
        /// <returns></returns>
        public object GetExamples()
        {
            return new UpdateNotificationRecordRequest
            {
                NotificacionWkId = 1
            };
        }
    }
}