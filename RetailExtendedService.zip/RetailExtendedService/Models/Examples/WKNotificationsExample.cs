﻿using NotificationsMessages;
using Swashbuckle.Examples;
using System;

namespace RetailExtendedService.Models.Examples
{
    /// <summary>
    /// Ejemplo de parámetros para la actualización de los registros de notificación
    /// </summary>
    public class WKNotificationsExample : IExamplesProvider
    {
        /// <summary>
        /// Return examples
        /// </summary>
        /// <returns></returns>
        public object GetExamples()
        {
            return new WKNotificationsRequest
            {
                InitDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now
            };
        }
    }
}