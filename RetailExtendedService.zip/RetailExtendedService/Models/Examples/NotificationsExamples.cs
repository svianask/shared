﻿using NotificationsMessages;
using Swashbuckle.Examples;

namespace RetailExtendedService.Models.Examples
{
    /// <summary>
    /// Notifications request example
    /// </summary>
    public class GetFirstNotificationTemplateExample : IExamplesProvider
    {
        /// <summary>
        /// Return examples
        /// </summary>
        /// <returns></returns>
        public object GetExamples()
        {
            return new FirstNotificationTemplateRequest
            {
                PlanId = "270"
            };
        }
    }
}