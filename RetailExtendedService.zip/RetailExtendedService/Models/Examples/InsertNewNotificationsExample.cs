﻿using NotificationsDomain.NotificationsAggregate;
using NotificationsMessages;
using Swashbuckle.Examples;
using System;
using System.Collections.Generic;

namespace RetailExtendedService.Models.Examples
{
    /// <summary>
    /// Ejemplo de parámetros para la actualización de los registros de notificación
    /// </summary>
    public class InsertNewNotificationsExample : IExamplesProvider
    {
        /// <summary>
        /// Return examples
        /// </summary>
        /// <returns></returns>
        public object GetExamples()
        {
            return new InsertNewNotificationsRequest
            {
                NotificationsList = new List<WKNotification> { 
                    new WKNotification(0, String.Empty, String.Empty, DateTime.Now, DateTime.Now, String.Empty, false) 
                }
            };
        }
    }
}