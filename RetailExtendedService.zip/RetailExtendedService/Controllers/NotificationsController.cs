﻿using CommonDomain;
using NotificationsApplication;
using NotificationsDomain.NotificationsAggregate;
using NotificationsMessages;
using RetailExtendedService.Models.Examples;
using Swashbuckle.Examples;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of notifications
    /// </summary>
    [Authorize]
    public class NotificationsController : ApiController
    {
        private readonly INotificationsApp _notificationsApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="notificationsApp"></param>
        public NotificationsController(INotificationsApp notificationsApp)
        {
            _notificationsApp = notificationsApp;
        }

        /// <summary>
        /// Get Notification template's name and path
        /// </summary>
        /// <param name="request">Request[]{ goalIds:short,... }</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(NotificationTemplateInfoResponse))]
        public NotificationTemplateInfoResponse GetNotificationTemplateInfo(NotificationTemplateInfoRequest request)
        {
            NotificationTemplateInfoResponse response = new NotificationTemplateInfoResponse();
            OperationResult result = new OperationResult();

            response.NotificationTemplateInfo = _notificationsApp.GetNotificationTemplateInfo(request.TemplateId, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get Template For First Notification 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [SwaggerRequestExample(typeof(FirstNotificationTemplateRequest), typeof(GetFirstNotificationTemplateExample))]
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(FirstNotificationTemplateResponse))]
        [ActionName("GetFirstNotificationTemplate")]
        public FirstNotificationTemplateResponse GetFirstNotificationTemplate(FirstNotificationTemplateRequest request)
        {
            OperationResult result;

            NotificationTemplate template = _notificationsApp.GetFirstNotificationTemplate(request.PlanId, out result);

            FirstNotificationTemplateResponse response = new FirstNotificationTemplateResponse
            {
                TemplateId = template.TemplateId, 
                Template = template.EncryptedTemplateBody,
                Result = result
            };

            return response;
        }

        /// <summary>
        /// Get Welcome Kit Notifications for the period
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [SwaggerRequestExample(typeof(WKNotificationsRequest), typeof(WKNotificationsExample))]
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(WKNotificationsResponse))]
        [ActionName("GetWKNotifications")]
        public WKNotificationsResponse GetWKNotifications(WKNotificationsRequest request)
        {
            OperationResult result;

            List<WKNotification> notificationsList = _notificationsApp.GetWKNotifications(request.InitDate, request.EndDate, out result);

            WKNotificationsResponse response = new WKNotificationsResponse
            {
                NotificationsList = notificationsList,
                Result = result
            };

            return response;
        }

        /// <summary>
        /// Get Welcome Kit Notifications using Generic Template for the User - Contract
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [SwaggerRequestExample(typeof(WKGenericNotificationsRequest), typeof(WKGenericNotificationsExample))]
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(WKGenericNotificationsResponse))]
        [ActionName("GetWKGenericNotifications")]
        public WKGenericNotificationsResponse GetWKGenericNotifications(WKGenericNotificationsRequest request)
        {
            OperationResult result;

            List<WKNotification> notificationsList = _notificationsApp.GetWKGenericNotifications(request.ContractId, request.UserName, out result);

            WKGenericNotificationsResponse response = new WKGenericNotificationsResponse
            {
                NotificationsList = notificationsList,
                Result = result
            };

            return response;
        }

        /// <summary>
        /// Update the notification data 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [SwaggerRequestExample(typeof(UpdateNotificationRecordRequest), typeof(UpdateNotificationRecordExample))]
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(UpdateNotificationRecordResponse))]
        [ActionName("UpdateNotificationRecord")]
        public UpdateNotificationRecordResponse UpdateNotificationRecord(UpdateNotificationRecordRequest request)
        {
            OperationResult result;

            _notificationsApp.UpdateNotificationRecord(request.NotificacionWkId, request.UsedTemplate, out result);

            UpdateNotificationRecordResponse response = new UpdateNotificationRecordResponse
            {
                Result = result
            };

            return response;
        }

        /// <summary>
        /// Insert new notification 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [SwaggerRequestExample(typeof(InsertNotificationRequest), typeof(InsertNotificationExample))]
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(InsertNotificationResponse))]
        [ActionName("InsertNotification")]
        public InsertNotificationResponse InsertNotification(InsertNotificationRequest request)
        {
            int notificationId = _notificationsApp.InsertNotification(request.Notification, out OperationResult result);

            InsertNotificationResponse response = new InsertNotificationResponse
            {
                NotificationId = notificationId,
                Result = result
            };

            return response;
        }

        /// <summary>
        /// Insert new notification 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [SwaggerRequestExample(typeof(FilterContractsWithoutWKRequest), typeof(FilterContractsWithoutWKExample))]
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(FilterContractsWithoutWKResponse))]
        [ActionName("GetFilterContractsWithoutWK")]
        public FilterContractsWithoutWKResponse GetFilterContractsWithoutWK(FilterContractsWithoutWKRequest request)
        {
            OperationResult result;

            FilterContractsWithoutWKResponse response = new FilterContractsWithoutWKResponse
            {
                FilteredContracts = _notificationsApp.GetFilterContractsWithoutWK(request.Contracts, out result),
                Result = result
            };

            return response;
        }
    }
}