﻿using System;
using System.Web.Http;
using System.Web.Http.Description;
using ClientWithdrawalsApplication;
using ClientWithdrawalsMessages;
using CommonDomain;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of withdrawals
    /// </summary>
    [Authorize]
    public class ClientWithdrawalsController : ApiController
    {
        private readonly IClientWithdrawalsApp _withdrawalsApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="clientWithdrawalsApp"></param>
        public ClientWithdrawalsController(IClientWithdrawalsApp clientWithdrawalsApp)
        {
            _withdrawalsApp = clientWithdrawalsApp;
        }

        /// <summary>
        /// Insert partial withdrawal's operation log
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(PartialWithdrawalLogResponse))]
        public PartialWithdrawalLogResponse SetPartialWithdrawalLog(PartialWithdrawalLogRequest request)
        {
            var response = new PartialWithdrawalLogResponse
            {
                Result = _withdrawalsApp.SetPartialWithdrawalLog(request.ContractIdentifier, request.TransactionId, request.WithdrawalAmount, request.WithdrawalNumber, request.UserId)
            };

            return response;
        }

        /// <summary>
        /// Get withdrawal's parameter value
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(WithdrawalParameterResponse))]
        public WithdrawalParameterResponse GetWithdrawalsParameter(WithdrawalParameterRequest request)
        {
            OperationResult result = new OperationResult();
            var response = new WithdrawalParameterResponse
            {
                ValueParameter = _withdrawalsApp.GetWithdrawalsParameter(request.SegmentId, request.ParameterId, out result),
                Result = result
            };

            return response;
        }
    }
}
