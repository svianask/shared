﻿using CommonDomain;
using Contracts.Application;
using Contracts.Messages;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Contracts controller implementation 
    /// </summary>

    [Authorize]
    public class ContractsController : ApiController
    {
        private readonly IContractsApp _contractsApp;

        /// <summary>
        /// Controller constrcutor
        /// </summary>
        /// <param name="contractsApp"></param>
        public ContractsController(IContractsApp contractsApp)
        {
            _contractsApp = contractsApp;
        }

        /// <summary>
        /// Obtain updated contracts in the period
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(Updated_NewContractsResponse))]
        [ActionName("GetUpdatedAndNewContracts")]
        public Updated_NewContractsResponse GetUpdatedAndNewContracts(Updated_NewContractsRequest request)
        {
            Updated_NewContractsResponse response = new Updated_NewContractsResponse
            {
                UpdatedAndNewContracts = _contractsApp.GetUpdatedAndNewContracts(request.InitDate, request.EndDate, out OperationResult result),
                Result = result
            };

            return response;
        }

        /// <summary>
        /// Validate if the contracts are released
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ReleasedContractsResponse))]
        [ActionName("GetReleasedContracts")]
        public ReleasedContractsResponse GetReleasedContracts(ReleasedContractsRequest request)
        {
            ReleasedContractsResponse response = new ReleasedContractsResponse
            {
                ReleasedContracts = _contractsApp.GetReleasedContracts(request.ContractsId, out OperationResult result),
                Result = result
            };

            return response;
        }
        

    }
}
