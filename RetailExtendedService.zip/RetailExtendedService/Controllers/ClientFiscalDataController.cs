﻿using ClientFiscalDataMessages;
using CommonDomain;
using FiscalDataApplication;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    public class ClientFiscalDataController : ApiController
    {
        private readonly IFiscalDataApp _fiscalDataApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <typeparamref name="FiscalDataMapp"/>
        /// <param name="clientData"></param>
        public ClientFiscalDataController(IFiscalDataApp fiscalDataApp)
        {
            _fiscalDataApp = fiscalDataApp;
        }

        /// <summary>
        /// Get townships by zipcode, get a list
        /// </summary>
        /// <param name="req"></param>
        /// <returns>GetTownshipResponse</returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GetTownshipResponse))]
        [ActionName("GetTownshipsByZipCode")]
        public GetTownshipResponse GetTownshipsByZipCode(GetTownshipRequest req)
        {
            return new GetTownshipResponse
            {
                townships = _fiscalDataApp.GetTownshipsByZipCode(req.ZipCode,  out OperationResult result),
                Result = result
            };
        }


        /// <summary>
        /// Update Fiscal information  from Client by Rfc
        /// </summary>
        /// <param name="req">UpdateFiscalDataRequest contains Rfc Client</param>
        /// <returns>UpdateFiscalDataResponse</returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(UpdateFiscalDataResponse))]
        [ActionName("UpdateFiscalData")]
        public UpdateFiscalDataResponse UpdateFiscalData(UpdateFiscalDataRequest req)
        {

            this._fiscalDataApp.UpdateFiscalData(req, out OperationResult result);
            return new UpdateFiscalDataResponse
            {
                Result = result
            };
        }


        /// <summary>
        /// Update Fiscal information  from Client by Rfc
        /// </summary>
        /// <param name="req">UpdateFiscalDataRequest contains Rfc Client</param>
        /// <returns>UpdateFiscalDataResponse</returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GetFiscalDataResponse))]
        [ActionName("GetFiscalData")]
        public GetFiscalDataResponse GetFiscalData(GetFiscalDataRequest req)
        {

            return new GetFiscalDataResponse
            {
                fiscalData = this._fiscalDataApp.GetFiscalData(req.ClientId, out OperationResult result),
                Result = result
            };
        }

    }
}