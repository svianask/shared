﻿using ClientSurveyNPSApplication;
using ClientSurveyNPSMessages;
using CommonDomain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of client NPS.
    /// </summary>
    [Authorize]
    public class ClientSurveyNPSController : ApiController
    {
        private readonly IClientSurveyNPSApp _surveyNPSApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="clientSurveyNPS"></param>
        public ClientSurveyNPSController(IClientSurveyNPSApp clientSurveyNPS)
        {
            _surveyNPSApp = clientSurveyNPS;
        }

        /// <summary>
        /// Insert register log survey NPS.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ActionName("InsertClientSurveyLog")]
        [ResponseType(typeof(InsertClientSurveyLogResponse))]
        public InsertClientSurveyLogResponse InsertClientSurveyLog(InsertClientSurveyLogRequest request)
        {
            var response = new InsertClientSurveyLogResponse() { Result = _surveyNPSApp.InsertClientSurveyLog(request.RFC) };
            return response;
        }

        /// <summary>
        /// Validate apply survey NPS.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost] 
        [AllowAnonymous]
        [ActionName("GetDateLastApplyNPS")]
        [ResponseType(typeof(GetDateLastApplyNPSResponse))]
        public GetDateLastApplyNPSResponse GetDateLastApplyNPS(GetDateLastApplyNPSRequest request)
        {
            var response = new GetDateLastApplyNPSResponse()
            {
                DateApplySurveyNPS = _surveyNPSApp.GetDateLastApplyNPS(request.RFC, out OperationResult result),
                Result = result
            };

            return response;
        }
    }
}
