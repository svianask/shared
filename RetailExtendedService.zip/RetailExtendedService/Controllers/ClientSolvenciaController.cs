﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CommonDomain;
using ClientSolvenciaApplication;
using ClientSolvenciaMessages; 

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of solvencia
    /// </summary>
    [Authorize]
    public class ClientSolvenciaController : ApiController
    {
        private readonly IClientSolvenciaApp _solvenciaApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="solvenciaApp"></param>
        public ClientSolvenciaController(IClientSolvenciaApp solvenciaApp)
        {
            _solvenciaApp = solvenciaApp;
        }

        /// <summary>
        /// Get client solvencia basic info
        /// </summary>
        /// <param name="request">GetDocumentsContractRequest (contract)</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ClientSolvenciaBasicInfoResponse))]
        [ActionName("GetClientSolvenciaBasicInfo")]
        public ClientSolvenciaBasicInfoResponse GetClientSolvenciaBasicInfo(ClientSolvenciaBasicInfoRequest request)
        {
            return new ClientSolvenciaBasicInfoResponse
            {
                SolvenciaInfo = _solvenciaApp.GetClientSolvenciaBasicInfo(request.UserId, request.PortalId, out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Get Stories by Users
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ClientSolvencyStoriesResponse))]
        [ActionName("GetSolvencyStories")]
        public ClientSolvencyStoriesResponse GetClientSolvenciaBasicInfo()
        {
            return new ClientSolvencyStoriesResponse
            {
                Stories = _solvenciaApp.GetClientSolvencyStories(out OperationResult result),
                Result = result
            };
        }

    }
}
