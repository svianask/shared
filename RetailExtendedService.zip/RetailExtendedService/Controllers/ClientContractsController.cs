﻿using ClientContractsApplication;
using ClientContractsDomain.AgentsAggregate;
using ClientContractsMessages;
using CommonDomain;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of client contracts
    /// </summary>
    [Authorize]
    public class ClientContractsController : ApiController
    {
        private readonly IClientContractsApp _clientContractsApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="clientContractsApp"></param>
        public ClientContractsController(IClientContractsApp clientContractsApp)
        {
            _clientContractsApp = clientContractsApp;
        }

        /// <summary>
        /// Get image associated with the contract
        /// </summary>
        /// <param name="request">Request[]{ goalIds:short,... }</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GoalsImageResponse))]
        [ActionName("GetGoalsImage")]
        public GoalsImageResponse GetGoalsImage(GoalsImageRequest request)
        {
            GoalsImageResponse response = new GoalsImageResponse();
            OperationResult result = new OperationResult();

            response.Images =  _clientContractsApp.GetGoalsImage(request.GoalIds, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get the amount of life insurance associated with de contract
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(LifeInsuranceAmountResponse))]
        [ActionName("GetLifeInsuranceAmount")]
        public LifeInsuranceAmountResponse GetLifeInsuranceAmount(LifeInsuranceAmountRequest request)
        {
            LifeInsuranceAmountResponse response = new LifeInsuranceAmountResponse();
            OperationResult result = new OperationResult();

            response.LifeInsuranceAmount = _clientContractsApp.GetLifeInsuranceAmount(request.ContractId, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get the amount of life insurance associated with de contract
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(TypeOfContractResponse))]
        [ActionName("GetTypeOfContract")]
        public TypeOfContractResponse GetTypeOfContract(TypeOfContractRequest request)
        {
            TypeOfContractResponse response = new TypeOfContractResponse();
            OperationResult result = new OperationResult();

            response.TypeOfContract = _clientContractsApp.GetTypeOfContract(request.ContractId, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get extended information of one contract
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractExtBasicInfoResponse))]
        [ActionName("GetContractExtBasicInfo")]
        public ContractExtBasicInfoResponse GetContractExtBasicInfo(ContractExtBasicInfoRequest request)
        {
            ContractExtBasicInfoResponse response = new ContractExtBasicInfoResponse();
            OperationResult result = new OperationResult();

            response.ContractExtBasicInfo = _clientContractsApp.GetContractExtBasicInfo(request.ContractId, out result);
            response.Result = result;            

            return response;
        }

        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractBasicInfoResponse))]
        [ActionName("GetContractBasicInfo")]
        public ContractBasicInfoResponse GetContractBasicInfo(ContractBasicInfoRequest request)
        {
            ContractBasicInfoResponse response = new ContractBasicInfoResponse();
            OperationResult result = new OperationResult();

            response.ContractBasicInfo = _clientContractsApp.GetContractBasicInfo(request.ContractId, out result);
            response.Result = result;

            return response;
        }

        /// <summary>
        /// Get the segment to which the contract belongs
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractSegmentTypeResponse))]
        [ActionName("GetContractSegmentType")]
        public ContractSegmentTypeResponse GetContractSegmentType(ContractSegmentTypeRequest request)
        {
            ContractSegmentTypeResponse response = new ContractSegmentTypeResponse();
            OperationResult result = new OperationResult();

            response.SegmentOfContractType = _clientContractsApp.GetContractSegmentType(request.ContractId, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get the segment to which the contract belongs
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(FpContractsResponse))]
        [ActionName("GetFpContracts")]
        public FpContractsResponse GetFpContracts(FpContractsRequest request)
        {
            FpContractsResponse response = new FpContractsResponse();
            OperationResult result = new OperationResult();

            response.ClientContractsId = _clientContractsApp.GetFpContracts(request.ClientContractsId, request.FpEmail, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get the list of CAV funds
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractSegmentTypeResponse))]
        [ActionName("GetContractCAVFunds")]
        public ContractCAVFundsResponse GetContractCAVFunds()
        {
            ContractCAVFundsResponse response = new ContractCAVFundsResponse();
            OperationResult result = new OperationResult();

            response.ContractFundsCAV = _clientContractsApp.GetContractCAVFunds(out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get a specific parameter from SOC_CORE db
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractCoreParameterResponse))]
        [ActionName("GetContractCoreParameter")]
        public ContractCoreParameterResponse GetContractCoreParameter(ContractCoreParameterRequest request)
        {
            ContractCoreParameterResponse response = new ContractCoreParameterResponse();
            OperationResult result = new OperationResult();

            response.ParameterQueryResult = _clientContractsApp.GetContractCoreParameter(request.ContractId, request.PlanId, request.Platform, request.ParameterId, request.Attribute, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get a specific parameter from SOC_CORE db
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractCoreParameterResponse))]
        [ActionName("GetContractCoreParameterByValue")]
        public ContractCoreParameterResponse GetContractCoreParameterByValue(ContractCoreParameterValueRequest request)
        {
            ContractCoreParameterResponse response = new ContractCoreParameterResponse();
            OperationResult result = new OperationResult();

            response.ParameterQueryResult = _clientContractsApp.GetContractCoreParameter(request.ContractId, request.PlanId, request.Platform, request.ParameterId, request.Attribute, request.ReferencialValue, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get contract's pending and rejected contributions from DOMICILIATION
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractPendingContributionsResponse))]
        [ActionName("GetContractPendingContributions")]
        public ContractPendingContributionsResponse GetContractPendingContributions(ContractPendingContributionsRequest request)
        {
            ContractPendingContributionsResponse response = new ContractPendingContributionsResponse();
            OperationResult result = new OperationResult();

            response.ContractMovementsPendingDetail = _clientContractsApp.GetContractPendingContributions(request.AssociatedContracts, request.InitialDate, request.FinalDate, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get parameter BanksAllowedDomi from VinculacionDigital db
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractCoreParameterResponse))]
        [ActionName("GetBanksAllowedDomiParameter")]
        public BanksAllowedDomiParameterResponse GetBanksAllowedDomiParameter()
        {
            return new BanksAllowedDomiParameterResponse()
            {
                BanksAllowedDomiParameter = _clientContractsApp.GetBanksAllowedDomiParameter(out OperationResult result),
                Result = result
            }; 
        }

        /// <summary>
        /// Get parameter BanksAllowedTdc from VinculacionDigital db
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractCoreParameterResponse))]
        [ActionName("GetBanksAllowedTdcParameter")]
        public BanksAllowedTdcParameterResponse GetBanksAllowedTdcParameter()
        {
            return new BanksAllowedTdcParameterResponse()
            {
                Parameter = _clientContractsApp.GetBanksAllowedTdcParameter(out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Get Contract Agents
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GetContractAdviserResponse))]
        [ActionName("GetContractAdviserInfo")]
        public GetContractAdviserResponse GetContractAdviserInfo(GetContractAdviserRequest request)
        {
            return new GetContractAdviserResponse()
            {
                Adviser = _clientContractsApp.GetContractAdviserInfo(request.ContractId, out OperationResult result),
                Result = result
            };
        }

    }
}
