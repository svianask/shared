﻿using ClientDocumentsApplication;
using ClientDocumentsMessages;
using CommonDomain;
using System;
using System.Text;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of notifications
    /// </summary>
    [Authorize]
    public class ClientDocumentsController : ApiController
    {
        private readonly IClientDocumentsApp _documentsApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="documentsApp"></param>
        public ClientDocumentsController(IClientDocumentsApp documentsApp)
        {
            _documentsApp = documentsApp;
        }

        /// <summary>
        /// Get documents (edos. Cuenta, constancias) by contractId
        /// </summary>
        /// <param name="request">GetDocumentsContractRequest (contract)</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(DocumentsContractResponse))]
        [ActionName("GetDocumentsContract")]
        public DocumentsContractResponse GetDocumentsContract(DocumentsContractRequest request)
        {
            return new DocumentsContractResponse
            {
                ListDocuments = _documentsApp.GetDocumentsByContractId(request.ContractId, request.DocumentHandlingInstance, out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Get specific document for download
        /// </summary>
        /// <param name="request">GetDocumentFileRequest</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(DocumentFileResponse))]
        [ActionName("GetDocumentFileByDocumentId")]
        public DocumentFileResponse GetDocumentFileByUserDocumentId(DocumentFileRequest request)
        {
            return new DocumentFileResponse
            {
                FileDocument = _documentsApp.GetDocumentFileByUserDocumentId(request.UserName, request.DocumentId, request.DocumentName, request.DocumentHandlingInstance, out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Sets password to pdf document
        /// </summary>
        /// <param name="request">GetDocumentFileRequest</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(PasswordPdfDocumentResponse))]
        [ActionName("SetPasswordPdfDocument")]
        public PasswordPdfDocumentResponse SetPasswordPdfDocument(PasswordPdfDocumentRequest request)
        {
            var file = Convert.FromBase64String(request.EncodedFile);

            return new PasswordPdfDocumentResponse
            {
                FileEncrypted = _documentsApp.SetPasswordPdfDocument(file, request.Password, out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Send mail with document attached
        /// </summary>
        /// <param name="request">SendPdfDocumentRequest</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(SendContractDocumentResponse))]
        [ActionName("SendContractDocument")]
        public SendContractDocumentResponse SendContractDocument(SendPdfDocumentRequest request)
        {

            return new SendContractDocumentResponse
            {
                Result = _documentsApp.SendContractDocument(request.RFC, request.DocumentId, request.DocumentName, request.DocumentDesc, request.DocType, request.ProductName)
            };
        }


        /// <summary>
        /// Valida si el documento requiere notificacion de descarga.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(DocumentValidNotificationResponse))]
        [ActionName("ValidateDocumentToNotification")]
        public DocumentValidNotificationResponse ValidateDocumentToNotification(DocumentValidNotificationRequest request)
        {
            var response = new DocumentValidNotificationResponse
            {
                ExistResgister = _documentsApp.ValidateDocumentToNotification(request.DocumentId, request.Token, request.UserName, out OperationResult result),
                Result = result
            };

            return response;
        }


        /// <summary>
        /// Elimina los resgitros de la tabla que administra las notificaciones para los documentos descargados.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(DocumentCleanNotificationResponse))]
        [ActionName("DocumentCleanNotification")]
        public DocumentCleanNotificationResponse DocumentCleanNotification(DocumentCleanNotificationRequest request)
        {
            var response = new DocumentCleanNotificationResponse()
            {
                Result = _documentsApp.DocumentCleanNotification(request.UserName)
            };

            return response;
        }

    }
}
