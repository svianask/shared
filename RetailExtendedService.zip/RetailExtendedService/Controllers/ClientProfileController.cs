﻿using ClientProfileApplication;
using ClientProfileMessages;
using CommonDomain;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Cliet profile controller
    /// </summary>
    [Authorize]
    public class ClientProfileController : ApiController
    {
        private readonly IClientProfileApp _clientProfile;

        /// <summary>
        /// Client profile controller
        /// </summary>
        /// <param name="clientProfile"></param>
        public ClientProfileController(IClientProfileApp clientProfile)
        {
            _clientProfile = clientProfile;
        }

        /// <summary>
        /// Get profiling portfolios
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ProfilingPortfolioResponse))]
        [ActionName("GetProfilingPortfolio")]
        public ProfilingPortfolioResponse GetProfilingPortfolio()
        {

            return new ProfilingPortfolioResponse
            {                
                SalesPracticeProfiles = _clientProfile.GetProfilingPortfolio(out OperationResult result),
                Result = result
            };
        }

        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ClientSegmentResponse))]
        [ActionName("GetClientSegment")]
        public ClientSegmentResponse GetClientSegment(ClientSegmentRequest pRequest)
        {
            var segmentClient = _clientProfile.GetClientSegmentInfo(pRequest.rfc, out OperationResult result);

            return new ClientSegmentResponse
            {
                ClientSegment = new ClientSegmentModel
                {
                    Segmento = segmentClient.ClientSegmentDsc
                },
                Result = result
            };
        }
    }
}
