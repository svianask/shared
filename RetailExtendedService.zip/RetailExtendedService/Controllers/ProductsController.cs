﻿using CommonDomain;
using ProductsApplication;
using ProductsMessage;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of planes
    /// </summary>
    [Authorize]
    public class ProductsController : ApiController
    {
        private readonly IProductsApp _productsApp;


        /// <summary>
        /// OConstructor method with dependency injections
        /// </summary>
        /// <param name="productsApp"></param>
        public ProductsController(IProductsApp productsApp)
        {
            _productsApp = productsApp;
        }

        /// <summary>
        /// Get image associated with the contract
        /// </summary>
        /// <param name="request">Request[] { goalIds:short,... }</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(PlansResponse))]
        [ActionName("GetPlansById")]
        public PlansResponse GetPlansById(PlansRequest request)
        {
            PlansResponse response = new PlansResponse();
            OperationResult result = new OperationResult();

            response.Plans = _productsApp.GetPlansById(request.PlanIds, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get image associated with the contract
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(PlansResponse))]
        [ActionName("GetPlans")]
        public PlansResponse GetPlans()
        {
            PlansResponse response = new PlansResponse();
            OperationResult result = new OperationResult();

            response.Plans = _productsApp.GetPlans(out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get a list of plans that apply withdrawals 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GetPlansApplyWithdrawalsResponse))]
        [ActionName("GetPlansApplyWithdrawals")]
        public GetPlansApplyWithdrawalsResponse GetPlansApplyWithdrawals()
        {
            return new GetPlansApplyWithdrawalsResponse()
            {
                PlansWithdrawals = _productsApp.GetPlansApplyWithdrawals(out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Get minimun and maximun amounts
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GetAmountsTransactionPlanResponse))]
        [ActionName("GetAmountsTransactionPlan")]
        public GetAmountsTransactionPlanResponse GetAmountsTransactionPlan(GetAmountsTransactionPlanRequest request)
        {
            return new GetAmountsTransactionPlanResponse()
            {
                WithdrawalAmounts = _productsApp.GetAmountsTransactionPlan(request.PlanId, request.TransactionType, out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Get product comercial name by contract id
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ProductComercialNameResponse))]
        [ActionName("GetProductComercialNameByContractId")]
        public ProductComercialNameResponse GetProductComercialNameByContractId(ProductComercialNameRequest request)
        {
            ProductComercialNameResponse response = new ProductComercialNameResponse();
            OperationResult result = new OperationResult();

            response.ComercialName = _productsApp.GetProductComercialNameByContractId(request.ContractId, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get plans apply contribution from webconfig.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>list string</returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(GetProductsApplyContributionsResponse))]
        [ActionName("GetProductsApplyContributions")]
        public GetProductsApplyContributionsResponse GetProductsApplyContributions()
        {
            var response = new GetProductsApplyContributionsResponse();

            response.ProductsApplyContribution = _productsApp.GetPlansApplyContribution(out OperationResult result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Get plans apply transfers from webconfig.
        /// </summary>
        /// <returns>list string</returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(PlansApplyTransferResponse))]
        [ActionName("GetPlansApplyTransfer")]
        public PlansApplyTransferResponse GetPlansApplyTransfer()
        {
            var response = new PlansApplyTransferResponse()
            {
                PlansTransferApply = _productsApp.GetPlansApplyTransfer(out OperationResult result),
                Result = result
            };
            return response;
        }

        /// <summary>
        /// Validate that the request is within the transfer schedule
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ValidateScheduleTransferResponse))]
        [ActionName("ValidateScheduleTransfer")]
        public ValidateScheduleTransferResponse ValidateScheduleTransfer()
        {
            return new ValidateScheduleTransferResponse()
            {
                TransferSchedule = _productsApp.ValidateScheduleTransfer(out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Validate that the request is within the contribution schedule
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ValidateScheduleContributionResponse))]
        [ActionName("ValidateScheduleContribution")]
        public ValidateScheduleContributionResponse ValidateScheduleContribution()
        {
            return new ValidateScheduleContributionResponse()
            {
                ContributionSchedule = _productsApp.ValidateScheduleContribution(out OperationResult result),
                Result = result
            };
        }

        /// <summary>
        /// Validate that the request is within the contribution schedule
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ValidateScheduleWithdrawalsResponse))]
        [ActionName("ValidateScheduleWithdrawals")]
        public ValidateScheduleWithdrawalsResponse ValidateScheduleWithdrawals()
        {
            return new ValidateScheduleWithdrawalsResponse()
            {
                WithdrawalsSchedule = _productsApp.ValidateScheduleWithdrawals(out OperationResult result),
                Result = result
            };
        }
    }
}
