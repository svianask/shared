﻿using ClientDomiciliationApplication;
using ClientDomiciliationMessages;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Operations controller of domiciliation
    /// </summary>
    [Authorize]
    public class ClientDomiciliationController : ApiController
    {
        private readonly IClientDomiciliationApp _domiApp;

        /// <summary>
        /// Constructor method with dependency injections
        /// </summary>
        /// <param name="domiApp"></param>
        public ClientDomiciliationController(IClientDomiciliationApp domiApp)
        {
            _domiApp = domiApp;
        }

        /// <summary>
        /// Cancel contract's domiciliation in Domiciliation database
        /// </summary>
        /// <param name="request">CancelDomiciliationByContractRequest (contract)</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(CancelDomiciliationByContractRequest))]
        [ActionName("CancelDomiciliationByContract")]
        public CancelDomiciliationByContractResponse CancelDomiciliationByContract(CancelDomiciliationByContractRequest request)
        {
            return new CancelDomiciliationByContractResponse
            {
                Result = _domiApp.CancelDomiciliationByContract(request.ContractId, request.Reason, request.User)
            };
        }

        /// <summary>
        /// Retrive direct debit HSBC by contract
        /// </summary>
        /// <param name="request">DomiciliationsHsbcByContractRequest (contract)</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(DomiciliationsHsbcByContractRequest))]
        [ActionName("GetDomiciliationsHSBCByContract")]
        public DomiciliationsHsbcByContractResponse GetDomiciliationsHsbcByContract(DomiciliationsHsbcByContractRequest request)
        {
            var response = new DomiciliationsHsbcByContractResponse()
            {
                Domiciliation = _domiApp.GetDomiciliationsHsbcByContract(request.ContractId, request.ClientIdentifier, out var result),
                Result = result
            };
            return response;
        }

        /// <summary>
        /// Retrive direct debit Santander by contract
        /// </summary>
        /// <param name="request">DomiciliationsSantanderByContractRequest (contract)</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(DomiciliationsSantanderByContractRequest))]
        [ActionName("GetDomiciliationsSantanderByContract")]
        public DomiciliationsSantanderByContractResponse GetDomiciliationsSantanderByContract(DomiciliationsSantanderByContractRequest request)
        {
            var response = new DomiciliationsSantanderByContractResponse()
            {
                Domiciliation = _domiApp.GetDomiciliationsSantanderByContract(request.ContractId, request.ClientIdentifier, out var result),
                Result = result
            };
            return response;
        }


        /// <summary>
        /// Retrive salesforce last pending case
        /// </summary>
        /// <param name="request">SalesforceLastPendingCaseRequest (contract)</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(SalesforceLastPendingCaseRequest))]
        [ActionName("GetSalesforceLastPendingCase")]
        public SalesforceLastPendingCaseResponse GetSalesforceLastPendingCase(SalesforceLastPendingCaseRequest request)
        {
            var response = new SalesforceLastPendingCaseResponse()
            {
                SalesforceCases = _domiApp.GetSalesforceLastPendingCase(request.ContractId, request.Issue, request.OriginCase, request.Category, request.OriginType, request.CaseType, request.SubType, request.Tracing, out var result),
                Result = result
            };
            return response;
        }
    }
}
