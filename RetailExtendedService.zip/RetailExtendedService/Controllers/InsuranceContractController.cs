﻿using System.Web.Http;
using System.Web.Http.Description;
using CommonDomain;
using InsuranceContractApplication;
using InsuranceContractMessages;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Controller for the insurance product contract
    /// </summary>
    public class InsuranceContractController : ApiController
    {
        IInsuranceContractApp _insuranceContractApp;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="insuranceContractApp"></param>
        public InsuranceContractController(IInsuranceContractApp insuranceContractApp) 
        {
            _insuranceContractApp = insuranceContractApp;
        }

        /// <summary>
        /// Save insurance product information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(SaveInsuranceContractResponse))]
        [ActionName("SetInsuranceContract")]
        public SaveInsuranceContractResponse SetInsuranceContract(SaveInsuranceContractRequest request) 
        {
            SaveInsuranceContractResponse response = new SaveInsuranceContractResponse();
            response.Result = _insuranceContractApp.SetInsuranceContract(request.ContractId, request.PeriodId, request.FixedInsuranceCost, request.FactorUMA, request.YearlyInsurancePremium, request.MonthlyInsurancePremium, request.InitialEffectiveDate, request.FinalEffectiveDate);
            return response;
        }

        /// <summary>
        /// Obtains the parameters for calculating the insurance premium
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(InsurancePremiumParamsResponse))]
        [ActionName("GetInsurancePremiumParams")]
        public InsurancePremiumParamsResponse GetInsurancePremiumParams(InsurancePremiumParamsRequest request)
        {
            InsurancePremiumParamsResponse response = new InsurancePremiumParamsResponse();
            OperationResult result = new OperationResult();

            response.InsurancePremiumParams = _insuranceContractApp.GetInsurancePremiumParams(request.ContractId, out result);
            response.Result = result;
            return response;
        }

        /// <summary>
        /// Update insurance product information
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(UpdateInsuranceContractResponse))]
        [ActionName("UpdateInsuranceContract")]
        public UpdateInsuranceContractResponse UpdateInsuranceContract(UpdateInsuranceContractRequest request)
        {
            UpdateInsuranceContractResponse response = new UpdateInsuranceContractResponse();
            response.Result = _insuranceContractApp.UpdateInsuranceContract(request.ContractId, request.PeriodId, request.FixedInsuranceCost, request.FactorUMA, request.DailyUMA);
            return response;
        }
    }
}