﻿using ClientBehaviorApplication;
using ClientBehaviorMessages;
using CommonDomain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    /// <summary>
    /// Client Behavior information
    /// </summary>
    [Authorize]
    public class ClientBehaviorController : ApiController
    {
        private readonly IClientBehaviorApp _clientBehaviorApp;

        /// <summary>
        /// Client Behavior controller constructor
        /// </summary>
        /// <param name="clientBehaviorApp">injection of client behavior business logic</param>
        public ClientBehaviorController(IClientBehaviorApp clientBehaviorApp)
        {
            _clientBehaviorApp = clientBehaviorApp;
        }

        /// <summary>
        /// Obtain information related to client behavior
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ClientBehaviorDataResponse))]
        [ActionName("GetClientBehaviorData")]
        public ClientBehaviorDataResponse GetClientBehaviorData(ClientBehaviorDataRequest request)
        {

            ClientBehaviorDataResponse response = new ClientBehaviorDataResponse
            {
                ClientBehaviorData = _clientBehaviorApp.GetClientBehaviorData(request.RFC, out OperationResult result),
                Result = result
            };
            return response;
        }

        /// <summary>
        /// Update client behavior data 
        /// </summary>
        /// <param name="request">Client identifier and client behavior data</param>
        /// <returns>UpdateClientBehaviorDataResponse</returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(UpdateClientBehaviorDataResponse))]
        [ActionName("UpdateClientBehaviorData")]
        public UpdateClientBehaviorDataResponse UpdateClientBehaviorData(UpdateClientBehaviorDataRequest request)
        {
            _clientBehaviorApp.UpdateClientBehaviorData(request.ClientId, request.Motivation , out OperationResult result);

            return new UpdateClientBehaviorDataResponse
            {
                Result = result
            };
        }
    }
}
