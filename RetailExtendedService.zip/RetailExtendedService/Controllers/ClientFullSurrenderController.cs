﻿using ClientContractsMessages;
using ClientFullSurrenderApplication;
using ClientFullSurrenderMessages;
using CommonDomain;
using System.Web.Http;
using System.Web.Http.Description;

namespace RetailExtendedService.Controllers
{
    [Authorize]
    public class ClientFullSurrenderController : ApiController
    {
        IClientFullSurrenderApp _clientFullSurrender;

        public ClientFullSurrenderController(IClientFullSurrenderApp ClientFullSurrenderApp)
        {
            _clientFullSurrender = ClientFullSurrenderApp;
        }

        /// <summary>
        /// Get a specific parameter from SOC_CORE db
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractDeductibleZoneResponse))]
        [ActionName("GetContractDeductibleZone")]
        public ContractDeductibleZoneResponse GetContractDeductibleZone(ContractDeductibleZoneRequest request)
        {
            ContractDeductibleZoneResponse response = new ContractDeductibleZoneResponse();
            OperationResult result = new OperationResult();

            response.Zone = _clientFullSurrender.GetContractDeductibleZone(request.CityId, request.StateId, request.CountryId, out result);
            response.Result = result;
            return response;
        }

        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractDeductibleInfoResponse))]
        [ActionName("GetContractDeductibleInfo")]
        public ContractDeductibleInfoResponse GetContractDeductibleInfo(ContractDeductibleInfoRequest request)
        {
            ContractDeductibleInfoResponse response = new ContractDeductibleInfoResponse();
            OperationResult result = new OperationResult();

            response.ContractDeductibleInfo = _clientFullSurrender.GetContractDeductibleInfo(request.ContractId, out result);
            response.Result = result;
            return response;
        }

        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractDeductibleInfoHistoryResponse))]
        [ActionName("GetContractDeductibleInfoHistory")]
        public ContractDeductibleInfoHistoryResponse GetContractDeductibleInfoHistory(ContractDeductibleInfoHistoryRequest request)
        {
            ContractDeductibleInfoHistoryResponse response = new ContractDeductibleInfoHistoryResponse();
            OperationResult result = new OperationResult();

            response.ContractDeductibleInfo = _clientFullSurrender.GetContractDeductibleInfoHistory(request.ContractId, out result);
            response.Result = result;
            return response;
        }

      
        /// <summary>
        /// Update contract's insured amount for FullSurrender
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractInsuredAmountInfoResponse))]
        [ActionName("UpdateContractInsuredAmountInfo")]
        public ContractInsuredAmountInfoResponse UpdateContractInsuredAmountInfo(ContractInsuredAmountInfoRequest request)
        {
            ContractInsuredAmountInfoResponse response = new ContractInsuredAmountInfoResponse();

            response.Result = _clientFullSurrender.UpdateContractInsuredAmountInfo(request.ContractId, request.Origen);
            return response;
        }

        /// <summary>
        /// Get contract's extra info
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [ResponseType(typeof(ContractFullSurrenderExtraInfoResponse))]
        [ActionName("GetContractFullSurrenderExtraInfo")]
        public ContractFullSurrenderExtraInfoResponse GetContractFullSurrenderExtraInfo(ContractFullSurrenderExtraInfoRequest request)
        {
            ContractFullSurrenderExtraInfoResponse response = new ContractFullSurrenderExtraInfoResponse();
            OperationResult result = new OperationResult();

            response.ContractFullSurrenderExtraInfo = _clientFullSurrender.GetContractFullSurrenderExtraInfo(request.ContractId, out result);
            response.Result = result;
            return response;
        }
    }
}