Imports System
Imports System.Web

Namespace Skandia.Mx.DNN.Utilities

    'WebServiceUtility class provides the ability add information into the soap headers
    ' before calling the web service.
    Public NotInheritable Class WebServiceUtility

        Private Const UserNameHeaderKey As String = "UserName"
        Private Const ChannelHeaderKey As String = "Channel"
        Private Const RequestIdHeaderKey As String = "RequestId"

        Private Sub WebServiceUtility()

        End Sub

        ' Method to populate the Soap header before calling the web service.
        ' <param name="userName">
        ' User login id used to login to Global Bank.
        ' </param>
        ' <param name="channel">
        ' Channel used to access Global Bank.
        ' </param>
        ' <returns>
        ' Returns an object array that can be assigned to the Soap Header before
        ' calling the web method on the web service.
        ' </returns>

        Public Shared Function PopulateHeaderValues() As Object()
            Dim headerValues(6) As Object

            Dim currAppUser As String = DotNetNuke.Entities.Users.UserController.GetCurrentUserInfo.Username
            Dim headerArray1(1) As Object
            headerArray1(0) = "AppUser"
            headerArray1(1) = currAppUser
            headerValues(0) = headerArray1

            Dim currUserIp As String = HttpContext.Current.Request.UserHostAddress
            Dim headerArray2(1) As Object
            headerArray2(0) = "AppUserIp"
            headerArray2(1) = currUserIp
            headerValues(1) = headerArray2

            Dim currAppComp As String = DotNetNuke.Entities.Tabs.TabController.CurrentPage.TabName
            Dim headerArray3(1) As Object
            headerArray3(0) = "AppComponent"
            headerArray3(1) = currAppComp
            headerValues(2) = headerArray3

            Dim appChannel As String = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings.PortalName
            Dim headerArray4(1) As Object
            headerArray4(0) = "AppChannel"
            headerArray4(1) = appChannel
            headerValues(3) = headerArray4

            Dim currentContract As System.Collections.Specialized.ListDictionary = CType(HttpContext.Current.Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary)

            Dim context1 As String = String.Empty
            Dim context2 As String = String.Empty
            Dim context3 As String = String.Empty

            If Not currentContract Is Nothing Then
                context1 = currentContract.Item("ContractNumber")
                context2 = currentContract.Item("ContractPlan")
                context3 = currentContract.Item("ClientRFCCURP")
            End If

            Dim headerArray5(1) As Object
            headerArray5(0) = "Context1"
            headerArray5(1) = context1
            headerValues(4) = headerArray5

            Dim headerArray6(1) As Object
            headerArray6(0) = "Context2"
            headerArray6(1) = context2
            headerValues(5) = headerArray6

            Dim headerArray7(1) As Object
            headerArray7(0) = "Context3"
            headerArray7(1) = context3
            headerValues(6) = headerArray7

            Return headerValues
        End Function

        'SE DEBE ELIMINAR DESPUES DE REALIZAR AJUSTES RAMMIG 2010-08-13
        Public Shared Function PopulateHeaderValues(ByVal userName As String, ByVal channel As String) As Object()
            Dim headerValues(2) As Object

            Dim headerArray1(1) As Object
            headerArray1(0) = UserNameHeaderKey
            headerArray1(1) = userName
            headerValues(0) = headerArray1

            Dim headerArray2(1) As Object
            headerArray2(0) = ChannelHeaderKey
            headerArray2(1) = channel
            headerValues(1) = headerArray2

            Dim headerArray3(1) As Object
            headerArray3(0) = RequestIdHeaderKey
            headerArray3(1) = Guid.NewGuid().ToString()
            headerValues(2) = headerArray3

            Return headerValues
        End Function
    End Class

End Namespace



