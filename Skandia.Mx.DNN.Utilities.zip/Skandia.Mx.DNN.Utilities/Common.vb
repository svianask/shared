﻿Imports Telerik.WebControls

Namespace Skandia.Mx.DNN.Utilities

    Public Class Common

        Public Shared Function GetChannelName(ByVal portalId As Integer) As String

            Select Case portalId

                Case Convert.ToInt32(Portals.ClientsPortal)
                    Return Portals.ClientsPortal.ToString()

                Case Convert.ToInt32(Portals.SkandiaOperationCenter)
                    Return Portals.SkandiaOperationCenter.ToString()

                Case Else
                    Return String.Empty

            End Select

        End Function


        Public Shared Sub DisplayMenu(ByVal strMenu As ArrayList, ByRef menu As RadPanelbar)
            For Each strItem As String In strMenu
                Dim item As String = strItem.Split("|")(0)
                Dim visibility As String = strItem.Split("|")(1)
                Dim prad As PanelItem = menu.FindPanelItemById(item)
                If Not prad Is Nothing Then
                    If visibility = "none" Then
                        prad.Visible = False
                    Else
                        prad.Visible = True
                    End If
                End If

            Next
        End Sub



        Public Shared Function MenuAll() As ArrayList
            Dim lstMenuSK As ArrayList = New ArrayList()


            lstMenuSK.Add("P_83| ") ''83	Actualizar E-mail
            lstMenuSK.Add("P_87| ") ''87	Avance de Ahorro
            lstMenuSK.Add("P_100| ") ''100	BulkReg Users
            lstMenuSK.Add("P_90| ") ''90	Cambiar Contraseña
            lstMenuSK.Add("P_81| ") ''81	Consulta de Documentos
            lstMenuSK.Add("P_78| ") ''78	Consultas
            lstMenuSK.Add("P_80| ") ''80	Documentos en Línea
            lstMenuSK.Add("P_89| ") ''89	Historia Domiciliación
            lstMenuSK.Add("P_86| ") ''86	Información General
            lstMenuSK.Add("P_95| ") ''95	Inicio
            lstMenuSK.Add("P_98| ") ''98	IWeb
            lstMenuSK.Add("P_77| ") ''77	Mis contratos
            lstMenuSK.Add("P_91| ") ''91	Monitor
            lstMenuSK.Add("P_84| ") ''84	Portafolio de Inversión
            lstMenuSK.Add("P_85| ") ''85	Resumen de Transacciones
            lstMenuSK.Add("P_92| ") ''92	Skandia Investor House
            lstMenuSK.Add("P_82| ") ''82	Suscripción/Cancelación
            lstMenuSK.Add("P_93| ") ''93	Términos y Condiciones de Uso
            lstMenuSK.Add("P_233| ") ''233	Transacciones
            lstMenuSK.Add("P_234| ") ''234	Transferencia de Fondos
            lstMenuSK.Add("P_99| ") ''99	Usuarios en Línea
            lstMenuSK.Add("P_79| ") ''79	Valuación

            Return lstMenuSK

        End Function


        Public Shared Function MenuGl() As ArrayList
            Dim arrMenuGlobalTrus As ArrayList = New ArrayList()


            arrMenuGlobalTrus.Add("P_83|none") ''83	Actualizar E-mail
            arrMenuGlobalTrus.Add("P_87|none") ''87	Avance de Ahorro
            arrMenuGlobalTrus.Add("P_100|none") ''100	BulkReg Users
            arrMenuGlobalTrus.Add("P_90| ") ''90	Cambiar Contraseña
            arrMenuGlobalTrus.Add("P_81| ") ''81	Consulta de Documentos
            arrMenuGlobalTrus.Add("P_78| ") ''78	Consultas
            arrMenuGlobalTrus.Add("P_80| ") ''80	Documentos en Línea
            arrMenuGlobalTrus.Add("P_89|none") ''89	Historia Domiciliación
            arrMenuGlobalTrus.Add("P_86| ") ''86	Información General
            arrMenuGlobalTrus.Add("P_95| ") ''95	Inicio
            arrMenuGlobalTrus.Add("P_98|none") ''98	IWeb
            arrMenuGlobalTrus.Add("P_77| ") ''77	Mis contratos
            arrMenuGlobalTrus.Add("P_91|none") ''91	Monitor
            arrMenuGlobalTrus.Add("P_84|none") ''84	Portafolio de Inversión
            arrMenuGlobalTrus.Add("P_85|none") ''85	Resumen de Transacciones
            arrMenuGlobalTrus.Add("P_92|none") ''92	Skandia Investor House
            arrMenuGlobalTrus.Add("P_82|none") ''82	Suscripción/Cancelación
            arrMenuGlobalTrus.Add("P_93| ") ''93	Términos y Condiciones de Uso
            arrMenuGlobalTrus.Add("P_233|none") ''233	Transacciones
            arrMenuGlobalTrus.Add("P_234|none") ''234	Transferencia de Fondos
            arrMenuGlobalTrus.Add("P_99| ") ''99	Usuarios en Línea
            arrMenuGlobalTrus.Add("P_79|none") ''79	Valuación

            Return arrMenuGlobalTrus

        End Function


        Private Enum Portals
            ClientsPortal = 9
            SkandiaOperationCenter = 3
        End Enum

    End Class

    Public Enum enumAuthorizationType
        JointContract = 1
        MinimumAmount = 2
        ThirdPersonAccount = 3
        MaximumSurrenderAmountByDay = 4
        UndocumentedContract = 5
    End Enum

    Public Enum enumAuthorizationStatus
        Inactive = 0
        Active = 1
        Applied = 2
        Expired = 3
    End Enum

End Namespace