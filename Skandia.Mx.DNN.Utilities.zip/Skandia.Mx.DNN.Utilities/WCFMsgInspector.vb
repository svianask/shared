﻿Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.ServiceModel
Imports System.ServiceModel.Dispatcher
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Description
Imports System.ServiceModel.Configuration

Namespace Skandia.Mx.DNN.Utilities
    Public Class WCFMsgInspector
        Implements IClientMessageInspector

        Public Sub AfterReceiveReply(ByRef reply As Message, ByVal correlationState As Object) Implements IClientMessageInspector.AfterReceiveReply
        End Sub

        Public Function BeforeSendRequest(ByRef request As Channels.Message, ByVal channel As IClientChannel) As Object Implements IClientMessageInspector.BeforeSendRequest

            Dim currAppUser As String = String.Empty
            If (Not DotNetNuke.Entities.Users.UserController.GetCurrentUserInfo Is Nothing) Then
                currAppUser = DotNetNuke.Entities.Users.UserController.GetCurrentUserInfo.Username
            End If
            Dim mhAppUser As New MessageHeader(Of String)(currAppUser)
            request.Headers.Add(mhAppUser.GetUntypedHeader("AppUser", "ns"))

            Dim currAppComp As String = String.Empty
            If (Not DotNetNuke.Entities.Tabs.TabController.CurrentPage Is Nothing) Then
                currAppComp = DotNetNuke.Entities.Tabs.TabController.CurrentPage.TabName
            End If
            Dim mhAppComp As New MessageHeader(Of String)(currAppComp)
            request.Headers.Add(mhAppComp.GetUntypedHeader("AppComponent", "ns"))

            Dim appChannel As String = String.Empty
            If (Not DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings Is Nothing) Then
                appChannel = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings.PortalName
            End If
            Dim mhAppChannel As New MessageHeader(Of String)(appChannel)
            request.Headers.Add(mhAppChannel.GetUntypedHeader("AppChannel", "ns"))

            Dim currUserIp As String = String.Empty
            If (Not HttpContext.Current Is Nothing) Then
                currUserIp = HttpContext.Current.Request.UserHostAddress
            End If
            Dim mhUserIp As New MessageHeader(Of String)(currUserIp)
            request.Headers.Add(mhUserIp.GetUntypedHeader("AppUserIp", "ns"))

            Dim currentContract As System.Collections.Specialized.ListDictionary = Nothing
            If (Not HttpContext.Current Is Nothing) Then
                currentContract = CType(HttpContext.Current.Session.Item("_ContractSelected"), System.Collections.Specialized.ListDictionary)
            End If

            Dim context1 As String = String.Empty
            Dim context2 As String = String.Empty
            Dim context3 As String = String.Empty
            'Dim context4 As String = String.Empty

            If Not currentContract Is Nothing Then
                context1 = currentContract.Item("ContractNumber")
                context2 = currentContract.Item("ContractPlan")
                context3 = currentContract.Item("ClientRFCCURP")
                'context4 = currentContract.Item("ClientRFCCURP")
            End If

            Dim mhContext1 As New MessageHeader(Of String)(context1)
            request.Headers.Add(mhContext1.GetUntypedHeader("Context1", "ns"))

            Dim mhContext2 As New MessageHeader(Of String)(context2)
            request.Headers.Add(mhContext2.GetUntypedHeader("Context2", "ns"))

            Dim mhContext3 As New MessageHeader(Of String)(context3)
            request.Headers.Add(mhContext3.GetUntypedHeader("Context3", "ns"))

            'Dim mhContext4 As New MessageHeader(Of String)(context4)
            'request.Headers.Add(mhContext4.GetUntypedHeader("Context4", "ns"))

            Return Nothing

        End Function

    End Class


    Public Class AuditLogBehavior
        Implements IEndpointBehavior

        Public Sub AddBindingParameters(ByVal endpoint As ServiceEndpoint, ByVal bindingParameters As BindingParameterCollection) Implements IEndpointBehavior.AddBindingParameters
        End Sub

        Public Sub ApplyClientBehavior(ByVal endpoint As ServiceEndpoint, ByVal clientRuntime As ClientRuntime) Implements IEndpointBehavior.ApplyClientBehavior
            Dim inspector As New WCFMsgInspector()
            clientRuntime.MessageInspectors.Add(inspector)
        End Sub

        Public Sub ApplyDispatchBehavior(ByVal endpoint As ServiceEndpoint, ByVal endpointDispatcher As EndpointDispatcher) Implements IEndpointBehavior.ApplyDispatchBehavior
        End Sub

        Public Sub Validate(ByVal endpoint As ServiceEndpoint) Implements IEndpointBehavior.Validate
        End Sub

    End Class

    Public Class AuditLogBehaviorExtensionElement
        Inherits BehaviorExtensionElement


        Public Overrides ReadOnly Property BehaviorType() As System.Type
            Get
                Return GetType(AuditLogBehavior)
            End Get
        End Property

        Protected Overrides Function CreateBehavior() As Object
            Return New AuditLogBehavior()
        End Function
    End Class

End Namespace