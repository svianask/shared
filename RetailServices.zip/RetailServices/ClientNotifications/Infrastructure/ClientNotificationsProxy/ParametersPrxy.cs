﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using SeriLogH;
using System;
using System.Configuration;
using static ClientNotificationsDomain.Enumerators;

namespace ClientNotificationsProxy
{
    public class ParametersPrxy : IParametersPrxy
    {
        private readonly ISeriLogHelper _log;
        private IProxyEngine _proxyEngine;

        public ParametersPrxy(ISeriLogHelper seriLogHelper, IProxyEngine proxyEngine)
        {
            _log = seriLogHelper;
            _proxyEngine = proxyEngine;
        }

        public string GetStringParameter(string parameterId, out OperationResult result)
        {
            PrxyStringParameterResponse response;
            string templateBody;

            if (string.IsNullOrEmpty(parameterId)) throw new Exception("El identificador del parámetro no puede ser nulo.");

            string url = ConfigurationManager.AppSettings["BursinessParameters:URLService"].ToString() + "Query/GetStringParameter";

            _log.Info("Generación del filtro para el requerimiento del parámetro.");
            PrxyStringParameterRequest request = new PrxyStringParameterRequest
            {
                ParameterId = parameterId,
                ContractId = "",
                PlanId = "",
                ProductType = ProductType.GlobalTrust.ToString(),
                ContractAttributeType = ContractAttributeType.Standar.ToString()
            };
            _log.Debug("Filtro para el requerimiento del parámetro: {cntx}", request);

            _log.Info("Envío de la solicitud de requerimiento del parámetros.");
            string jsonResult = _proxyEngine.SendMSRequestJson(url, request, out result);
            _log.Debug("Resultado de la consulta del parámetro: {cntx}", result);

            if (result.Successful)
            {
                response = JsonConvert.DeserializeObject<PrxyStringParameterResponse>(jsonResult);

                if (!response.Result.Successful) { throw new ApplicationException("Error al consumir el servicio " + url + " - " + response.Result.SystemMessages[0]); }

                templateBody = response.StringParameter.Value;
            }
            else
            {
                result.Successful = false;
                throw new Exception("Error al consumir el servicio " + url + " - " + result.SystemMessages[0]);
            }

            return templateBody;
        }
    }
}