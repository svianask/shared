﻿using Common.Domain;

namespace ClientNotificationsProxy
{
    public interface IParametersPrxy
    {
        string GetStringParameter(string parameterId, out OperationResult result);
    }
}
