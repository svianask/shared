﻿using Common.Domain;

namespace ClientNotificationsProxy
{
    public interface IClientNotificatoinsPrxy
    {
        void SendNotification(ClientNotificationsPrxyRequest request, string provider, string configuracion, string idPlantilla, out OperationResult result);
    }
}
