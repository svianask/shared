﻿using Common.Domain;
using Newtonsoft.Json;
using Proxy;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using static ClientNotificationsDomain.Enumerators;

namespace ClientNotificationsProxy
{
    public class ClientNotificatoinsPrxy : IClientNotificatoinsPrxy
    {
        private readonly ISeriLogHelper _log;
        private readonly IProxyEngine _proxyEngine;

        public ClientNotificatoinsPrxy(ISeriLogHelper seriLogHelper, IProxyEngine proxyEngine)
        {
            _log = seriLogHelper;
            _proxyEngine = proxyEngine;
        }

        public void SendNotification(ClientNotificationsPrxyRequest request, string provider, string configuracion, string idPlantilla, out OperationResult result)
        {
            byte[] bodyInBytes = Convert.FromBase64String(request.Template);
            string templateBody = Encoding.UTF8.GetString(bodyInBytes);

            string url = ConfigurationManager.AppSettings["ServiceNotificationApiUrl"].ToString() + "SendMailExpress";

            result = new OperationResult();

            _log.Info("Generación del cuerpo de la llamada al servicio de notificaciones.");
            SendInBluePrxyRequest requestToSendInBlue = new SendInBluePrxyRequest
            {
                Provider = provider,                // "Sendinblue",
                Asunto = request.Subject,
                Configuracion = configuracion,      // "{ SendMailId: '1' }",
                IdPlantilla = idPlantilla,          // "1",
                Plantillahtml = ApplyDataOnTemplate(templateBody, request.TemplateData),
                Sender = new Address
                {
                    Email = request.SenderData.Email,
                    Name = request.SenderData.Name,
                    AtributosPlantillaHTML = null,
                    Files = null
                },
                Destinatarios = new List<Address>
                {
                    new Address
                    {
                        Email = request.ToEmails[0],
                        Name = "",
                        AtributosPlantillaHTML = null,
                        Files = null
                    }
                },
                CC = new List<Address>(),
                BCC = new List<Address>(),
                AttachedFiles = null
            };
            _log.Debug("Plantilla del cuerpo de la llamada: {cntx}", requestToSendInBlue);

            _log.Info("Envío de la solicitud de notificación al sistema de SendingBlue.");
            string JsonResult = _proxyEngine.SendMSRequestJson(url, requestToSendInBlue, out result);
            _log.Debug("Respuesta del servicio: {cntx}", result);

            if (result.Successful)
            {
                ClientNotificationsPrxyResponse response = JsonConvert.DeserializeObject<ClientNotificationsPrxyResponse>(JsonResult);

                if (!response.successful) { throw new Exception("Error al consumir el servicio de envío de notificaciones: " + url + " - " + response.systemMessages); }
            }
            else
            {
                result.Successful = false;

                throw new Exception("Error al consumir el servicio de envío de notificaciones: " + url + " - " + result.SystemMessages[0]);
            }
        }

        private string ApplyDataOnTemplate(string template, Dictionary<string, string> templateData)
        {
            _log.Info("Aplicación de la data en el template: {cntx}", templateData);
            foreach (string key in templateData.Keys)
            {
                template = template.Replace("{%%" + key + "%%}", templateData[key]);
            }

            template = template.Replace("{%%", "").Replace("%%}", "");

            _log.Debug("Plantilla final: {cntx}", template);

            return template;
        }
    }
}
