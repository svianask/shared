﻿using ClientNotificationsDomain.ClientNotificationsAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientNotificationsProxy
{
    public class ClientNotificationsPrxyRequest
    {
        public string Subject;
        public SenderData SenderData;
        public List<string> ToEmails;
        public List<string> ToCcEmails;
        public string Template;
        public Dictionary<string, string> TemplateData;
        public List<AttachmentFile> Attachments;
    }

    public class ClientNotificationsPrxyResponse
    {
        public bool successful { get; set; }
        public string MessageId { get; set; }
        public string systemMessages { get; set; }
    }

    public class PrxySenderData
    {
        public string Name;
        public string Email;
    }

    public class SendInBluePrxyRequest
    {
        public string Provider;
        public string Asunto;
        public string Configuracion; // "{ SendMailId: '1' }"
        public string IdPlantilla;
        public string Plantillahtml;
        public Address Sender;
        public List<Address> Destinatarios;
        public List<Address> CC;
        public List<Address> BCC;
        public List<AttachedFile> AttachedFiles;
    }

    public class Address
    {
        public string Name;
        public string Email;
        public Dictionary <string, string> AtributosPlantillaHTML;
        public int[] Files;
    }

    public class AttachedFile
    {
        public string Name;
        public string ContentByte;
        public string ContentBase64;
        public string Url;
    }
}
