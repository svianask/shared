﻿namespace ClientNotificationsDomain
{
    public class Enumerators
    {
        public enum ParametersType : int
        {
            /// <summary>
            /// Parámetro que guarda la data del remitente 
            /// </summary>
            FNPROVIDER 
                
            /// <summary>
            /// Configuración utilizada para el envío del correo
            /// </summary>
            , FNCONFIG
                
            /// <summary>
            /// Id del template utilizado
            /// </summary>
            , FNIDPLANTI
        }

        public enum ContractAttributeType
        {
            /// <summary>
            /// Standar Contract
            /// </summary>
            Standar = 5,
            /// <summary>
            /// Vanitiy Contract
            /// </summary>
            Vanity = 10
        }

        /// <summary>
        /// Type of product
        /// </summary>
        public enum ProductType
        {
            GlobalTrust = 5,
            RegularSaving = 10,
            CajaAhorro = 15,
            FondoAhorro = 20,
            PlanPensiones = 25,
            GreenLight = 30,
            RetailMass = 35
        }
    }
}
