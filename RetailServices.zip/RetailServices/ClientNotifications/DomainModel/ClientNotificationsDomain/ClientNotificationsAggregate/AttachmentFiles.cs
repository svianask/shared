﻿namespace ClientNotificationsDomain.ClientNotificationsAggregate
{
    public class AttachmentFile
    {
        public string Name { get; set; }
        public byte[] Content { get; set; }
    }
}
