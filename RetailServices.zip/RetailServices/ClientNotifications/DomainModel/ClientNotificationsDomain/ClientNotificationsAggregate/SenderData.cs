﻿namespace ClientNotificationsDomain.ClientNotificationsAggregate
{
    public class SenderData
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
