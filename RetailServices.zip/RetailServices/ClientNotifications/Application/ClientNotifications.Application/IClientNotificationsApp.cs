﻿using ClientNotificationsDomain.ClientNotificationsAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientNotifications.Application
{
    public interface IClientNotificationsApp
    {
        void SendNotification(string subject, SenderData senderData, List<string> toEmails, List<string> toCcEmails, string template, Dictionary<string, string> templateData, List<AttachmentFile> attachments, out OperationResult result);
    }
}
