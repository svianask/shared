﻿using ClientNotificationsDomain.ClientNotificationsAggregate;
using ClientNotificationsProxy;
using Common.Domain;
using Newtonsoft.Json;
using SeriLogH;
using System;
using System.Collections.Generic;
using static ClientNotificationsDomain.Enumerators;

namespace ClientNotifications.Application
{
    public class ClientNotificationsApp : IClientNotificationsApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientNotificatoinsPrxy _clientNotificationsPrxy;
        private readonly IParametersPrxy _parametersPrxy;

        public ClientNotificationsApp(ISeriLogHelper seriLogHelper, IClientNotificatoinsPrxy clientNotificationsPrxy, IParametersPrxy parametersPrxy)
        {
            _log = seriLogHelper;
            _clientNotificationsPrxy = clientNotificationsPrxy;
            _parametersPrxy = parametersPrxy;
        }

        public void SendNotification(string subject, SenderData senderData, List<string> toEmails, List<string> toCcEmails, string template, Dictionary<string, string> templateData, List<AttachmentFile> attachments, out OperationResult result)
        {
            string provider, configuracion, idPlantilla;
            ClientNotificationsPrxyRequest request;

            result = new OperationResult { Successful = true };

            try
            {
                _log.Info("Recuperación de los parámetros útiles para el envío de notificaciones.");
                provider = _parametersPrxy.GetStringParameter(ParametersType.FNPROVIDER.ToString(), out result);
                configuracion = _parametersPrxy.GetStringParameter(ParametersType.FNCONFIG.ToString(), out result);
                idPlantilla = _parametersPrxy.GetStringParameter(ParametersType.FNIDPLANTI.ToString(), out result);
                _log.Debug("Data recuperada desde parámetro: {cntx}", new {provider, configuracion, idPlantilla});

                _log.Info("Generando el cuerpo de la llamada para el envío de la notificación: {cntx}", 
                    new
                    {
                        subject,
                        senderData,
                        toEmails,
                        toCcEmails,
                        template,
                        templateData,
                        attachments
                    });
                request = new ClientNotificationsPrxyRequest
                {
                    Subject = subject,
                    SenderData = senderData,
                    ToEmails = toEmails,
                    ToCcEmails = toCcEmails,
                    Template = template,
                    TemplateData = templateData,
                    Attachments = attachments
                };
                _log.Debug("Resultado de la generación del cuerpo de llamada al envío de notificación: {cntx}", request);

                _log.Info("Envío de la notificación con el parámetro seleccionado: {cntx}", new { request, provider, configuracion, idPlantilla });
                _clientNotificationsPrxy.SendNotification(request, provider, configuracion, idPlantilla, out result);
                _log.Debug("Resultado de la llamada al envío de notificación: {cntx}", result);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "(SendNotification) - Error al enviar la notificación con los datos {cntx}", new { subject, senderData, toEmails, toCcEmails, template, templateData, attachments });

                result.Successful = false;

                result.SystemMessages.Add(
                    new SystemMessage { 
                        Message = "(SendNotification) - Error al enviar la notificación con los datos.",
                        MessageType = SystemMessageTypes.Error 
                    }
                );
            }
        }
    }
}
