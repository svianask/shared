﻿using Common.Domain;

namespace ClientNotifications.Message
{
    public class ClientNotificationsResponse
    {
        public OperationResult Result { get; set; }
    }
}
