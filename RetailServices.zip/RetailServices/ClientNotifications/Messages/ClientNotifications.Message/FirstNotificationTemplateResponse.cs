﻿using Common.Domain;

namespace ClientNotifications.Message
{
    public class FirstNotificationTemplateResponse
    {
        public string TemplateId;

        public OperationResult Result;
    }
}
