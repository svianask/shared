﻿namespace ClientNotifications.Message
{
    public class FirstNotificationTemplateRequest
    {
        public string PlanId;
    }
}
