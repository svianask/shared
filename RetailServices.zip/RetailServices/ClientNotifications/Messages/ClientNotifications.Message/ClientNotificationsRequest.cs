﻿using ClientNotificationsDomain.ClientNotificationsAggregate;
using System.Collections.Generic;

namespace ClientNotifications.Message
{
    public class ClientNotificationsRequest
    {
        public string Subject { get; set; }
        public SenderData SenderData { get; set; }
        public List<string> ToEmails { get; set; }
        public List<string> ToCcEmails { get; set; }
        public string Template { get; set; }
        public Dictionary<string, string> TemplateData { get; set; }
        public List<AttachmentFile> Attachments { get; set; }
    }
}
