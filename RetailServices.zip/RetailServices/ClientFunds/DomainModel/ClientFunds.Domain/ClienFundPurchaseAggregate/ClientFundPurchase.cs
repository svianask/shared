﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFunds.Domain.ClienFundPurchaseAggregate
{
    public class ClientFundPurchase : Entity<string>, IRootAggregate
    {
        private bool _buyAvailable;
        private bool _saleAvailable;

        //Operator (quien lo opera o lo emite)
        private int _operatorId;
        private string _operatorName;

        //configuration
        private int _clasificationId;
        private string _clasificationName;
        private int _typeId;
        private string _typeName;

        //person config
        private int _personTypeId;
        private string _personTypeName;

        //divisa
        private int _currencyTypeId;
        private string _currencyTypeName;

        private ClientFundPurchase(string fundId)
        {
            Id = fundId;
        }

        public bool BuyAvailable => _buyAvailable;
        public bool SaleAvailable => _saleAvailable;
        public int OperatorId => _operatorId;
        public string OperatorName => _operatorName;
        public int ClasificationId => _clasificationId;
        public string ClasificationName => _clasificationName;
        public int TypeId => _typeId;
        public string TypeName => _typeName;
        public int PersonTypeId => _personTypeId;
        public string PersonTypeName => _personTypeName;
        public int CurrencyTypeId => _currencyTypeId;
        public string CurrencyTypeName => _currencyTypeName;

        public static ClientFundPurchase Create(string fundId)
        {
            return new ClientFundPurchase(fundId);
        }

        public ClientFundPurchase SetOperator(int operatorId, string operatorName)
        {
            if (operatorId < 0) { throw new ArgumentException("El id del emisor debe ser mayor a 0"); }

            _operatorId = operatorId;
            _operatorName = operatorName;

            return this;
        }

        public ClientFundPurchase SetCurrency(int currencyTypeId, string currencyTypeName)
        {
            if (currencyTypeId < 0) { throw new ArgumentException("El id de la divisa debe ser mayor a 0"); }

            _currencyTypeId = currencyTypeId;
            _currencyTypeName = currencyTypeName;

            return this;
        }

        public ClientFundPurchase SetPurchaseConfiguration(int typeId, string typeName, int clasificationId, string clasificationName)
        {
            _typeId = typeId;
            _typeName = typeName;
            _clasificationId = clasificationId;
            _clasificationName = clasificationName;

            return this;
        }

        public ClientFundPurchase SetPersonConfiguration(int personTypeId, string personTypeName)
        {
            _personTypeId = personTypeId;
            _personTypeName = personTypeName;

            return this;
        }

        public ClientFundPurchase SetAvailableOperation(bool buyAvailable, bool salesAvailable)
        {
            _buyAvailable = buyAvailable;
            _saleAvailable = salesAvailable;
            return this;
        }
    }
}
