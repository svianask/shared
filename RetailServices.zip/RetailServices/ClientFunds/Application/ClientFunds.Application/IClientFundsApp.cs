﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFunds.Application
{
    public interface IClientFundsApp
    {
        List<ClientFundPurchase> GetFundsForPurchase(string contractId, int planId, int personTypeId, int platform, out OperationResult result);
        ClientFundPurchase GetFundBridge(string contractId, int planId, int personTypeId, int platform, out OperationResult result);
    }
}
