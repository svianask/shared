﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using ClientFunds.Repository;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClientFunds.Application
{
    public class ClientFundsApp : IClientFundsApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientFundsRepository _fundsRepository;
        public ClientFundsApp(IClientFundsRepository clientFundsRepository, ISeriLogHelper seriLog)
        {
            _fundsRepository = clientFundsRepository;
            _log = seriLog;
        }

        public List<ClientFundPurchase> GetFundsForPurchase(string contractId, int planId, int personTypeId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }
            if (planId <= 0) { throw new ArgumentException("El id del plan es incorrecto"); }
            if (personTypeId <= 0) { throw new ArgumentException("El id del tipo de persona es incorrecto"); }
            if (platform <= 0) { throw new ArgumentException("El id de la plataforma es incorrecto"); }

            List<ClientFundPurchase> fundsPurchase = new List<ClientFundPurchase>();

            try
            {
                _log.Info("Determinando el sp de acuerdo a la plataforma");
                var SpName = platform == 10 ? "usp_SOC_SIIF_RS_GetFondosIntegrados" : "usp_SOC_SIIF_GT_GetFondosIntegrados";
                _log.Debug("{cntx}", SpName);

                _log.Info("Obteniendo la información comercial de los fondos");
                fundsPurchase = _fundsRepository.GetFundsForPurchase(SpName, contractId, planId, personTypeId);
                _log.Debug("{cntx}", fundsPurchase);

                _log.Info("Filtra por fondos que estan habilitados para compra.");
                fundsPurchase = fundsPurchase.Where(x => x.BuyAvailable).ToList();
                _log.Debug("{cntx}", fundsPurchase);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los fondos" + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return fundsPurchase;
        }

        public ClientFundPurchase GetFundBridge(string contractId, int planId, int personTypeId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }
            if (planId <= 0) { throw new ArgumentException("El id del plan es incorrecto"); }
            if (personTypeId <= 0) { throw new ArgumentException("El id del tipo de persona es incorrecto"); }
            if (platform <= 0) { throw new ArgumentException("El id de la plataforma es incorrecto"); }

            ClientFundPurchase fundBridge = null;

            try
            {
                _log.Info("Determinando el sp de acuerdo a la plataforma");
                var SpName = platform == 10 ? "usp_SOC_SIIF_RS_GetFondosIntegrados" : "usp_SOC_SIIF_GT_GetFondosIntegrados";
                _log.Debug("{cntx}", SpName);

                _log.Info("Obteniendo la información comercial de los fondos");
                var fundsPurchase = _fundsRepository.GetFundsForPurchase(SpName, contractId, planId, personTypeId);
                _log.Debug("{cntx}", fundsPurchase);

                _log.Info("Filtra por fondos que estan habilitados para compra.");
                fundsPurchase = fundsPurchase.Where(x => x.BuyAvailable).ToList();
                _log.Debug("{cntx}", fundsPurchase);

                fundBridge = fundsPurchase.FirstOrDefault();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información del fondo puente");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información del fondo puente" + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return fundBridge;
        }
    }
}
