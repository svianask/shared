﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientFunds.Application;
using ClientFunds.Domain.ClienFundPurchaseAggregate;
using ClientFunds.Repository;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;

namespace ClientFunds.ApplicationTest
{
    [TestClass]
    public class ClientFundsAppTest
    {
        private readonly Mock<ISeriLogHelper> _log;
        private readonly Mock<IClientFundsRepository> _fundsRepository;
        private readonly ClientFundsApp _clientFundsBL;

        private OperationResult result;
        public ClientFundsAppTest()
        {
            _log = new Mock<ISeriLogHelper>();
            _fundsRepository = new Mock<IClientFundsRepository>();
            _clientFundsBL = new ClientFundsApp(_fundsRepository.Object, _log.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            result = new OperationResult() { Successful = true };
            var fundPurchase = ClientFundPurchase.Create("STERDOWB1")
                .SetAvailableOperation(true, false);
            List<ClientFundPurchase> lstFunds = new List<ClientFundPurchase>();
            lstFunds.Add(fundPurchase);
            _fundsRepository.Setup(x => x.GetFundsForPurchase(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(lstFunds);
        }

        [TestMethod, TestCategory("GetFundsForPurchase")]
        [DataRow("", 245, 10, 10)]
        [DataRow("112533", 0, 10, 10)]
        [DataRow("112533", 245, 0, 10)]
        [DataRow("112533", 245, 10, 0)]
        [ExpectedException(typeof(ArgumentException))]
        public void GetFundsForPurchaseError(string contractId, int planId, int personTypeId, int platform)
        {
            var lstFunds = _clientFundsBL.GetFundsForPurchase(contractId, planId, personTypeId, platform, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(lstFunds);
        }

        [TestMethod, TestCategory("GetFundsForPurchase")]
        public void GetFundsForPurchaseSuccess()
        {
            var lstFunds = _clientFundsBL.GetFundsForPurchase("112533", 245, 10, 10, out result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(lstFunds);
            Assert.IsTrue(lstFunds.Count > 0);
        }
    }
}
