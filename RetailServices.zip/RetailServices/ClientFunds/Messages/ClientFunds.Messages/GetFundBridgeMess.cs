﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFunds.Messages
{
    public class GetFundBridgeResponse
    {
        public OperationResult Result;
        public ClientFundPurchase FundBridge;
    }

    public class GetFundBridgeRequest
    {
        public string ContractId;
        public int PlanId;
        public int PersontypeId;
        public int Platform;
    }
}
