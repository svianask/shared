﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClientFunds.Messages
{
    public class GetClientFundsPurchaseResponse
    {
        public OperationResult Result;
        public List<ClientFundPurchase> FundsPurchase;

        public GetClientFundsPurchaseResponse() { Result = new OperationResult(); FundsPurchase = new List<ClientFundPurchase>(); }
    }

    public class GetClientFundsPurchaseRequest
    {
        public string ContractId;
        public int PlanId;
        public int PersontypeId;
        public int Platform;
    }
}
