﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using ClientFunds.Mappings;
using SqlClient.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace ClientFunds.Repository
{
    public class ClientFundsRepository : IClientFundsRepository
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;
        public ClientFundsRepository([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            this._dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public List<ClientFundPurchase> GetFundsForPurchase(string spName, string contractId, int planId, int personType)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@pstrContratoId", contractId);
            cmd.AddParameterWithValue("@pstrtipoPersona", personType);
            cmd.AddParameterWithValue("@splanId", planId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ClientFundPurchaseMapp.Mapp(ds);
        }
    }
}
