﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFunds.Repository
{
    public interface IClientFundsRepository
    {
        List<ClientFundPurchase> GetFundsForPurchase(string spName, string contractId, int planId, int personType);
    }
}
