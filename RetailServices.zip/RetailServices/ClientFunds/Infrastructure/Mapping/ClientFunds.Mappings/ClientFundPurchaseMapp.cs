﻿using ClientFunds.Domain.ClienFundPurchaseAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.Application;

namespace ClientFunds.Mappings
{
    public class ClientFundPurchaseMapp
    {
        public static List<ClientFundPurchase> Mapp(DataSet ds)
        {
            List<ClientFundPurchase> fundsPurchase = new List<ClientFundPurchase>();
            foreach (DataTable table in ds.Tables)
            {
                foreach (DataRow dr in table.Rows)
                {
                    fundsPurchase.Add(
                        ClientFundPurchase.Create(dr["Emision_Id"].ToString())
                        .SetOperator(
                            Convert.ToInt32(Null.SetNull(dr["Emisor_Id"], new Int32())),
                            dr["Emisor_Dsc"].ToString())
                        .SetAvailableOperation(
                            bool.Parse(dr["Fondo_Habilita_Compras"].ToString()),
                            bool.Parse(dr["Fondo_Habilita_Ventas"].ToString()))
                        .SetCurrency(
                            Convert.ToInt32(Null.SetNull(dr["Divisa_Id"], new Int32())),
                            dr["Divisa_Dsc"].ToString())
                        .SetPersonConfiguration(
                            Convert.ToInt32(Null.SetNull(dr["Tipo_Personalidad_Id"], new Int32())),
                            dr["Tipo_Personalidad_Dsc"].ToString())
                        .SetPurchaseConfiguration(
                            Convert.ToInt32(Null.SetNull(dr["Tipo_Fondo_Id"], new Int32())),
                            dr["Tipo_Fondo_Dsc"].ToString(),
                            Convert.ToInt32(Null.SetNull(dr["Clasif_Fondo_Id"], new Int32())),
                            dr["Clasif_Fondo_Dsc"].ToString())
                    );
                }
            }

            return fundsPurchase;
        }
    }
}
