﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using ClientAccounts.Domain.AccountClabeAggregate;

namespace ClientAccounts.Mapping
{
    public class AccountClabeMap
    {

        public static AccountClabeSchema MapSchemaAccountClabe(DataSet dsAccountClabeSchema) {
            AccountClabeSchema accClabeSchema = null; 
            foreach (DataRow row in dsAccountClabeSchema.Tables[0].Rows) { 
                var bankId = row["Banco_Clave_Banxico"].ToString();
                var bankCode = row["SPEI_Banco"].ToString();
                var bankPlace = row["SPEI_Plaza"].ToString();
                var bankBranchOffice = row["SPEI_Sucursal"].ToString();
                var bankAccount = row["SPEI_CuentaBancaria"].ToString();
                var bankControlDigit = row["SPEI_DigitodeControl"].ToString();

                accClabeSchema = AccountClabeSchema.Create(bankId, bankCode, bankPlace, bankBranchOffice, bankAccount, bankControlDigit);
            }
            return accClabeSchema;
        }
    }
}
