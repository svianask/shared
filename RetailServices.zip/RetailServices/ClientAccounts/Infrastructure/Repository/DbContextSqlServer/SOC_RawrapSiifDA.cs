﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlClient.Helper;
namespace DbContextSqlServer
{
    public class SOC_RawrapSiifDA : ISOC_RawrapSiifDA
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;
        private readonly string _ConnectionRawrapsiff;

        public SOC_RawrapSiifDA(string connectionRawrapsiif, ISqlClientHelper sqlClientHelper)
        {
            _ConnectionRawrapsiff = connectionRawrapsiif;
            _sqlClientHelper = sqlClientHelper;
            _dbConn = new SqlConnection(connectionRawrapsiif);

        }
        public DataSet GetSpeiSchema(int clabeIdentifier)
        {
            DataSet dsResult = null;

            using (IDbCommand cmd = _sqlClientHelper.CreateCmdSP("USP_Get_MM_Orden", _dbConn))
            {
                cmd.AddParameterWithValue("@ClabeBankId", clabeIdentifier);
                dsResult = _sqlClientHelper.ExecuteDataSet(cmd);
            }
            return dsResult;
        }

    }
}
