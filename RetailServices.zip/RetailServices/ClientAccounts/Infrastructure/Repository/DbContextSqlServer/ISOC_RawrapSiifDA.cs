﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbContextSqlServer
{
    public interface ISOC_RawrapSiifDA
    {
        DataSet GetSpeiSchema(int clabeIdentifier);
    }
}
