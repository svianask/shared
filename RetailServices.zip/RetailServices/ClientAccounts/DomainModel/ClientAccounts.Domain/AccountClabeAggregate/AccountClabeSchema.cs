﻿using Ddd;
using System;
namespace ClientAccounts.Domain.AccountClabeAggregate
{
    public class AccountClabeSchema: Entity<string>
    {
        private string _bankCode;
        private string _bankPlace;
        private string _bankBranchOffice;
        private string _bankAccount;
        private string _bankControlDigit;

        private AccountClabeSchema(string clabeId, string bankCode, string bankPlace, string bankBranchOffice, string bankAccount, string bankControlDigit) 
        {
            Id = clabeId;
            _bankCode = bankCode;
            _bankPlace = bankPlace;
            _bankBranchOffice = bankBranchOffice;
            _bankAccount = bankAccount;
            _bankControlDigit = bankControlDigit;

        }

        public string BankCode { get => _bankCode; set => _bankCode = value; }
        public string BankPlace { get => _bankPlace; set => _bankPlace = value; }
        public string BankBranchOffice { get => _bankBranchOffice; set => _bankBranchOffice = value; }
        public string BankAccount { get => _bankAccount; set => _bankAccount = value; }
        public string BankControlDigit { get => _bankControlDigit; set => _bankControlDigit = value; }

        public static AccountClabeSchema Create(string clabeId, string bankCode, string bankPlace, string bankBranchOffice, string bankAccount, string bankControlDigit) 
        {
            if (clabeId == null) { throw new ArgumentException("BankId no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankCode)) { throw new ArgumentException("CodigoBanco no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankPlace)) { throw new ArgumentException("Plaza no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankBranchOffice)) { throw new ArgumentException("Sucursal no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankAccount)) { throw new ArgumentException("Cuenta bancaria no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankControlDigit)) { throw new ArgumentException("Digito verificador no puede ser nulo."); }

            return new AccountClabeSchema(clabeId, bankCode, bankPlace, bankBranchOffice, bankAccount, bankControlDigit);
        }

    }
}
