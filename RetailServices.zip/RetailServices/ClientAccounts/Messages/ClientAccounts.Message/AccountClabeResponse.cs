﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;
using ClientAccounts.Domain.AccountClabeAggregate;

namespace ClientAccounts.Message
{
    public class AccountClabeResponse
    {
        public OperationResult Result;
     
        public AccountClabeSchema AccountClabeSchema;

        public AccountClabeResponse()
        {
            Result = new OperationResult();
        }


    }
}
