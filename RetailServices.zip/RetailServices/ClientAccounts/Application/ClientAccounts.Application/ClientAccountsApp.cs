﻿using System;
using System.Collections.Generic;
using System.Linq;
using ClientAccounts.Domain.AccountClabeAggregate;
using ClientContracts.Repository;
using SeriLogH;
using Common.Domain;

namespace ClientAccounts.Application
{
    public class ClientAccountsApp:IClientAccountsApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IRAWRAPSIIFDa _iRawRapSiifDa;
        public ClientAccountsApp(ISeriLogHelper log, IRAWRAPSIIFDa iRawRapSiifDa)
        {
            _log = log;
            _iRawRapSiifDa = iRawRapSiifDa;
        }

        public AccountClabeSchema GetClabeAccountSchema(string clabeId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            string bankClabe = string.Empty;
            string bankCode = string.Empty;
            string bankPlace = string.Empty;
            string bankBranchOffice = string.Empty;
            string bankAccount = string.Empty;
            string bankControlDigit = string.Empty;

            try
            {
                if (clabeId.Length < 18)
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "Cuenta clabe invalida, la referencia no tiene 18 digitos: " + clabeId, MessageType = SystemMessageTypes.Error });
                    throw new ArgumentException("Cuenta clabe invalida, la referencia no tiene 18 digitos: " + clabeId);
                }

                 bankClabe = clabeId.Substring(0, 3);

                var ClabeSchema = _iRawRapSiifDa.GetAccountClabeSchema(bankClabe);

                if (!(ClabeSchema is null))
                {
                    bankCode = clabeId.Substring(0, Convert.ToInt32(ClabeSchema.BankCode));

                    bankPlace = clabeId.Substring(3, Convert.ToInt32(ClabeSchema.BankPlace));

                    if ((ClabeSchema.BankBranchOffice.Length > 0) && (Convert.ToInt32(ClabeSchema.BankBranchOffice) > 0))
                    {
                        bankBranchOffice = clabeId.Substring(6, Convert.ToInt32(ClabeSchema.BankBranchOffice));
                        bankAccount = clabeId.Substring((6 + Convert.ToInt32(ClabeSchema.BankBranchOffice)), Convert.ToInt32(ClabeSchema.BankAccount));
                    }
                    else
                    {
                        bankBranchOffice = "0"; //clabeId.Substring(6, ClabeSchema.BankBranchOffice);
                        bankAccount = clabeId.Substring(6, Convert.ToInt32(ClabeSchema.BankAccount));
                    }

                    bankControlDigit = clabeId.Substring((clabeId.Length - 1), Convert.ToInt32(ClabeSchema.BankControlDigit));

                    AccountClabeSchema clabeAccoutComposition = AccountClabeSchema.Create("", bankCode, bankPlace, bankBranchOffice, bankAccount, bankControlDigit);

                    return clabeAccoutComposition;
                }
                else {
                    
                    throw new ArgumentException("No existe configuracion de schema cuenta clabe para el Código de Banco: " + bankClabe);
                }
             

            }
            catch (Exception ex)
            {

                _log.Error(ex, "Error al obtener el schema cuenta clabe para el Código de Banco {clabex}", new { bankClabe });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error : " + ex.Message  });
                return null;
            }

        }
    }
}
