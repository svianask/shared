﻿using System;
using System.Collections.Generic;
using System.Linq;
using ClientAccounts.Domain.AccountClabeAggregate;
using Common.Domain;

namespace ClientAccounts.Application
{
    public interface IClientAccountsApp
    {
        AccountClabeSchema GetClabeAccountSchema(string ClabeId, out OperationResult result);

    }
}
