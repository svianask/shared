﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ClientContracts.Domain.ContractsAcceptedAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using ClientContracts.Message;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ClientContracts.MessageTest
{
    [TestClass]
    public class ClientContractsMessageTest
    {
        [TestMethod, TestCategory("PocoInstance")]
        public void ClientContractsRequestInstance()
        {
            var clientContractsRequest = new ClientContractsRequest()
            {
                ClientIdentifier = "XXXX123456ZZZ"
            };
                

            Assert.IsInstanceOfType(
                clientContractsRequest,
                typeof(ClientContractsRequest)
            );

            Assert.IsTrue(clientContractsRequest.ClientIdentifier == "XXXX123456ZZZ");
        }

        [TestMethod, TestCategory("PocoInstance")]
        public void ClientContractsResponseInstance()
        {
            var clientContractsResponse = new ClientContractsResponse()
            {
                ContractsOfClient = new ContractsOfClient("XXXX123456ZZZ"),
                Result = new OperationResult
                {
                    Successful = true,
                    SystemMessages = new List<SystemMessage>()
                        {
                            new SystemMessage
                            {
                                Message = "Test",
                                MessageType = SystemMessageTypes.Information
                            }
                        }
                }
            };

            Assert.IsInstanceOfType(
                clientContractsResponse,
                typeof(ClientContractsResponse)
            );
            Assert.IsTrue(clientContractsResponse.ContractsOfClient.Id == "XXXX123456ZZZ");
            Assert.IsTrue(clientContractsResponse.ContractsOfClient.Contracts.Count() == 0);
            Assert.IsTrue(clientContractsResponse.Result.Successful == true);
            Assert.IsTrue(clientContractsResponse.Result.SystemMessages[0].Message == "Test");
            Assert.IsTrue(clientContractsResponse.Result.SystemMessages[0].MessageType == SystemMessageTypes.Information);
        }

        [TestMethod, TestCategory("PocoInstance")]
        public void ContractUpdateRequestInstance()
        {
            var contractUpdateRequest = new ContractUpdateRequest()
            {
                ContractsUpdate = new List<ContractUpdate>
                {
                    new ContractUpdate
                    {
                        ContractIdentifier = "000000000",
                        Email = "test@Skandia.com.mx"
                    }
                }
            };

            Assert.IsInstanceOfType(
                contractUpdateRequest,
                typeof(ContractUpdateRequest)
            );

            Assert.IsTrue(contractUpdateRequest.ContractsUpdate[0].ContractIdentifier == "000000000");
            Assert.IsTrue(contractUpdateRequest.ContractsUpdate[0].Email == "test@Skandia.com.mx");
        }

        [TestMethod, TestCategory("PocoInstance")]
        public void ContractUpdateResponseInstance()
        {
            var contractUpdateResponse = new ContractUpdateResponse
            {
                Result = new OperationResult
                {
                    Successful = true,
                    SystemMessages = new List<SystemMessage>()
                        {
                            new SystemMessage
                            {
                                Message = "Test",
                                MessageType = SystemMessageTypes.Information
                            }
                        }
                }
            };

            Assert.IsInstanceOfType(
                contractUpdateResponse,
                typeof(ContractUpdateResponse)
            );

            Assert.IsTrue(contractUpdateResponse.Result.Successful == true);
            Assert.IsTrue(contractUpdateResponse.Result.SystemMessages[0].Message == "Test");
            Assert.IsTrue(contractUpdateResponse.Result.SystemMessages[0].MessageType == SystemMessageTypes.Information);
        }

        [TestMethod, TestCategory("PocoInstance")]
        public void ContractsAcceptedResponseInstance()
        {
            ContractsAcceptedGetByRFCResponse contractResponse = new ContractsAcceptedGetByRFCResponse()
            {
                Contracts = new List<Domain.ContractsAcceptedAggregate.ContractAccepted>()
                {
                    ContractAccepted.Create(1, "DOLA911012PH2", "9999999999999", new DateTime(23, 11, 30) )
                },
                Result = new OperationResult
                {
                    Successful = true,
                    SystemMessages = new List<SystemMessage>()
                        {
                            new SystemMessage
                            {
                                Message = "Test",
                                MessageType = SystemMessageTypes.Information
                            }
                        }
                }
            };

            Assert.IsInstanceOfType(
                contractResponse,
                typeof(ContractsAcceptedGetByRFCResponse)
            );

            Assert.IsTrue( contractResponse.Contracts != null);
        }
    }
}
