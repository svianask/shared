﻿namespace ClientContracts.Message
{
    public class ContractBeneficiariesRequest
    {
        public string ContractId { get; set; }
        public int PlatformId { get; set; }
    }
}
