﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class ReferenceNumberResponse
    {
        public string ReferenceNumber;

        public OperationResult Result;
    }
}
