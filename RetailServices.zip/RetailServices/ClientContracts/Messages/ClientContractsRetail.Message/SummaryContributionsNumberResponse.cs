﻿using ClientContracts.Domain.SummaryContributionsAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class SummaryContributionsNumberResponse
    {
        private SummaryContributions _summaryContributions;
        private OperationResult _result;

        public SummaryContributionsNumberResponse()
        {
        }

        public SummaryContributions SummaryContributions { get => _summaryContributions; set => _summaryContributions = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
