﻿namespace ClientContracts.Message
{
    public class OnDemandCashRequest
    {
        private string contractId;

        public OnDemandCashRequest()
        {
        }

        public string ContractId { get => contractId; set => contractId = value; }
    }
}
