﻿

namespace ClientContracts.Message
{
    public class GetAllowedUnpaidContributionsRequest
    {
        public string ContractId { get; set; }
    }
}
