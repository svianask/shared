﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ClientIdByContractRequest
    {
        private string _contractId;

        public ClientIdByContractRequest()
        {
        }

        public string ContractId { get => _contractId; set => _contractId = value; }
    }
}
