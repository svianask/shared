﻿using ClientContracts.Domain.ContractsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractsResponse
    {
        private ContractsOf _contractsOfClient;
        private OperationResult _result;

        public ContractsResponse()
        {
        }

        public ContractsOf ContractsOfClient { get => _contractsOfClient; set => _contractsOfClient = value; }
        public OperationResult Result { get => _result; set => _result = value; }

        public void Dispose()
        {

        }
    }
}
