﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ClabeAccountRequest
    {
        private string _clabeAccount;

        public ClabeAccountRequest()
        {
        }

        public string ClabeAccount { get => _clabeAccount; set => _clabeAccount = value; }
    }
}
