﻿namespace ClientContracts.Message
{
    public class SavingTargetRequest
    {
        public string ContractId;

        public int Platform;
    }
}
