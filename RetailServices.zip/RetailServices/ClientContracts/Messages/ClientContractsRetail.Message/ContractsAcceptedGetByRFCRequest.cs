﻿namespace ClientContracts.Message
{
    public class ContractsAcceptedGetByRFCRequest
    {
        public string Rfc { get; set; }
    }
}
