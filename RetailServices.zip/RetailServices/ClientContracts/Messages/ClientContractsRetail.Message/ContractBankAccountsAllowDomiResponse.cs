﻿using ClientContracts.Domain.ContractBankAccountAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractBankAccountsAllowDomiResponse
    {
        public List<ContractBankAccountAllowDomi> ContractBankAccountAllowDomis { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }
}
