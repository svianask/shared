﻿
namespace ClientContracts.Message
{
    public class GetContractInflationRequest
    {
        public string ContractId { get; set; }
    }
}
