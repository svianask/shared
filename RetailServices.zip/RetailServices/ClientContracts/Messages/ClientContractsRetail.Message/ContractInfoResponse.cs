﻿using System;
using ClientContracts.Domain.ContractsAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractInfoResponse
    {
        private OperationResult _result;
        private Contr _contract;

        public ContractInfoResponse()
        {
        }

        public Contr ContractInfo { get => _contract; set => _contract = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }

}
