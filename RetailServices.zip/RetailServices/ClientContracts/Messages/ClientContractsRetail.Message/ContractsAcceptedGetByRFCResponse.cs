﻿

using ClientContracts.Domain.ContractsAcceptedAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractsAcceptedGetByRFCResponse
    {
        private OperationResult _result;
        private List<ContractAccepted> contracts;
        public ContractsAcceptedGetByRFCResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<ContractAccepted> Contracts { get => contracts; set => contracts = value; }
    }
}
