﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class AssociateContractsRequest
    {
        private string _clientIdentifier;

        public AssociateContractsRequest()
        {
        }

        public string ClientIdentifier { get => _clientIdentifier; set => _clientIdentifier = value; }
    }
}
