﻿namespace ClientContracts.Message
{
    public class GetContractPortfolioRequest
    {
        public string ContractId { get; set; }
    }
}
