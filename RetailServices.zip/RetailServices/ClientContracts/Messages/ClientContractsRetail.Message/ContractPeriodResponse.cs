﻿using ClientContracts.Domain.ContractAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class GetContractPeriodResponse
    {
        private OperationResult _result;
        private ContractPeriod _period;
        public GetContractPeriodResponse()
        {
            _result = new OperationResult();
        }

        public ContractPeriod Period  { get => _period; set => _period = value;}
        public OperationResult Result { get => _result; set => _result = value;}
    }
}
