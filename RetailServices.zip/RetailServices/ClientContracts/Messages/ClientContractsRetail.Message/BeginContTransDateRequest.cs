﻿using ClientContracts.Domain.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class BeginContTransDateRequest
    {

        private string _contractId;
        private int _sourceContract;

        public BeginContTransDateRequest()
        {
        }

        public string ContractId { get => _contractId; set => _contractId = value; }
        public int SourceContract { get => _sourceContract; set => _sourceContract = value; }

        public void Dispose() { }
    }
}
