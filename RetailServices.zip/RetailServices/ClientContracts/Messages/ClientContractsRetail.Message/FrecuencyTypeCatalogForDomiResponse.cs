﻿using ClientContracts.Domain.FrecuencyTypeAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class FrecuencyTypeCatalogForDomiResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();
        public List<FrecuencyTypeCatalog> FrecuencyTypes { get; set; } = new List<FrecuencyTypeCatalog>();
    }
}
