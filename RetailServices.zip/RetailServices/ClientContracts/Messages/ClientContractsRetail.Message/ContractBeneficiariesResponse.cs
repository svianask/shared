﻿using ClientContracts.Domain.ContractBeneficiariesAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractBeneficiariesResponse
    {
        private OperationResult _result;
        private List<Beneficiary> _beneficiaries;
    
        public ContractBeneficiariesResponse()
        {
            _result = new OperationResult();
            _beneficiaries = new List<Beneficiary>();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<Beneficiary> Beneficiaries { get; set; }
    }
}