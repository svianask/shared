﻿namespace ClientContracts.Message
{
    public class ContractBankAccountsByRfcRequest
    {
        public string RFC { get; set; }
    }
}
