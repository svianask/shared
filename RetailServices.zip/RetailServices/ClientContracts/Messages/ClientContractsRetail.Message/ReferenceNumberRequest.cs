﻿namespace ClientContracts.Message
{
    public class ReferenceNumberRequest
    {
        public string ContractId;

        public int Platform;
    }
}
