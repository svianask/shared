﻿using ClientContracts.Domain.DetailBankAccountAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class BankAccountContractResponse
    {
        private OperationResult _result;
        private List<DetailBankAccount> _BankAccounts;

        public BankAccountContractResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<DetailBankAccount> BankAccounts { get => _BankAccounts; set => _BankAccounts = value; }

    }
}
