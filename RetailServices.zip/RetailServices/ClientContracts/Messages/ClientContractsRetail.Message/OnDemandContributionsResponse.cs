﻿using ClientContracts.Domain.ContributionsOnDemandAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class OnDemandContributionsResponse
    {
        private ContributionsOnDemand _contributionsOnDemand;
        private OperationResult _result;

        public OnDemandContributionsResponse()
        {
            ContributionsOnDemand = null;
        }

        public ContributionsOnDemand ContributionsOnDemand { get => _contributionsOnDemand; set => _contributionsOnDemand = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
