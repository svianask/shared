﻿using System;
using ClientContracts.Domain.ContractWithdrawalsAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractWithdrawalsByDateResponse
    {
        private ContractWithdrawals _contractWithdrawals;
        private OperationResult _result;

        public ContractWithdrawalsByDateResponse()
        {
            ContractWithdrawals = null;
        }

        public ContractWithdrawals ContractWithdrawals { get => _contractWithdrawals; set => _contractWithdrawals = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
