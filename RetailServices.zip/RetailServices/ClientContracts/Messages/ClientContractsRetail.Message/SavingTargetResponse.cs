﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class SavingTargetResponse
    {
        public string SavingTarget;

        public OperationResult Result;
    }
}

