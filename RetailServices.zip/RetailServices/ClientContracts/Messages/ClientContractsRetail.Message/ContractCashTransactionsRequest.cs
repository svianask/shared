﻿using System;

namespace ClientContracts.Message
{
    public class ContractCashTransactionsRequest
    {
        private string contractId;
        private int platform;
        private DateTime? startDate;
        private DateTime? endDate;

        public ContractCashTransactionsRequest()
        {
        }

        public string ContractId { get => contractId; set => contractId = value; }
        public int Platform { get => platform; set => platform = value; }
        public DateTime? StartDate { get => startDate; set => startDate = value; }
        public DateTime? EndDate { get => endDate; set => endDate = value; }
    }
}
