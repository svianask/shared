﻿using ClientContracts.Domain.FundAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class GetContractPortfolioResponse
    {
        public List<FundPortfolio> fundsPortfolio { get; set; }
        public OperationResult Result { get; set; }
    }
}
