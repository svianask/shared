﻿using ClientContracts.Domain.BankAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class GetBankCatalogResponse
    {
        public OperationResult Result { get; set; }
        public List<Bank> Banks { get; set; }

        public GetBankCatalogResponse()
        {
            Result = new OperationResult();
            Banks = new List<Bank>();
        }
    }

    public class GetBankCatalogRequest
    {
        public int Platform;
    }
}
