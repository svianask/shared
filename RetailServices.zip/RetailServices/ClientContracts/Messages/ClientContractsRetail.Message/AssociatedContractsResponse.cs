﻿using ClientContracts.Domain.AssociatedContractAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class AssociatedContractsResponse
    {
        private OperationResult _result;
        private List<AssociatedContract> _lstAssociatedContracts;

        public AssociatedContractsResponse()
        {
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<AssociatedContract> LstAssociatedContracts { get => _lstAssociatedContracts; set => _lstAssociatedContracts = value; }
    }
}
