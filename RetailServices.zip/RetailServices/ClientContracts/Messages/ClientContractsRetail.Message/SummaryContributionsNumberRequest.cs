﻿using System;

namespace ClientContracts.Message
{
    public class SummaryContributionsNumberRequest
    {
        private string _contractId;

        public SummaryContributionsNumberRequest()
        {
        }

        public string ContractId { get => _contractId; set => _contractId = value; }
    }
}
