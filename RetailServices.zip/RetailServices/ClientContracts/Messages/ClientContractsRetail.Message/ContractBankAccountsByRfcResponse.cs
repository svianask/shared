﻿using ClientContracts.Domain.DetailBankAccountAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractBankAccountsByRfcResponse
    {
        public List<DetailBankAccount> BankAccounts { get; set; }
        public OperationResult Result { get; set; }

        public ContractBankAccountsByRfcResponse(List<DetailBankAccount> bankAccounts, OperationResult result)
        {
            BankAccounts = bankAccounts;
            Result = result;
        }
    }
}
