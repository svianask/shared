﻿

using ClientContracts.Domain.ContractTrackerAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class GetContractTrackerGraphicInfoResponse
    {
        public List<ContractTrackerGraphicInfo> TrackerGraphicInfo { get; set; }
        public OperationResult Result { get; set; }
    }
}
