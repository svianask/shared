﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;
using ClientContracts.Domain.FundSaleDatesAggregate;

namespace ClientContracts.Message
{
    public class FundsSaleDatesResponse
    {
        private OperationResult _operationResult;
        private List<FundSaleDates> _fundsLiquidityDates;

        public FundsSaleDatesResponse()
        {
            _operationResult = new OperationResult();
        }

        public OperationResult Result { get => _operationResult; set => _operationResult = value; }
        
        public List<FundSaleDates> FundsSaleDates { get => _fundsLiquidityDates; set => _fundsLiquidityDates = value; }
    }
}
