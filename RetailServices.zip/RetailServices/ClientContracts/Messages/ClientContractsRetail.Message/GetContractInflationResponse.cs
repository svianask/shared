﻿
using ClientContracts.Domain.ContractInflationAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class GetContractInflationResponse
    {
        public OperationResult Result { get; set; }
        public ContractInflation ContractInflation { get; set; }
    }
}
