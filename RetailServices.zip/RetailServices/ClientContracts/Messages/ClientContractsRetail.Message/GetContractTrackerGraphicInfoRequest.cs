﻿
namespace ClientContracts.Message
{
    public class GetContractTrackerGraphicInfoRequest
    {
        public string ContractId { get; set; }
    }
}
