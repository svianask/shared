﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class AssociatedContractsRequest
    {
        private string _clientIdentifier;

        public AssociatedContractsRequest()
        {
        }

        public string ClientIdentifier { get => _clientIdentifier; set => _clientIdentifier = value; }
    }
}
