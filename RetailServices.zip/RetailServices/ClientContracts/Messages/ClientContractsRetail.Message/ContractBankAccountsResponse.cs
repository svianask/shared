﻿using System;
using System.Collections.Generic;
using ClientContracts.Domain.ContractBankAccountAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractBankAccountsResponse
    {
        public OperationResult Result { get; set; }

        public List<ContractBankAccount> ContractBankAccounts { get; set; }

        public ContractBankAccountsResponse()
        {
            Result = new OperationResult();
        }
    }
}
