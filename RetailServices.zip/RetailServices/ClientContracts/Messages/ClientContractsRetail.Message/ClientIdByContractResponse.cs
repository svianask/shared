﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ClientIdByContractResponse
    {
        private OperationResult _result;
        private string _clientIdentifier;

        public ClientIdByContractResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public string ClientIdentifier { get => _clientIdentifier; set => _clientIdentifier = value; }
    }
}
