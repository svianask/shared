﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class GetContractCRMKeyResponse
    {
        public string CRMKey { get; set; }
        public OperationResult Result { get; set; }

        public GetContractCRMKeyResponse() { Result = new OperationResult(); }
    }

    public class GetContractCRMKeyRequest
    {
        public string ContractId { get; set; }
        public int ProducType { get; set; }
    }
}
