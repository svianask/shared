﻿using ClientContracts.Domain.InvestmentsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractBalanceDetailResponse
    {
        private Investments _investments;
        private OperationResult _result;

        public ContractBalanceDetailResponse()
        {
            _result = new OperationResult();
        }

        public Investments Investments { get => _investments; set => _investments = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
