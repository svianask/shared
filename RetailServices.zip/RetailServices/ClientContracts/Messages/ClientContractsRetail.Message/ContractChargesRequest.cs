﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractChargesRequest
    {
        public ContractChargesRequest()
        {
            AssociatedContracts = new List<AssociatedContractMess>();
        }

        public List<AssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
    }
}