﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class DeregisterPremiumResponse
    {
        public OperationResult Result { get; set; }
    }
}
