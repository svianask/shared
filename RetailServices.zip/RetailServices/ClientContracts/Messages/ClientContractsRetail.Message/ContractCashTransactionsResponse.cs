﻿using ClientContracts.Domain.CashTransactionAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractCashTransactionsResponse
    {
        private CashTransaction _cashTransaction;
        private OperationResult result;

        public ContractCashTransactionsResponse()
        {
        }

        public OperationResult Result { get => result; set => result = value; }
        public CashTransaction CashTransaction { get => _cashTransaction; set => _cashTransaction = value; }
    }
}
