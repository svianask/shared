﻿using System;
using System.Collections.Generic;
using Common.Domain;
using ClientContracts.Domain.AssociatedContractAggregate;

namespace ClientContracts.Message
{
    public class AssociatedContractsByContractResponse
    {
        private OperationResult _result;
        private List<AssociatedContract> _associatedContract;

        public AssociatedContractsByContractResponse() { }

        public OperationResult Result { get => _result; set => _result = value; }
        public List<AssociatedContract> LstAssociatedContracts { get => _associatedContract; set => _associatedContract = value; }
    }
}
