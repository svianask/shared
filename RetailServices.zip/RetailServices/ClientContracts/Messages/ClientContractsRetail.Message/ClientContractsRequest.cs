﻿namespace ClientContracts.Message
{
    public class ClientContractsRequest
    {
        public string ClientIdentifier { get; set; }

        public ClientContractsRequest()
        {
        }
    }
}
