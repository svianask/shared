﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class GrouperContractResponse
    {
        public string GrouperContract;

        public OperationResult Result;
    }
}