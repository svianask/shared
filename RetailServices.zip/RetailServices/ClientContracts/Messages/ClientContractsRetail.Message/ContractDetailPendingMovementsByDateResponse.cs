﻿using System;
using System.Collections.Generic;
using ClientContracts.Domain.ContractMovementsAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractDetailPendingMovementsByDateResponse
    {
        private List<ContractDetailMovement> _pendingMovementsDetail;
        private OperationResult _result;

        public ContractDetailPendingMovementsByDateResponse()
        {
            _result = new OperationResult();
        }

        public List<ContractDetailMovement> ContractMovementsPendingDetail { get => _pendingMovementsDetail; set => _pendingMovementsDetail = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
