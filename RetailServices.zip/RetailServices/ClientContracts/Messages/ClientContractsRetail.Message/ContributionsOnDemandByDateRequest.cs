﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContributionsOnDemandByDateRequest
    {
        public ContributionsOnDemandByDateRequest()
        {
            AssociatedContracts = new List<AssociatedContractMess>();
        }

        public List<AssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
        public DateTime InitialDate { get; set; }
        public DateTime FinalDate { get; set; }
    }
}
