﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractsRequest
    {
        private string _clientIdentifier;

        public ContractsRequest()
        {
        }

        public string ClientIdentifier { get => _clientIdentifier; set => _clientIdentifier = value; }

        public void Dispose()
        { }
    }
}
