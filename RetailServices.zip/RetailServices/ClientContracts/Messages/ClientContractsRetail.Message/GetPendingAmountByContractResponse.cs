﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class GetPendingAmountByContractResponse
    {
        public OperationResult Result { get; set; }
        public decimal PendingAmount { get; set; }
    }
}
