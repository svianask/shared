﻿using ClientContracts.Domain.ContractsPeriodicityAggregate;
using Common.Domain;


namespace ClientContracts.Message
{
    public class ContractPeriodicityResponse
    {
        private OperationResult _result;
        private ContractPeriodicity _contractPeriodicity;
        public ContractPeriodicityResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        public ContractPeriodicity ContractPeriodicity { get => _contractPeriodicity; set => _contractPeriodicity = value; }
    }
}
