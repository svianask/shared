﻿using ClientContracts.Domain.ContractsAcceptedAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractsAcceptedUpdateCommitResponse
    {
        private OperationResult _result;
        public ContractsAcceptedUpdateCommitResponse()
        {
            _result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
    }
}
