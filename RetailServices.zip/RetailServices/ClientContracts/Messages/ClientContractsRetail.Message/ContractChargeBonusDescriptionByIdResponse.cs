﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractChargeBonusDescriptionByIdResponse
    {
        private OperationResult result;
        private string chargeDescripction;
        public ContractChargeBonusDescriptionByIdResponse()
        {
            result = new OperationResult();
        }
        public string Description { get => chargeDescripction; set => chargeDescripction = value; }
        public OperationResult Result { get => result; set => result = value; }
    }
}
