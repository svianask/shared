﻿
using System;

namespace ClientContracts.Message
{
    public class ContractBalanceRequest
    {
        private string _contractId;
        private int _platform;
        private DateTime _afiliationDate;
        private string _additionalContributionsContract;
        private string _contractControlContributions;

        public ContractBalanceRequest()
        {
        }

        public string ContractId { get => _contractId; set => _contractId = value; }
        public int Platform { get => _platform; set => _platform = value; }
        public string AdditionalContributionsContract { get => _additionalContributionsContract; set => _additionalContributionsContract = value; }
        public string ContractControlContributions { get => _contractControlContributions; set => _contractControlContributions = value; }
        public DateTime AfiliationDate { get => _afiliationDate; set => _afiliationDate = value; }
    }
}
