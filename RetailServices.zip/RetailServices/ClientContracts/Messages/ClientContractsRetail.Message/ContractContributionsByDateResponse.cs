﻿using System;
using ClientContracts.Domain.ContractContributionsAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractContributionsByDateResponse
    {
        private ContractContributions _contractsContributions;
        private OperationResult _result;

        public ContractContributionsByDateResponse()
        {
            ContractsContributions = null;
        }

        public ContractContributions ContractsContributions { get => _contractsContributions; set => _contractsContributions = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
