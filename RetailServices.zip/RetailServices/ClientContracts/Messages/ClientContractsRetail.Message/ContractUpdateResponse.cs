﻿
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractUpdateResponse
    {
        public ContractUpdateResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result { get; set; }
    }
}