﻿using System;

namespace ClientContracts.Message
{
    public class ContractPeriodicityRequest
    {
        public String ContractMaster { get; set; }
    }
}
