﻿using Common.Domain;
using ClientContracts.Domain.ContractsOfClientAggregate;

namespace ClientContracts.Message
{
    public class ClientContractsResponse
    {
        public ContractsOfClient ContractsOfClient { get; set; }
        public OperationResult Result { get; set; }

        public ClientContractsResponse()
        {
            Result = new OperationResult();
        }
    }
}
