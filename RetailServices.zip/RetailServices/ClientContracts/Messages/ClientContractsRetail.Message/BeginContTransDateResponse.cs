﻿using ClientContracts.Domain.ImageContractAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class BeginContTransDateResponse
    {

        private DateTime _beginContractTransDate;
        private OperationResult _result;

        public BeginContTransDateResponse()
        {
            _result = new OperationResult();
        }
        
        public OperationResult Result { get => _result; set => _result = value; }
        public DateTime BeginContractTransDate { get => _beginContractTransDate; set => _beginContractTransDate = value; }

        public void Dispose()
        { }
    }
}
