﻿using System;
using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractChargesByDateRequest
    {
        public List<AssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
        public DateTime InitialDate { get; set; }
        public DateTime FinalDate { get; set; }
    }
}
