﻿namespace ClientContracts.Message
{
    public class GrouperContractRequest
    {
        public string ContractId;

        public int Platform;
    }
}

