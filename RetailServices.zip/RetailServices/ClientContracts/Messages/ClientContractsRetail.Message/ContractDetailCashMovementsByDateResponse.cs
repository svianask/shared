﻿using System;
using System.Collections.Generic;
using ClientContracts.Domain.ContractMovementsAggregate;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractDetailCashMovementsByDateResponse
    {
        private List<ContractDetailMovement> _cashMovementsDetail;
        private OperationResult _result;

        public ContractDetailCashMovementsByDateResponse()
        {
            _result = new OperationResult();
        }

        public List<ContractDetailMovement> ContractCashMovementsDetail { get => _cashMovementsDetail; set => _cashMovementsDetail = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
