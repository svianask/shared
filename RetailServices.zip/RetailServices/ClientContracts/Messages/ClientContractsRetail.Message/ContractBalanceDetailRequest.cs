﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractBalanceDetailRequest
    {
        private int platform;
        private List<string> contracts;

        public ContractBalanceDetailRequest()
        {
        }

        public int Platform { get => platform; set => platform = value; }
        public List<string> Contracts { get => contracts; set => contracts = value; }
    }
}
