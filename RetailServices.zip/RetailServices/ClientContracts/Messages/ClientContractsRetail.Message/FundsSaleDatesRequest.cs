﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class FundsSaleDatesRequest
    {
        public List<string> Funds;
        public DateTime DateRequest;
        public int Platform;
    }
}
