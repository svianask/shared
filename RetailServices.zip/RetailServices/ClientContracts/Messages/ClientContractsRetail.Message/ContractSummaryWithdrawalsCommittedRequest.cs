﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractSummaryWithdrawalsCommittedRequest
    {
        public string ContractId;
    }
}
