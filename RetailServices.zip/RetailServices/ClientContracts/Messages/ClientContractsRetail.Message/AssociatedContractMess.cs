﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class AssociatedContractMess
    {
        public AssociatedContractMess()
        {
        }

        public string ContractId { get; set; }
        public string AssociatedContractId { get; set; }
        public int AssociatedType { get; set; }
    }
}
