﻿using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractWithdrawalsRequest
    {
        public ContractWithdrawalsRequest()
        {
            AssociatedContracts = new List<AssociatedContractMess>();
        }

        public List<AssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
    }
}
