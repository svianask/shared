﻿using ClientContracts.Domain.ContractContributionsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractContributionsResponse
    {
        private ContractContributions _contractsContributions;
        private OperationResult _result;

        public ContractContributionsResponse()
        {
            ContractsContributions = null;
        }

        public ContractContributions ContractsContributions { get => _contractsContributions; set => _contractsContributions = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
