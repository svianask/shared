﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ClientRFCByContractResponse
    {
        private OperationResult _result;
        private string _clientRFC;

        public ClientRFCByContractResponse() { }

        public OperationResult Result { get => _result; set => _result = value; }
        public string ClientRFC { get => _clientRFC; set => _clientRFC = value; }
    }
}
