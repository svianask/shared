﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractChargeBonusDescriptionByIdRequest
    {
        private int _operationType;
        private string _chargeId;
        private int _platform;

        public int OperationType { get => _operationType; set => _operationType = value; } 
        public string ChargeId { get => _chargeId; set => _chargeId = value; }
        public int Platform { get => _platform; set => _platform = value; }
    }
}
