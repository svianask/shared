﻿

namespace ClientContracts.Message
{
    public class GetPendingAmountByContractRequest
    {
        public string ContractId { get; set; }  
    }
}
