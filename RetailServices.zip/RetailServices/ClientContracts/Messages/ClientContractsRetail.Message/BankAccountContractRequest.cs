﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class BankAccountContractRequest
    {
        public string ContractId { get; set; }
    }
}
