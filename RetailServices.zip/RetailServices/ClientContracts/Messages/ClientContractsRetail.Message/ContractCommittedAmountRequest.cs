﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractCommittedAmountRequest
    {
        private string _contractId;

        public ContractCommittedAmountRequest() {}

        public string ContractId { get => _contractId; set => _contractId = value; }
    }
}
