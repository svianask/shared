﻿using System;
using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractCommittedAmountResponse
    {
        private decimal _committedAmount;
        private OperationResult _result;

        public ContractCommittedAmountResponse()
        {
            Result = new OperationResult();
        }

        public decimal CommittedAmount { get => _committedAmount; set => _committedAmount = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
