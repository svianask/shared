﻿namespace ClientContracts.Message
{
    public class ContractsAcceptedUpdateCommitRequest
    {
        public string Rfc { get; set; }
        public string ContractId { get; set; }
        public bool IsCommited { get; set; }
    }
}
