﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;
namespace ClientContracts.Message
{
    public class ContractSummaryWithdrawalsCommittedResponse
    {
        private decimal _withdrawalsCommittedAmount;
        private OperationResult _result;

        public ContractSummaryWithdrawalsCommittedResponse()
        {
            _result = new OperationResult();
        }

        public decimal WithdrawalsCommittedAmount { get => _withdrawalsCommittedAmount; set => _withdrawalsCommittedAmount = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
