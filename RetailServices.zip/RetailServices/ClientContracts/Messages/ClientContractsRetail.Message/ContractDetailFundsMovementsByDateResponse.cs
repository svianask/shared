﻿using ClientContracts.Domain.ContractMovementsAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractDetailFundsMovementsByDateResponse
    {

        public ContractDetailFundsMovementsByDateResponse()
        {
            _result = new OperationResult();
        }

        private List<ContractDetailMovement> _fundsMovementsDetail;

        private OperationResult _result;

        public List<ContractDetailMovement> ContractFundsMovementsDetail { get => _fundsMovementsDetail; set => _fundsMovementsDetail = value; }

        public OperationResult Result { get => _result; set => _result = value; }
    }
}
