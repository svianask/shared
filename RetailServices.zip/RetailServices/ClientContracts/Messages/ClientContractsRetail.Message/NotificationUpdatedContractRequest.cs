﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class NotificationUpdatedContractRequest
    {
        public string ClientIdentifier { get; set; }

        public NotificationUpdatedContractRequest()
        {
        }
    }
}
