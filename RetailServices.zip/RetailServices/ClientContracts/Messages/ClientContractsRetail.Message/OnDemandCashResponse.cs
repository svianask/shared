﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class OnDemandCashResponse
    {
        private decimal _onDemandCash;
        private OperationResult _result;

        public OnDemandCashResponse()
        {
            Result = new OperationResult();
        }

        public decimal OnDemandCash { get => _onDemandCash; set => _onDemandCash = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
