﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class LogsRegisterBankAccountCRMResponse
    {
        public OperationResult Result { get; set; }

        public LogsRegisterBankAccountCRMResponse() { Result = new OperationResult(); }
    }

    public class LogsRegisterBankAccountCRMRequest
    {
        public string ContractId { get; set; }
        public string CRMKey { get; set; }
        public string BankName { get; set; }
        public string AccountBank { get; set; }
        public string RFC { get; set; }
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
    }
}
