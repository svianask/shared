﻿using System;

namespace ClientContracts.Message
{
    public class DeregisterPremiumRequest
    {
        public string ContractId { get; set; }
        public string ClientId { get; set; }
        public string FundsPorfolioOld { get; set; }
        public string FundsPortfolioNew { get; set; }
        public int TotalFunds { get; set; }
        public DateTime TranDate { get; set; }
        public string TranId { get; set; }
        public int PlatformId { get; set; }
    }
}
