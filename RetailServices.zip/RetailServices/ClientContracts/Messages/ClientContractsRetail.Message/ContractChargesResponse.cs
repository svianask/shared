﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractChargesResponse
    {
        private decimal _charges;
        private OperationResult _result;

        public ContractChargesResponse()
        {
            Result = new OperationResult();
        }

        public decimal Charges { get => _charges; set => _charges = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
