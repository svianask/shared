﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ClabeAccountResponse
    {

        private OperationResult _result;
        //private int _verifyDigit;

        public ClabeAccountResponse()
        {
            Result = new OperationResult();
        }

        public OperationResult Result { get => _result; set => _result = value; }
        //public int VerifyDigit { get => _verifyDigit; set => _verifyDigit = value; }
    }
}
