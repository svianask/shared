﻿

namespace ClientContracts.Message
{
    public class GetContributionSumAmountByContractRequest
    {
        public string ContractId { get; set; }

    }
}
