﻿using ClientContracts.Domain.AssociatedContractAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Message
{
    public class ContractContributionsRequest
    {
        public ContractContributionsRequest()
        {
            AssociatedContracts = new List<AssociatedContractMess>();
        }

        public List<AssociatedContractMess> AssociatedContracts { get; set; }
        public int Platform { get; set; }
    }

    
}
