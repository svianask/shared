﻿using System.Collections.Generic;

namespace ClientContracts.Message
{
    public class ContractUpdateRequest
    {
        public ContractUpdateRequest()
        {
        }

        public List<ContractUpdate> ContractsUpdate { get; set; }
    }

    public class ContractUpdate
    {
        public string ContractIdentifier { get; set; }
        public string Email { get; set; }
    }
}
