﻿using Common.Domain;
using ClientContracts.Domain.ContractAggregate;

namespace ClientContracts.Message
{
    public class ContractStatusResponse
    {
        public OperationResult Result;
        public ContractStatus ContractStatusInfo;
    }
}
