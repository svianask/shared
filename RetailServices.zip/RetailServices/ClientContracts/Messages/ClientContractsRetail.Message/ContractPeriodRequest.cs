﻿
using System;

namespace ClientContracts.Message
{
    public class GetContractPeriodRequest
    {
        public String ContractId { get; set; }
    }
}
