﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class ContractBalanceResponse
    {
        private decimal _contractBalance;
        private OperationResult _result;

        public ContractBalanceResponse()
        {
        }

        public decimal ContractBalance { get => _contractBalance; set => _contractBalance = value; }
        public OperationResult Result { get => _result; set => _result = value; }
    }
}
