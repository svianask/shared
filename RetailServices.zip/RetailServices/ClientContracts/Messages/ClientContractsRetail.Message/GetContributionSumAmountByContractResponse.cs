﻿
using Common.Domain;

namespace ClientContracts.Message
{
    public class GetContributionSumAmountByContractResponse
    {
        public OperationResult Result { get; set; }
        public decimal ContributionSumAmount { get; set; }
    }
}
