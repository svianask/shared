﻿using Common.Domain;

namespace ClientContracts.Message
{
    public class NotificationUpdatedContractResponse
    {
        public OperationResult Result { get; set; }

        public NotificationUpdatedContractResponse()
        {
            Result = new OperationResult();
        }

    }
}
