﻿


using Common.Domain;

namespace ClientContracts.Message
{
    public class GetAllowedUnpaidContributionsResponse
    {
        public OperationResult Result { get; set; }
        public int AllowedUnpaid { get; set; }
    }
}
