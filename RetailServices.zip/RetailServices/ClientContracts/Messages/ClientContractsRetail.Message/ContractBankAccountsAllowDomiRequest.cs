﻿namespace ClientContracts.Message
{
    public class ContractBankAccountsAllowDomiRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
    }
}
