﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.FundAggregate
{
    public class MarketValues : ValueObject<MarketValues>
    {
        private readonly decimal _marketValue;
        private readonly decimal _marketPurchaseValue;
        private readonly decimal _marketSalesValue;
        private readonly decimal _distributionPercent;

        private MarketValues(decimal marketValue, decimal marketPurchaseValue, decimal marketSalesValue, decimal ditributionPercent)
        {
            _marketValue = Math.Round(marketValue, 2);
            _marketPurchaseValue = Math.Round(marketPurchaseValue, 2);
            _marketSalesValue = Math.Round(marketSalesValue, 2);
            _distributionPercent = Math.Round(ditributionPercent, 2);
        }

        public decimal MarketValue => _marketValue;

        public decimal MarketPurchaseValue => _marketPurchaseValue;

        public decimal MarketSalesValue => _marketSalesValue;

        public decimal DistributionPercent => _distributionPercent;

        internal static MarketValues Create(decimal marketValue, decimal marketPurchaseValue, decimal marketSalesValue, decimal ditributionPercent)
        {
            return new MarketValues(marketValue, marketPurchaseValue, marketSalesValue, ditributionPercent);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                MarketValue,
                MarketPurchaseValue,
                MarketSalesValue,
                DistributionPercent
            };
        }
    }
}