﻿using System;
using System.Collections.Generic;
using Ddd;

namespace ClientContracts.Domain.FundAggregate
{
    public class Shares : ValueObject<Shares>
    {

        private readonly decimal _availableShares;
        private readonly decimal _committedShares;
        private readonly decimal _committedSharesSales;

        private Shares(decimal availableShares, decimal committedShares, decimal committedSharesSales)
        {
            _availableShares = Math.Round(availableShares, 2);
            _committedShares = Math.Round(committedShares, 2);
            _committedSharesSales = Math.Round(committedSharesSales, 2);
        }

        public decimal AvailableShares => _availableShares;

        public decimal CommittedShares => _committedShares;

        public decimal CommittedSharesSales => _committedSharesSales;

        internal static Shares Create(decimal availableShares, decimal committedShares, decimal committedSharesSales)
        {
            return new Shares(availableShares, committedShares, committedSharesSales);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>{
                AvailableShares,
                CommittedShares,
                CommittedSharesSales
            };
        }
    }
}