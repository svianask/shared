﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.FundAggregate
{
    public class Fund : Entity<string>
    {
        private Shares _shares;
        private Prices _prices;
        private MarketValues _marketValues;
        private string _contractId;
        private readonly string _name;

        private  Fund(string identifier, string name)
        {
            Id = identifier;
            _name = name;
        }

        public string ContractId => _contractId;

        public string Name => _name;

        public Shares Shares => _shares;

        public Prices Prices => _prices;

        public MarketValues MarketValues => _marketValues;

        public static Fund Create(string identifier, string name)
        {
            return new Fund(identifier, name);
        }

        public Fund SetShares(decimal availableShares, decimal committedShares, decimal committedSharesSales)
        {
            _shares = Shares.Create(availableShares, committedShares, committedSharesSales);
            return this;
        }

        public Fund SetPrices(decimal price, decimal purchasePrice, decimal salesPrice)
        {
            _prices = Prices.Create(price, purchasePrice, salesPrice);
            return this;
        }

        public void SetPriceDate(DateTime datePrice)
        {
            _prices.SetPriceDate(datePrice);
        }

        public Fund SetMarketValues(decimal marketValue, decimal marketPurchaseValue, decimal marketSalesValue, decimal ditributionPercent)
        {
            _marketValues = MarketValues.Create(marketValue, marketPurchaseValue, marketSalesValue, ditributionPercent);
            return this;
        }

        public Fund SetContract(string contractId)
        {
            _contractId = contractId;
            return this;
        }


    }
}
