﻿using Ddd;
using System;

namespace ClientContracts.Domain.FundAggregate
{
    public class FundPortfolio : Entity<string>
    {
        private readonly string _name;
        private readonly decimal _percentage;

        private FundPortfolio( string idFund, string name, decimal percentage)
        {
            Id = idFund;
            _name = name;
            _percentage = percentage;
        }

        public string Name => _name;
        public decimal Percentage => _percentage;

        public static FundPortfolio Create(string id, string name, decimal percentage)
        {
            if (string.IsNullOrEmpty(id)) { throw new ArgumentNullException("La propiedad id es requerida"); }
            if (string.IsNullOrEmpty(name)) { throw new ArgumentNullException("La propiedad name es requerida"); }
            return new FundPortfolio(id, name, percentage);
        }

    }
}
