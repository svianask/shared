﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.SummaryContributionsAggregate
{
    public class SummaryContributions : ValueObject<SummaryContributions>
    {
        private readonly int _totalContributions;
        private readonly int _expectedContributions;
        private readonly int _realizedContributions;
        private readonly int _failedContributions;
        private readonly int _pendingContributions;
        private readonly int _availableContributions;
        private readonly DateTime _afiliationDate;

        public SummaryContributions(int totalContributions, int expectedContributions, int realizedContributions, int failedContributions, DateTime afiliationDate,int availableContributions)
        {
            _totalContributions = totalContributions;
            _expectedContributions = expectedContributions;
            _realizedContributions = realizedContributions;
            _failedContributions = failedContributions;
            _pendingContributions = totalContributions - realizedContributions;
            _availableContributions = availableContributions;
            _afiliationDate = afiliationDate;
        }

        public int TotalContributions => _totalContributions;

        public int ExpectedContributions => _expectedContributions;

        public int RealizedContributions => _realizedContributions;

        public int FailedContributions => _failedContributions;

        public int PendingContributions => _pendingContributions;

        public int AvailableContributions => _availableContributions;

        public DateTime AfiliationDate => _afiliationDate;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
               {
                  TotalContributions,
                  ExpectedContributions,
                  RealizedContributions,
                  FailedContributions,
                  PendingContributions,
                  AvailableContributions,
                  AfiliationDate
               };
        }
    }
}
