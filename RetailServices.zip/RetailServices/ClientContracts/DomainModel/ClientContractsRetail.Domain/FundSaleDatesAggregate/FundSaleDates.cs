﻿using System;
using Ddd;
namespace ClientContracts.Domain.FundSaleDatesAggregate
{
    public class FundSaleDates : Entity<string>
    {
        private DateTime _saleLiquidityDate;
        private DateTime _saleOperationDate;

        private FundSaleDates(string fundId)
        {
            Id = fundId;
        }

        public DateTime SaleLiquidityDate => _saleLiquidityDate;
        public DateTime SaleOperationDate => _saleOperationDate;

        public static FundSaleDates Create(string fundId)
        {
            return new FundSaleDates(fundId);
        }

        public FundSaleDates SetSaleLiquidityDate(DateTime saleLiquidityDate)
        {
            this._saleLiquidityDate = saleLiquidityDate;
            return this;
        }

        public FundSaleDates SetSaleOperationDate(DateTime saleOperationDate)
        {
            this._saleOperationDate = saleOperationDate;
            return this;
        }
    }
}
