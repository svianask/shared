﻿

using Ddd;
using System;

namespace ClientContracts.Domain.ContractTrackerAggregate
{
    public class ContractTrackerGraphicInfo : Entity<long>
    {
        private readonly string _clientId;
        private readonly DateTime _historyDate;
        private readonly decimal _monthlySavingGoal;
        private readonly decimal _monthlySavingValuation;
        private readonly decimal _monthlyAdditionalValuation;
        private readonly decimal _monthlyTotalValuation;
        private readonly Boolean _hasPendingContribution;

        public ContractTrackerGraphicInfo(long Id, string clientId, DateTime historyDate, decimal monthlySavingGoal, decimal monthlySavingValuation,
                                          decimal monthlyAdditionalValuation, decimal monthlyTotalValuation,  bool hasPendingContribution)
        {
            this.Id = Id;
            _clientId = clientId;
            _historyDate = historyDate;
            _monthlySavingGoal = monthlySavingGoal;
            _monthlySavingValuation = monthlySavingValuation;
            _monthlyAdditionalValuation = monthlyAdditionalValuation;
            _monthlyTotalValuation = monthlyTotalValuation;
            _hasPendingContribution = hasPendingContribution;
        }

        public string ClientId => _clientId;
        public DateTime HistoryDate => _historyDate;
        public decimal MonthlySavingGoal => _monthlySavingGoal;
        public decimal MonthlySavingValuation => _monthlySavingValuation;
        public decimal MonthlyAdditionalValuation => _monthlyAdditionalValuation;
        public decimal MonthlyTotalValuation => _monthlyTotalValuation;

        public Boolean HasPendingContribution => _hasPendingContribution;

        public static ContractTrackerGraphicInfo Create(long Id, string clientId, DateTime historyDate, decimal monthlySavingGoal, decimal monthlySavingValuation,
                                          decimal monthlyAdditionalValuation, decimal monthlyTotalValuation, bool hasPendingContribution)
        {
            return new ContractTrackerGraphicInfo(Id, clientId, historyDate, monthlySavingGoal, monthlySavingValuation, monthlyAdditionalValuation, monthlyTotalValuation, hasPendingContribution);
        }

        public static ContractTrackerGraphicInfo CreateEmpty()
        {

            return new ContractTrackerGraphicInfo(0, "",DateTime.MinValue, 0, 0, 0, 0, false);
        }
    }
}
