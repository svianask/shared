﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.AssociatedContractAggregate
{
    public class AssociatedContract : ValueObject<AssociatedContract>
    {
        private readonly string _contractId;
        private readonly string _associatedContractId;
        private readonly int _associatedType;

        private AssociatedContract(string contractId, string associatedContractId, int associatedType)
        {
            _contractId = contractId;
            _associatedContractId = associatedContractId;
            _associatedType = associatedType;
        }

        public string ContractId => _contractId;

        public string AssociatedContractId => _associatedContractId;

        public int AssociatedType => _associatedType;

        public static AssociatedContract Create(string contractId, string associatedContract, int associatedType)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío"); }
            if (string.IsNullOrEmpty(associatedContract)) { throw new ArgumentException("associatedContract no puede ser nulo o vacío"); }
            if (associatedType < 1) { throw new ArgumentException("El valor de associatedType no es válido"); }
            return new AssociatedContract(contractId, associatedContract, associatedType);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                AssociatedContractId,
                AssociatedType
            };
        }
    }
}