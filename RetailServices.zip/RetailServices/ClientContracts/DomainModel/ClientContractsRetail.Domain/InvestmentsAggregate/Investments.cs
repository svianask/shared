﻿using ClientContracts.Domain.FundAggregate;
using Ddd;
using System.Collections.Generic;

namespace ClientContracts.Domain.InvestmentsAggregate
{
    public class Investments : ValueObject<Investments>
    {
        private readonly List<Fund> _cash;
        private readonly List<Fund> _funds;

        private Investments(List<Fund> cash, List<Fund> funds)
        {
            _cash = cash;
            _funds = funds;
        }

        public List<Fund> Cash => _cash;

        public List<Fund> Funds => _funds;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Cash,
                Funds
            };
        }

        public static Investments Create(List<Fund> cash, List<Fund> funds)
        {
            return new Investments(cash, funds);
        }
    }
}
