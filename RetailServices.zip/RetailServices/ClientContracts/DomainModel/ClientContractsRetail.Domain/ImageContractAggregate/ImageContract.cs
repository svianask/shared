﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.ImageContractAggregate
{
    public class ImageContract : Entity<string>
    {
        private readonly short _goalsId;
        private string _imageName;
         
        public ImageContract(string contractId, short goalsId)
        {
            Id = contractId;
            _goalsId = goalsId;
        }

        public short GoalsId { get => _goalsId;}
        public string ImageName { get => _imageName; }

        public void fillImageName(string imageName)
        { _imageName = imageName; }
    }
}
