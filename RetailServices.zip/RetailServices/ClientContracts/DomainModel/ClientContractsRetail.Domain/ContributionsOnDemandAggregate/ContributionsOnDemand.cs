﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.ContributionsOnDemandAggregate
{
    public class ContributionsOnDemand : ValueObject<ContributionsOnDemand>
    {
        private decimal _ordinalContributionsOnDemandAmount;
        private decimal _additionalContributionsOnDemandAmount;

        private ContributionsOnDemand(decimal _ordinalContributionsOnDemandAmount)
        {
            this._ordinalContributionsOnDemandAmount = _ordinalContributionsOnDemandAmount;
        }

        public decimal OrdinalContributionsOnDemandAmount => _ordinalContributionsOnDemandAmount;
        public decimal AdditionalContributionsOnDemandAmount => _additionalContributionsOnDemandAmount;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                OrdinalContributionsOnDemandAmount,
                _additionalContributionsOnDemandAmount
            };
        }

        public static ContributionsOnDemand Create(decimal ordinalContributionsOnDemandAmount)
        {
            return new ContributionsOnDemand(ordinalContributionsOnDemandAmount);
        }

        public ContributionsOnDemand SetOrdinalContributionsOnDemand(decimal ordinalContributionsOnDemandAmount)
        {
            this._ordinalContributionsOnDemandAmount += ordinalContributionsOnDemandAmount;
            return this;
        }

        public ContributionsOnDemand SetAdditionalContributionsOnDemand(decimal additionalContributionsOnDemandAmount)
        {
            this._additionalContributionsOnDemandAmount = additionalContributionsOnDemandAmount;
            return this;
        }
    }
}
