﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.AccountOwnerAggregate
{
    public class AccountOwner : Entity<string>
    {
        private int _ownerId;

        public AccountOwner(int OwnerId)
        {
            _ownerId = OwnerId;
        }

        public int OwnerId => _ownerId;

        public static AccountOwner Create(int OwnerId)
        {
            return new AccountOwner(OwnerId);
        }
    }
}
