﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.ContractContributionsAggregate
{
    public class ContractContributions : ValueObject<ContractContributions>
    {
        private decimal _ordinalContributionsAmount;
        private int _ordinalContributionsNumber;
        private decimal _additionalContributionsAmount;
        private int _additionalContributionsNumber;
        private DateTime _firstContributionDate;

        private ContractContributions(decimal ordinalContributionsAmount, int ordinalContributionsNumber)
        {
            _ordinalContributionsAmount = ordinalContributionsAmount;
            _ordinalContributionsNumber = ordinalContributionsNumber;
        }

        public decimal OrdinalContributionsAmount => _ordinalContributionsAmount;

        public int OrdinalContributionsNumber => _ordinalContributionsNumber;

        public decimal AdditionalContributionsAmount => _additionalContributionsAmount;

        public int AdditionalContributionsNumber => _additionalContributionsNumber;

        public DateTime FirstContributionDate => _firstContributionDate;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                OrdinalContributionsAmount,
                OrdinalContributionsNumber,
                AdditionalContributionsAmount,
                AdditionalContributionsNumber,
                FirstContributionDate
            };
        }

        public static ContractContributions Create(decimal ordinalContributionsAmount, int ordinalContributionsNumber)
        {
            return new ContractContributions(ordinalContributionsAmount, ordinalContributionsNumber);
        }

        public ContractContributions SetOrdinalContributions(decimal ordinalContributionsAmount, int ordinalContributionsNumber)
        {
            this._ordinalContributionsAmount += ordinalContributionsAmount;
            this._ordinalContributionsNumber += ordinalContributionsNumber;
            return this;
        }

        public ContractContributions SetAdditionalContributions(decimal additionalContributionsAmount, int additionalContributionsNumber)
        {
            this._additionalContributionsAmount = additionalContributionsAmount;
            this._additionalContributionsNumber = additionalContributionsNumber;
            return this;
        }

        public ContractContributions SetFirstContributionDate(DateTime firstContributionDate)
        {
            this._firstContributionDate = firstContributionDate;
            return this;
        }
    }
}
