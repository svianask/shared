﻿using Ddd;
using System;

namespace ClientContracts.Domain.ContractBankAccountAggregate
{
    public class ContractBankAccountAllowDomi : Entity<string>
    {
        private int _accountId;
        private string _accountNumber;
        private int _accountUseTypeId;
        private string _accountUseTypeDsc;

        private int _bankId;
        private string _accountBankName;
        private int _bankAccountTypeId;

        private int _classificationId;
        private string _classificationDsc;

        private int _accountStatusId;
        private string _accountStatusDsc;

        private ContractBankAccountAllowDomi(string contractId)
        {
            Id = contractId;
        }

        public static ContractBankAccountAllowDomi Create(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío."); }

            return new ContractBankAccountAllowDomi(contractId);
        }

        public ContractBankAccountAllowDomi SetAccountData(int accountId, string accountNumber, int accountUseTypeId, string accountUseTypeDsc)
        {
            this._accountId = accountId;
            this._accountNumber = accountNumber;
            this._accountUseTypeId = accountUseTypeId;
            this._accountUseTypeDsc = accountUseTypeDsc;
            return this;
        }

        public ContractBankAccountAllowDomi SetBankData(int bankId, string accountBankName, int bankAccountTypeId)
        {
            this._bankId = bankId;
            this._accountBankName = accountBankName;
            this._bankAccountTypeId = bankAccountTypeId;
            return this;
        }

        public ContractBankAccountAllowDomi SetClassificationAccount(int classificationId, string classificationDsc)
        {
            this._classificationId = classificationId;
            this._classificationDsc = classificationDsc;
            return this;
        }

        public ContractBankAccountAllowDomi SetAccountStatusDsc(int accountStatusId, string accountStatusDsc)
        {
            this._accountStatusId = accountStatusId;
            this._accountStatusDsc = accountStatusDsc;
            return this;
        }

        public int AccountId => _accountId;
        public string AccountNumber => _accountNumber;
        public int AccountUseTypeId => _accountUseTypeId;
        public string AccountUseTypeDsc => _accountUseTypeDsc;

        public int BankId => _bankId;
        public string AccountBankName => _accountBankName;
        public int BankAccountTypeId => _bankAccountTypeId;

        public int ClassificationId => _classificationId;
        public string Classification => _classificationDsc;

        public int AccountStatusId => _accountStatusId;
        public string AccountStatus => _accountStatusDsc;
    }
}
