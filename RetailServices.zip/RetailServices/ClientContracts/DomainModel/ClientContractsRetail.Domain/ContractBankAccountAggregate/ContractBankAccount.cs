﻿using System;
using Ddd;

namespace ClientContracts.Domain.ContractBankAccountAggregate
{
    public class ContractBankAccount : Entity<string>
    {
        private int _accountId;
        private int _bankId;
        private int _bankAccountTypeId;
        private string _accountNumber;
        private string _accountBankName;
        private int _accountUseTypeId;
        private int _classificationId;
        private string _accountStatusDsc;
        private string _accountUseTypeDsc;
        private DateTime _accountCreatedDate;
        private string _accountDescClasification;
        private string _acccountUseType;

        private ContractBankAccount(string contractId)
        {
            Id = contractId;
        }

       

        public static ContractBankAccount Create(string contractId )
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío."); }

            return new ContractBankAccount(contractId);
        }

        public ContractBankAccount SetBankData(int bankId,  string accountBankName, int bankAccountTypeId)
        {
            this._bankId = bankId;
            this._accountBankName = accountBankName;
            this._bankAccountTypeId = bankAccountTypeId;

            return this;
        }

        public ContractBankAccount SetAccountData(int accountId, string accountNumber, int accountUseTypeId)
        {
            this._accountId = accountId;
            this._accountNumber = accountNumber;
            this._accountUseTypeId = accountUseTypeId;

            return this;
        }

        public ContractBankAccount SetClassificationAccount(int classificationId)
        {
            this._classificationId = classificationId;
            return this;
        }

        public ContractBankAccount SetAccountStatusDsc(string accountStatusDsc)
        {
            this._accountStatusDsc = accountStatusDsc;
            return this;
        }

        public ContractBankAccount SetAccountUseTypeDsc( string accountUseTypeDsc)
        {
            _accountUseTypeDsc = accountUseTypeDsc;
            return this;
        }

        public ContractBankAccount SetAccountCreatedDate( DateTime accountCreatedDate)
        {
            _accountCreatedDate = accountCreatedDate;
            return this;
        }

        public ContractBankAccount SetAccountDescClasification( string accountDescClasification)
        {
            _accountDescClasification = accountDescClasification;
            return this;
        }

        public ContractBankAccount SetAccountUseType( string acccountUseType)
        {
            _acccountUseType = acccountUseType;
            return this;
        }

        public int BankId => _bankId;
        public int BankAccountTypeId => _bankAccountTypeId;
        public int AccountId => _accountId;
        public string AccountNumber => _accountNumber;
        public string AccountBankName => _accountBankName;
        public int AccountUseTypeId => _accountUseTypeId;
        public int ClassificationId => _classificationId;
        public string AccountStatus => _accountStatusDsc;
        public string AccountUseTypeDsc => _accountUseTypeDsc;
        public DateTime AccountCreatedDate => _accountCreatedDate;
        public string AccountDescClasification => _accountDescClasification;
        public string AccountUseType => _acccountUseType;
    }
}
