﻿using Ddd;
using System;

namespace ClientContracts.Domain.BankAggregate
{
    public class Bank : Entity<string>
    {
        private string _description;
        private string _descriptionShort;
        private int _code;

        private Bank(string bankId, string descr, string descrShort, int code)
        {
            Id = bankId;
            _description = descr;
            _descriptionShort = descrShort;
            _code = code;
        }

        public string Description => _description;
        public string DescriptionShort => _descriptionShort;
        public int Code => _code;

        public static Bank Create(string bankId, string descr, string descrShort, int code)
        {
            if(bankId == null) { throw new ArgumentException("BankId no puede ser nulo."); }
            if (string.IsNullOrEmpty(descr)) { throw new ArgumentException("La descripcion del banco no pueder ir vacia."); }
            if (string.IsNullOrEmpty(descrShort)) { throw new ArgumentException("La descripcion corta del banco no pueder ir vacia."); }
            if (code == null) { throw new ArgumentException("El codigo bancaria no puede ser nulo."); }

            return new Bank(bankId, descr, descrShort, code);
        }
    }
}
