﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.ContractAggregate
{
    public class Plan : ValueObject<Plan>
    {
        private readonly string _planName;

        public Plan(string planName)
        {
            _planName = planName;
        }

        public string PlanName => _planName;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                PlanName
            };
        }
    }
}
