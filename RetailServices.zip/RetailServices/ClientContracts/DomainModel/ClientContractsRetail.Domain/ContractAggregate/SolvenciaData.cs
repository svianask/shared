﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ddd;

namespace ClientContracts.Domain.ContractAggregate
{
    public class SolvenciaData : Entity<string>
    {
        private string _email;
        private string _fullName;

        private SolvenciaData(string user, string email, string fullName)
        {
            Id = user;
            _email = email;
            _fullName = fullName;
        }

        public string User => Id;
        public string Email => _email;
        public string FullName => _fullName;

        public static SolvenciaData Create(string user, string email, string fullName)
        {
            if (string.IsNullOrEmpty(user)) { throw new ArgumentException("user no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(email)) { throw new ArgumentException("email no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(fullName)) { throw new ArgumentException("fullName no puede ser nulo ni vacío"); }

            return new SolvenciaData(user, email, fullName);
        }
    }
}
