﻿using Ddd;

namespace ClientContracts.Domain.ContractAggregate
{
    public class ContractStatus : Entity<string>
    {
        private readonly int _statusId;
        private readonly string _statusDescription;

        private ContractStatus(string contratoId,int statusId, string statusDsc)
        {
            Id = contratoId;
            _statusDescription = statusDsc;
            _statusId = statusId;
        }

        public static ContractStatus Create(string contratoId, int statusId, string statusDsc)
        {
            return new ContractStatus(contratoId, statusId, statusDsc);
        }

        public string ContratoId => Id;
        public int StatusId => _statusId;
        public string StatusDescription => _statusDescription;
    }
}
