﻿using Ddd;
using System;

namespace ClientContracts.Domain.ContractAggregate
{
    public class Contract : Entity<string>
    {
        private ContactData _contactData;
        private string _planName;
        private readonly short _planId;

        private Contract(string contractId, short planId)
        {
            Id = contractId;
            _planId = planId;
        }

        public ContactData ContactData => _contactData;

        public string PlanName => _planName;

        public short PlanId => _planId;

        public static Contract Create(string contractId, short planId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío"); }
            if (planId <= 0) { throw new ArgumentException("El valor de planId no es válido"); }

            return new Contract(contractId, planId);
        }

        public Contract FillContactData(string cellPhone, string phone, string email)
        {
            this._contactData = new ContactData(cellPhone, phone, email);
            return this;
        }

        public Contract FillPlan(string planName)
        {
            this._planName = planName;
            return this;
        }
    }
}
