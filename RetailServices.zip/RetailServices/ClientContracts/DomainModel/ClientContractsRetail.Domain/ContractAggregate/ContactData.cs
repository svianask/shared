﻿using Ddd;
using System.Collections.Generic;

namespace ClientContracts.Domain.ContractAggregate
{
    public class ContactData : ValueObject<ContactData>
    {

        private readonly string _cellPhone;
        private readonly string _phone;
        private readonly string _email;

        public ContactData(string cellPhone, string phone, string email)
        {
            _cellPhone = cellPhone;
            _phone = phone;
            _email = email;
        }

        public string CellPhone => _cellPhone;
        public string Phone => _phone;
        public string Email => _email;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                CellPhone,
                Phone,
                Email
            };
        }
    }
}
