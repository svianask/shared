﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.ContractAggregate
{
    public class ContractPeriod : ValueObject<ContractPeriod>
    {
        private readonly DateTime _periodStart;
        private readonly DateTime _periodEnd;

        private ContractPeriod(DateTime periodStart, DateTime periodEnd)
        {
            this._periodStart = periodStart;
            this._periodEnd = periodEnd;    
        }

        public DateTime PeriodStart => _periodStart;
        public DateTime PeriodEnd => _periodEnd;

        public static ContractPeriod Create(DateTime periodStart, DateTime periodEnd)
        {
            return new ContractPeriod(periodStart, periodEnd);
        }

        public static ContractPeriod CreateEmpty()
        {
            return new ContractPeriod( DateTime.MinValue, DateTime.MinValue);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                PeriodStart,
                PeriodEnd
            };
        }
    }
}
