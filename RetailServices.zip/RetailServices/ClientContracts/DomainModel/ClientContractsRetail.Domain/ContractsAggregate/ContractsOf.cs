﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.ContractsAggregate
{
    public class ContractsOf : Entity<string>
    {
        private List<Contr> _contracts;

        public ContractsOf(string clientIdentifier)
        {
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("clientIdentifier no puede ser nulo o vacío"); }
            Id = clientIdentifier;
            _contracts = new List<Contr>();
        }

        public IEnumerable<Contr> Contracts => _contracts.AsReadOnly();

        public ContractsOf AddContract(Contr contract)
        {
            _contracts.Add(contract);
            return this;
        }
    }
}
