﻿using ClientContracts.Domain.ContractAggregate;
using Ddd;
using System;

namespace ClientContracts.Domain.ContractsAggregate
{
    public class Contr : Entity<string>
    {
        private readonly string _planBasId;
        private readonly int _platform;
        private readonly short _goalId;
        private readonly string _contratoAgrupa;
        private DateTime _afiliationDate;
        private DateTime _periodStart;
        private DateTime _periodEnd;
        private string _contractDigit;
        private string _goalDescription;
        private bool _applyDeducible;
        private int _statusContract;
        private int _statusOperation;

        private  Contr(string contractId, string planBasId, int platform, short goalId, string contratoAgrupa)
        {
            Id = contractId;
            _planBasId = planBasId;
            _platform = platform;
            _goalId = goalId;
            _contratoAgrupa = contratoAgrupa;

        }

        public string PlanBasId => _planBasId;

        public int Platform => _platform;

        public short GoalId => _goalId;

        public string ContratoAgrupa => _contratoAgrupa;

        public DateTime AfiliationDate => _afiliationDate;
        public DateTime PeriodStart => _periodStart;
        public DateTime PeriodEnd => _periodEnd;
        public string GoalDescription => _goalDescription;
        public string ContractDigit => _contractDigit;
        public bool ApplyDeducible => _applyDeducible;
        public int StatusContract => _statusContract;
        public int StatusOperation => _statusOperation;

        public static Contr Create(string contractId, string planBasId, int platform, short goalId, string contratoAgrupa)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(contratoAgrupa)) { throw new ArgumentException("contratoAgrupa no puede ser nulo ni vacío"); }
            if (string.IsNullOrEmpty(planBasId)) { throw new ArgumentException("El valor de planId no es válido"); }
            if (platform != 5 && platform != 10) { throw new ArgumentException("El tipo de producto es inválido"); }
            if (goalId < 0) { throw new ArgumentException("el id de la meta es inválido"); }
            
            return new Contr(contractId, planBasId, platform, goalId, contratoAgrupa);
        }

        public Contr SetAfiliationDate(DateTime afiliationDate )
        {
            _afiliationDate = afiliationDate;
            return this;
        }

        public Contr SetContractDigit(string contractDigit)
        {
            _contractDigit = contractDigit;
            return this;
        }

        public Contr SetGoalDescription(string goalDescription)
        {
            _goalDescription = goalDescription;
            return this;
        }
        public Contr SetDeducibleApply(bool applyDeducible)
        {
            _applyDeducible = applyDeducible;
            return this;
        }

        public Contr SetStatus(int statusContract, int statusOperation)
        {
            _statusContract = statusContract;
            _statusOperation = statusOperation;
            return this;
        }

        public Contr SetPeriod( ContractPeriod period )
        {
            _periodStart = period.PeriodStart;
            _periodEnd = period.PeriodEnd;
            return this;
        }
    }
}
