﻿using Ddd;
using System.Collections.Generic;

namespace ClientContracts.Domain.ContractInflationAggregate
{
    public class ContractInflation: ValueObject<ContractInflation>
    {
        private readonly bool _hasAutomaticInflation;
        private readonly decimal _customPercentInflation;

        public ContractInflation( bool hasAutomaticInflation, decimal customPercentInflation)
        {
            _hasAutomaticInflation = hasAutomaticInflation;
            _customPercentInflation = customPercentInflation;
        }

        public bool HasAutomaticInflation => _hasAutomaticInflation;
        public decimal CustomPercentInflation => _customPercentInflation;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                HasAutomaticInflation,
                CustomPercentInflation
            };
        }

        public static ContractInflation Create(bool hasAutomaticInflation, decimal customPercentInflation)
        {
            return new ContractInflation(hasAutomaticInflation, customPercentInflation);
        }

        public static ContractInflation CreateEmpty()
        {
            return new ContractInflation(false, 0);
        }

    }
}
