﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.ContractWithdrawalsAggregate
{
    public class ContractWithdrawals : ValueObject<ContractWithdrawals>
    {
        private decimal _ordinalWithdrawalsAmount;
        private int _ordinalWithdrawalsNumber;
        private decimal _additionalWithdrawalsAmount;
        private int _additionalWithdrawalsNumber;

        private ContractWithdrawals(decimal ordinalWithdrawalsAmount, int ordinalWithdrawalsNumber)
        {
            _ordinalWithdrawalsAmount = ordinalWithdrawalsAmount;
            _ordinalWithdrawalsNumber = ordinalWithdrawalsNumber;
        }

        public decimal OrdinalWithdrawalsAmount => _ordinalWithdrawalsAmount;

        public int OrdinalWithdrawalsNumber => _ordinalWithdrawalsNumber;

        public decimal AdditionalWithdrawalsAmount => _additionalWithdrawalsAmount;

        public int AdditionalWithdrawalsNumber => _additionalWithdrawalsNumber;


        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                OrdinalWithdrawalsAmount,
                OrdinalWithdrawalsNumber,
                AdditionalWithdrawalsAmount,
                AdditionalWithdrawalsNumber
            };
        }

        public static ContractWithdrawals Create(decimal ordinalWithdrawalsAmount, int ordinalWithdrawalsNumber)
        {
            return new ContractWithdrawals(ordinalWithdrawalsAmount, ordinalWithdrawalsNumber);
        }

        public ContractWithdrawals SetOrdinalWithdrawals(decimal ordinalWithdrawalsAmount, int ordinalWithdrawalsNumber)
        {
            this._ordinalWithdrawalsAmount += ordinalWithdrawalsAmount;
            this._ordinalWithdrawalsNumber += ordinalWithdrawalsNumber;
            return this;
        }

        public ContractWithdrawals SetAdditionalWithdrawals(decimal additionalWithdrawalsAmount, int additionalWithdrawalsNumber)
        {
            this._additionalWithdrawalsAmount = additionalWithdrawalsAmount;
            this._additionalWithdrawalsNumber = additionalWithdrawalsNumber;
            return this;
        }

    }
}
