﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Domain.Messages
{
    public class Contract_Type
    {
        private string _contractId;
        private string _type;

        public string ContractId { get => _contractId; set => _contractId = value; }
        public string Type { get => _type; set => _type = value; }
    }
}
