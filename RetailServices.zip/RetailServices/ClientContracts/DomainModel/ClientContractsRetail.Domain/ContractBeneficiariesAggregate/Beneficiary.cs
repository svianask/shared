﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.ContractBeneficiariesAggregate
{
    public class Beneficiary:ValueObject<Beneficiary>
    {
        private readonly string _fullName;
        private readonly string _kinship;
        private readonly decimal _percentage;


        private Beneficiary( string fullName, string kinship, decimal percentage)
        {
            _fullName = fullName;
            _kinship = kinship;
            _percentage = percentage;
        }   

        public string FullName => _fullName;
        public string Kinship => _kinship;
        public decimal Percentage => _percentage;

        public static Beneficiary Create(string fullName, string kinship, decimal percentage)
        {
            if (string.IsNullOrEmpty(fullName)) { throw new ArgumentException("FullName no puede ser nulo o vacío"); }
            if (string.IsNullOrEmpty(kinship)) { throw new ArgumentException("Kinship no puede ser nulo o vacío"); }

            return new Beneficiary(fullName, kinship, percentage);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                FullName,
                Kinship,
                Percentage
            };
        }
    }
}
