﻿using ClientContracts.Domain.ContractAggregate;
using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.ContractsOfClientAggregate
{
    public class ContractsOfClient : Entity<string>
    {
        private List<Contract> _contracts;

        public ContractsOfClient(string clientIdentifier)
        {
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("clientIdentifier no puede ser nulo o vacío"); }
            Id = clientIdentifier;
            _contracts = new List<Contract>();
        }

        public IEnumerable<Contract> Contracts => _contracts.AsReadOnly();

        public ContractsOfClient AddContract(Contract contract)
        {
            _contracts.Add(contract);
            return this;
        }


    }
}
