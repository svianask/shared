﻿using ClientContracts.Domain.AccountOwnerAggregate;
using Ddd;
using System;
using System.Collections.Generic;

namespace ClientContracts.Domain.DetailBankAccountAggregate
{
    public class DetailBankAccount : Entity<string>
    {
        private string _bankName;
        private string _bankAccount;
        private int _useType;
        private string _AccountClabe;
        private int _BankId;
        private int _typeAccount;
        // private Dictionary<string, string> _lstProducts;
        private readonly List<ContractProduct> _products;
        private string _accountStatusDsc;
        private string _accountUseTypeDsc;

        private AccountOwner _ownerAccount;

        private DetailBankAccount(int bankId, string bankName, string bankAccount, int useType, string accountClabe, int typeAccount)
        {
            _bankName = bankName;
            _bankAccount = bankAccount;
            _useType = useType;
            _AccountClabe = accountClabe;
            _BankId = bankId;
            _typeAccount = typeAccount;
            //_lstProducts = new Dictionary<string, string>();
            _products = new List<ContractProduct>();
        }

        public string BankName => _bankName;
        public string BankAccount => _bankAccount;
        public int Usetype => _useType;
        public string AccountClabe => _AccountClabe;
        public int BankId => _BankId;
        public int TypeAccount => _typeAccount;
        public AccountOwner AccountOwner => _ownerAccount;
        //public Dictionary<string, string> ListProducts => _lstProducts;
        public List<ContractProduct> Products => _products;
        public string AccountStatusDsc => _accountStatusDsc;
        public string AccountUseTypeDsc => _accountUseTypeDsc;

        public static DetailBankAccount Create(int bankId, string bankName, string bankAccount, int useType, string accountClabe, int typeAccount)
        {
            if (string.IsNullOrEmpty(bankName)) { throw new ArgumentException("El nombre del banco no puede ser nulo."); }
            if (string.IsNullOrEmpty(bankAccount)) { throw new ArgumentException("La cuenta bancaria no puede ser nula."); }

            return new DetailBankAccount(bankId, bankName, bankAccount, useType, accountClabe, typeAccount);
        }

        public DetailBankAccount FillProducts(string nameComercial, string contractId)
        {
            //_lstProducts.Add(contractId, nameComercial);
            return this;
        }

        public DetailBankAccount AddProduct(string nameComercial, string contractId, bool isAccountThird)
        {
            _products.Add(new ContractProduct(contractId, nameComercial, isAccountThird));
            return this;
        }

        public DetailBankAccount AddAccountStatusDsc(string accountStatusDsc) 
        {
            _accountStatusDsc = accountStatusDsc;
            return this; 
        }

        public DetailBankAccount AddAccountUseTypeDsc(string accountUseTypeDsc)
        {
            _accountUseTypeDsc = accountUseTypeDsc;
            return this;
        }

        public DetailBankAccount AddOwnerAccount(AccountOwner _ownerAccount)
        {
            this._ownerAccount = _ownerAccount;
            return this;
        }

        //protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        //{
        //    return new List<object>
        //    {
        //        BankName,
        //        BankAccount,
        //        Usetype,
        //        ListProducts,
        //    };
        //}
    }

    
}
