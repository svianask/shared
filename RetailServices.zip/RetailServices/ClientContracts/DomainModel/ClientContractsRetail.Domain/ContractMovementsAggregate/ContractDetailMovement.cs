﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ddd;

namespace ClientContracts.Domain.ContractMovementsAggregate
{
    public class ContractDetailMovement : Entity<String>
    {
        private string _movementContract;
        private string _movementSubaccountName;
        private string _movementDescription;
        private decimal _movementAmount;
        private DateTime _movementProcessDate;
        private string _movementBankAccount;

        private ContractDetailMovement(string contractId, string movementContract, string movementSubaccountName, decimal movementAmount, DateTime movementDate, string movementBankAccount)
        {
            Id = contractId;
            _movementContract = movementContract;
            _movementSubaccountName = movementSubaccountName;
            _movementAmount = movementAmount;
            _movementProcessDate = movementDate;
            _movementBankAccount = movementBankAccount;
        }

        public ContractDetailMovement SetMovementDescription(string movementDescription)
        {
            _movementDescription = movementDescription;
            return this;
        }

        public string MovementContractId => _movementContract;
        public DateTime MovementProcessDate => _movementProcessDate;
        public string MovementDescription => _movementDescription;
        public decimal MovementAmount => _movementAmount;
        public string MovementSubaccountName => _movementSubaccountName;
        public string MovementBankAccount => _movementBankAccount;

        public static ContractDetailMovement Create(string contractId, string movementContract, string movementSubaccountName, decimal movementAmount, DateTime movementDate, string movementBankAccount)
        {
            return new ContractDetailMovement(contractId, movementContract, movementSubaccountName, movementAmount, movementDate, movementBankAccount);
        }
    }
}
