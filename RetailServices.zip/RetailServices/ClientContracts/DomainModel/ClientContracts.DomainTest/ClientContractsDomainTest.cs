﻿using System;
using System.Linq;
using ClientContracts.Domain.ContractAggregate;
using ClientContracts.Domain.ContractsAcceptedAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ClientContracts.DomainTest
{
    [TestClass]
    public class ClientContractsDomainTest
    {
        [TestMethod, TestCategory("ParamError")]
        public void ContractsOfClientParamError()
        {
            Assert.ThrowsException<ArgumentException>(() => new ContractsOfClient(""));
            Assert.ThrowsException<ArgumentException>(() => new ContractsOfClient(null));
        }


        [TestMethod, TestCategory("ParamError")]
        [DataRow("579183", (short)0)]
        [DataRow("", (short)480)]
        [DataRow(null, (short)0)]
        public void ContractCreateParamError(string contractId, short planId)
        {
            Assert.ThrowsException<ArgumentException>(() => Contract.Create(contractId, planId));
        }


        [TestMethod, TestCategory("ProcessSuccessful")]
        public void ContractCreateSuccess()
        {
            Contract contract = Contract.Create("00000001", 480);
            contract.FillContactData("1234567890", "0987654321", "test@skandia.com.mx");
            contract.FillPlan("MULTITRUST");

            Assert.IsNotNull(contract);
            Assert.IsTrue(contract.ContactData.Equals(new ContactData("1234567890", "0987654321", "test@skandia.com.mx")));
            Assert.IsTrue(contract.PlanName.Equals("MULTITRUST"));
            Assert.IsTrue(contract.PlanId.Equals(480));
            Assert.IsTrue(contract.Id.Equals("00000001"));
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void PlanCreateSuccess()
        {
            Plan plan = new Plan("MULTITRUST");

            Assert.IsNotNull(plan);
            Assert.IsTrue(plan.Equals(new Plan("MULTITRUST")));
            Assert.IsTrue(plan != new Plan("GLOBALTRUST"));
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void ContactDataCreateSuccess()
        {
            ContactData contactData = new ContactData("1234567890", "0987654321", "test@skandia.com.mx");
            var notEqual = contactData.Equals(null);
            var equal = contactData.Equals(new ContactData("1234567890", "0987654321", "test@skandia.com.mx"));
            Assert.IsTrue(equal);
        }

        [TestMethod, TestCategory("ParamError")]
        [DataRow("", "test@gmail.com", "name")]
        [DataRow("MEAJ", "", "name")]
        [DataRow("MEAJ", "test@gmail.com", "")]
        public void SolvenciaDataCreateParamError(string user, string email, string fullName)
        {
            Assert.ThrowsException<ArgumentException>(() => SolvenciaData.Create(user, email, fullName));
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void SolvenciaDataCreateSucccess()
        {
            SolvenciaData solvenciaData = SolvenciaData.Create("user", "email", "fullName");
            Assert.IsNotNull(solvenciaData);
            Assert.IsTrue(solvenciaData.User.Equals("user"));
            Assert.IsTrue(solvenciaData.Email.Equals("email"));
            Assert.IsTrue(solvenciaData.FullName.Equals("fullName"));
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        [DataRow( 1, "DOLA911012PH2", "9999999999999", "2023-11-10 00:00:00", true, "2023-11-28 00:00:00.000")]
        [DataRow(1, null , "9999999999999", "2023-11-10 00:00:00", true, "2023-11-28 00:00:00.000")]
        public void ContractAceptationGetAllSuccess(int id, string contractor_rfc, string contract_id, string start_date, bool flag_activarPantalla, bool? flag_compromiso, DateTime? fecha_seleccion, DateTime? fecha_visualizacion, string created_date)
        {
            DateTime inp_start_date = DateTime.Parse(start_date);
            DateTime inp_created_date = DateTime.Parse(created_date);
            Assert.IsNotNull( ContractAccepted.Create( id, contractor_rfc, contract_id, inp_start_date) );

        }


        [TestMethod, TestCategory("ParamError")]
        [DataRow(1, null, null, "2023-11-10 00:00:00", true, "2023-11-28 00:00:00.000")]
        public void ContractAceptationGetAllError(int id, string contractor_rfc, string contract_id, string start_date, bool flag_activarPantalla, bool? flag_compromiso, DateTime? fecha_seleccion, DateTime? fecha_visualizacion, string created_date)
        {
            DateTime inp_start_date = DateTime.Parse(start_date);
            DateTime inp_created_date = DateTime.Parse(created_date);
            Assert.ThrowsException<ArgumentException>(() => ContractAccepted.Create(id, contractor_rfc, contract_id, inp_start_date) );
        }

    }
}
