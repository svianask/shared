﻿using ClientContracts.Application;
using ClientContracts.Domain.ContractAggregate;
using ClientContracts.Domain.ContractBankAccountAggregate;
using ClientContracts.Domain.ContractsAcceptedAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using ClientContracts.Domain.FrecuencyTypeAggregate;
using ClientContracts.Message;
using ClientContracts.Repository;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using System.Collections.Generic;
using System.Configuration;
using Utilities.Application;
using prxyNotsTypes = ClientContracts.Repository.NotificationsProxyTypes;

namespace ClientContract.ApplicationTest
{
    [TestClass]
    public class ClientContractsAppTest
    {
        private readonly Mock<IRAWRAPSIIFDa> _repositoryContract;
        private readonly Mock<IRADa> _repositoryPlan;
        private readonly Mock<ISeriLogHelper> _SeriloHelper;
        private readonly Mock<INotificationsProxy> _notificationsProxy;
        private readonly Mock<ISecurityGlobalAppDa> _repositorySecurityGlobal;
        private readonly Mock<ITransform> _transform;
        private readonly ClientContractsApp _clientContractsBL;


        private List<ContractUpdate> contractsUpdateSuccess;
        private List<ContractUpdate> contractsUpdateErrorNoRows;

        public ClientContractsAppTest()
        {
            _repositoryContract = new Mock<IRAWRAPSIIFDa>();
            _repositoryPlan = new Mock<IRADa>();
            _SeriloHelper = new Mock<ISeriLogHelper>();
            _notificationsProxy = new Mock<INotificationsProxy>();
            _repositorySecurityGlobal = new Mock<ISecurityGlobalAppDa>();
            _transform = new Mock<ITransform>();
            _clientContractsBL = new ClientContractsApp(_SeriloHelper.Object, _repositoryContract.Object,
                _repositoryPlan.Object, _notificationsProxy.Object, _repositorySecurityGlobal.Object, _transform.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            _repositoryContract
                .Setup(x => x.GetClientContracts("XXXX123456"))
                .Returns(
                    new ContractsOfClient("XXXX123456")
                    .AddContract(
                        Contract.Create("1234567890", 480)
                        .FillContactData("1234598760", "0987654321", "test@skandia.com.mx")
                    )
                );

            _repositoryPlan
                .Setup(x => x.GetByContract("1234567890"))
                .Returns(
                    new Plan("MULTITRUST")
                );

            _repositoryContract
                .Setup(x => x.UpdateContactData("1234567890", "test@skandia.com.mx"))
                .Returns(1);

            _repositorySecurityGlobal
                .Setup(x => x.GetClienteDatosSolvencia("XXXX123456XXX", 1))
                .Returns(
                    SolvenciaData.Create("XXXX123456XXX", "test@skandia.com.mx", "fullName")
                );

            _notificationsProxy
                .Setup(x => x.NotificationsAppSync(new prxyNotsTypes.SendNotificationDistListNRequest()))
                .Returns(new OperationResult() { Successful = true });


            contractsUpdateSuccess = new List<ContractUpdate>();
            contractsUpdateSuccess.Add(new ContractUpdate() { ContractIdentifier = "1234567890", Email = "test@skandia.com.mx" });

            contractsUpdateErrorNoRows = new List<ContractUpdate>();
            contractsUpdateErrorNoRows.Add(new ContractUpdate() { ContractIdentifier = "000000000", Email = "test@skandia.com.mx" });
        }

        [TestMethod, TestCategory("ParamError")]
        public void GetClientContractsParamError()
        {
            OperationResult result = new OperationResult();
            var clientContract = _clientContractsBL.GetClientContracts("", out result);

            Assert.IsFalse(result.Successful);
        }


        [TestMethod, TestCategory("ProcessFailed")]
        public void GetClientContractsFailClientIdentifier()
        {
            OperationResult result = new OperationResult();
            var ClientContracts = _clientContractsBL.GetClientContracts("EUEA7309076G7", out result);

            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void GetClientContractsSuccess()
        {
            OperationResult result = new OperationResult();
            var ClientContracts = _clientContractsBL.GetClientContracts("XXXX123456", out result);

            Assert.IsTrue(result.Successful);
        }

        [TestMethod, TestCategory("ParamError")]
        public void UpdateContractsContactParamErrorContractsNull()
        {
            OperationResult result = new OperationResult();

            _clientContractsBL.UpdateContractsContactInfo(null, out result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("ProcessFailed")]
        public void UpdateContractsContactFailNoUpdateRows()
        {
            OperationResult result = new OperationResult();

            _clientContractsBL.UpdateContractsContactInfo(contractsUpdateErrorNoRows, out result);

            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void UpdateContractsContactSuccess()
        {
            OperationResult result = new OperationResult();
            _clientContractsBL.UpdateContractsContactInfo(contractsUpdateSuccess, out result);

            Assert.IsTrue(result.Successful);
        }

        [TestMethod, TestCategory("ParamError")]
        public void SendNotificationUpdateContractParamErrorContractsNull()
        {
            OperationResult result = new OperationResult();

            _clientContractsBL.SendNotificationUpdateContract(null, out result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod, TestCategory("ProcessFailed")]
        public void SendNotificationUpdateContractFailClientIdentifier()
        {
            OperationResult result = new OperationResult();
            ConfigurationManager.AppSettings["Notifications:UpdateContract"] = "1";
            var sendNotification = _clientContractsBL.SendNotificationUpdateContract("EUEA7309076G7", out result);

            Assert.IsTrue(result.Successful && result.SystemMessages.Count > 0);
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void SendNotificationUpdateContractSuccess()
        {
            OperationResult result = new OperationResult();
            ConfigurationManager.AppSettings["Notifications:UpdateContract"] = "1";
            var sendNotification = _clientContractsBL.SendNotificationUpdateContract("XXXX123456XXX", out result);

            Assert.IsTrue(result.Successful && result.SystemMessages.Count == 0);
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void GetContractsAcceptedSuccess()
        {
            OperationResult result = new OperationResult();
            _repositoryContract
               .Setup(x => x.GetContractsAccepted("AISL931105514"))
               .Returns(
                   new List<ContractAccepted>()
                   {
                        ContractAccepted.Create(1, "DOLA911012PH2", "9999999999999", new System.DateTime(2023 , 11, 30) )
                   }
               );
            List<ContractAccepted> contracts = _clientContractsBL.GetContractsAccepted("AISL931105514", out result);

            Assert.IsNotNull(contracts);
            Assert.IsTrue(result.Successful && result.SystemMessages.Count == 0);
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void GetContractsAcceptedFail()
        {
            OperationResult result = new OperationResult();
            List<ContractAccepted> contracts = _clientContractsBL.GetContractsAccepted("AISL931105514", out result);

            Assert.IsNull(contracts);
            Assert.IsFalse(!result.Successful && result.SystemMessages.Count == 0);
        }

        [TestMethod, TestCategory("Domiciliations")]
        public void GetContractBankAccountsAllowDomi()
        {
            _repositoryContract.Setup(c => c.GetContractBankAccountsAllowDomi(It.IsAny<string>(), It.IsAny<string>())).Returns(Mock.Of<List<ContractBankAccountAllowDomi>>());
            var contractBankAccountAllowDomis = _clientContractsBL.GetContractBankAccountsAllowDomi("727599", "BEEJ930917SW1", out var result);
            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(contractBankAccountAllowDomis);
        }

        [TestMethod, TestCategory("Domiciliations")]
        public void GetFrecuencyTypeCatalogForDomi()
        {
            _repositoryContract.Setup(c => c.GetFrecuencyTypeCatalogForDomi()).Returns(Mock.Of<List<FrecuencyTypeCatalog>>());
            var frecuencyTypeCatalogs = _clientContractsBL.GetFrecuencyTypeCatalogForDomi(out var result);
            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(frecuencyTypeCatalogs);
        }

    }
}
