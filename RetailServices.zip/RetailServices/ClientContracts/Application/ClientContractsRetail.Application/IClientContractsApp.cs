﻿using ClientContracts.Domain.AssociatedContractAggregate;
using ClientContracts.Domain.BankAggregate;
using ClientContracts.Domain.CashTransactionAggregate;
using ClientContracts.Domain.ContractAggregate;
using ClientContracts.Domain.ContractBankAccountAggregate;
using ClientContracts.Domain.ContractBeneficiariesAggregate;
using ClientContracts.Domain.ContractContributionsAggregate;
using ClientContracts.Domain.ContractInflationAggregate;
using ClientContracts.Domain.ContractMovementsAggregate;
using ClientContracts.Domain.ContractsAcceptedAggregate;
using ClientContracts.Domain.ContractsAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using ClientContracts.Domain.ContractsPeriodicityAggregate;
using ClientContracts.Domain.ContractTrackerAggregate;
using ClientContracts.Domain.ContractWithdrawalsAggregate;
using ClientContracts.Domain.ContributionsOnDemandAggregate;
using ClientContracts.Domain.DetailBankAccountAggregate;
using ClientContracts.Domain.FrecuencyTypeAggregate;
using ClientContracts.Domain.FundAggregate;
using ClientContracts.Domain.FundSaleDatesAggregate;
using ClientContracts.Domain.InvestmentsAggregate;
using ClientContracts.Domain.SummaryContributionsAggregate;
using ClientContracts.Message;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientContracts.Application
{
    public interface IClientContractsApp
    {
        ContractsOfClient GetClientContracts(string clientIdentifier, out OperationResult result);
        void UpdateContractsContactInfo(List<ContractUpdate> Contracts, out OperationResult result);
        OperationResult SendNotificationUpdateContract(string clientIdentifier, out OperationResult result);
        ContractsOf GetContracts(string clientIdentifier, out OperationResult result);
        SummaryContributions GetSummaryContributionsNumber(string contractId, out OperationResult result);
        CashTransaction GetContractCashTransactions(string contractId, int platform, DateTime? startDate, DateTime? endDate, out OperationResult result);
        decimal GetOnDemandCash(string contractId, out OperationResult result);
        List<AssociatedContract> GetAssociateContracts(string clientIdentifier, out OperationResult result);
        List<AssociatedContract> GetAssociateContractsByContract(string contractId, out OperationResult result);
        decimal GetContractInitBalance(string contractId, int platform, DateTime afiliationDate, string contractControlContributions, string additionalContributionsContract, out OperationResult result);
        decimal GetContractCharges(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result);
        Investments GetContractBalanceDetail(int platform, List<string> contracts, out OperationResult result);
        decimal GetContractCommittedAmount(string contractId, out OperationResult result);
        ContractContributions GetContractContributions(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result);
        ContractWithdrawals GetContractWithdrawals(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result);
        ContributionsOnDemand GetContributionsOnDemand(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result);
        string GetClientRFCByContract(string contractId, out OperationResult result);
        Contr GetContractInfo(string contractId, out OperationResult result);
        string GetClientIdByContract(string contractId, out OperationResult result);
        List<ContractBankAccount> GetContractBankAccounts(string contractId, out OperationResult result);
        List<DetailBankAccount> GetContractBankAccountsByRfc(string RFC, out OperationResult result);
        decimal GetContractSummaryWithdrawalsCommitted(string contractId, out OperationResult result);
        List<FundSaleDates> GetContractFundsSaleDates(List<string> Funds, DateTime dateRequest, int platform, out OperationResult result);
        string GetContractChargeBonusDescriptionById(int operationType, int platform, string chargeId, out OperationResult result);
        ContractWithdrawals GetContractWithdrawalsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        ContractContributions GetContractContributionsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        ContributionsOnDemand GetContributionsOnDemandByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        decimal GetContractChargesByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        List<ContractDetailMovement> GetContractDetailCashMovementsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        List<ContractDetailMovement> GetContractDetailFundsMovementsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);

        List<ContractDetailMovement> GetContractDetailPendingMovementsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result);
        List<Bank> GetBanksCatalog(int platform, out OperationResult result);
        string GetCRMKey(string contractId, int productType, out OperationResult result);
        OperationResult LogsRegisterBankAccountCRM(LogsRegisterBankAccountCRMRequest logInfo);

        void GetClabeAccountVerifyDigit(string accountClabe, out OperationResult result);

        List<DetailBankAccount> GetAccountsByContract(string ContractId, out OperationResult result);

        ContractStatus GetContractStatusInfo(string contractId, out OperationResult result);

        string GetReferenceNumber(string contractId, int platform, out OperationResult result);
        List<ContractAccepted> GetContractsAccepted(string rfc, out OperationResult result);
        void UpdateContractsAccepted(string rfc, string contractId, bool isCommited, out OperationResult result);
        ContractPeriodicity GetContractPeriodicity(string contractMaster, out OperationResult result);
        ContractsOf GetClientContractsActivePaidUp(string clientIdentifier, out OperationResult result);
        List<AssociatedContract> GetAssociateContractsActivePaidUp(string clientIdentifier, out OperationResult result);
        decimal GetPendingContributionAmount(string contractId, out OperationResult result);
        decimal GetContributionSum(string contractId, out OperationResult result);
        ContractInflation GetContractInflation(string contractId, out OperationResult result);
        int GetAllowedUnpaidContributions(string contractId, out OperationResult result);
        List<ContractTrackerGraphicInfo> GetContractTrackerGraphicInfo(string contractId, out OperationResult result);
        List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier, out OperationResult result);
        List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi(out OperationResult result);
        ContractPeriod GetContractPeriodByContract(string contractId, out OperationResult result);
        List<FundPortfolio> GetPortfolioByContract(string contractId, out OperationResult result);
        void ExecuteDeregisterPremium(string contractId, string clientId, string fundsPorfolioOld, string fundsPortfolioNew, DateTime tranDate, string tranId, int platformId, out OperationResult result);
        List<Beneficiary> GetContractBeneficiaries(string contractId, int platformId, out OperationResult result);
    }
}
