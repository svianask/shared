﻿using ClientContracts.Domain.AssociatedContractAggregate;
using ClientContracts.Domain.BankAggregate;
using ClientContracts.Domain.CashTransactionAggregate;
using ClientContracts.Domain.ContractAggregate;
using ClientContracts.Domain.ContractBankAccountAggregate;
using ClientContracts.Domain.ContractBeneficiariesAggregate;
using ClientContracts.Domain.ContractContributionsAggregate;
using ClientContracts.Domain.ContractInflationAggregate;
using ClientContracts.Domain.ContractMovementsAggregate;
using ClientContracts.Domain.ContractsAcceptedAggregate;
using ClientContracts.Domain.ContractsAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using ClientContracts.Domain.ContractsPeriodicityAggregate;
using ClientContracts.Domain.ContractTrackerAggregate;
using ClientContracts.Domain.ContractWithdrawalsAggregate;
using ClientContracts.Domain.ContributionsOnDemandAggregate;
using ClientContracts.Domain.DetailBankAccountAggregate;
using ClientContracts.Domain.FrecuencyTypeAggregate;
using ClientContracts.Domain.FundAggregate;
using ClientContracts.Domain.FundSaleDatesAggregate;
using ClientContracts.Domain.InvestmentsAggregate;
using ClientContracts.Domain.SummaryContributionsAggregate;
using ClientContracts.Message;
using ClientContracts.Repository;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using Utilities.Application;
using static Common.Domain.Enumerations;
using prxyNotsTypes = ClientContracts.Repository.NotificationsProxyTypes;

namespace ClientContracts.Application
{
    public class ClientContractsApp : IClientContractsApp
    {
        delegate void delUpdateContactData(string contractIdentifier, string email);

        private readonly ISeriLogHelper _log;
        private readonly IRAWRAPSIIFDa _repositoryRetail;
        private readonly IRADa _repositoryRetailExtend;
        private readonly INotificationsProxy _notificationsProxy;
        private readonly ISecurityGlobalAppDa _repositorySecurityGlobalAppDa;
        private readonly ITransform _transform;

        public ClientContractsApp(ISeriLogHelper log, IRAWRAPSIIFDa iRawRapSiifDa,
            IRADa iRaDa, INotificationsProxy iNotificationsProxy, ISecurityGlobalAppDa iSecurityGlobalAppDa,
            ITransform iTransform)
        {
            _log = log;
            _repositoryRetail = iRawRapSiifDa;
            _repositoryRetailExtend = iRaDa;
            _notificationsProxy = iNotificationsProxy;
            _repositorySecurityGlobalAppDa = iSecurityGlobalAppDa;
            _transform = iTransform;
        }

        public ContractsOfClient GetClientContracts(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult();
            ContractsOfClient clientContracts = null;

            try
            {
                clientContracts = _repositoryRetail.GetClientContracts(clientIdentifier);
                if (clientContracts == null || clientContracts.Contracts.Count() <= 0) { throw new ArgumentException("El cliente no tiene contratos asociados"); }

                foreach (Domain.ContractAggregate.Contract contract in clientContracts.Contracts)
                {
                    try
                    {
                        var planName = _repositoryRetailExtend.GetComercialNameByPlanId(contract.PlanId.ToString()).PlanName;
                        contract.FillPlan(planName);
                    }
                    catch (Exception ex)
                    {
                        _log.Error(ex, "Error al obtener el plan del contrato del cliente {data}", new { contract.Id, clientIdentifier });
                    }
                }

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente {clientIdentifier}", clientIdentifier);
                result = new OperationResult
                {
                    Successful = false,
                    SystemMessages = new List<SystemMessage> {
                        new SystemMessage { Message = "Error al obtener los contratos del cliente - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                    }
                };

            }
            return clientContracts;
        }

        public void UpdateContractsContactInfo(List<ContractUpdate> contracts, out OperationResult result)
        {
            result = new OperationResult();
            result.Successful = true;

            try
            {
                if (contracts == null) { throw new ArgumentException("No se encontraron contratos para actualizar"); }

                foreach (ContractUpdate cont in contracts)
                {
                    try
                    {
                        var updateRow = _repositoryRetail.UpdateContactData(cont.ContractIdentifier, cont.Email);

                        if (updateRow <= 0) { throw new ApplicationException("Error al actualizar el registro"); }
                    }
                    catch (Exception ex)
                    {
                        _log.Error(ex, "Error al actualizar los datos de contacto del contrato: {contractIdentifier}", cont.ContractIdentifier);
                        result.Successful = false;
                        result.SystemMessages.Add(
                            new SystemMessage { Message = "Error al actualizar los datos de contacto del contrato - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar los datos de contacto del contrato");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al actualizar los datos de contacto del contrato " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );

            }

        }

        public OperationResult SendNotificationUpdateContract(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            try
            {
                if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("El id del cliente no puede ser nulo o vacío"); }

                string operation = ConfigurationManager.AppSettings["Notifications:UpdateContract"].ToString();
                var solvenciaData = _repositorySecurityGlobalAppDa.GetClienteDatosSolvencia(clientIdentifier, 1);
                if (solvenciaData != null)
                {
                    result.Successful = true;
                    _notificationsProxy.NotificationsAppSync(FillTemplateUpdateContractData(operation, solvenciaData));
                }
                else
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "No se pudo obtener los datos de solvencia para el usuario:" + clientIdentifier, MessageType = SystemMessageTypes.Warning });
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al al enviar la notificación");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Ocurrió un error al enviar la notificación " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return result;
        }

        private prxyNotsTypes.SendNotificationDistListNRequest FillTemplateUpdateContractData(string template, SolvenciaData solvenciaData)
        {
            var clientEmail = solvenciaData.Email;
            var name = solvenciaData.FullName;
            /** PARAMETROS DEL HTML **/
            Dictionary<string, string> dsMensajes = new Dictionary<string, string>
            {
                { "%%campo3%%", name }
            };

            prxyNotsTypes.SendNotificationDistListNRequest request = new prxyNotsTypes.SendNotificationDistListNRequest()
            {
                ContextBusiness = new prxyNotsTypes.ContextBusinessN()
                {
                    Application = "Portal Retail",
                    Process = "NOTIFICACION ACTUALIZACION DATOS CONTRATO",
                    ClientIdentifier = "000000000",
                    ClientMobile = "",
                    Contract = "00000000",
                    ClientEmail = clientEmail,
                },
                SendParameters = new prxyNotsTypes.SendParametersN()
                {
                    Amount = 0,
                    ClientIdentifier = "000000000",
                    ClientTypeId = "C",
                    Contract = "00000000",
                    EmailFP = "",
                    MobileClient = "",
                    MobileFP = "",
                    EmailClient = clientEmail,
                    AdditionalMessages = dsMensajes
                },
                Plantilla = (NotificationsProxyTypes.NotificationTemplateN)Enum.Parse(typeof(NotificationsProxyTypes.NotificationTemplateN), template),
                LstEmail = new string[] { "" }
            };

            return request;
        }

        public ContractsOf GetContracts(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult();
            ContractsOf clientContracts = null;

            try
            {
                result.Successful = true;
                clientContracts = _repositoryRetail.GetContracts(clientIdentifier);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = $"Error al obtener los contratos del cliente {ex.Message}; {ex.StackTrace}",
                    MessageType = SystemMessageTypes.Error
                });
            }

            return clientContracts;
        }

        public SummaryContributions GetSummaryContributionsNumber(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            SummaryContributions summaryContributions = null;

            try
            {
                result.Successful = true;
                summaryContributions = _repositoryRetail.GetSummaryContributionsNumber(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el resumen del número de contribuciones {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el resumen del número de contribuciones " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return summaryContributions;
        }

        public CashTransaction GetContractCashTransactions(string contractId, int platform, DateTime? startDate, DateTime? endDate, out OperationResult result)
        {
            result = new OperationResult();
            CashTransaction cashTransaction = null;

            try
            {
                result.Successful = true;
                cashTransaction = _repositoryRetail.GetContractCashTransactions(contractId, platform, startDate, endDate);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las transacciones de efectivo del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las transacciones de efectivo del contrato " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return cashTransaction;
        }

        public decimal GetOnDemandCash(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            decimal onDemandCash = 0M;

            try
            {
                result.Successful = true;
                onDemandCash = _repositoryRetail.GetOnDemandCash(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto de las aportaciones del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el monto de las aportaciones del contrato" + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return onDemandCash;
        }

        public List<AssociatedContract> GetAssociateContracts(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult();
            List<AssociatedContract> lstAssociatedContracts = new List<AssociatedContract>();

            try
            {
                result.Successful = true;
                lstAssociatedContracts = _repositoryRetail.GetAssociateContracts(clientIdentifier);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos asociados al cliente: {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos asociados al cliente - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return lstAssociatedContracts;

        }

        public decimal GetContractInitBalance(string contractId, int platform, DateTime afiliationDate, string contractControlContributions, string additionalContributionsContract, out OperationResult result)
        {
            result = new OperationResult();
            decimal balance = 0M;

            try
            {
                result.Successful = true;
                var queryDates = new List<DateTime> { afiliationDate.AddDays(-1) };

                balance = GetContractBalanceHistory(contractId, platform, queryDates, contractControlContributions, additionalContributionsContract);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los saldos de los contratos: {cntx}", new { contractId, contractControlContributions, additionalContributionsContract });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los saldos de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return balance;
        }

        private decimal GetContractBalanceHistory(string contractId, int platform, List<DateTime> queryDates, string contractControlContributions, string additionalContributionsContract)
        {
            decimal balanceHistory = 0M;
            StringBuilder strQueryDates = new StringBuilder();
            foreach (DateTime queryDate in queryDates)
            {
                var year = queryDate.Year.ToString();
                var month = queryDate.Month.ToString().PadLeft(2, '0');
                var day = queryDate.Day.ToString().PadLeft(2, '0');
                strQueryDates.Append(year + month + day + "|");
            }

            var firstSPName = platform == 10 ? "usp_SOC_SIIF_RS_GetContratoBalancesHistorico" : "usp_SOC_SIIF_GT_GetContratoBalancesHistorico";
            var secondSPName = platform == 10 ? "usp_SOC_SIIF_RSH_GetContratoBalancesHistorico" : "usp_SOC_SIIF_GTH_GetContratoBalancesHistorico";

            balanceHistory += _repositoryRetail.GetContractBalanceHistory(contractId, strQueryDates.ToString(), firstSPName, true);
            balanceHistory += _repositoryRetail.GetContractBalanceHistory(contractId, strQueryDates.ToString(), secondSPName, true);

            if (!string.IsNullOrEmpty(contractControlContributions))
            {
                balanceHistory += _repositoryRetail.GetContractBalanceHistory(contractControlContributions, strQueryDates.ToString(), firstSPName, true);
                balanceHistory += _repositoryRetail.GetContractBalanceHistory(contractControlContributions, strQueryDates.ToString(), secondSPName, true);
            }

            if (!string.IsNullOrEmpty(additionalContributionsContract))
            {
                balanceHistory += _repositoryRetail.GetContractBalanceHistory(additionalContributionsContract, strQueryDates.ToString(), firstSPName, true);
                balanceHistory += _repositoryRetail.GetContractBalanceHistory(additionalContributionsContract, strQueryDates.ToString(), secondSPName, true);
            }

            return balanceHistory;
        }

        private decimal GetPortfolioProduct(string contractId, int platform, string contractControlContributions, string additionalContributionsContract)
        {
            decimal balancePortfolio = 0M;

            var storedProcName = platform == 10 ? "usp_SOC_SIIF_RS_GetContratoPortafolio" : "usp_SOC_SIIF_GT_GetContratoPortafolio";

            balancePortfolio += _repositoryRetail.GetPortfolioProduct(contractId, storedProcName);
            if (!string.IsNullOrEmpty(contractControlContributions))
            {
                balancePortfolio += _repositoryRetail.GetPortfolioProduct(contractControlContributions, storedProcName);
            }

            if (!string.IsNullOrEmpty(additionalContributionsContract))
            {
                balancePortfolio += _repositoryRetail.GetPortfolioProduct(additionalContributionsContract, storedProcName);
            }

            return balancePortfolio;
        }

        private List<DateTime> defineDates(DateTime afiliationDate)
        {
            return new List<DateTime>() {
                        Convert.ToDateTime(afiliationDate),
                        DateTime.Now,
                        Convert.ToDateTime(afiliationDate).AddDays(-1)
                    };

        }

        public decimal GetContractCharges(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result)
        {
            result = new OperationResult();
            decimal charges = 0M;

            try
            {
                result.Successful = true;
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);

                charges = _repositoryRetail.GetContractCharges(stringXml, platform);

                decimal historicCharges = _repositoryRetail.GetContractHistoricCharges(stringXml, platform);

                // merge historic data
                charges += historicCharges;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los cargos de los contratos: {cntx}", new { associatedContracts, platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los cargos de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return charges;
        }

        public Investments GetContractBalanceDetail(int platform, List<string> contracts, out OperationResult result)
        {
            string strXmlContracts = string.Empty;
            string storedProcName = string.Empty;
            Investments investment = null;
            result = new OperationResult();

            try
            {
                result.Successful = true;
                strXmlContracts = _transform.ObjectToXml<List<string>>(contracts);

                storedProcName = platform == 10 ? "usp_SOC_SIIF_RS_GetDetalleSaldosContrato" : "usp_SOC_SIIF_GT_GetDetalleSaldosContrato";
                investment = _repositoryRetail.GetContractBalanceDetail(strXmlContracts, storedProcName);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el detalle de los saldos de los contratos: {cntx}", new { contracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el detalle de los saldos de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return investment;
        }

        public decimal GetContractCommittedAmount(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            decimal committedAmount = 0M;
            try
            {
                result.Successful = true;
                committedAmount = _repositoryRetail.GetContractCommittedAmount(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto comprometido del contrato: {cnt}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el monto comprometido del contrato - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return committedAmount;
        }

        public ContractContributions GetContractContributions(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result)
        {
            result = new OperationResult();
            ContractContributions contractsContributions = null;
            try
            {
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                contractsContributions = _repositoryRetail.GetContractContributions(stringXml, platform);

                ContractContributions contractsHistoricContributions = _repositoryRetail.GetContractHistoricContributions(stringXml, platform);

                contractsContributions.SetOrdinalContributions(contractsHistoricContributions.OrdinalContributionsAmount, contractsHistoricContributions.OrdinalContributionsNumber);

                decimal additionalContributionsAmount = contractsContributions.AdditionalContributionsAmount + contractsHistoricContributions.AdditionalContributionsAmount;
                int additionalContributionsNumber = contractsContributions.AdditionalContributionsNumber + contractsHistoricContributions.AdditionalContributionsNumber;

                contractsContributions.SetAdditionalContributions(additionalContributionsAmount, additionalContributionsNumber);

                if (contractsHistoricContributions.FirstContributionDate < contractsContributions.FirstContributionDate)
                {
                    contractsContributions.SetFirstContributionDate(contractsHistoricContributions.FirstContributionDate);
                }

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las aportaciones. Contrato(s): {context}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las aportaciones - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return contractsContributions;
        }

        public ContractWithdrawals GetContractWithdrawals(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result)
        {
            result = new OperationResult();
            ContractWithdrawals contractWithdrawals = null;

            try
            {
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                contractWithdrawals = _repositoryRetail.GetContractWithdrawals(stringXml, platform);

                ContractWithdrawals contractsHistoricWithdrawals = _repositoryRetail.GetContractHistoricWithdrawals(stringXml, platform);

                contractWithdrawals.SetOrdinalWithdrawals(contractsHistoricWithdrawals.OrdinalWithdrawalsAmount, contractsHistoricWithdrawals.OrdinalWithdrawalsNumber);

                decimal additionalWithdrawalsAmount = contractWithdrawals.AdditionalWithdrawalsAmount + contractsHistoricWithdrawals.AdditionalWithdrawalsAmount;
                int additionalWithdrawalsNumber = contractWithdrawals.AdditionalWithdrawalsNumber + contractsHistoricWithdrawals.AdditionalWithdrawalsNumber;

                contractWithdrawals.SetAdditionalWithdrawals(additionalWithdrawalsAmount, additionalWithdrawalsNumber);

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los retiros. Contrato(s): {context}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los retiros - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return contractWithdrawals;
        }

        public ContributionsOnDemand GetContributionsOnDemand(List<AssociatedContractMess> associatedContracts, int platform, out OperationResult result)
        {
            result = new OperationResult();
            ContributionsOnDemand contributionsOnDemand = null;
            try
            {
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                contributionsOnDemand = _repositoryRetail.GetContributionsOnDemand(stringXml, platform);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las aportaciones On Demand. Contrato(s): {context}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las aportaciones On Demand - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return contributionsOnDemand;
        }

        public string GetClientRFCByContract(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            string clientRFC = string.Empty;
            try
            {

                clientRFC = _repositoryRetail.GetClientRFCByContract(contractId);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el RFC del contrato: {context}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el RFC del contrato - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
            return clientRFC;
        }

        public Contr GetContractInfo(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            Contr contract = null;
            try
            {

                contract = _repositoryRetail.GetContractInfo(contractId);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el contrato: {context}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el contrato - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
            return contract;
        }

        public string GetClientIdByContract(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            string ClientIdentifier = null;
            try
            {

                ClientIdentifier = _repositoryRetail.GetClientIdByContract(contractId);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el contrato: {context}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el contrato - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
            return ClientIdentifier;
        }

        public List<ContractBankAccount> GetContractBankAccounts(string contractId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            try
            {
                if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El productId no puede ir vacío o null"); }

                return _repositoryRetail.GetContractBankAccounts(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las cuentas bancarias del contrato");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener las cuentas bancarias del contrato - " + ex.Message + "-" });
                return null;
            }
        }

        public List<DetailBankAccount> GetContractBankAccountsByRfc(string RFC, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            try
            {
                if (string.IsNullOrEmpty(RFC)) { throw new ArgumentException("El RFC no puede ir vacío o null"); }

                var contractsGrouped = _repositoryRetail.usp_SOC_SIIF_GetContractsActPdUpWithIsAccountThirdByRFC(RFC).GroupBy(x => x[0]).ToList();
                var bankAccountsList = new List<ContractBankAccount>();
                var contractsProducts = new List<string[]>();

                contractsGrouped.ForEach(contractGrouped =>
                {
                    var contract = contractGrouped.First();
                    var contractId = contract[0];
                    var isAccountThird = contract[1];
                    var bankAccounts = _repositoryRetail.GetContractBankAccountsTddTdcClb(contractId);
                    bankAccountsList.AddRange(bankAccounts);

                    var plan = _repositoryRetailExtend.GetByContract(contractId);
                    contractsProducts.Add(new[] { contractId, plan.PlanName, isAccountThird });
                });

                var bankAccountsListGrouped = bankAccountsList.GroupBy(b => new { b.AccountNumber, b.AccountBankName, b.AccountUseTypeId }).ToList();

                var response = new List<DetailBankAccount>();
                bankAccountsListGrouped.ForEach(bankAccountGrouped =>
                {
                    var bankAccount = bankAccountGrouped.First();
                    var detailBankAccount = DetailBankAccount
                        .Create(0, bankAccount.AccountBankName, bankAccount.AccountNumber, bankAccount.AccountUseTypeId, null, 0)
                        .AddAccountStatusDsc(bankAccount.AccountStatus)
                        .AddAccountUseTypeDsc(bankAccount.AccountUseTypeDsc);

                    bankAccountGrouped
                        .ToList()
                            .ForEach(bag =>
                                contractsProducts
                                    .FindAll(x =>
                                        x[0] == bag.Id)
                                            .ForEach(x =>
                                                detailBankAccount.AddProduct(x[1], bag.Id, bool.Parse(x[2]))
                                                ));

                    response.Add(detailBankAccount);
                });


                return response;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las cuentas bancarias del rfc");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener las cuentas bancarias del rfc - " + ex.Message + "-" });
                return null;
            }
        }

        public decimal GetContractSummaryWithdrawalsCommitted(string contractId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            try
            {
                if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El productId no puede ir vacío o null"); }

                return _repositoryRetail.GetContractSummaryWithdrawalsCommitted(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto de retiros comprometido");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener  el monto de retiros comprometido - " + ex.Message + "-" });
                return 0M;
            }
        }

        public List<FundSaleDates> GetContractFundsSaleDates(List<string> Funds, DateTime dateRequest, int platform, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                List<FundSaleDates> fundSaleDates = new List<FundSaleDates>();
                foreach (string fundId in Funds)
                {
                    var fundInfo = _repositoryRetail.GetContractFundsLiquidityDates(fundId, dateRequest, platform);
                    fundSaleDates.Add(fundInfo);
                }
                return fundSaleDates;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el listado de fechas de liquidez de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al obtener el listado de fechas de liquidez de fondos - " + ex.Message + "-" });
                return null;
            }
        }

        public string GetContractChargeBonusDescriptionById(int operationType, int platform, string chargeId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                return _repositoryRetail.GetContractChargeBonusDescriptionById(operationType, platform, chargeId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el listado de fechas de liquidez de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al obtener el listado de fechas de liquidez de fondos - " + ex.Message + "-" });
                return null;
            }
        }

        public ContractWithdrawals GetContractWithdrawalsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            ContractWithdrawals contractWithdrawals = null;
            try
            {
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);

                // recuperación de los movimientos de la base de datos actual
                contractWithdrawals = _repositoryRetail.GetContractWithdrawalsByDate(stringXml, platform, initialDate, finalDate);

                // recuperación de los movimientos de la base de datos histórica
                ContractWithdrawals historicContractWithdrawals = _repositoryRetail.GetHistoricContractWithdrawalsByDate(stringXml, platform, initialDate, finalDate);

                // merge de información
                decimal additionalAmount = contractWithdrawals.AdditionalWithdrawalsAmount + historicContractWithdrawals.AdditionalWithdrawalsAmount;
                int addtionalNumber = contractWithdrawals.AdditionalWithdrawalsNumber + historicContractWithdrawals.AdditionalWithdrawalsNumber;

                contractWithdrawals.SetAdditionalWithdrawals(additionalAmount, addtionalNumber);

                contractWithdrawals.SetOrdinalWithdrawals(historicContractWithdrawals.OrdinalWithdrawalsAmount, historicContractWithdrawals.OrdinalWithdrawalsNumber);

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los retiros. Contrato(s): {context}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los retiros - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return contractWithdrawals;
        }

        public ContractContributions GetContractContributionsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            ContractContributions contractsContributions = null;

            try
            {
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                contractsContributions = _repositoryRetail.GetContractContributionsByDate(stringXml, platform, initialDate, finalDate);

                // merge de datos históricos
                ContractContributions contractsContributionsHistoric = _repositoryRetail.GetHistoricContractContributionsByDate(stringXml, platform, initialDate, finalDate);

                contractsContributions.SetOrdinalContributions(contractsContributionsHistoric.OrdinalContributionsAmount, contractsContributionsHistoric.OrdinalContributionsNumber);

                decimal additionalContributionsAmount = contractsContributions.AdditionalContributionsAmount + contractsContributionsHistoric.AdditionalContributionsAmount;
                int additionalContributionsNumber = contractsContributions.AdditionalContributionsNumber + contractsContributionsHistoric.AdditionalContributionsNumber;

                contractsContributions.SetAdditionalContributions(additionalContributionsAmount, additionalContributionsNumber);

                if (contractsContributionsHistoric.FirstContributionDate < contractsContributions.FirstContributionDate)
                {
                    contractsContributions.SetFirstContributionDate(contractsContributionsHistoric.FirstContributionDate);
                }

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las aportaciones. Contrato(s): {context}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las aportaciones - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return contractsContributions;
        }

        public ContributionsOnDemand GetContributionsOnDemandByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            ContributionsOnDemand contributionsOnDemand = null;
            try
            {
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                contributionsOnDemand = _repositoryRetail.GetContributionsOnDemandByDate(stringXml, platform, initialDate, finalDate);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las aportaciones On Demand. Contrato(s): {context}", new { associatedContracts });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las aportaciones On Demand - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return contributionsOnDemand;
        }

        public decimal GetContractChargesByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            decimal charges = 0M;

            try
            {
                result.Successful = true;
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                charges = _repositoryRetail.GetContractChargesByDate(stringXml, platform, initialDate, finalDate);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los cargos de los contratos: {cntx}", new { associatedContracts, platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los cargos de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return charges;
        }

        public List<ContractDetailMovement> GetContractDetailFundsMovementsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractDetailMovement> contractFundsMovements = new List<ContractDetailMovement>();

            try
            {
                result.Successful = true;

                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                var contractId = associatedContracts.Select(x => x.ContractId).First();

                contractFundsMovements = _repositoryRetail.GetContractDetailFundsMovementsByDate(contractId, stringXml, platform, initialDate, finalDate);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los movimientos de efectivo de los contratos: {cntx}", new { associatedContracts, platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los movimientos de efectivo de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return contractFundsMovements;
        }

        public List<ContractDetailMovement> GetContractDetailCashMovementsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractDetailMovement> contractCashMovements = new List<ContractDetailMovement>();
            List<ContractDetailMovement> contractHistoricCashMovements = new List<ContractDetailMovement>();

            try
            {
                result.Successful = true;

                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                var contractId = associatedContracts.Select(x => x.ContractId).First();

                contractCashMovements = _repositoryRetail.GetContractDetailCashMovementsByDate(contractId, stringXml, platform, initialDate, finalDate);
                contractHistoricCashMovements = _repositoryRetail.GetHistoricContractDetailCashMovementsByDate(contractId, stringXml, platform, initialDate, finalDate);

                contractCashMovements.AddRange(contractHistoricCashMovements);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los movimientos de efectivo de los contratos: {cntx}", new { associatedContracts, platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los movimientos de efectivo de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return contractCashMovements;
        }

        public List<ContractDetailMovement> GetContractDetailPendingMovementsByDate(List<AssociatedContractMess> associatedContracts, int platform, DateTime initialDate, DateTime finalDate, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractDetailMovement> contractPendingMovements = new List<ContractDetailMovement>();

            try
            {
                result.Successful = true;
                var stringXml = _transform.ObjectToXml<List<AssociatedContractMess>>(associatedContracts);
                var contractId = associatedContracts.Select(x => x.ContractId).First();
                contractPendingMovements = _repositoryRetail.GetContractDetailPendingMovementsByDate(contractId, stringXml, platform, initialDate, finalDate);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los movimientos pendientes de los contratos: {cntx}", new { associatedContracts, platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los movimientos pendientes de los contratos - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return contractPendingMovements;
        }

        public List<Bank> GetBanksCatalog(int platform, out OperationResult result)
        {
            result = new OperationResult();
            List<Bank> lstBanks = new List<Bank>();

            try
            {
                lstBanks = _repositoryRetail.GetBanksCatalog(platform);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el catalogo de bancos - plataforma: {context}", new { platform });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return lstBanks;
        }

        public string GetCRMKey(string contractId, int productType, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var crmKey = string.Empty;

            try
            {
                crmKey = _repositoryRetail.GetCRMKey(contractId, productType);
            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = ex.Message });
                _log.Error(ex, "Error al obterner la llave crm de siif");
            }

            return crmKey;
        }

        public OperationResult LogsRegisterBankAccountCRM(LogsRegisterBankAccountCRMRequest logInfo)
        {
            var result = new OperationResult();
            try
            {
                var xml = _transform.ObjectToXml(logInfo);
                _repositoryRetail.LogsRegisterBankAccountCRM(xml);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al insertar el xml siif");
                result.Successful = true;
                result.SystemMessages.Add(new SystemMessage() { Message = ex.Message });
            }

            return result;
        }

        public List<AssociatedContract> GetAssociateContractsByContract(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            List<AssociatedContract> associatedContracts = new List<AssociatedContract>();

            try
            {
                result.Successful = true;
                associatedContracts = _repositoryRetail.GetAssociateContractsByContract(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos asociados del contrato: {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos asociados del contrato - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return associatedContracts;
        }

        public List<DetailBankAccount> GetAccountsByContract(string ContractId, out OperationResult result)
        {
            result = new OperationResult();
            List<DetailBankAccount> AccountsBanc = new List<DetailBankAccount>();

            try
            {
                result.Successful = true;
                AccountsBanc = _repositoryRetail.GetAccountsByContract(ContractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los Cuentas bancarias: {cntx}", new { ContractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener cuentas bancarias del contrato - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return AccountsBanc;
        }

        public void GetClabeAccountVerifyDigit(string accountClabe, out OperationResult result)
        {
            result = new OperationResult();

            string refAux = string.Empty;


            int[] factor = { 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7 };
            int sumMod = 0;
            int itemRef = 0;
            //int verifyDigit = int.MinValue;
            int verifyDigit = -1;
            int iresult = int.MinValue;
            const int valorDigito = 10;
            const int mod = 10;



            try
            {

                if (accountClabe.Length < 18)
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "No se puede determinar el digito verificador, la referencia no tiene 18 digitos: " + accountClabe, MessageType = SystemMessageTypes.Error });
                    result.Successful = false;
                }
                else
                {
                    string CtaClabeVerifyDigit = accountClabe.Substring(accountClabe.Length - 1, 1);

                    refAux = accountClabe.Substring(0, 17);
                    //Se itera cada uno de los elementos del factor y se multiplica por cada una de las posiciones de la referencia auxiliar
                    for (int i = 0; i < factor.Length; i++)
                    {
                        itemRef = int.Parse(refAux.Substring(i, 1));
                        iresult = factor[i] * itemRef;
                        sumMod += iresult % mod;
                    }
                    //se obtiene el digito verificador
                    verifyDigit = valorDigito - (sumMod % mod);
                    if (verifyDigit >= 10)
                    {
                        verifyDigit = verifyDigit % mod;
                    }

                    result.Successful = (CtaClabeVerifyDigit == verifyDigit.ToString()) ? true : false;
                }


            }
            catch (Exception ex)
            {

                _log.Error(ex, "Error al determinar el digito verificador de la cuenta clabe:" + accountClabe);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al determinar el digito verificador de la cuenta clabe - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            //return verifyDigit;
        }

        public ContractStatus GetContractStatusInfo(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            ContractStatus contractStatus = null;
            try
            {
                contractStatus = _repositoryRetail.GetContractStatusInfo(contractId);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el status del contrato.");
                result.Successful = false;
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el status del contrato - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return contractStatus;
        }

        public string GetReferenceNumber(string contractId, int platform, out OperationResult result)
        {
            result = new OperationResult();
            string referenceNumber = string.Empty;

            try
            {
                _log.Info("Obteniendo el número de referencia: {cntx}", new { contractId, platform });

                referenceNumber = _repositoryRetail.GetReferenceNumber(contractId, platform);

                _log.Debug($"Número de referencia obtenido: {referenceNumber}");

                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el número de referencia.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el número de referencia - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return referenceNumber;
        }

        public List<ContractAccepted> GetContractsAccepted(string rfc, out OperationResult result)
        {
            _log.Info("[GetContractsAccepted]");
            result = new OperationResult();
            List<ContractAccepted> contracts = new List<ContractAccepted>();
            try
            {
                if (string.IsNullOrEmpty(rfc)) { throw new ArgumentException("El rfc del cliente no puede ser nulo o vacío"); }
                _log.Info("Obteniendo contratos:");
                contracts = _repositoryRetail.GetContractsAccepted(rfc);
                _log.Debug("Contratos obtenidos: {cntx}", contracts);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener contratos aceptados.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener contratos - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
            return contracts;
        }

        public void UpdateContractsAccepted(string rfc, string contractId, bool isCommited, out OperationResult result)
        {
            _log.Info("[UpdateContractsAccepted]");
            result = new OperationResult();
            try
            {
                if (string.IsNullOrEmpty(rfc)) { throw new ArgumentException("El rfc del cliente no puede ser nulo o vacío"); }
                if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contractId del cliente no puede ser nulo o vacío"); }
                _log.Info("Actualizando contrato {rfc} {contractId} {isCommited}:", rfc, contractId, isCommited);
                _repositoryRetail.UpdateContractsAccepted(rfc, contractId, isCommited);
                _log.Info("Se actualizó el flag compromiso de Contratos aceptados.");
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar contratos aceptados.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al actualizar contratos - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
        }

        public ContractPeriodicity GetContractPeriodicity(string contractMaster, out OperationResult result)
        {
            _log.Info("[GetContractPeriodicity]");
            result = new OperationResult();
            ContractPeriodicity contractPeriodicity = null;
            try
            {
                if (string.IsNullOrEmpty(contractMaster)) { throw new ArgumentException("El contrato maestro no puede ser nulo o vacío"); }
                _log.Info("Obteniendo Periodicidad de contrato maestro {cntx}:" + contractMaster);
                contractPeriodicity = _repositoryRetail.GetPeriodicityByContract(contractMaster);
                _log.Debug("Contratos obtenidos: {cntx}", contractPeriodicity);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la periodicidad del contrato.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener la periodicidad - " + ex.Message, MessageType = SystemMessageTypes.Error });
            }
            return contractPeriodicity;
        }

        public ContractsOf GetClientContractsActivePaidUp(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            ContractsOf clientContracts = null;

            try
            {
                clientContracts = _repositoryRetail.GetContractsActivePaidUp(clientIdentifier);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos del cliente {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = $"Error al obtener los contratos del cliente {ex.Message}; {ex.StackTrace}",
                    MessageType = SystemMessageTypes.Error
                });
            }

            return clientContracts;
        }

        public List<AssociatedContract> GetAssociateContractsActivePaidUp(string clientIdentifier, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            List<AssociatedContract> lstAssociatedContracts = new List<AssociatedContract>();

            try
            {
                lstAssociatedContracts = _repositoryRetail.GetAssociateContractsPaidUp(clientIdentifier);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los contratos asociados al cliente: {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener los contratos asociados al cliente - " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return lstAssociatedContracts;

        }



        public decimal GetPendingContributionAmount(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            decimal amount = 0M;

            try
            {
                result.Successful = true;
                _log.Info("Obteniendo el monto pendiente del contrato: {cntx}", contractId);
                amount = _repositoryRetail.GetPendingContributionAmount(contractId);
                _log.Debug("Monto Pendiente: {cntx} ", amount);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el monto pendiente del contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el monto pendiente del contrato " + contractId + " | " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return amount;
        }

        public decimal GetContributionSum(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            decimal amount = 0M;

            try
            {
                result.Successful = true;
                _log.Info("Obteniendo la Suma de Aportaciones del contrato: {cntx}", contractId);
                amount = _repositoryRetailExtend.GetContributionSum(contractId);
                _log.Debug("Suma Aportacionse: {cntx} ", amount);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la Suma de Aportaciones del contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener la Suma de Aportaciones del contrato  " + contractId + " | " + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }

            return amount;
        }

        public ContractInflation GetContractInflation(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            ContractInflation contractInflation = ContractInflation.CreateEmpty();
            try
            {
                result.Successful = true;
                _log.Info("Obteniendo Inflación del Contrato");
                contractInflation = _repositoryRetail.GetContractInflation(contractId);
                _log.Debug("ContractInflation: {cntx} ", contractInflation);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la Inflación del contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener la Inflación del Contrato - " + contractId + " |" + ex.StackTrace, MessageType = SystemMessageTypes.Error });
            }
            return contractInflation;
        }

        public int GetAllowedUnpaidContributions(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            int noContributions = 0;

            try
            {
                result.Successful = true;
                _log.Info("Obteniendo las contribuciones permitidas para falta de pago");
                noContributions = _repositoryRetail.GetAllowedUnpaidContributions(contractId);
                _log.Debug("Contribuciones: {cntx}", noContributions);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las contribuciones permitidad para falta de pago del contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las contribuciones permitidas para falta de pago del Contrato - " + contractId + " | " + ex.StackTrace, MessageType = SystemMessageTypes.Error });

            }

            return noContributions;
        }

        public List<ContractTrackerGraphicInfo> GetContractTrackerGraphicInfo(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractTrackerGraphicInfo> contractTrackerGraphicInfo = new List<ContractTrackerGraphicInfo>();

            try
            {
                result.Successful = true;
                _log.Info("Obteniendo información de rastreo para la gráfica del contrato: {cntx}", contractId);
                contractTrackerGraphicInfo = _repositoryRetail.GetContractTrackerGraphicInformation(contractId);
                _log.Debug("Información consultada: {cntx}", contractTrackerGraphicInfo);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener información de rastreo para la gráfica del contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener información de rastreo para la gráfica del contrato:  - " + contractId + " | " + ex.StackTrace, MessageType = SystemMessageTypes.Error });

            }

            return contractTrackerGraphicInfo;
        }

        public List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contractId no puede ir vacío o null"); }
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException("El clientIdentifier no puede ir vacío o null"); }

            result = new OperationResult { Successful = true };
            var contractBankAccounts = new List<ContractBankAccountAllowDomi>();

            try
            {

                contractBankAccounts = _repositoryRetail.GetContractBankAccountsAllowDomi(contractId, clientIdentifier);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las cuentas bancarias del contrato");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener las cuentas bancarias del contrato - " + ex.Message + "-" });
            }

            return contractBankAccounts;
        }

        public List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi(out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var lstBankCatalogs = new List<FrecuencyTypeCatalog>();

            try
            {
                lstBankCatalogs = _repositoryRetail.GetFrecuencyTypeCatalogForDomi();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el catalogo de bancos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return lstBankCatalogs;
        }

        public ContractPeriod GetContractPeriodByContract(string contractId, out OperationResult result)
        {
            result = new OperationResult();
            ContractPeriod period = null;
            try
            {
                result.Successful = true;
                period = _repositoryRetailExtend.GetContractPeriodByContract(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el periodo del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = $"Error al obtener el periodo del contrato {ex.Message}\n {ex.StackTrace} ",
                    MessageType = SystemMessageTypes.Error
                });
            }

            return period;
        }

        public List<FundPortfolio> GetPortfolioByContract( string contractId, out OperationResult result)
        {
            result = new OperationResult();
            List<FundPortfolio> fundsPortfolio = null;

            try
            {
                _log.Info("Consultando [GetPortfoliosByContract] con contrato: {contractId}", contractId);
                fundsPortfolio = _repositoryRetail.GetPortfolioByContractId(contractId);
                _log.Debug("Resultado de [GetPortFoliosByContract] : {cntx}", fundsPortfolio);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtenerlos fondos del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = $"Error al obtener los fondos del contrato {contractId} {ex.Message}\n {ex.StackTrace} ",
                    MessageType = SystemMessageTypes.Error

                });
            }
            return fundsPortfolio;
        }

        public void ExecuteDeregisterPremium( string contractId, string clientId, string fundsPorfolioOld, string fundsPortfolioNew, DateTime tranDate, string tranId, int platformId, out OperationResult result)
        {
            _log.Info("Ejecutando [ExecuteDeregisterPremium]");
            result = new OperationResult();
            string separator = ";";
            try
            {
                clientId = clientId.ToUpper();
                _log.Info("{cntx}", contractId, clientId, fundsPorfolioOld, fundsPortfolioNew, tranDate, tranId, platformId);
                string[] fundsSplit = fundsPorfolioOld.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                _log.Info("Cantidad de elementos(Funds) {cntx}", fundsSplit.Length);               

                string productName = this.GetProductName(platformId);
                _log.Info("ProductName: {cntx}", productName);
                _log.Debug("Ejecutando [GenerateFundTransactionSIIF]");
                //TransactionTypeId = 1 <---- TransferManyToMany
                _repositoryRetail.GenerateFundTransactionSIIF(1, productName, tranId, tranDate, contractId, clientId);
                _log.Debug("Finaliza ejecución de [GenerateFundTransactionSIIF]");
                _log.Info("Ejecutando [UpdateDefinedPortfolio] ");
                _repositoryRetail.UpdateDefinedPortfolio(fundsPorfolioOld, fundsSplit.Length, separator, tranDate, contractId, platformId);
                _log.Info("Terminando ejecución de [UpdateDefinedPortfolio]");
                _log.Info("Ejecutando cambio de perfil de inversión [ExecuteUpdateProfile] con contrato: {contractId}\nplataformId:{platformId}", contractId, platformId);
                _repositoryRetail.UpdatePerfilPortfolio(contractId, platformId);
                _log.Debug("Terminando ejecución de [UpdatePerfilPortfolio]");
                _log.Info("Ejecutando [InsertContractPortfolioDefinedLogs]");
                _repositoryRetail.InsertContractPortfolioDefinedLogs(fundsPorfolioOld, fundsPortfolioNew, contractId, tranId);
                _log.Info("Finaliza ejecución de [InsertContractPortfolioDefinedLogs]");
                result.Successful = true;
            }catch(Exception ex)
            {
                _log.Error(ex, "Error al actualizar el perfil de inversión del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = $"Error al obtener los fondos del contrato {contractId} {ex.Message}\n {ex.StackTrace} ",
                    MessageType = SystemMessageTypes.Error

                });
            }
        }

        private string GetProductName(int platformId)
        {
            string mapProductId = string.Empty;
            if (platformId == 10)
            {
                mapProductId = "RS";
            }
            else if (platformId == 5)
            {
                mapProductId = "GT";
            }
            else
            {
                throw new Exception("Invalid product type for a transaction.");
            }
            return mapProductId;
        }


        public List<Beneficiary>  GetContractBeneficiaries(string contractId, int platformId, out OperationResult result)
        {
            result = new OperationResult();
            List<Beneficiary> beneficiaries = new List<Beneficiary>();

            try
            {
                _log.Info("Ejecutando [GetContractBeneficiaries] con contrato: {contractId}", contractId);
                _log.Info("Validando Platform: {cntx}", platformId);
                if (platformId == 10)
                {
                    beneficiaries = _repositoryRetail.GetContractBeneficiariesRS(contractId);
                }
                else
                {
                    beneficiaries= _repositoryRetail.GetContractBeneficiariesGT(contractId);
                }
                _log.Debug("Beneficiarios obtenidos: {cntx}", beneficiaries);
                result.Successful = true;
                _log.Info("Finalizando [GetContractBeneficiaries]");
            }
            catch(Exception ex )
            {
                _log.Error(ex, "Error al obtener los beneficiarios del contrato {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage()
                {
                    Message = $"Error al obtener los beneficiarios del contrato {contractId} {ex.Message}\n {ex.StackTrace} ",
                    MessageType = SystemMessageTypes.Error

                });
            }

            return beneficiaries;
        }
    }
}
