﻿using ClientContracts.Logs;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Serilog;
using System;

namespace ClientContracts.LogsTest
{
    [TestClass]
    public class ClientContractsLogsTest
    {
        
        private readonly ISeriLogHelper _seriLogHelper;

        public ClientContractsLogsTest()
        {
        
            _seriLogHelper = new SeriLogHelper();
        }

        [TestMethod]
        public void TraceLog()
        {
            _seriLogHelper.Trace("Test trace log");
        }


        [TestMethod]
        public void TraceLogWithParameters()
        {
            _seriLogHelper.Trace("Test trace log with parameters {Objeto1}, {Objeto2}", new object[] { "Objeto1", "Objeto3" });
        }

        [TestMethod]
        public void DebugLog()
        {
            _seriLogHelper.Debug("Test debug log");
        }


        [TestMethod]
        public void DebugLogWithParameters()
        {
            _seriLogHelper.Debug("Test debug log with parameters {Objeto1}, {Objeto2}", new object[] { "Objeto1", "Objeto3" });
        }

        [TestMethod]
        public void InfoLog()
        {
            _seriLogHelper.Info("Test information log");
        }


        [TestMethod]
        public void InfoLogWithParameters()
        {
            _seriLogHelper.Info("Test information log with parameters {Objeto1}, {Objeto2}", new object[] { "Objeto1", "Objeto3" });
        }

        [TestMethod]
        public void WarnLog()
        {
            _seriLogHelper.Warn("Test warning log");
        }


        [TestMethod]
        public void WarnLogWithParameters()
        {
            _seriLogHelper.Warn("Test warning log with parameters {Objeto1}, {Objeto2}", new object[] { "Objeto1", "Objeto3" });
        }


        [TestMethod]
        public void ErrorLog()
        {
            _seriLogHelper.Error(new Exception("Application error"), "Test error log");
        }


        [TestMethod]
        public void ErrorLogWithParameters()
        {
            _seriLogHelper.Error(new Exception("Application error"), "Test error log {Objeto1}, {Objeto2}", new object[] { "Objeto1", "Objeto3" });
        }

        [TestMethod]
        public void FatalLog()
        {
            _seriLogHelper.Fatal(new Exception("Application fatal"), "Test fatal log");
        }


        [TestMethod]
        public void FatalLogWithParameters()
        {
            _seriLogHelper.Fatal(new Exception("Application fatal"), "Test fatal log", new object[] { "Objeto1", "Objeto3" });
        }
    }

}
