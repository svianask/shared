﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContracts.Domain.ContractWithdrawalsAggregate;

namespace ClientContracts.Mapping
{
    public class ContractWithdrawalsMapp
    {
        public static ContractWithdrawals Mapp(DataSet ds)
        {
            ContractWithdrawals contractWithdrawals = null;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                var WithdrawalsAmount = Convert.ToDecimal(dr["MontoRetiros"].ToString());
                var WithdrawalsNumber = Convert.ToInt16(dr["NumRetiros"].ToString());
                var ContractType = Convert.ToInt16(dr["TipoContratoAsociado"]);

                switch (ContractType)
                {
                    case 1:
                        contractWithdrawals =
                            ContractWithdrawals
                                .Create(
                                    WithdrawalsAmount,
                                    WithdrawalsNumber
                                );
                        break;
                    case 2:
                        contractWithdrawals.SetOrdinalWithdrawals(
                                    WithdrawalsAmount,
                                    WithdrawalsNumber
                                );
                        break;
                    case 3:
                        contractWithdrawals
                            .SetAdditionalWithdrawals(
                                WithdrawalsAmount,
                                WithdrawalsNumber
                            );
                        break;
                }
            }

            return contractWithdrawals;
        }
    }
}
