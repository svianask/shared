﻿using ClientContracts.Domain.BankAggregate;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class BankMap
    {
        public static List<Bank> MappList(DataSet dsBanks)
        {
            List<Bank> lstBanks = new List<Bank>();
            foreach(DataRow row in dsBanks.Tables[0].Rows)
            {
                var id = row["Banco_Id"].ToString();
                var description = row["Banco_Dsc"].ToString();
                var descrShort = row["Banco_Dsc_Corta"].ToString();
                var code = (int)row["Banco_Clave_Banxico"];

                var bank = Bank.Create(id, description, descrShort, code);
                lstBanks.Add(bank);
            }

            return lstBanks;
        }
    }
}
