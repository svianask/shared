﻿using ClientContracts.Domain.FundAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class FundPortfolioMapp
    {
        public static List<FundPortfolio> Mapp(DataSet dsFundPortfolio)
        {
            List<FundPortfolio> fundsPortfolio = new List<FundPortfolio>();

            foreach (DataRow drFundPortfolio in dsFundPortfolio.Tables[0].Rows)
            {
                var id = drFundPortfolio["Emision_Id"].ToString();
                var name = drFundPortfolio["Emision_Nombre"].ToString();
                var percentage = Convert.ToDecimal( drFundPortfolio["Porcentaje"]);

                fundsPortfolio.Add( FundPortfolio.Create(id, name, percentage ) );
            }

            return fundsPortfolio;
        }
    }
}
