﻿using System;
using System.Collections.Generic;
using System.Data;
using ClientContracts.Domain.FundAggregate;
using ClientContracts.Domain.InvestmentsAggregate;

namespace ClientContracts.Mapping
{
    public class InvestmentsMapp
    {
        public static Investments Mapp(DataSet dsInvestment)
        {
            Investments investmentBalance = null;

            Fund cashTF = null;
            List<Fund> cashFunds = new List<Fund>();
            List<Fund> displayFunds = new List<Fund>();


            foreach (DataRow drInvst in dsInvestment.Tables[0].Rows)
            {
                var identifier = drInvst["Emision_Id"].ToString();

                if (identifier.IndexOf('|') >= 0)
                {
                    cashFunds.Add(FundMapp.Mapp(drInvst));
                    if (cashTF == null) { cashTF = Fund.Create("EFECTIVO", "EFECTIVO").SetMarketValues(0, 0, 0, 0); }
                    var marketValue = cashTF.MarketValues.MarketValue + Convert.ToDecimal(drInvst["Valor_Fondo"]);
                    var marketPurchaseValue = cashTF.MarketValues.MarketPurchaseValue + Convert.ToDecimal(drInvst["Valor_Fondo_Compra"]);
                    var marketSalesValue = cashTF.MarketValues.MarketSalesValue + Convert.ToDecimal(drInvst["Valor_Fondo_Venta"]);
                    cashTF.SetMarketValues(marketValue, marketPurchaseValue, marketSalesValue, 0).SetContract("").SetPrices(0,0,0).SetShares(0,0,0);
                }
                else
                {
                    displayFunds.Add(FundMapp.Mapp(drInvst));
                }
            }
            displayFunds.Add(cashTF);
            investmentBalance = Investments.Create(cashFunds, displayFunds);

            return investmentBalance;
        }
    }
}
