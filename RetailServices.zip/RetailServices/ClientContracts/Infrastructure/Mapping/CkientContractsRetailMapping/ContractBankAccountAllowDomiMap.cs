﻿using ClientContracts.Domain.ContractBankAccountAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public static class ContractBankAccountAllowDomiMap
    {
        public static List<ContractBankAccountAllowDomi> Mapp(string contractId, DataSet ds)
        {
            var contractBankAccounts = new List<ContractBankAccountAllowDomi>();
            if (ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
                return contractBankAccounts;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {

                var accountId = Convert.ToInt32(dr["Contrato_Cta_Id"].ToString());
                var accountNumber = dr["Contrato_Cta_Numero"].ToString();
                var accountClabe = dr["Contrato_Cta_Clabe"].ToString();
                accountNumber = string.IsNullOrEmpty(accountNumber) ? accountClabe : accountNumber;
                var accountUseTypeId = Convert.ToInt16(dr["Tipo_Uso_Cuenta_Id"].ToString());
                var accountUseTypeDsc = ds.Tables[0].Columns.Contains("Tipo_Uso_Cuenta_Dsc") ? dr["Tipo_Uso_Cuenta_Dsc"].ToString() : "";

                var bankId = Convert.ToInt32(dr["Banco_Id"].ToString());
                var accountBankName = dr["Banco_Dsc_Corta"].ToString();
                var bankAccountTypeId = Convert.ToInt32(dr["Tipo_CtaBancoId"].ToString());

                var classificationId = Convert.ToInt32(dr["Clasif_Cuenta_Banco_Id"].ToString());
                var classificationDsc = ds.Tables[0].Columns.Contains("Clasif_Cuenta_Banco_Dsc_Corta") ? dr["Clasif_Cuenta_Banco_Dsc_Corta"].ToString() : "";


                var accountStatusId = Convert.ToInt32(dr["Sts_Contrato_Cta_Id"].ToString());
                var accountStatusDsc = ds.Tables[0].Columns.Contains("Sts_Contrato_Cta_Dsc") ? dr["Sts_Contrato_Cta_Dsc"].ToString() : "";

                contractBankAccounts.Add(ContractBankAccountAllowDomi
                    .Create(contractId)
                    .SetAccountData(accountId, accountNumber, accountUseTypeId, accountUseTypeDsc)
                    .SetBankData(bankId, accountBankName, bankAccountTypeId)
                    .SetClassificationAccount(classificationId, classificationDsc)
                    .SetAccountStatusDsc(accountStatusId, accountStatusDsc));
            }
            return contractBankAccounts;
        }
    }
}
