﻿using System;
using System.Collections.Generic;
using System.Data;
using ClientContracts.Domain.ContractMovementsAggregate;

namespace ClientContracts.Mapping
{
    public class ContractPendingMovementMapp
    {
        public static List<ContractDetailMovement> Mapp(string contractId, DataSet dsMovements)
        {
            List<ContractDetailMovement> contractPendingMovements = new List<ContractDetailMovement>();
            foreach(DataTable dt in dsMovements.Tables)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ContractDetailMovement contractPendingMovement = null;
                    var movementContract = dr["ContratoId"].ToString();
                    var movementDescripcion = dr["Movimiento"].ToString();
                    var movementAmount = Convert.ToDecimal(dr["Importe"]);
                    var movementProcessDate = Convert.ToDateTime(dr["Fecha"].ToString());
                    var movementSubaccountName = dr["SubCuentaNombre"].ToString();
                    var movementBankAccount = dr["CuentaBancaria"].ToString();

                    contractPendingMovement = ContractDetailMovement
                                                .Create(contractId, movementContract, movementSubaccountName, movementAmount, movementProcessDate, movementBankAccount)
                                                .SetMovementDescription(movementDescripcion);

                    contractPendingMovements.Add(contractPendingMovement);
                }
            }

            return contractPendingMovements;
        }
    }
}
