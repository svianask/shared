﻿using ClientContracts.Domain.ContractsAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class ClientContractMapp
    {
        public static Contr MappingContract(DataRow drContrato)
        {
            Contr contract = null;

            contract = Contr
                .Create(
                        contractId: drContrato["Contrato_Id"].ToString(),
                        planBasId: drContrato["Contrato_Plan_Id"].ToString(),
                        platform: int.Parse(drContrato["Contrato_Origen"].ToString()),
                        goalId: short.Parse(drContrato["Meta_Ahorro_Id"].ToString()),
                        contratoAgrupa: drContrato["Contrato_Agrupador"].ToString()
                    )
                    .SetAfiliationDate(Convert.ToDateTime(drContrato["Contrato_Fecha"]))
                    .SetContractDigit(drContrato["Digito"].ToString())
                    .SetGoalDescription(drContrato["Meta_Ahorro_Dsc"].ToString())
                    .SetDeducibleApply(Boolean.Parse(drContrato["Contrato_Plan_Deducible"].ToString()));

            return contract;
            
        }

        public static Contr MappingContractPaidUp(DataRow drContrato)
        {
            Contr contract = null;

            contract = Contr
                .Create(
                        contractId: drContrato["Contrato_Id"].ToString(),
                        planBasId: drContrato["Contrato_Plan_Id"].ToString(),
                        platform: int.Parse(drContrato["Contrato_Origen"].ToString()),
                        goalId: short.Parse(drContrato["Meta_Ahorro_Id"].ToString()),
                        contratoAgrupa: drContrato["Contrato_Agrupador"].ToString()
                    )
                    .SetAfiliationDate(Convert.ToDateTime(drContrato["Contrato_Fecha"]))
                    .SetContractDigit(drContrato["Digito"].ToString())
                    .SetGoalDescription(drContrato["Meta_Ahorro_Dsc"].ToString())
                    .SetDeducibleApply(Boolean.Parse(drContrato["Contrato_Plan_Deducible"].ToString()))
                    .SetStatus(int.Parse(drContrato["Sts_Contrato_Id"].ToString()), int.Parse(drContrato["Sts_Contrato_Operacion_Id"].ToString()));

            return contract;
        }

        public static Contr CreateWithNull()
        {
            throw new ArgumentException("El contrato no existe o está eliminado.");
        }
    }
}
