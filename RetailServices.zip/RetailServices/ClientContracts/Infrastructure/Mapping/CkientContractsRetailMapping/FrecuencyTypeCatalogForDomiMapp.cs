﻿using ClientContracts.Domain.FrecuencyTypeAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public static class FrecuencyTypeCatalogForDomiMapp
    {
        public static List<FrecuencyTypeCatalog> Mapp(DataSet dsBanks)
        {
            var lstBanks = new List<FrecuencyTypeCatalog>();
            foreach (DataRow row in dsBanks.Tables[0].Rows)
            {
                var id = Convert.ToInt16(row["Tipo_Frecuencia_Id"].ToString());
                var description = row["Tipo_Frecuencia_Dsc"].ToString();
                var descriptionShort = row["Tipo_Frecuencia_Dsc_Corta"].ToString();
                lstBanks.Add(FrecuencyTypeCatalog.Create(id, description, descriptionShort));
            }
            return lstBanks;
        }
    }
}
