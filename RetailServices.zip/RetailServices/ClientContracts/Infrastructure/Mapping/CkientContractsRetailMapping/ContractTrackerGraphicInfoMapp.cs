﻿using ClientContracts.Domain.ContractTrackerAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractTrackerGraphicInfoMapp
    {
        public static List<ContractTrackerGraphicInfo> Mapp(DataSet dsContractTrackerGraphicInfo)
        {
            List<ContractTrackerGraphicInfo> contractTrackerGraphicInfo = new List<ContractTrackerGraphicInfo>();

            if (dsContractTrackerGraphicInfo == null) { return contractTrackerGraphicInfo;  }

            foreach (DataRow row in dsContractTrackerGraphicInfo.Tables[0].Rows)
            {
                var Id = long.Parse( row["Id"].ToString());
                var clientId = row["clientId"].ToString();
                var historyDate = DateTime.Parse(row["historyDate"].ToString());
                var monthlySavingGoal = decimal.Parse(row["monthlySavingGoal"].ToString());
                var monthlySavingValuation = decimal.Parse(row["monthlySavingValuation"].ToString());
                var monthlyAdditionalValuation = decimal.Parse(row["monthlyAdditionalValuation"].ToString());
                var monthlyTotalValuation = decimal.Parse(row["monthlyTotalValuation"].ToString());
                var hasPendingContribution = int.Parse(row["hasPendingContribution"].ToString()) != 0;


                ContractTrackerGraphicInfo graphicInfo = ContractTrackerGraphicInfo.Create( Id, clientId, historyDate, monthlySavingGoal, monthlySavingValuation, monthlyAdditionalValuation, monthlyTotalValuation, hasPendingContribution);
                contractTrackerGraphicInfo.Add(graphicInfo );
               
            }

            return contractTrackerGraphicInfo;
        }

    }
}