﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContracts.Domain.ContributionsOnDemandAggregate;

namespace ClientContracts.Mapping
{
    public class ContributionsOnDemandMapp
    {
        public static ContributionsOnDemand Mapp(DataSet ds)
        {
            ContributionsOnDemand contributionsOnDemand = null;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                var ContributionsOnDemandAmount = Convert.ToDecimal(dr["MontoContribuciones"].ToString());
                var ContractType = Convert.ToInt16(dr["TipoContratoAsociado"]);

                switch (ContractType)
                {
                    case 1:
                        contributionsOnDemand =
                            ContributionsOnDemand
                                .Create(
                                    ContributionsOnDemandAmount
                                );
                        break;
                    case 2:
                        contributionsOnDemand.SetOrdinalContributionsOnDemand(
                                    ContributionsOnDemandAmount
                                );
                        break;
                    case 3:
                        contributionsOnDemand
                            .SetAdditionalContributionsOnDemand(
                                ContributionsOnDemandAmount
                            );
                        break;
                }
            }
            return contributionsOnDemand;
        }
    }
}
