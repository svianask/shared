﻿using ClientContracts.Domain.ContractAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ClientContractsMapp
    {
        public static ContractsOfClient MappingClientContracts(DataSet dsClientContracts)
        {

            ContractsOfClient clientContracts = null;

            clientContracts = new ContractsOfClient(dsClientContracts.Tables[0].Rows[0]["Contrato_RFC"].ToString());
            foreach (DataRow dr in dsClientContracts.Tables[0].Rows)
            {
                Contract contract = ContractMapp.MappingContract(dr);

                clientContracts.AddContract(contract);
            }

            return clientContracts;
        }
    }
}
