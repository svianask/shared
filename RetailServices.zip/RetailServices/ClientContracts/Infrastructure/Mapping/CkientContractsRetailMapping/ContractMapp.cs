﻿using System.Data;
using ClientContracts.Domain.ContractAggregate;

namespace ClientContracts.Mapping
{
    public class ContractMapp
    {
        public static Contract MappingContract(DataRow dr)
        {
            Contract contract = null;
                       
            contract = Contract
                    .Create(
                        contractId: dr["Contrato_Id"].ToString(),
                        planId: short.Parse(dr["Contrato_Plan_Id"].ToString())
                    )
                    .FillContactData(
                        dr["Celular"].ToString(),
                        dr["Telefono"].ToString(),
                        dr["Email"].ToString()
                    );


            return contract;
        }
    }
}
