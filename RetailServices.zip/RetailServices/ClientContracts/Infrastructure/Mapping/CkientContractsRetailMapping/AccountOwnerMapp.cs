﻿using ClientContracts.Domain.AccountOwnerAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class AccountOwnerMapp
    {
        public static AccountOwner Mapp(DataSet dsBanks)
        {
            AccountOwner _AccountOwner = null;
            foreach (DataRow row in dsBanks.Tables[0].Rows)
            {
                var OwnerId = Int32.Parse(row["Tipo_Representante_Id"].ToString());

                _AccountOwner = AccountOwner.Create(OwnerId);
            }

            return _AccountOwner;
        }
    }
}
