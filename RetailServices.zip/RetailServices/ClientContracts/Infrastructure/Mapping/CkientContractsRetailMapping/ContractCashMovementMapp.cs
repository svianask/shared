﻿using System;
using System.Collections.Generic;
using System.Data;
using ClientContracts.Domain.ContractMovementsAggregate;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class ContractCashMovementMapp
    {
        public static List<ContractDetailMovement> Mapp(string contractId, DataSet dt)
        {
            List<ContractDetailMovement> contractCashMovements = new List<ContractDetailMovement>();
            foreach (DataRow dr in dt.Tables[0].Rows)
            {
                ContractDetailMovement contractCashMovement = null;
                var movementContract = dr["Contrato_Id"].ToString();
                var movementDescripcion = dr["Movimiento"].ToString();
                var movementAmount = Convert.ToDecimal(dr["Importe"]);
                var movementProcessDate = Convert.ToDateTime(dr["Fecha"].ToString());
                var movementSubaccountName = dr["SubCuentaNombre"].ToString();
                var movementBankAccount =  dr["CuentaBancaria"].ToString();

                contractCashMovement = ContractDetailMovement
                                            .Create(contractId, movementContract, movementSubaccountName, movementAmount, movementProcessDate, movementBankAccount)
                                            .SetMovementDescription(movementDescripcion);

                contractCashMovements.Add(contractCashMovement);
            }

            return contractCashMovements;
        }
    }
}
