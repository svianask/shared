﻿using ClientContracts.Domain.AccountOwnerAggregate;
using ClientContracts.Domain.DetailBankAccountAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class DetailBankAccountMapp
    {
        public static List<DetailBankAccount> MappList(DataSet dsBanks)
        {
            List<DetailBankAccount> lstBanks = new List<DetailBankAccount>();
            foreach (DataRow row in dsBanks.Tables[0].Rows)
            {
                var Banco_Id = Int32.Parse(row["Banco_Id"].ToString());
                var Bank_name = row["Banco_Dsc"].ToString();
                var bankAccount = row["Contrato_Cta_Numero"].ToString();
                var useType = Int32.Parse(row["Tipo_Uso_Cuenta_Id"].ToString());
                var AccountClabe = row["Contrato_Cta_CLABE"].ToString();
                var typeAccount = Int32.Parse(row["Clasif_Cuenta_Banco_id"].ToString());

                DetailBankAccount _DetailBankAccount = DetailBankAccount.Create(Banco_Id, Bank_name, bankAccount, useType, AccountClabe, typeAccount);
                AccountOwner _AccountOwner = AccountOwnerMapp.Mapp(dsBanks);
                _DetailBankAccount.AddOwnerAccount(_AccountOwner);

                lstBanks.Add(_DetailBankAccount);
            }

            return lstBanks;
        }
    }
}
