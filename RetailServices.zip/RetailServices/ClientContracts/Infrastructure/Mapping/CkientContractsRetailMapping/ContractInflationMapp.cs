﻿using ClientContracts.Domain.ContractInflationAggregate;
using System;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractInflationMapp
    {
        public static ContractInflation Mapp(DataSet dsContractInflation)
        {
            ContractInflation contractInflation = ContractInflation.CreateEmpty();
            foreach (DataRow row in dsContractInflation.Tables[0].Rows)
            {
                var hasAutomaticInflation = Convert.ToBoolean(row["HasAutomaticInflation"]);
                var customPercentInflation = Convert.ToDecimal(row["CustomPercentInflation"]);
                contractInflation = ContractInflation.Create(hasAutomaticInflation, customPercentInflation);
            }

            return contractInflation;
        }
    }
}
