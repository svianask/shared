﻿using ClientContracts.Domain.ContractAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class PlanMapp
    {
        public static Plan Mapp(DataSet dsPlan)
        {
            Plan plan;

            if (dsPlan.Tables.Count > 0 && dsPlan.Tables[0].Rows.Count > 0)
            {
                plan = new Plan(dsPlan.Tables[0].Rows[0]["Plan_Descripcion_Comercial"].ToString());
            }
            else
            {
                plan = new Plan("");
            }

            return plan;
        }
    }
}
