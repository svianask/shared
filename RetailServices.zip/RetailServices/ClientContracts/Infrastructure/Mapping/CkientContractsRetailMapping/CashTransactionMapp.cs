﻿using ClientContracts.Domain.CashTransactionAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class CashTransactionMapp
    {
        public static CashTransaction Mapp(DataSet dsTransactions)
        {
            CashTransaction cashTransaction = new CashTransaction();


            DateTime tmpDate = new DateTime(1900, 1, 1);

            foreach (DataRow drCash in dsTransactions.Tables[0].Rows)
            {
                if (drCash["Transaccion_Signo"].ToString() == "+")
                {
                    cashTransaction.AmountContributions += Convert.ToDecimal(drCash["Orden_Importe"]);

                    if (tmpDate != Convert.ToDateTime(drCash["Transaccion_Fecha"]))
                    {
                        cashTransaction.TotalContributions++;
                    }
                }
                else if (drCash["Transaccion_Signo"].ToString() == "-")
                {
                    cashTransaction.AmountWithdrawals += Convert.ToDecimal(drCash["Orden_Importe"]);

                    if (tmpDate != Convert.ToDateTime(drCash["Transaccion_Fecha"]))
                    {
                        cashTransaction.TotalWithdrawals++;
                    }

                }
                tmpDate = Convert.ToDateTime(drCash["Transaccion_Fecha"]);
            }

            return cashTransaction;
        }
    }
}
