﻿using ClientContracts.Domain.ContractContributionsAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractsContributionsMapp
    {
        public static ContractContributions Mapp(DataSet ds)
        {
            ContractContributions contractContributions = null;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                var ContributionsAmount = Convert.ToDecimal(dr["Aportaciones"].ToString());
                var ContributionsNumber = Convert.ToInt16(dr["NumAportaciones"].ToString());
                var ContractType = Convert.ToInt16(dr["TipoContratoAsociado"]);

                switch (ContractType)
                {
                    case 1:
                        contractContributions =
                            ContractContributions
                                .Create(
                                    ContributionsAmount,
                                    ContributionsNumber
                                );
                        break;
                    case 2:
                        contractContributions.SetOrdinalContributions(
                                    ContributionsAmount,
                                    ContributionsNumber
                                );
                        break;
                    case 3:
                        contractContributions
                            .SetAdditionalContributions(
                                ContributionsAmount,
                                ContributionsNumber
                            );
                        break;
                }
            }

            if (contractContributions != null)
                contractContributions.SetFirstContributionDate(Convert.ToDateTime(ds.Tables[1].Rows[0]["FechaPrimeraAportacion"]));

            return contractContributions;
        }
    }
}
