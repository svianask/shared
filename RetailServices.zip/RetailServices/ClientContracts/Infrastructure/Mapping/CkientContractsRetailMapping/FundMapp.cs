﻿using ClientContracts.Domain.FundAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class FundMapp
    {
        public static Fund Mapp(DataRow drFund)
        {
            var name = drFund["Emision_Nombre"].ToString();
            var identifier = drFund["Emision_Id"].ToString();

            var fund = Fund.Create(identifier, name);
            fund
                .SetContract(drFund["Contrato_Id"].ToString())
                .SetPrices(
                    Convert.ToDecimal(drFund["Precio_Fondo"]),
                    Convert.ToDecimal(drFund["Precio_Fondo_Venta"]),
                    Convert.ToDecimal(drFund["Precio_Fondo_Compra"])
                )
                .SetShares(
                    Convert.ToDecimal(drFund["Portafolio_Tit_Imp"]),
                    Convert.ToDecimal(drFund["Portafolio_Tit_Comprometidos"]),
                    Convert.ToDecimal(drFund["Portafolio_Tit_Comprometidos_Venta"])
                )
                .SetMarketValues(
                    Convert.ToDecimal(drFund["Valor_Fondo"]),
                    Convert.ToDecimal(drFund["Valor_Fondo_Compra"]),
                    Convert.ToDecimal(drFund["Valor_Fondo_Venta"]),
                    Convert.ToDecimal(drFund["Porcentaje"])
                );

            return fund;
        }
    }
}
