﻿using ClientContracts.Domain.ContractsAcceptedAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractAcceptedMapp
    {
        public static List<ContractAccepted> Mapp(DataSet ds)
        {
            List<ContractAccepted> contracts = new List<ContractAccepted>();

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var id = Int32.Parse( row["Id"].ToString());
                var contractor_rfc = row["Rfc_Contratante"].ToString();
                var contract_id =  row["Contrato_Id"].ToString();
                var start_date = DateTime.Parse(row["Fecha_Inicio"].ToString()); 
               
                contracts.Add(ContractAccepted.Create( id, contractor_rfc, contract_id, start_date));
               
            }
            return contracts;
        }
    }
}
