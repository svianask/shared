﻿using System;
using System.Data;
using System.Data.SqlClient;
using ClientContracts.Domain.ContractAggregate;


namespace ClientContracts.Mapping
{
    public class SolvenciaDataMapp
    {
        public static SolvenciaData SolvenciaDataMapping(DataSet dsSolvencia)
        {
            var user = dsSolvencia.Tables[0].Rows[0]["UserName"] != DBNull.Value ? dsSolvencia.Tables[0].Rows[0]["UserName"].ToString() : String.Empty;
            var email = dsSolvencia.Tables[0].Rows[0]["Email"] != DBNull.Value ? dsSolvencia.Tables[0].Rows[0]["Email"].ToString() : String.Empty;
            var fullName = dsSolvencia.Tables[0].Rows[0]["NombreCompleto"] != DBNull.Value ? dsSolvencia.Tables[0].Rows[0]["NombreCompleto"].ToString() : String.Empty;
            return SolvenciaData.Create(user, email, fullName);
        }
    }
}
