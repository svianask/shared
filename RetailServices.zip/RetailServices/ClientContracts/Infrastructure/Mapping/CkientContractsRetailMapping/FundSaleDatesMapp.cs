﻿using System;
using System.Collections.Generic;
using System.Data;
using ClientContracts.Domain.FundSaleDatesAggregate;

namespace ClientContracts.Mapping
{
    public class FundSaleDatesMapp
    {
        public static FundSaleDates Mapping(DataSet ds, string fundId)
        {
            var dr = ds.Tables[0].Rows.Count > 0 ? ds.Tables[0].Rows[0] : null;
            if(dr != null)
            {
                return FundSaleDates
                        .Create(dr["Emision"].ToString())
                        .SetSaleLiquidityDate(Convert.ToDateTime(dr["Fecha_Liquidez_Venta"]))
                        .SetSaleOperationDate(Convert.ToDateTime(dr["Fecha_Operacion_Venta"]));
            } else
            {
                return FundSaleDates
                        .Create(fundId)
                        .SetSaleLiquidityDate(DateTime.MinValue)
                        .SetSaleOperationDate(DateTime.MinValue);
            }



        }
    }
}
