﻿using ClientContracts.Domain.SummaryContributionsAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Mapping
{
    public class SummaryContributionsMapp
    {
        public static SummaryContributions Mapp(DataRow drContributions)
        {
            return new SummaryContributions(
                int.Parse(drContributions["AportaTotales"].ToString()),
                int.Parse(drContributions["AportaEsperadas"].ToString()),
                int.Parse(drContributions["AportaRealizadas"].ToString()),
                int.Parse(drContributions["AportaFallidas"].ToString()),
                DateTime.Parse(drContributions["FechaInicio"].ToString()),
                int.Parse(drContributions["AportaFavor"].ToString())
                );
        }
    }
}
