﻿using ClientContracts.Domain.ContractAggregate;
using System;
using System.Data;
namespace ClientContracts.Mapping
{
    public class ContractPeriodMapp
    {
        public static ContractPeriod Mapp(DataSet dsPeriod)
        {
            if (dsPeriod.Tables.Count > 0 &&
                dsPeriod.Tables[0].Rows.Count > 0 &&
                dsPeriod.Tables[0].Rows[0]["PeriodStart"] != DBNull.Value &&
                dsPeriod.Tables[0].Rows[0]["PeriodEnd"] != DBNull.Value)
            {
                DateTime periodStart = (DateTime)dsPeriod.Tables[0].Rows[0]["PeriodStart"];
                DateTime periodEnd = (DateTime)dsPeriod.Tables[0].Rows[0]["PeriodEnd"];

                return ContractPeriod.Create(periodStart, periodEnd);
            }

            return ContractPeriod.CreateEmpty();
        }
    }
}
