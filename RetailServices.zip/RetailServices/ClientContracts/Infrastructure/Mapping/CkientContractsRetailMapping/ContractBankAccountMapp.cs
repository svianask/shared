﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using ClientContracts.Domain.ContractBankAccountAggregate;

namespace ClientContracts.Mapping
{
    public static class ContractBankAccountMapp
    {
        public static List<ContractBankAccount> ContractBankAccountMapping(DataSet ds)
        {
            List<ContractBankAccount> contractBankAccounts = new List<ContractBankAccount>();

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    var contractId = row["Contrato_Id"].ToString();
                    var accountId = Convert.ToInt32(row["Contrato_Cta_Id"].ToString());
                    var accountNumber = row["Contrato_Cta_Numero"].ToString();
                    var accountCLABE = row["Contrato_Cta_Clabe"].ToString();
                    accountNumber = string.IsNullOrEmpty(accountNumber) ? accountCLABE : accountNumber;
                    var accountUseTypeId = Convert.ToInt16(row["Tipo_Uso_Cuenta_Id"].ToString());
                    var bankId = Convert.ToInt32(row["Banco_Id"].ToString());
                    var accountBankName = row["Banco_Dsc_Corta"].ToString();
                    var bankAccountTypeId = Convert.ToInt32(row["Tipo_CtaBancoId"].ToString());
                    var classificationId = Convert.ToInt32(row["Clasif_Cuenta_Banco_Id"].ToString());                    
                    var accountStatusDsc = ds.Tables[0].Columns.Contains("Sts_Contrato_Cta_Dsc") ? row["Sts_Contrato_Cta_Dsc"].ToString() : "";
                    var accountUseTypeDsc = ds.Tables[0].Columns.Contains("Tipo_Uso_Cuenta_Dsc") ? row["Tipo_Uso_Cuenta_Dsc"].ToString() : "";
                    var accountCreatedDate = Convert.ToDateTime(row["Contrato_Cta_Fecha"].ToString());
                    var accountDescClasification = row["Clasif_Cuenta_Banco_Dsc_Corta"].ToString();
                    var accountTypeUse = row["Tipo_Uso_Cuenta_Dsc_Corta"].ToString();
                    contractBankAccounts.Add(ContractBankAccount
                        .Create(contractId)
                        .SetAccountData(accountId, accountNumber, accountUseTypeId)
                        .SetBankData(bankId, accountBankName, bankAccountTypeId)
                        .SetClassificationAccount(classificationId)
                        .SetAccountStatusDsc(accountStatusDsc)
                        .SetAccountUseTypeDsc(accountUseTypeDsc)
                        .SetAccountCreatedDate(accountCreatedDate)
                        .SetAccountDescClasification(accountDescClasification)
                        .SetAccountUseType(accountTypeUse));
                
                }
            }

            return contractBankAccounts;
        }

        public static List<ContractBankAccount> ContractBankAccountTddTdcClbMapping(DataSet ds)
        {
            List<ContractBankAccount> contractBankAccounts = new List<ContractBankAccount>();

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    var contractId = row["Contrato_Id"].ToString();
                    var accountId = Convert.ToInt32(row["Contrato_Cta_Id"].ToString());
                    var accountNumber = row["Contrato_Cta_Numero"].ToString();
                    var accountCLABE = row["Contrato_Cta_Clabe"].ToString();
                    accountNumber = string.IsNullOrEmpty(accountNumber) ? accountCLABE : accountNumber;
                    var accountUseTypeId = Convert.ToInt16(row["Tipo_Uso_Cuenta_Id"].ToString());
                    var bankId = Convert.ToInt32(row["Banco_Id"].ToString());
                    var accountBankName = row["Banco_Dsc_Corta"].ToString();
                    var bankAccountTypeId = Convert.ToInt32(row["Tipo_CtaBancoId"].ToString());
                    var classificationId = Convert.ToInt32(row["Clasif_Cuenta_Banco_Id"].ToString());
                    var accountStatusDsc = ds.Tables[0].Columns.Contains("Sts_Contrato_Cta_Dsc") ? row["Sts_Contrato_Cta_Dsc"].ToString() : "";
                    var accountUseTypeDsc = ds.Tables[0].Columns.Contains("Tipo_Uso_Cuenta_Dsc") ? row["Tipo_Uso_Cuenta_Dsc"].ToString() : "";                    
                    contractBankAccounts.Add(ContractBankAccount
                        .Create(contractId)
                        .SetAccountData(accountId, accountNumber, accountUseTypeId)
                        .SetBankData(bankId, accountBankName, bankAccountTypeId)
                        .SetClassificationAccount(classificationId)
                        .SetAccountStatusDsc(accountStatusDsc)
                        .SetAccountUseTypeDsc(accountUseTypeDsc));

                }
            }

            return contractBankAccounts;
        }
    }
}
