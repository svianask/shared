﻿using ClientContracts.Domain.ContractsPeriodicityAggregate;
using System;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractPeriodicityMapp
    {
        public static ContractPeriodicity Mapp(DataSet ds)
        {
            ContractPeriodicity periodicity = null;

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                var contractId =  row["ContractId"].ToString();
                var contractMaster =  row["ContractMaster"].ToString();
                var periodicityId = Int16.Parse(row["PeriodicityId"].ToString());
                var periodicityName = row["PeriodicityName"].ToString();
                var termMonths = Int16.Parse(row["TermMonths"].ToString());

                periodicity = ContractPeriodicity.Create( contractId, contractMaster, periodicityId, periodicityName, termMonths);

            }
            return periodicity;
        }
    }
}
