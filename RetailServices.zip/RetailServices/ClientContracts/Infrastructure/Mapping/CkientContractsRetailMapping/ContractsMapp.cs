﻿using ClientContracts.Domain.ContractsAggregate;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractsMapp
    {
        public static ContractsOf MappingClientContracts(DataSet dsContracts)
        {
            ContractsOf contracts = null;
            contracts = new ContractsOf(dsContracts.Tables[0].Rows[0]["Contrato_RFC"].ToString());

            foreach (DataRow dr in dsContracts.Tables[0].Rows)
            {
                Contr contract = ClientContractMapp.MappingContract(dr);

                contracts.AddContract(contract);
            }
            

            return contracts;
        }

        public static ContractsOf MappingClientContractsPaidUp(DataSet dsContracts)
        {
            ContractsOf contracts = null;
            contracts = new ContractsOf(dsContracts.Tables[0].Rows[0]["Contrato_RFC"].ToString());

            foreach (DataRow dr in dsContracts.Tables[0].Rows)
            {
                Contr contract = ClientContractMapp.MappingContractPaidUp(dr);

                contracts.AddContract(contract);
            }


            return contracts;
        }
    }
}
