﻿using ClientContracts.Domain.AssociatedContractAggregate;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class AssociatedContractsMapp
    {
        public static List<AssociatedContract> Mapp(DataSet dsAssociatedContract)
        {
            List<AssociatedContract> lstAssociatedContracts = new List<AssociatedContract>();
            string tmpMasterContract = string.Empty;
            string MasterContract = string.Empty;
            string AdditionalContributionsContract = string.Empty;
            string ContractControlContribution = string.Empty;
            foreach (DataRow drAssocContract in dsAssociatedContract.Tables[0].Rows)
            {
                lstAssociatedContracts.Add(
                    AssociatedContract.Create(
                        drAssocContract["Contrato_id"].ToString(),
                        drAssocContract["Contrato_Id_Agrupador"].ToString(),
                        int.Parse(drAssocContract["tipo"].ToString())
                    )
                );
            }
            return lstAssociatedContracts;
        }
    }
}
