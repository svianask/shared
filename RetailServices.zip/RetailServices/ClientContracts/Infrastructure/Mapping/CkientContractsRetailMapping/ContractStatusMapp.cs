﻿using System;
using ClientContracts.Domain.ContractAggregate;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractStatusMapp
    {
        public static ContractStatus Mapp(DataSet ds)
        {
            ContractStatus contractStatus = null;
            if(ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                var contractId = dr["Contrato_Id"].ToString();
                var statusId = Convert.ToInt16(dr["Sts_Contrato_Id"]);
                var statusDsc = dr["Sts_Contrato_Dsc_Corta"].ToString();

                contractStatus = ContractStatus.Create(contractId, statusId, statusDsc);
            }

            return contractStatus;
        }
    }
}
