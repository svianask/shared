﻿using ClientContracts.Domain.ContractBeneficiariesAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientContracts.Mapping
{
    public class ContractBeneficiariesMapp
    {
        public static List<Beneficiary> MappList(DataSet dsBeneficiaries)
        {
            List<Beneficiary> beneficiaries = new List<Beneficiary>();
            foreach (DataRow row in dsBeneficiaries.Tables[0].Rows)
            {
                var name = row["Contrato_Repr_Nombre"].ToString();
                var surname = row["Contrato_Repr_Apellido_Pat"].ToString();
                var secondSurname = row["Contrato_Repr_Apellido_Mat"].ToString();
                var kinship = row["Tipo_Parentesco_Dsc_Corta"].ToString();
                var percentage = Decimal.Parse(row["Contrato_Repr_Porcentaje"].ToString());

                var beneficiary = Beneficiary.Create($"{name} {surname} {secondSurname}", kinship, percentage);    
                beneficiaries.Add( beneficiary );
            }

            return beneficiaries;
        }
    }
}
