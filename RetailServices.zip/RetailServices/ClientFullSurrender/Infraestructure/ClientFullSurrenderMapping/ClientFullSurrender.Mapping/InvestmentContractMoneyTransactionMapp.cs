﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.Domain.Enumerations;

namespace ClientFullSurrender.Mapping
{
    public class InvestmentContractMoneyTransactionMapp
    {
        public static InvestmentContractMoneyTransaction Mapp(DataSet dtContractTransaction, string TransactionId, string ContractId)
        {
            InvestmentContractMoneyTransaction ListInvestmentFundOrder = null;
            if (dtContractTransaction != null)
            {
                if (dtContractTransaction.Tables.Count > 0)
                {

                        ICMoneyTransactionType TransactionType = (ICMoneyTransactionType)Convert.ToInt32(dtContractTransaction.Tables[0].Rows[0]["Tipo_Transaccion_Id"]);
                        int transactionTypeId = (int)TransactionType;
                        string _ContractId = ContractId;
                        DateTime TransactionDate = Convert.ToDateTime(dtContractTransaction.Tables[0].Rows[0]["Fecha_Transaccion"].ToString());
                        string User = dtContractTransaction.Tables[0].Rows[0]["Usuario_Id"].ToString();

                        InvestmentContractMoneyTransaction invesment = InvestmentContractMoneyTransaction.Create(TransactionId, TransactionType, TransactionDate, User);                    
                }
            }

            return ListInvestmentFundOrder;
        }
    }
}
