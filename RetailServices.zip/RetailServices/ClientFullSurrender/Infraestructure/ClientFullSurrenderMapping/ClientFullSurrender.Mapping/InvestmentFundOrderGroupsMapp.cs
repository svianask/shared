﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Mapping
{
    public class InvestmentFundOrderGroupsMapp
    {
        public static List<InvestmentFundOrderGroups> MappList(DataSet dtCharges)
        {
            List<InvestmentFundOrderGroups> Groups = new List<InvestmentFundOrderGroups>();
            if (dtCharges != null)
            {
                if (dtCharges.Tables.Count > 0)
                {
                    foreach (DataRow dr in dtCharges.Tables[0].Rows)
                    {

                        string sourceBaseDate = dr["Tipo_Cargo_Abono_Dsc"].ToString();
                        string typeMerchanId = dr["Tipo_Cargo_Abono_Dsc"].ToString();
                        string typeOperationId = dr["Tipo_Cargo_Abono_Dsc"].ToString();
                        string typeOrderId = dr["Tipo_Cargo_Abono_Dsc"].ToString();
                        DateTime orderSetlemenDate = DateTime.Parse(dr["Tipo_Cargo_Abono_Dsc"].ToString());

                        InvestmentFundOrderGroups Group = InvestmentFundOrderGroups.Create(sourceBaseDate, typeMerchanId, typeOperationId, typeOrderId, orderSetlemenDate);

                        Groups.Add(Group);
                    }
                }
            }

            return Groups;
        }
    }
}
