﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Mapping
{
    public class FullFundSaleDatesMapp
    {
        public static FullFundSaleDates Mapping(DataSet ds, string fundId)
        {
            var dr = ds.Tables[0].Rows.Count > 0 ? ds.Tables[0].Rows[0] : null;
            if (dr != null)
            {
                return FullFundSaleDates
                        .Create(dr["Emision"].ToString())
                        .SetSaleLiquidityDate(Convert.ToDateTime(dr["Fecha_Liquidez_Venta"]))
                        .SetSaleOperationDate(Convert.ToDateTime(dr["Fecha_Operacion_Venta"]))
                        .SetIsLiquidSale(Convert.ToBoolean(dr["FondoLiquidoVenta"]))
                        .SetValuation(Convert.ToDouble(Convert.ToBoolean(dr["PrecioFondo"])))
                        .SetOperatorCommisionSale(Convert.ToDouble(Convert.ToBoolean(dr["Fondo_Comision_Venta"])))
                        ;
            }
            else
            {
                return FullFundSaleDates
                        .Create(fundId)
                        .SetSaleLiquidityDate(DateTime.MinValue)
                        .SetSaleOperationDate(DateTime.MinValue);
            }
        }
    }
}
