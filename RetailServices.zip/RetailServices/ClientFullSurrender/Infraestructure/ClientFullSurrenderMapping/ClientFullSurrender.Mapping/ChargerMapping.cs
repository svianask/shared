﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.Domain.Enumerations;

namespace ClientFullSurrender.Mapping
{
    public class ChargerMapping
    {
        public static List<ChargeConfig> MappList(DataSet dtCharges)
        {
            List<ChargeConfig> Chargers = new List<ChargeConfig>();
            if (dtCharges != null)
            {
                if (dtCharges.Tables.Count > 0)
                {
                    foreach (DataRow dr in dtCharges.Tables[0].Rows)
                    {
                        string description = dr["Tipo_Cargo_Abono_Dsc"].ToString();
                        int ChargeID = Convert.ToInt32(dr["Tipo_Cargo_Abono_Id"].ToString());

                        ChargeConfig Charge = ChargeConfig.Create(ChargeID, description.ToUpper());

                        Chargers.Add(Charge);
                    }
                }
            }

            return Chargers;
        }

        public static bool MappExisting(DataSet dtCharges, int chargeId)
        {
            bool chargeExists = false;

            if (dtCharges != null && dtCharges.Tables.Count > 0 && dtCharges.Tables[0].Rows.Count > 0)
            {
                chargeExists = true;
                if ((int)ChargesIdentifierSIIF.AssetFee == chargeId)
                {
                    chargeExists = false;
                    foreach (DataRow dr in dtCharges.Tables[0].Rows)
                    {
                        DateTime orderDate = new DateTime();
                        orderDate = Convert.ToDateTime(dr["Orden_Fecha_Proceso"]);

                        if (orderDate.Year == DateTime.Now.Year && orderDate.Month == DateTime.Now.Month)
                        {
                            chargeExists = true;
                        }
                    }
                }
            }

            return chargeExists;
        }
    }
}
