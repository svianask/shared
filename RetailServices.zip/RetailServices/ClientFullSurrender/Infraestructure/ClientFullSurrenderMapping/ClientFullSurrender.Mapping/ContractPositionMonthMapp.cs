﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Mapping
{
    public class ContractPositionMonthMapp
    {
        public static List<ContractPositionMonth> MappList(DataSet dtContracts)
        {
            List<ContractPositionMonth> ContractsPosition = new List<ContractPositionMonth>();
            if (dtContracts != null)
            {
                if (dtContracts.Tables.Count > 0)
                {
                    foreach (DataRow dr in dtContracts.Tables[0].Rows)
                    {
                        string ContratoId = dr["Contrato"].ToString();
                        double Position = Convert.ToDouble(dr["Posicion"].ToString());
                        DateTime Date = Convert.ToDateTime(dr["Fecha"].ToString());

                        ContractPositionMonth _ContractPositionMonth = ContractPositionMonth.Create(ContratoId, Date, Position);

                        ContractsPosition.Add(_ContractPositionMonth);
                    }
                }
            }

            return ContractsPosition;
        }
    }
}
