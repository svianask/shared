﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Mapping
{
    public class TransactionWithdrawalMapp
    {
        public static List<TransactionWithdrawal> MappList(DataSet dtTrans)
        {
            List<TransactionWithdrawal> Trans = new List<TransactionWithdrawal>();
            if (dtTrans != null)
            {
                if (dtTrans.Tables.Count > 0)
                {
                    foreach (DataRow dr in dtTrans.Tables[0].Rows)
                    {
                        string TransSign = dr["Transaccion_Signo"].ToString();
                        DateTime TransDate = DateTime.Parse(dr["Transaccion_Fecha"].ToString());
                        decimal TotalOrder = decimal.Parse(dr["Orden_Importe"].ToString());

                        TransactionWithdrawal Tran = TransactionWithdrawal.Create(TransSign, TransDate, TotalOrder);

                        Trans.Add(Tran);
                    }
                }
            }

            return Trans;
        }
    }
}
