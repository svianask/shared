﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.Domain.Enumerations;

namespace ClientFullSurrender.Mapping
{
    public class InvestmentFundOrderMapp
    {
        public static List<InvestmentFundOrder> MappList(DataSet dtCharges)
        {
            List<InvestmentFundOrder> ListInvestmentFundOrder = new List<InvestmentFundOrder>();
            if (dtCharges != null)
            {
                if (dtCharges.Tables.Count > 0)
                {
                    foreach (DataRow dr in dtCharges.Tables[0].Rows)
                    {
                        int OrderType = (int)InvestmentFundOrderType.SaleFund;
                        InvestmentFundSubOrderType OrderSubType = InvestmentFundSubOrderType.SaleFundToBuyFund;
                        if (dr["Tipo_Operacion_Id"].ToString().Equals("5"))
                        {
                            OrderType = (int)InvestmentFundOrderType.BuyFund;
                            OrderSubType = InvestmentFundSubOrderType.BuyFundFromSaleFund;
                        }
                        else if (dr["Tipo_Operacion_Id"].ToString().Equals("10"))
                        {
                            OrderType = (int)InvestmentFundOrderType.SaleFund;
                            OrderSubType = InvestmentFundSubOrderType.SaleFundToBuyFund;
                        }

                        string description = dr["Tipo_Cargo_Abono_Dsc"].ToString();
                        int Linaje = Convert.ToInt32(dr["Linage"].ToString().Substring(1, 1));

                        InvestmentFundOrder invesment = InvestmentFundOrder.Create(OrderType, OrderSubType, Linaje);

                        InvestmentFundOrder inv = ListInvestmentFundOrder.Find(I => I.Linaje == Linaje);

                        if (inv == null)
                            ListInvestmentFundOrder.Add(invesment);
                        else
                            inv = invesment;
                    }
                }
            }

            return ListInvestmentFundOrder;
        }
    }
}
