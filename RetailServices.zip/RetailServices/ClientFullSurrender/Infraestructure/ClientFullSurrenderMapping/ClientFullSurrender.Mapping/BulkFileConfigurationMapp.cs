﻿using System.Data;
using ClientFullSurrender.Domain.BulkFileAggregate;

namespace ClientFullSurrender.Mapping
{
    public class BulkFileConfigurationMapp
    {
        public static BulkFileConfiguration Mapp(DataSet ds)
        {
            BulkFileConfiguration fileConfiguration = null;

            if(ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                var inputPath = dr["Ruta_Entrada"].ToString();
                var outputPath = dr["Ruta_Salida"].ToString();
                var backupPath = dr["Ruta_Backup"].ToString();
                var user = dr["Usuario"].ToString();
                var pwd = dr["Password"].ToString();
                var domain = dr["Dominio"].ToString();

                fileConfiguration = BulkFileConfiguration.Create(inputPath, outputPath, backupPath);
                fileConfiguration.SetCredentials(user, domain, pwd);
            }

            return fileConfiguration;
        }
    }
}
