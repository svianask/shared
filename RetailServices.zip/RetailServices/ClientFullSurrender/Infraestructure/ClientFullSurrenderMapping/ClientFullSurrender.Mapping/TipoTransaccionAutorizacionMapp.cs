﻿using System;
using System.Data;
using System.Collections.Generic;
using ClientFullSurrender.Domain.AuthorizationAggregate;

namespace ClientFullSurrender.Mapping
{
    public class TipoTransaccionAutorizacionMapp
    {
        public static List<TipoTransaccionAutorizacion> Mapp(DataSet ds)
        {
            List<TipoTransaccionAutorizacion> tipoTransaccionAutorizacions = new List<TipoTransaccionAutorizacion>();
            foreach(DataRow dr in ds.Tables[0].Rows)
            {
                if(dr["Tipo_Transaccion_Id"].ToString().Equals("2")) 
                {
                    int tipo_Transaccion_Id = Convert.ToInt32(dr["Tipo_Transaccion_Id"]);
                    string tipo_Transaccion_Dsc = dr["Tipo_Transaccion_Dsc"].ToString();
                    int tipo_Autorizacion_Id = Convert.ToInt32(dr["Tipo_Autorizacion_Id"]);
                    string tipo_Autorizacion_Dsc = dr["Tipo_Autorizacion_Dsc"].ToString();
                    bool monto_Requerido = Convert.ToBoolean(dr["Tipo_Autorizacion_Id"]);

                    TipoTransaccionAutorizacion tipoTransaccionAutorizacion = TipoTransaccionAutorizacion
                        .Create(tipo_Transaccion_Id, tipo_Transaccion_Dsc, tipo_Autorizacion_Id, tipo_Autorizacion_Dsc, monto_Requerido);

                    tipoTransaccionAutorizacions.Add(tipoTransaccionAutorizacion);
                }
            }

            return tipoTransaccionAutorizacions;
        }
    }
}
