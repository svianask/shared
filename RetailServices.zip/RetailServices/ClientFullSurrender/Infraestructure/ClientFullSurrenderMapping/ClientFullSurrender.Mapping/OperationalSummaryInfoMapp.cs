﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Mapping
{
    public class OperationalSummaryInfoMapp
    {
        public static OperationalSummaryInfo Mapp(DataSet dtTransactions, DateTime openingDate)
        {
            DateTime firstContributionDate = DateTime.MinValue;
            DateTime beginningDate = new DateTime(1900, 1, 1);
            DataRow[] drContrib = null;
            int currentMonths;
            TimeSpan ts;
            decimal cntExactYears = 0m;

            if (dtTransactions.Tables[0].Rows.Count > 0)
            {

                drContrib = dtTransactions.Tables[0].Select("Transaccion_Signo = '+'", "Transaccion_Fecha");
                if (drContrib.Length > 0)
                    firstContributionDate = Convert.ToDateTime(drContrib[0]["Transaccion_Fecha"]);
            }

            beginningDate = (firstContributionDate.Ticks >= openingDate.Ticks) ? firstContributionDate : openingDate;

            ts = new TimeSpan(DateTime.Now.Ticks - beginningDate.Ticks);

            cntExactYears = Convert.ToDecimal(Convert.ToDouble(ts.Days) / Convert.ToDouble(365));//Exact

            currentMonths = ((DateTime.Now.Year - beginningDate.Year) * 12) + (DateTime.Now.Month - beginningDate.Month);
            if (beginningDate.Ticks == new DateTime(1900, 1, 1).Ticks)
                beginningDate = DateTime.Now;

            return OperationalSummaryInfo
                .Create(cntExactYears, currentMonths).AddBeginDate(beginningDate);
        }
    }
}
