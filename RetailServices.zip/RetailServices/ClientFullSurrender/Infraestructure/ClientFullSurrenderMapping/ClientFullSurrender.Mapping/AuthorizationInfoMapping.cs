﻿using System;
using ClientFullSurrenderDomainModel.AuthorizationAggregate;
using System.Data;

namespace ClientFullSurrender.Mapping
{
    public class AuthorizationInfoMapping
    {
        public static AuthorizationInfo Map(DataSet ds)
        {
            AuthorizationInfo authorizationInfo = null;
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                var amount = Convert.ToDecimal(dr["Monto_Autorizado"]);
                var contractId = dr["Contrato_Id"].ToString();
                var authId = Convert.ToInt32(dr["Autorizacion_Id"]);
                var aplicationDate = Convert.ToDateTime(dr["Fecha_Aplicacion"]);
                var user = dr["Usuario_Id"].ToString();
                authorizationInfo = AuthorizationInfo.Create(contractId, authId, aplicationDate, user, amount);
            }
            return authorizationInfo;
        }
    }
}
