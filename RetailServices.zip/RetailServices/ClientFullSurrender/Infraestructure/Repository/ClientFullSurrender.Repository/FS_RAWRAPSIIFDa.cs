﻿using SqlClient.Helper;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using Unity;
using ClientFullSurrender.Domain.AuthorizationAggregate;
using ClientFullSurrender.Mapping;
using ClientFullSurrender.Domain.BulkFileAggregate;
using ClientFullSurrender.Domain;
using ClientFullSurrenderDomainModel.AuthorizationAggregate;
using System.Linq;
using Common.Domain;

namespace ClientFullSurrender.Repository
{
    public class FS_RAWRAPSIIFDa: IFS_RAWRAPSIIFDa
    {
        private readonly SqlConnection _cmdConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public FS_RAWRAPSIIFDa([Dependency("RAWRAPSIIF")] SqlConnection cmdConn, ISqlClientHelper sqlClientHelper)
        {
            this._cmdConn = cmdConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public DateTime GetNextLaboralDayGT(DateTime RequiredDate)
        {
            DataSet ds = new DataSet();

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_GT_GetProximoDiaHabil", _cmdConn);
            cmd.AddParameterWithValue("@pdtmFechaRequerida", RequiredDate);

            ds = _sqlClientHelper.ExecuteDataSet(cmd);

            if (ds != null && ds.Tables[0].Rows.Count > 0)
                return Convert.ToDateTime(ds.Tables[0].Rows[0]);
            else
                return new DateTime(1900, 1, 1);
        }

        public int InsertCompoundTransaction(string contractIdentifier, string transactionIdentifier, string compoundTransactionIdentifier, int transactionType)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertTransaccionCompuesta", _cmdConn);

            cmd.AddParameterWithValue("@pstrContratoId", contractIdentifier);
            cmd.AddParameterWithValue("@pstrTransaccionId", transactionIdentifier);
            cmd.AddParameterWithValue("@pstrTransaccionCompuestaId", compoundTransactionIdentifier);
            cmd.AddParameterWithValue("@pintTipoTransaccionGrupoId",  transactionType);

            return cmd.ExecuteNonQuery();
        }

        public int InsertProgrammedCharges(string contractIdentifier, string compoundTransactionIdentifier, Int16 chargeIdentifier, double chargeAmountOriginal, double chargeAmount, double chargeTaxOriginal, double chargeTax, string chargeDescription)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertCargosProgramados", _cmdConn);

            cmd.AddParameterWithValue("@pstrContratoId", contractIdentifier);
            cmd.AddParameterWithValue("@pstrTransaccionCompuestaId", compoundTransactionIdentifier);
            cmd.AddParameterWithValue("@pintCargoId",  chargeIdentifier);
            cmd.AddParameterWithValue("@pfltMontoOriginal", chargeAmountOriginal);
            cmd.AddParameterWithValue("@pfltMonto", chargeAmount);
            cmd.AddParameterWithValue("@pfltIVAOriginal", chargeTaxOriginal);
            cmd.AddParameterWithValue("@pfltIVA", chargeTax);
            cmd.AddParameterWithValue("@pstrDescripcion", chargeDescription);

            return cmd.ExecuteNonQuery();
        }

        public int InsertProgrammedTransaction(string contractIdentifier, string compoundTransactionIdentifier, int transactionType, DateTime requestDate,
            DateTime applyTransactionDate, int statusTransactionId, string errorDescription, string userId,
            string contextText1, string contextText2, string contextText3, string contextText4,
            string contextText5, string contextText6, Double contextNumeric1, Double contextNumeric2,
            Double contextNumeric3, Double contextNumeric4, Double contextNumeric5, Double contextNumeric6, int liquidationType, int surrenderProcessType, string migrationDestContract)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertTransaccionProgramada", _cmdConn);

            cmd.AddParameterWithValue("@pstrContratoId", contractIdentifier);
            cmd.AddParameterWithValue("@pstrTransaccionCompuestaId", compoundTransactionIdentifier);
            cmd.AddParameterWithValue("@pintTipoTransaccionId", transactionType);
            cmd.AddParameterWithValue("@pdteFechaSolicitud", requestDate);
            cmd.AddParameterWithValue("@pdteFechaTransacAplicacion", applyTransactionDate);
            cmd.AddParameterWithValue("@pintEstatusTransacId", statusTransactionId);
            cmd.AddParameterWithValue("@pstrDescripcionError", errorDescription);
            cmd.AddParameterWithValue("@pstrUsuarioId", userId);
            cmd.AddParameterWithValue("@pstrContexto1", contextText1);
            cmd.AddParameterWithValue("@pstrContexto2", contextText2);
            cmd.AddParameterWithValue("@pstrContexto3", contextText3);
            cmd.AddParameterWithValue("@pstrContexto4", contextText4);
            cmd.AddParameterWithValue("@pstrContexto5", contextText5);
            cmd.AddParameterWithValue("@pstrContexto6", contextText6);
            cmd.AddParameterWithValue("@pfltContexto1", contextNumeric1);
            cmd.AddParameterWithValue("@pfltContexto2", contextNumeric2);
            cmd.AddParameterWithValue("@pfltContexto3", contextNumeric3);
            cmd.AddParameterWithValue("@pfltContexto4", contextNumeric4);
            cmd.AddParameterWithValue("@pfltContexto5", contextNumeric5);
            cmd.AddParameterWithValue("@pfltContexto6", contextNumeric6);
            cmd.AddParameterWithValue("@pintLiquidationType", liquidationType);
            cmd.AddParameterWithValue("@pintSurrenderProcessType", surrenderProcessType);
            cmd.AddParameterWithValue("@pstrMigrationDestContract", migrationDestContract);

            return cmd.ExecuteNonQuery();
        }

        public List<TipoTransaccionAutorizacion> GetTransactionsAuthorizations()
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_GetTipoTransaccionAutorizacion", _cmdConn);
            DataSet dsResult = _sqlClientHelper.ExecuteDataSet(cmd);

            return TipoTransaccionAutorizacionMapp.Mapp(dsResult);
        }

        public BulkFileConfiguration GetBulkFileConfiguration(int processId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_Get_Retiro_Total_Config", _cmdConn);
            cmd.AddParameterWithValue("@TipoId", processId);
            DataSet dsResult = _sqlClientHelper.ExecuteDataSet(cmd);
            return BulkFileConfigurationMapp.Mapp(dsResult);
        }

        public void GenerateFundTransactionSIIF(string product, int transactionType, string transctionId,
            DateTime transactionDate, string contractId, string userIdentifier)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertaContratoTransaccion", _cmdConn);
            cmd.AddParameterWithValue("@pstrContratoId", contractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", transctionId);
            cmd.AddParameterWithValue("@psintTipoTransaccionId", transactionType);
            cmd.AddParameterWithValue("@pdtFechaTransaccion", transactionDate);
            cmd.AddParameterWithValue("@pstrTipoProducto", product);
            cmd.AddParameterWithValue("@pstrUsuarioId", userIdentifier);
            DataSet dsResult = _sqlClientHelper.ExecuteDataSet(cmd);
        }

        public FullFundSaleDates GetContractFundsLiquidityDates(string fundId, DateTime dateRequest, int platform)
        {
            String spName = platform == 10 ? "usp_SOC_SIIF_RS_GetFondoDetalleCpaVta" : "usp_SOC_SIIF_GT_GetFondoDetalleCpaVta";
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _cmdConn);
            cmd.AddParameterWithValue("@pFondo", fundId);
            cmd.AddParameterWithValue("@pFecha", dateRequest);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FullFundSaleDatesMapp.Mapping(ds, fundId);
        }

        public void UpdateClientPortafolioType(string contractId, int clientType, int Platform)
        {
            string sp_name = Platform == 0 ? "usp_SOC_SIIF_RS_UpdateTipoPortafolioCliente" : "usp_SOC_SIIF_GT_UpdateTipoPortafolioCliente";
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(sp_name, _cmdConn);
            cmd.AddParameterWithValue("@ContratoID", contractId);
            cmd.AddParameterWithValue("@pintTipoClienteId", clientType);

            _sqlClientHelper.ExecuteDataSet(cmd);
        }

        public int InsertInvestmentFundTransferOrder(string ContractId, int OperationType, int AmountType, string EmisionId, float Shares, float Price, float Amount, DateTime OperationDate,
                                                        DateTime LiquidationDate, float ComissionAmount, float ComissionTaxAmount, string Comment, int OrderChainId, int IsLastOrder,
                                                        int OrderType, int NotValidateSalePos, int NotValidateCompromisedPos)
        {
            int OrderId = 0;

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_SIIF_ApplyFullSurrender", _cmdConn);
            cmd.AddParameterWithValue("@ContractId", ContractId);
            cmd.AddParameterWithValue("@OperationType", OperationType);
            cmd.AddParameterWithValue("@AmountType", AmountType);
            cmd.AddParameterWithValue("@EmisionId", EmisionId);
            cmd.AddParameterWithValue("@Shares", Shares);
            cmd.AddParameterWithValue("@Price", Math.Round(Price,6));
            cmd.AddParameterWithValue("@Amount", Math.Round(Amount,2));
            cmd.AddParameterWithValue("@OperationDate", OperationDate);
            cmd.AddParameterWithValue("@LiquidationDate", LiquidationDate);
            cmd.AddParameterWithValue("@ComissionAmount", ComissionAmount);
            cmd.AddParameterWithValue("@ComissionTaxAmount", ComissionTaxAmount);
            cmd.AddParameterWithValue("@Comment", Comment);
            cmd.AddParameterWithValue("@OrderChainId", OrderChainId);
            cmd.AddParameterWithValue("@IsLastOrder", IsLastOrder);
            cmd.AddParameterWithValue("@OrderType", OrderType);
            cmd.AddParameterWithValue("@NotValidateSalePos", NotValidateSalePos);
            cmd.AddParameterWithValue("@NotValidateCompromisedPos", NotValidateCompromisedPos);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    OrderId += Convert.ToInt32(row[0]);
                }
            }

            return OrderId;
        }

        public int InsertInvestmentFundOrderLog(string TransaccionId, string OrderLogId, string OrderLogFatherId, int OrderLogDepth, string OrderLogLinage, DateTime OrderLoadDate,
                                                DateTime OrderApplicationDate, int OrderLogEstatus, string OrderLogContractId, int OrderId, int OperationType, int OrderTypeLog,
                                                string EmisionId, double Shares, double Price, double Amount, DateTime OperationDate, DateTime LiquidationDate, double ComissionAmount,
                                                double ComissionTaxAmount, string Comments, int OrdenVentaId, int LiquidationType, string OrderContractId, int MarketType
            )
        {

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertOrdenProgramada", _cmdConn);
            cmd.AddParameterWithValue("@pstrTransaccionId", TransaccionId);
            cmd.AddParameterWithValue("@pstrOrdenProgramadaId", OrderLogId);
            if(string.IsNullOrEmpty(OrderLogFatherId))
                cmd.AddParameterWithValue("@pstrOrdenProgramadaPadreId", DBNull.Value);
            else
                cmd.AddParameterWithValue("@pstrOrdenProgramadaPadreId", OrderLogFatherId);

            cmd.AddParameterWithValue("@pintProfundidad", OrderLogDepth);
            cmd.AddParameterWithValue("@pstrLinage", OrderLogLinage);
            cmd.AddParameterWithValue("@pdtmFechaProgramacion", OrderLoadDate);
            cmd.AddParameterWithValue("@pdtmFechaAplicacion", OrderApplicationDate);
            cmd.AddParameterWithValue("@pintOrdenProgramadaEstatus", OrderLogEstatus);
            cmd.AddParameterWithValue("@pstrContratoId", OrderLogContractId);
            cmd.AddParameterWithValue("@pintOrdenId", OrderId);
            cmd.AddParameterWithValue("@psintTipoOperacionId", OperationType);
            cmd.AddParameterWithValue("@psintTipoOrdenId", OrderTypeLog);
            cmd.AddParameterWithValue("@pstrEmisionId", EmisionId);
            cmd.AddParameterWithValue("@pintOrdenTitulos", Shares);
            cmd.AddParameterWithValue("@pfltOrdenPrecio", Price);
            cmd.AddParameterWithValue("@pfltOrdenImporte", Amount);
            cmd.AddParameterWithValue("@pdtmOrdenFechaProceso", OrderLoadDate);
            cmd.AddParameterWithValue("@pdtmOrdenFechaOperacion", OperationDate);
            cmd.AddParameterWithValue("@pdtmOrdenFechaLiquidacion", LiquidationDate);
            cmd.AddParameterWithValue("@pfltOrdenComision", ComissionAmount);
            cmd.AddParameterWithValue("@pfltOrdenIVA", ComissionTaxAmount);
            cmd.AddParameterWithValue("@pstrOrdenObservaciones", Comments); 
            cmd.AddParameterWithValue("@pintOrdenVentaId", OrdenVentaId);
            cmd.AddParameterRequiredNull("@pbitTipoLiquidacion", LiquidationType);

            cmd.AddParameterWithValue("@OrdenContratoId", OrderContractId);
            cmd.AddParameterWithValue("@TipoMercadoId", MarketType);

            return _sqlClientHelper.ExecuteNonQuery(cmd);
        }

        public int InsertInvestmentChargeOrder(string ContractId, int CargoId, float Amount, float Comission, float ComissionTaxAmount, string Comments, int AvailableCash)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_SIIF_InsertInvestmentChargeOrder", _cmdConn);
            cmd.AddParameterWithValue("@pstrContratoId", ContractId);

            cmd.AddParameterWithValue("@psintTipoCargoId", CargoId);
            cmd.AddParameterWithValue("@pfltCargoImporte", Math.Round(Amount,2));
            cmd.AddParameterWithValue("@pfltCargoComisionImporte", Comission);
            cmd.AddParameterWithValue("@pfltCargoIVA", ComissionTaxAmount);
            cmd.AddParameterWithValue("@pbitEfectivoDisponible", AvailableCash);
            cmd.AddParameterWithValue("@pfltCargoObservaciones", Comments);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
        }

        public bool GetContractRegularSavingsIsGrouping(string ContractId)
        {
            bool IsGrouping = false;

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_RS_GetGrouping", _cmdConn);
            cmd.AddParameterWithValue("@ContractId", ContractId);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    IsGrouping = Convert.ToBoolean(row["isGrouping"]);
                }
            }

            return IsGrouping;
        }

        public Int64 GeneratePartialWithdrawal(string ContractId, string EmisionId, long Shares, double Price, double Amount, DateTime ProcessDate, DateTime OperationDate,
                DateTime LiquidityDate, double ComissionAmount, double ComissionTaxAmount, int BankId, string BankAccountNumber, int TypeAmount, string Comments, 
                int ValidRegAcct, int NotValidateSalePos, int LiquidationType
            )
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_SIIF_ApplyFullSurrenderDeposit", _cmdConn);
            cmd.AddParameterWithValue("@ContratoId", ContractId);
            cmd.AddParameterWithValue("@TypeAmount", TypeAmount);
            cmd.AddParameterWithValue("@EmisionId", EmisionId);
            cmd.AddParameterWithValue("@Shares", Shares);
            cmd.AddParameterWithValue("@Price", Price);
            cmd.AddParameterWithValue("@Amount", Amount);
            cmd.AddParameterWithValue("@ProcessDate", ProcessDate);
            cmd.AddParameterWithValue("@OperationDate", OperationDate);
            cmd.AddParameterWithValue("@LiquidityDate", LiquidityDate);
            cmd.AddParameterWithValue("@ComissionAmount", ComissionAmount);
            cmd.AddParameterWithValue("@ComissionTaxAmount", ComissionTaxAmount);
            cmd.AddParameterWithValue("@BankId", BankId);
            cmd.AddParameterWithValue("@BankAccountNumber", BankAccountNumber);
            cmd.AddParameterWithValue("@OrdenSalida", 0);
            cmd.AddParameterWithValue("@ValidRegAcct", ValidRegAcct);
            
            cmd.AddParameterWithValue("@NotValidateSalePos", NotValidateSalePos);
            cmd.AddParameterRequiredNull("@LiquidationType", LiquidationType);
            cmd.AddParameterWithValue("@Comments", Comments);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return Convert.ToInt64(ds.Tables[0].Rows[0][0].ToString());
        }

        public void InsertDepositLog(string ContractId, string TransaccionId, string BanckId, string BankAccount, string BeneficiaryName)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertaDepositoLog", _cmdConn);
            cmd.AddParameterWithValue("@pstrContratoId", ContractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", TransaccionId);
            cmd.AddParameterWithValue("@pintBancoDepositoId", BanckId);
            cmd.AddParameterWithValue("@pstrNumCuentaDeposito", BankAccount);
            cmd.AddParameterWithValue("@pstrNombreBeneficiario", BeneficiaryName);

            _sqlClientHelper.ExecuteDataSet(cmd);
        }

        public void InsertChargeLog(string ContractId, string TransactionId, string OrderLogId, int ChargerId, double OriginalAmount,
                                    double Amount, double ComissionTaxAmount, DateTime OrderApplicationDate, string ChargerReason, string User
            )   
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertaCargoLog", _cmdConn);
            cmd.AddParameterWithValue("@pstrContratoId", ContractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", TransactionId);
            cmd.AddParameterWithValue("@pstrOrdenProgramadaId", OrderLogId);
            cmd.AddParameterWithValue("@CargoId", ChargerId);
            cmd.AddParameterWithValue("@pfltMontoOriginal", OriginalAmount);
            cmd.AddParameterWithValue("@pfltMontoCobrado", Amount);
            cmd.AddParameterWithValue("@pfltIVACobrado", Amount);
            cmd.AddParameterWithValue("@pdtmFechaCobro", OrderApplicationDate);
            cmd.AddParameterWithValue("@pstrRazonCondonacion", ChargerReason);
            cmd.AddParameterWithValue("@pstrUsuarioId", User);

            _sqlClientHelper.ExecuteDataSet(cmd);
        }

        public AuthorizationInfo GetAuthorizationToApply(string contractId, int transactionTypeId, int authorizationTypeId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_SIIF_GetAutorizacionesVigentes", _cmdConn);
            cmd.AddParameterWithValue("@contratoId", contractId);
            cmd.AddParameterWithValue("@transaccionId", transactionTypeId);
            cmd.AddParameterWithValue("@tipoAutorizacionId", authorizationTypeId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return AuthorizationInfoMapping.Map(ds);
        }

        #region "Apply FullSurrender"
        public OperationResult ApplyFullSurrenderTran(FundTransaction FundTransaction, List<InvestmentFundTransferOrder> InvestmentFundTransferOrder, string TransactionId, DateTime transactionDate,
          List<InvestmentFundOrderLog> InvestmentFundOrderLog, List<InvestmentChargeOrder> InvestmentChargeOrder, List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo)
        {
            OperationResult result = new OperationResult();
            SqlTransaction transaction;
            _cmdConn.Open();
            transaction = _cmdConn.BeginTransaction();
            try
            {
                GenerateFundTransactionSIIF(FundTransaction, transaction);
                InsertInvestmentFundTransferOrderWithTransaction(TransactionId, InvestmentFundTransferOrder, InvestmentFundOrderLog, transaction);
                InsertInvestmentChargeOrderWithTransaction(InvestmentChargeOrder, TransactionId, InvestmentFundOrderLog, transaction);
                InsertPartialCharges(FullSurrenderConnectorInfo, TransactionId, InvestmentFundOrderLog, transaction);
                transaction.Commit();
                result.Successful = true;
             
            }
            catch(Exception ex)
            {
                transaction.Rollback();
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message, MessageType = SystemMessageTypes.Error });
            }
            _cmdConn.Close();
            return result;
        }

        private SqlCommand CreateCommandWithTransaction(string commandText, SqlConnection conn, SqlTransaction transaction)
        {
            var command = new SqlCommand(commandText, _cmdConn, transaction);
            command.CommandType = CommandType.StoredProcedure;
            return command;
        }
        private void GenerateFundTransactionSIIF(FundTransaction FundTransaction, SqlTransaction sqlTransaction)
        {
            var contractId = FundTransaction.ContractId;
            var transactionId = FundTransaction.TransctionId;
            var transactionType = FundTransaction.TransactionType;
            var transactionDate = FundTransaction.transactionDate;
            var product = FundTransaction.Product;
            var userIdentifier = FundTransaction.UserIdentifier;

            var cmd = CreateCommandWithTransaction("usp_SIIFX_InsertaContratoTransaccion", _cmdConn, sqlTransaction);
            cmd.AddParameterWithValue("@pstrContratoId", contractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", transactionId);
            cmd.AddParameterWithValue("@psintTipoTransaccionId", transactionType);
            cmd.AddParameterWithValue("@pdtFechaTransaccion", transactionDate);
            cmd.AddParameterWithValue("@pstrTipoProducto", product);
            cmd.AddParameterWithValue("@pstrUsuarioId", userIdentifier);
            cmd.ExecuteNonQuery();
        }
        private void InsertInvestmentFundTransferOrderWithTransaction(string transactionId, List<InvestmentFundTransferOrder> investmentFundTransferOrder, List<InvestmentFundOrderLog> investmentFundOrderLog, SqlTransaction sqlTransaction)
        {
            int contador = 0;
            foreach (InvestmentFundTransferOrder inv in investmentFundTransferOrder)
            {
                int orderId = 0;

                string ContractId = inv.ContractId;
                int OperationType = inv.OperationType;
                int AmountType = inv.AmountType;
                string EmisionId = inv.EmisionId;
                float Shares = inv.Shares;
                float Price = inv.Price;
                float Amount = inv.Amount;
                DateTime OperationDate = inv.OperationDate;
                DateTime LiquidationDate = inv.LiquidationDate;
                float ComissionAmount = inv.ComissionAmount;
                float ComissionTaxAmount = inv.ComissionTaxAmount;
                string Comment = inv.Comment;
                int OrderChainId = inv.OrderChainId;
                int IsLastOrder = inv.IsLastOrder;
                int OrderType = inv.OrderType;
                int NotValidateSalePos = inv.NotValidateSalePos;
                int NotValidateCompromisedPos = inv.NotValidateCompromisedPos;
                var cmd = CreateCommandWithTransaction("usp_ACL_SIIF_ApplyFullSurrender", _cmdConn, sqlTransaction);
                cmd.AddParameterWithValue("@ContractId", ContractId);
                cmd.AddParameterWithValue("@OperationType", OperationType);
                cmd.AddParameterWithValue("@AmountType", AmountType);
                cmd.AddParameterWithValue("@EmisionId", EmisionId);
                cmd.AddParameterWithValue("@Shares", Shares);
                cmd.AddParameterWithValue("@Price", Math.Round(Price, 6));
                cmd.AddParameterWithValue("@Amount", Math.Round(Amount, 2));
                cmd.AddParameterWithValue("@OperationDate", OperationDate);
                cmd.AddParameterWithValue("@LiquidationDate", LiquidationDate);
                cmd.AddParameterWithValue("@ComissionAmount", ComissionAmount);
                cmd.AddParameterWithValue("@ComissionTaxAmount", ComissionTaxAmount);
                cmd.AddParameterWithValue("@Comment", Comment);
                cmd.AddParameterWithValue("@OrderChainId", OrderChainId);
                cmd.AddParameterWithValue("@IsLastOrder", IsLastOrder);
                cmd.AddParameterWithValue("@OrderType", OrderType);
                cmd.AddParameterWithValue("@NotValidateSalePos", NotValidateSalePos);
                cmd.AddParameterWithValue("@NotValidateCompromisedPos", NotValidateCompromisedPos);

                IDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        orderId += Convert.ToInt32(row[0]);
                    }
                }
                ds.Dispose();

                var _InvestmentFundOrderLog = investmentFundOrderLog[contador];
                contador++;

                _InvestmentFundOrderLog.OrderId = orderId;
                InsertInvestmentFundOrderLogWithTransaction(transactionId, _InvestmentFundOrderLog.OrderLogId.ToString(), _InvestmentFundOrderLog.OrderLogFatherId,
                                            _InvestmentFundOrderLog.OrderLogDepth, _InvestmentFundOrderLog.OrderLogLinage, _InvestmentFundOrderLog.OrderLoadDate,
                                            _InvestmentFundOrderLog.OrderApplicationDate,
                                            _InvestmentFundOrderLog.OrderLogEstatus, _InvestmentFundOrderLog.OrderLogContractId, orderId,
                                            _InvestmentFundOrderLog.OperationType, _InvestmentFundOrderLog.OrderTypeLog, _InvestmentFundOrderLog.EmisionId,
                                            _InvestmentFundOrderLog.Shares, _InvestmentFundOrderLog.Price, _InvestmentFundOrderLog.Amount, _InvestmentFundOrderLog.OperationDate,
                                            _InvestmentFundOrderLog.LiquidationDate, _InvestmentFundOrderLog.ComissionAmount, _InvestmentFundOrderLog.ComissionTaxAmount,
                                            _InvestmentFundOrderLog.Comments, _InvestmentFundOrderLog.OrdenVentaId, _InvestmentFundOrderLog.LiquidationType,
                                            _InvestmentFundOrderLog.OrderContractId, _InvestmentFundOrderLog.MarketType, sqlTransaction);
                    }
            
        }
        private int InsertInvestmentFundOrderLogWithTransaction(string TransaccionId, string OrderLogId, string OrderLogFatherId, int OrderLogDepth, string OrderLogLinage, DateTime OrderLoadDate,
                                                DateTime OrderApplicationDate, int OrderLogEstatus, string OrderLogContractId, int OrderId, int OperationType, int OrderTypeLog,
                                                string EmisionId, double Shares, double Price, double Amount, DateTime OperationDate, DateTime LiquidationDate, double ComissionAmount,
                                                double ComissionTaxAmount, string Comments, int OrdenVentaId, int LiquidationType, string OrderContractId, int MarketType, SqlTransaction sqlTransaction)
        {
            var cmd = CreateCommandWithTransaction("usp_SIIFX_InsertOrdenProgramada", _cmdConn, sqlTransaction);
            cmd.AddParameterWithValue("@pstrTransaccionId", TransaccionId);
            cmd.AddParameterWithValue("@pstrOrdenProgramadaId", OrderLogId);
            if (string.IsNullOrEmpty(OrderLogFatherId))
                cmd.AddParameterWithValue("@pstrOrdenProgramadaPadreId", DBNull.Value);
            else
                cmd.AddParameterWithValue("@pstrOrdenProgramadaPadreId", OrderLogFatherId);

            cmd.AddParameterWithValue("@pintProfundidad", OrderLogDepth);
            cmd.AddParameterWithValue("@pstrLinage", OrderLogLinage);
            cmd.AddParameterWithValue("@pdtmFechaProgramacion", OrderLoadDate);
            cmd.AddParameterWithValue("@pdtmFechaAplicacion", OrderApplicationDate);
            cmd.AddParameterWithValue("@pintOrdenProgramadaEstatus", OrderLogEstatus);
            cmd.AddParameterWithValue("@pstrContratoId", OrderLogContractId);
            cmd.AddParameterWithValue("@pintOrdenId", OrderId);
            cmd.AddParameterWithValue("@psintTipoOperacionId", OperationType);
            cmd.AddParameterWithValue("@psintTipoOrdenId", OrderTypeLog);
            cmd.AddParameterWithValue("@pstrEmisionId", EmisionId);
            cmd.AddParameterWithValue("@pintOrdenTitulos", Shares);
            cmd.AddParameterWithValue("@pfltOrdenPrecio", Price);
            cmd.AddParameterWithValue("@pfltOrdenImporte", Amount);
            cmd.AddParameterWithValue("@pdtmOrdenFechaProceso", OrderLoadDate);
            cmd.AddParameterWithValue("@pdtmOrdenFechaOperacion", OperationDate);
            cmd.AddParameterWithValue("@pdtmOrdenFechaLiquidacion", LiquidationDate);
            cmd.AddParameterWithValue("@pfltOrdenComision", ComissionAmount);
            cmd.AddParameterWithValue("@pfltOrdenIVA", ComissionTaxAmount);
            cmd.AddParameterWithValue("@pstrOrdenObservaciones", Comments);
            cmd.AddParameterWithValue("@pintOrdenVentaId", OrdenVentaId);
            cmd.AddParameterRequiredNull("@pbitTipoLiquidacion", LiquidationType);
            cmd.AddParameterWithValue("@OrdenContratoId", OrderContractId);
            cmd.AddParameterWithValue("@TipoMercadoId", MarketType);
            return cmd.ExecuteNonQuery();
        }

        private void InsertInvestmentChargeOrderWithTransaction(List<InvestmentChargeOrder> InvestmentChargeOrder, 
            string TransactionId, List<InvestmentFundOrderLog> InvestmentFundOrderLog, SqlTransaction sqlTransaction)
        {
            foreach (InvestmentChargeOrder inv in InvestmentChargeOrder)
            {
                int orderId = 0;

                string ContractId = inv.ContractId;
                int CargoId = inv.CargoId;
                float Amount = inv.Amount;
                float Comission = inv.Comission;
                float ComissionTaxAmount = inv.ComissionTaxAmount;
                string Comments = inv.Comments;
                int AvailableCash = inv.AvailableCash;
                var cmd = CreateCommandWithTransaction("usp_ACL_SIIF_InsertInvestmentChargeOrder", _cmdConn, sqlTransaction);

                cmd.AddParameterWithValue("@pstrContratoId", ContractId);
                cmd.AddParameterWithValue("@psintTipoCargoId", CargoId);
                cmd.AddParameterWithValue("@pfltCargoImporte", Math.Round(Amount, 2));
                cmd.AddParameterWithValue("@pfltCargoComisionImporte", Comission);
                cmd.AddParameterWithValue("@pfltCargoIVA", ComissionTaxAmount);
                cmd.AddParameterWithValue("@pbitEfectivoDisponible", AvailableCash);
                cmd.AddParameterWithValue("@pfltCargoObservaciones", Comments);

                IDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                orderId = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());

                InvestmentFundOrderLog _InvestmentFundOrderLog = InvestmentFundOrderLog.Where(I => I.ChargeId == inv.CargoId).FirstOrDefault();

                if (_InvestmentFundOrderLog != null)
                {
                    InsertInvestmentFundOrderLogWithTransaction(TransactionId, _InvestmentFundOrderLog.OrderLogId.ToString(), _InvestmentFundOrderLog.OrderLogFatherId,
                                            _InvestmentFundOrderLog.OrderLogDepth, _InvestmentFundOrderLog.OrderLogLinage, _InvestmentFundOrderLog.OrderLoadDate,
                                            _InvestmentFundOrderLog.OrderApplicationDate,
                                            _InvestmentFundOrderLog.OrderLogEstatus, _InvestmentFundOrderLog.OrderLogContractId, orderId,
                                            _InvestmentFundOrderLog.OperationType, _InvestmentFundOrderLog.OrderTypeLog, _InvestmentFundOrderLog.EmisionId,
                                            _InvestmentFundOrderLog.Shares, _InvestmentFundOrderLog.Price, _InvestmentFundOrderLog.Amount, _InvestmentFundOrderLog.OperationDate,
                                            _InvestmentFundOrderLog.LiquidationDate, _InvestmentFundOrderLog.ComissionAmount, _InvestmentFundOrderLog.ComissionTaxAmount,
                                            _InvestmentFundOrderLog.Comments, _InvestmentFundOrderLog.OrdenVentaId, _InvestmentFundOrderLog.LiquidationType, _InvestmentFundOrderLog.OrderContractId,
                                            _InvestmentFundOrderLog.MarketType, sqlTransaction);

                    InsertChargeLogWithTransaction(inv.ContractId, TransactionId, _InvestmentFundOrderLog.OrderLogId, inv.CargoId, inv.Amount, inv.Amount,
                        inv.ComissionTaxAmount, _InvestmentFundOrderLog.OrderApplicationDate, inv.Comments, _InvestmentFundOrderLog.User, sqlTransaction);
                }
            }
        }

        private void InsertChargeLogWithTransaction(string ContractId, string TransactionId, string OrderLogId, int ChargerId, double OriginalAmount,
                                    double Amount, double ComissionTaxAmount, DateTime OrderApplicationDate, string ChargerReason, string User, SqlTransaction sqlTransaction)
        {
            var cmd = CreateCommandWithTransaction("usp_SIIFX_InsertaCargoLog", _cmdConn, sqlTransaction);
            cmd.AddParameterWithValue("@pstrContratoId", ContractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", TransactionId);
            cmd.AddParameterWithValue("@pstrOrdenProgramadaId", OrderLogId);
            cmd.AddParameterWithValue("@pintCargoId", ChargerId);
            cmd.AddParameterWithValue("@pfltMontoOriginal", OriginalAmount);
            cmd.AddParameterWithValue("@pfltMontoCobrado", Amount);
            cmd.AddParameterWithValue("@pfltIVACobrado", Amount);
            cmd.AddParameterWithValue("@pdtmFechaCobro", OrderApplicationDate);
            cmd.AddParameterWithValue("@pstrRazonCondonacion", ChargerReason);
            cmd.AddParameterWithValue("@pstrUsuarioId", User);
            cmd.ExecuteNonQuery();
        }

        private void InsertPartialCharges(List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo, string TransactionId, List<InvestmentFundOrderLog> investmentFundOrderLog, SqlTransaction sqlTransaction)
        {
            foreach(FullSurrenderConnectorInfo info in FullSurrenderConnectorInfo)
            {
                Int64 orderId = GeneratePartialWithdrawalWithTransaction(info.ContractId, info.EmisionId, info.Shares, info.Price, info.Amount, info.ProcessDate, info.OperationDate,
                    info.LiquidityDate, info.ComissionAmount, info.ComissionTaxAmount, info.BankId, info.BankAccountNumber, info.TypeAmount,
                    info.Comments, info.ValidRegAcct, info.NotValidateSalePos, info.LiquidationType, sqlTransaction);


                InvestmentFundOrderLog _InvestmentFundOrderLog = investmentFundOrderLog.Where(I => I.EmisionId == info.EmisionId && I.Comments.Contains("FS")).FirstOrDefault();
                if (_InvestmentFundOrderLog != null)
                    InsertInvestmentFundOrderLogWithTransaction(TransactionId, _InvestmentFundOrderLog.OrderLogId.ToString(), _InvestmentFundOrderLog.OrderLogFatherId,
                                            _InvestmentFundOrderLog.OrderLogDepth, _InvestmentFundOrderLog.OrderLogLinage, _InvestmentFundOrderLog.OrderLoadDate,
                                            _InvestmentFundOrderLog.OrderApplicationDate,
                                            _InvestmentFundOrderLog.OrderLogEstatus, _InvestmentFundOrderLog.OrderLogContractId, (int)orderId,
                                            _InvestmentFundOrderLog.OperationType, _InvestmentFundOrderLog.OrderTypeLog, _InvestmentFundOrderLog.EmisionId,
                                            _InvestmentFundOrderLog.Shares, _InvestmentFundOrderLog.Price, _InvestmentFundOrderLog.Amount, _InvestmentFundOrderLog.OperationDate,
                                            _InvestmentFundOrderLog.LiquidationDate, _InvestmentFundOrderLog.ComissionAmount, _InvestmentFundOrderLog.ComissionTaxAmount,
                                            _InvestmentFundOrderLog.Comments, _InvestmentFundOrderLog.OrdenVentaId, _InvestmentFundOrderLog.LiquidationType, _InvestmentFundOrderLog.OrderContractId, 
                                            _InvestmentFundOrderLog.MarketType, sqlTransaction);
            }
            FullSurrenderConnectorInfo infoLog = FullSurrenderConnectorInfo.FirstOrDefault();
            if (infoLog != null)
                InsertDepositLogWithTransaction(infoLog.ContractId, TransactionId, infoLog.BankId.ToString(), infoLog.BankAccountNumber, "", sqlTransaction);
        }

        private Int64 GeneratePartialWithdrawalWithTransaction(string ContractId, string EmisionId, long Shares, double Price, double Amount, DateTime ProcessDate, DateTime OperationDate,
               DateTime LiquidityDate, double ComissionAmount, double ComissionTaxAmount, int BankId, string BankAccountNumber, int TypeAmount, string Comments,
               int ValidRegAcct, int NotValidateSalePos, int LiquidationType, SqlTransaction sqlTransaction)
        {
            var cmd = CreateCommandWithTransaction("usp_ACL_SIIF_ApplyFullSurrenderDeposit", _cmdConn, sqlTransaction);
            cmd.AddParameterWithValue("@ContratoId", ContractId);
            cmd.AddParameterWithValue("@TypeAmount", TypeAmount);
            cmd.AddParameterWithValue("@EmisionId", EmisionId);
            cmd.AddParameterWithValue("@Shares", Shares);
            cmd.AddParameterWithValue("@Price", Price);
            cmd.AddParameterWithValue("@Amount", Amount);
            cmd.AddParameterWithValue("@ProcessDate", ProcessDate);
            cmd.AddParameterWithValue("@OperationDate", OperationDate);
            cmd.AddParameterWithValue("@LiquidityDate", LiquidityDate);
            cmd.AddParameterWithValue("@ComissionAmount", ComissionAmount);
            cmd.AddParameterWithValue("@ComissionTaxAmount", ComissionTaxAmount);
            cmd.AddParameterWithValue("@BankId", BankId);
            cmd.AddParameterWithValue("@BankAccountNumber", BankAccountNumber);
            cmd.AddParameterWithValue("@OrdenSalida", 0);
            cmd.AddParameterWithValue("@ValidRegAcct", ValidRegAcct);
            cmd.AddParameterWithValue("@NotValidateSalePos", NotValidateSalePos);
            cmd.AddParameterRequiredNull("@LiquidationType", LiquidationType);
            cmd.AddParameterWithValue("@Comments", Comments);

            IDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            return Convert.ToInt64(ds.Tables[0].Rows[0][0].ToString());
        }

        private void InsertDepositLogWithTransaction(string ContractId, string TransaccionId, string BanckId, string BankAccount, string BeneficiaryName, SqlTransaction sqlTransaction)
        {
            var cmd = CreateCommandWithTransaction("usp_SIIFX_InsertaDepositoLog", _cmdConn, sqlTransaction);
            cmd.AddParameterWithValue("@pstrContratoId", ContractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", TransaccionId);
            cmd.AddParameterWithValue("@pintBancoDepositoId", BanckId);
            cmd.AddParameterWithValue("@pstrNumCuentaDeposito", BankAccount);
            cmd.AddParameterWithValue("@pstrNombreBeneficiario", BeneficiaryName);
            cmd.ExecuteNonQuery();
        }
        #endregion

        public string SetContractStatus(string contractId, int statusId, string user)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_Set_Contrato_Status", _cmdConn);
            cmd.AddParameterWithValue("@ContratoId", contractId);
            cmd.AddParameterWithValue("@StatusId", statusId);
            cmd.AddParameterWithValue("@User", user);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            string messageResult = string.Empty;
            
            if(ds.Tables.Count > 0)
            {
                var tableIndex = ds.Tables.Count - 1;
                messageResult = ds.Tables[tableIndex].Rows[0][0].ToString();
            }

            return messageResult;
        }
    }
}
