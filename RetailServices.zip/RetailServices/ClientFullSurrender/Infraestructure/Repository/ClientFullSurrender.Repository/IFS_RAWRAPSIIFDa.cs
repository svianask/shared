﻿using System;
using System.Collections.Generic;
using ClientFullSurrender.Domain;
using ClientFullSurrender.Domain.AuthorizationAggregate;
using ClientFullSurrender.Domain.BulkFileAggregate;
using ClientFullSurrenderDomainModel.AuthorizationAggregate;
using Common.Domain;

namespace ClientFullSurrender.Repository
{
    public interface IFS_RAWRAPSIIFDa
    {
        OperationResult ApplyFullSurrenderTran(FundTransaction FundTransaction, List<InvestmentFundTransferOrder> InvestmentFundTransferOrder, string TransactionId, DateTime transactionDate,
          List<InvestmentFundOrderLog> InvestmentFundOrderLog, List<InvestmentChargeOrder> InvestmentChargeOrder, List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo);
        DateTime GetNextLaboralDayGT(DateTime RequiredDate);
        int InsertCompoundTransaction(string contractIdentifier, string transactionIdentifier, string compoundTransactionIdentifier, int transactionType);
        int InsertProgrammedCharges(string contractIdentifier, string compoundTransactionIdentifier, Int16 chargeIdentifier, double chargeAmountOriginal, double chargeAmount, double chargeTaxOriginal, double chargeTax, string chargeDescription);
        int InsertProgrammedTransaction(string contractIdentifier, string compoundTransactionIdentifier, int transactionType, DateTime requestDate,
            DateTime applyTransactionDate, int statusTransactionId, string errorDescription, string userId,
            string contextText1, string contextText2, string contextText3, string contextText4,
            string contextText5, string contextText6, Double contextNumeric1, Double contextNumeric2,
            Double contextNumeric3, Double contextNumeric4, Double contextNumeric5, Double contextNumeric6, int liquidationType, int surrenderProcessType, string migrationDestContract);
        List<TipoTransaccionAutorizacion> GetTransactionsAuthorizations();
        BulkFileConfiguration GetBulkFileConfiguration(int processId);

        void GenerateFundTransactionSIIF(string product, int transactionType, string transctionId,
            DateTime transactionDate, string contractId, string userIdentifier);

        FullFundSaleDates GetContractFundsLiquidityDates(string fundId, DateTime dateRequest, int platform);
        void UpdateClientPortafolioType(string contractId, int clientType, int Platform);

        int InsertInvestmentFundTransferOrder(string ContractId, int OperationType, int AmountType, string EmisionId, float Shares, float Price, float Amount, DateTime OperationDate,
                                                        DateTime LiquidationDate, float ComissionAmount, float ComissionTaxAmount, string Comment, int OrderChainId, int IsLastOrder,
                                                        int OrderType, int NotValidateSalePos, int NotValidateCompromisedPos);
        int InsertInvestmentFundOrderLog(string TransaccionId, string OrderLogId, string OrderLogFatherId, int OrderLogDepth, string OrderLogLinage, DateTime OrderLoadDate,
                                               DateTime OrderApplicationDate, int OrderLogEstatus, string OrderLogContractId, int OrderId, int OperationType, int OrderTypeLog,
                                               string EmisionId, double Shares, double Price, double Amount, DateTime OperationDate, DateTime LiquidationDate, double ComissionAmount,
                                               double ComissionTaxAmount, string Comments, int OrdenVentaId, int LiquidationType, string OrderContractId, int MarketType
           );

        int InsertInvestmentChargeOrder(string ContractId, int CargoId, float Amount, float Comission, float ComissionTaxAmount, string Comments, int AvailableCash);

        bool GetContractRegularSavingsIsGrouping(string ContractId);

        Int64 GeneratePartialWithdrawal(string ContractId, string EmisionId, long Shares, double Price, double Amount, DateTime ProcessDate, DateTime OperationDate,
               DateTime LiquidityDate, double ComissionAmount, double ComissionTaxAmount, int BankId, string BankAccountNumber, int TypeAmount, string Comments,
               int ValidRegAcct, int NotValidateSalePos, int LiquidationType
           );

        void InsertDepositLog(string ContractId, string TransaccionId, string BanckId, string BankAccount, string BeneficiaryName);

        void InsertChargeLog(string ContractId, string TransactionId, string OrderLogId, int ChargerId, double OriginalAmount,
                                    double Amount, double ComissionTaxAmount, DateTime OrderApplicationDate, string ChargerReason, string User
            );

        AuthorizationInfo GetAuthorizationToApply(string contractId, int transactionTypeId, int authorizationTypeId);
        string SetContractStatus(string contractId, int statusId, string user);
    }
}
