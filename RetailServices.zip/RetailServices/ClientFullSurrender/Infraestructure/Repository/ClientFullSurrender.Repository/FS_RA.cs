﻿using SqlClient.Helper;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using Unity;
using ClientFullSurrender.Domain.AuthorizationAggregate;
using ClientFullSurrender.Mapping;
using ClientFullSurrender.Domain.BulkFileAggregate;
using ClientFullSurrender.Domain;

namespace ClientFullSurrender.Repository
{
    public class FS_RA: IFS_RA
    {
        private readonly SqlConnection _cmdConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public FS_RA([Dependency("RA")] SqlConnection cmdConn, ISqlClientHelper sqlClientHelper)
        {
            this._cmdConn = cmdConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public int SetFullSurrenderLog(string contractIdentifier, int fullSurrenderCause, string transactionId, string documents,
            DateTime paymentDate, double amount, double balance, DateTime fullSurrenderDate, string userId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_RA_SetContratoRetiroTotal", _cmdConn);

            cmd.AddParameterWithValue("@pstrContratoId", contractIdentifier);
            cmd.AddParameterWithValue("@pintCausaId", fullSurrenderCause);
            cmd.AddParameterWithValue("@pstrTransaccionId", transactionId);
            cmd.AddParameterWithValue("@pstrDocumentos", documents);
            cmd.AddParameterWithValue("@pdtmFechaPago", paymentDate);
            cmd.AddParameterWithValue("@pmnyImportePago", amount);
            cmd.AddParameterWithValue("@pmnyUltimaValuacion", balance);
            cmd.AddParameterWithValue("@pdtmFechaRetiroTotal", fullSurrenderDate);
            cmd.AddParameterWithValue("@pstrUsuarioId", userId);

            return cmd.ExecuteNonQuery();
        }
    }
}
