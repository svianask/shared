﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Repository
{
    public interface IFS_RA
    {
        int SetFullSurrenderLog(string contractIdentifier, int fullSurrenderCause, string transactionId, string documents,
            DateTime paymentDate, double amount, double balance, DateTime fullSurrenderDate, string userId);
    }
}
