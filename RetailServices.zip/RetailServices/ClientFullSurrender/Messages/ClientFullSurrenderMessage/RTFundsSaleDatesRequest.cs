﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class RTFundsSaleDatesRequest
    {
        public List<string> Funds;
        public DateTime DateRequest;
        public int Platform;
    }
}
