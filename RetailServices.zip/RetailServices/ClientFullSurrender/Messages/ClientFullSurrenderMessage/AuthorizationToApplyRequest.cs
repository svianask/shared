﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class AuthorizationToApplyRequest
    {
        public string ContractId;
        public int TransactionTypeId;
        public int AuthorizationTypeId;
    }
}
