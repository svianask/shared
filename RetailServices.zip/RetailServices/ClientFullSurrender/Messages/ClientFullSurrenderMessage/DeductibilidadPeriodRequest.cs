﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class DeductibilidadPeriodRequest
    {
        public string TypeDeductible;
        public int Period;
        public Int16 SubtipoEdad;

        public DeductibilidadPeriodRequest () {

        }
    }
}
