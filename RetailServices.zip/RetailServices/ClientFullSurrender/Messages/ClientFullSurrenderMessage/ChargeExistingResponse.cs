﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ChargeExistingResponse
    {
        public OperationResult Result;
        public bool ChargeExists;

        public ChargeExistingResponse()
        {
            Result = new OperationResult();
        }
    }
}
