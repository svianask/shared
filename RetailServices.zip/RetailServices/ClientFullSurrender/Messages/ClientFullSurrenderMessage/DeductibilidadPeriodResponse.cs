﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class DeductibilidadPeriodResponse
    {
        public double freeVSM;
        public OperationResult Result;

        public DeductibilidadPeriodResponse()
        {
            Result = new OperationResult();
        }
    }
}
