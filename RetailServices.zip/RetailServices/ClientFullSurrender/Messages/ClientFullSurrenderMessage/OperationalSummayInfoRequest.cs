﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
   public  class OperationalSummayInfoRequest
    {
        public string ContractId;
        public DateTime OpenDate;

        public OperationalSummayInfoRequest()
        {

        }
    }
}
