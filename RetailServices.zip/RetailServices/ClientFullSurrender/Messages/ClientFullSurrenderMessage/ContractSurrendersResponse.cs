﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractSurrendersResponse
    {
        public List<TransactionWithdrawal> TransactionWithdrawal;
        public OperationResult Result;

        public ContractSurrendersResponse()
        {
            TransactionWithdrawal = new List<TransactionWithdrawal>();
            Result = new OperationResult();
        }
    }
}
