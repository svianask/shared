﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class FinancialIndicatorsResponse
    {
        public OperationResult Result;
        public decimal FinancialIndicator;

        public FinancialIndicatorsResponse()
        {
            Result = new OperationResult();

        }
    }
}
