﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class NextLaboralDayGTResponse
    {
        public OperationResult Result;

        public NextLaboralDayGTResponse()
        {
            Result = new OperationResult();
        }
    }
}
