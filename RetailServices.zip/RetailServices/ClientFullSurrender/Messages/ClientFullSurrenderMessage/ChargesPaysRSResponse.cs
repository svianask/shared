﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ChargesPaysRSResponse
    {
        public OperationResult Result;
        public List<ChargeConfig> Chargers;

        public ChargesPaysRSResponse()
        {
            Result = new OperationResult();
            Chargers = new List<ChargeConfig>();

        }
    }
}
