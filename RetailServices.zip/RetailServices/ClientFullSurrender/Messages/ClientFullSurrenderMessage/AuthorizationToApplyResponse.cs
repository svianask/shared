﻿using System;
using ClientFullSurrenderDomainModel.AuthorizationAggregate;
using Common.Domain;

namespace ClientFullSurrenderMessage
{
    public class AuthorizationToApplyResponse
    {
        public AuthorizationInfo AuthorizationInfo;
        public OperationResult Result;
    }
}
