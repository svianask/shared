﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class UpdateContractStatusRequest
    {
        public string ContractId { get; set; }
        public Int16 StatusId { get; set; }
        public string User { get; set; }
    }
}
