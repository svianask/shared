﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractRegularSavingsIsGroupingRequest
    {
        public string ContractId { get; set; }
    }
}
