﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class GenerateFundTransactionRequest
    {
        public string product{ get; set;}
        public int transactionType { get; set; }
        public string transctionId { get; set; }
        public DateTime transactionDate { get; set; }
        public string contractId { get; set; } 
        public string userIdentifier { get; set; }
    }
}
