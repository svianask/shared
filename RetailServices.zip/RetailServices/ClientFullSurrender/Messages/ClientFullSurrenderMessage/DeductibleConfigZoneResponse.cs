﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class DeductibleConfigZoneResponse
    {
        public decimal DeducibleAmount;
        public OperationResult Result;

        public DeductibleConfigZoneResponse()
        {
            Result = new OperationResult();
        }
    }
}
