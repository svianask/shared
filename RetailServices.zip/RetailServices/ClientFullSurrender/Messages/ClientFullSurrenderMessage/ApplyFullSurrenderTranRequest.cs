﻿using ClientFullSurrender.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ApplyFullSurrenderTranRequest
    {
        public List<InvestmentFundTransferOrder> InvestmentFundTransferOrder { get; set; }
        public List<InvestmentFundOrderLog> InvestmentFundOrderLog { get; set; }
        public List<InvestmentChargeOrder> InvestmentChargeOrder { get; set; }
        public List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo { get; set; }
        public FundTransaction FundTransaction { get; set; }

        public string TransactionId { get; set; }
        public DateTime transactionDate { get; set; }
    }
}
