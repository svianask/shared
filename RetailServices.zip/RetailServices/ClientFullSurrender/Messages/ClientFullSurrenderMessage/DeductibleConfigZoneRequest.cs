﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class DeductibleConfigZoneRequest
    {
        public int ZoneIdentifier { get; set; }
        public DateTime CurrentDate { get; set; }
    }
}
