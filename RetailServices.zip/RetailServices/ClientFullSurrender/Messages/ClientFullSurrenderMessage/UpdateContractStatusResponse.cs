﻿using System;
using Common.Domain;

namespace ClientFullSurrenderMessage
{
    public class UpdateContractStatusResponse
    {
        public OperationResult Result { get; set; }
    }
}
