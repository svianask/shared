﻿using Common.Domain;
using System.Collections.Generic;
using ClientFullSurrender.Domain.AuthorizationAggregate;

namespace ClientFullSurrenderMessage
{
    public class TransactionsAuthorizationsResponse
    {
        public List<TipoTransaccionAutorizacion> TipoTransaccionAutorizacions { get; set; } 
        public OperationResult Result { get; set; }
    }
}
