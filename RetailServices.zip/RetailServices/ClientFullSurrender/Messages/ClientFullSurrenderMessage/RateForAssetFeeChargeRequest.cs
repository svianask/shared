﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class RateForAssetFeeChargeRequest
    {
        public int ProductId { get; set; }
        public int planId { get; set; }
        public decimal balance { get; set; }
    }
}
