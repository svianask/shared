﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractTransactionResponse
    {
        public OperationResult Result { get; set; }
        public InvestmentContractMoneyTransaction InvestmentContractMoneyTransaction { get; set; }

        public ContractTransactionResponse()
        {
            Result = new OperationResult();
        }
    }
}
