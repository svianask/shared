﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class OperationalSummayInfoResponse
    {
        public OperationalSummaryInfo OperationalSummaryInfo;
        public OperationResult Result;

        public OperationalSummayInfoResponse()
        {
            Result = new OperationResult();
        }
    }
}
