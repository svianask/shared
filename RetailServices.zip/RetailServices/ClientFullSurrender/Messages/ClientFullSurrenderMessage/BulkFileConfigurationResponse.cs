﻿using Common.Domain;
using ClientFullSurrender.Domain.BulkFileAggregate;

namespace ClientFullSurrenderMessage
{
    public class BulkFileConfigurationResponse
    {
        public OperationResult Result;
        public BulkFileConfiguration BulkFileConfig;
    }
}
