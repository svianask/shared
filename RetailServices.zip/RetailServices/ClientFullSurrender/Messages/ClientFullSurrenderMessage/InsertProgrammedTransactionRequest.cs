﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class InsertProgrammedTransactionRequest
    {
        public string contractIdentifier { get; set; }
        public string compoundTransactionIdentifier { get; set; }
        public int transactionType { get; set; }
        public DateTime requestDate { get; set; }
        public DateTime applyTransactionDate { get; set; }
        public int statusTransactionId { get; set; }
        public string errorDescription { get; set; }
        public string userId { get; set; }
        public string contextText1 { get; set; }
        public string contextText2 { get; set; }
        public string contextText3 { get; set; }
        public string contextText4 { get; set; }
        public string contextText5 { get; set; }
        public string contextText6 { get; set; }
        public Double contextNumeric1 { get; set; }
        public Double contextNumeric2 { get; set; }
        public Double contextNumeric3 { get; set; }
        public Double contextNumeric4 { get; set; }
        public Double contextNumeric5 { get; set; }
        public Double contextNumeric6 { get; set; }
        public int liquidationType { get; set; }
        public int surrenderProcessType { get; set; }
        public string migrationDestContract { get; set; }
    }
}
