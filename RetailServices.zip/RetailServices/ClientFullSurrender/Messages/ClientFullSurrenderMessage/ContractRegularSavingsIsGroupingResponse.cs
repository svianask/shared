﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractRegularSavingsIsGroupingResponse
    {
        public bool IsGrouping { get; set;}
        public OperationResult Result { get; set; }

        public ContractRegularSavingsIsGroupingResponse()
        {
            Result = new OperationResult();
        }
    }
}
