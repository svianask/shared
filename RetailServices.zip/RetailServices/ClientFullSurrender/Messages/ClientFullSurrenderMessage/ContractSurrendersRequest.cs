﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractSurrendersRequest
    {
        public string ContractId;
        public DateTime InitialDate;
        public DateTime FinalDate;
        public int Applied;
    }
}
