﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class RTFundsSaleDatesResponse
    {
        private OperationResult _operationResult;
        private List<FullFundSaleDates> _fundsLiquidityDates;

        public RTFundsSaleDatesResponse()
        {
            _operationResult = new OperationResult();
        }

        public OperationResult Result { get => _operationResult; set => _operationResult = value; }

        public List<FullFundSaleDates> FundsSaleDates { get => _fundsLiquidityDates; set => _fundsLiquidityDates = value; }
    }
}
