﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class FullSurrenderLogRequest
    {
        public string contractIdentifier { get; set; } 
        public int fullSurrenderCause { get; set; }
        public string transactionId { get; set; }
        public string documents { get; set; }
        public DateTime paymentDate { get; set; }
        public double amount { get; set; }
        public double balance { get; set; }
        public DateTime fullSurrenderDate { get; set; }
        public string userId { get; set; }
    }
}
