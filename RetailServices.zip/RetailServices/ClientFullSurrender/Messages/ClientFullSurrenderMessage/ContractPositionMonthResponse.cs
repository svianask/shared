﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractPositionMonthResponse
    {
        public OperationResult Result;
        public List<ContractPositionMonth> ContractPositionMonth;

        public ContractPositionMonthResponse()
        {
            Result = new OperationResult();
            ContractPositionMonth = new List<ContractPositionMonth>();
        }
    }
}
