﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class InsertProgrammedChargesRequest
    {
        public string contractIdentifier { get; set; } 
        public string compoundTransactionIdentifier { get; set; }
        public Int16 chargeIdentifier { get; set; }
        
        public double chargeAmountOriginal { get; set; }
        public double chargeAmount { get; set; }
        
        public double chargeTaxOriginal { get; set; }
        public double chargeTax { get; set; }
        public string chargeDescription { get; set; }
    }
}
