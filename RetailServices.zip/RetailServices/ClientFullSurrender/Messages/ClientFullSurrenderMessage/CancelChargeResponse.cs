﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class CancelChargeResponse
    {
        public OperationResult Result;
        public decimal Charge;

        public CancelChargeResponse()
        {
            Result = new OperationResult();
        }
    }
}
