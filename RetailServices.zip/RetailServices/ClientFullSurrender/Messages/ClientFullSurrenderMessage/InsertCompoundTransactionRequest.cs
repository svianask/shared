﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class InsertCompoundTransactionRequest
    {
        public string contractId { get; set; }
        public string transactionIdentifier { get; set; }
        public string compoundTransactionIdentifier { get; set; }

        public int transactionType { get; set; }
    }
}
