﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class RateForAssetFeeChargeResponse
    {
        public OperationResult Result;
        public double AssetFeeRate;

        public RateForAssetFeeChargeResponse()
        {
            Result = new OperationResult();

        }
    }
}
