﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class CancelChargeRequest
    {
        public int ContractObjectiveNumContributions { get; set; }
        public decimal ContractMonthsOnPlan { get; set; }
        public int PlanIdentifier { get; set; }
    }
}
