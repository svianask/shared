﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class FullSurrenderLogResponse
    {
        public int LogId { get; set; }
        public OperationResult Result { get; set; }

        public FullSurrenderLogResponse()
        {
            Result = new OperationResult();
        }
    }
}
