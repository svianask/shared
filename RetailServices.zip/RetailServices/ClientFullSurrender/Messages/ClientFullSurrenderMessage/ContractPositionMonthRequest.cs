﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class ContractPositionMonthRequest
    {
        public string ContractId;
        public DateTime RequiredDate;

        public ContractPositionMonthRequest()
        {

        }
    }
}
