﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrenderMessage
{
    public class UpdateClientPortafolioTypeRequest
    {
        public string contractId { get; set; }
        public int clientType { get; set; }
        public int Platform { get; set; }
    }
}
