﻿using ClientContracts.Repository;
using ClientFullSurrender.Domain;
using ClientFullSurrender.Mapping;
using ClientFullSurrender.Repository;
using ClientFullSurrender.Domain.AuthorizationAggregate;
using ClientFullSurrender.Domain.BulkFileAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using SeriLogH;
using static Common.Domain.Enumerations;
using ClientFullSurrenderDomainModel.AuthorizationAggregate;

namespace ClientFullSurrenderApplication
{
    public class ClientFullSurrenderApp : IClientFullSurrenderApp
    {
        private readonly IRAWRAPSIIFDa _iRawRapSiifDa;
        private readonly IFS_RAWRAPSIIFDa _iFS_RAWRAPSIIFDa;
        private readonly ISeriLogHelper _log;
        private readonly IFS_RA _iFS_RA;

        public ClientFullSurrenderApp(IRAWRAPSIIFDa iRawRapSiifDa, IFS_RAWRAPSIIFDa iFS_RAWRAPSIIFDa, ISeriLogHelper seriLogHelper, IFS_RA iFS_RA)
        {
            _iRawRapSiifDa = iRawRapSiifDa;
            _iFS_RAWRAPSIIFDa = iFS_RAWRAPSIIFDa;
            _log = seriLogHelper;
            _iFS_RA = iFS_RA;
        } 

        public decimal GetFullSurrenderCancellationChargeMultitros(int contractObjectiveNumContributions, decimal contractMonthsOnPlan, int planIdentifier, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            decimal value = _iRawRapSiifDa.GetFullSurrenderCancellationChargeMultitros(contractObjectiveNumContributions, contractMonthsOnPlan, planIdentifier);

            return value;
        }

        public decimal GetFullSurrenderCancellationChargePercent(int contractObjectiveNumContributions, decimal contractMonthsOnPlan, int planIdentifier, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            decimal value = _iRawRapSiifDa.GetFullSurrenderCancellationChargePercent(contractObjectiveNumContributions, contractMonthsOnPlan, planIdentifier);

            return value;
        }

        public decimal GetFinancialIndicators(DateTime requiredDate, short indicadorId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            decimal value = _iRawRapSiifDa.GetFinancialIndicators(requiredDate, indicadorId);

            return value;
        }

        public List<ChargeConfig> GetChargesPaysRS(int ProductId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            List<ChargeConfig> Chargers = new List<ChargeConfig>();

            if (ProductId == (int)Product.GlobalTrust)
                Chargers = _iRawRapSiifDa.GetChargesPaysGT(30);
            else if (ProductId == (int)Product.RegularSaving)
                Chargers = _iRawRapSiifDa.GetChargesPaysRS(30);
            
            return Chargers;
        }

        public double GetSIIFRateForAssetFeeChargeRS_GT(int ProductId, int planId, decimal balance, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            return _iRawRapSiifDa.GetSIIFRateForAssetFeeChargeRS_GT(ProductId, planId, balance);
        }

        public double GetDeducibilidadPeriod(string TypeDeductible, int Period, Int16 SubtipoEdad, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            return _iRawRapSiifDa.GetDeducibilidadPeriod(TypeDeductible, Period, SubtipoEdad);
        }

        public decimal GetDeductibleConfigZone(int zoneIdentifier, DateTime currentDate, out OperationResult result)
        {
            result = new OperationResult { Successful = true };

            return _iRawRapSiifDa.GetDeductibleConfigZone(zoneIdentifier, currentDate);
        }

        public OperationalSummaryInfo GetOperationalSummaryInfo(string contractId, DateTime openingDate, out OperationResult result)
        {
            result = new OperationResult();
            OperationalSummaryInfo OperationalSummaryInfo = null;

            try
            {
                result.Successful = true;
                DataSet Data = _iRawRapSiifDa.GetContractCashTransactions(contractId, new DateTime(1900, 1, 1), DateTime.Now.Date);

                if (Data == null)
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el contrato No existe en RA", MessageType = SystemMessageTypes.Error });
                    result.Successful = false;
                }
                else
                {
                    return OperationalSummaryInfoMapp.Mapp(Data, openingDate);
                }
            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información ampliada del contrato - GetContractExtBasicInfo - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return OperationalSummaryInfo;
        }

        public List<InvestmentFundOrderGroups> GetInvestmentFundOrderGroups(string typeProduct, bool getSubGroup, out OperationResult result)
        {
            result = new OperationResult();
            List<InvestmentFundOrderGroups> _InvestmentFundOrderGroups = null;

            try
            {
                result.Successful = true;
                _InvestmentFundOrderGroups = _iRawRapSiifDa.GetInvestmentFundOrderGroups(typeProduct, getSubGroup);

                if (_InvestmentFundOrderGroups == null)
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el contrato GetInvestmentFundOrderGroups:", MessageType = SystemMessageTypes.Error });
                    result.Successful = false;
                }                
            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información ampliada del contrato - GetContractExtBasicInfo - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return _InvestmentFundOrderGroups;
        }

        public bool GetFullSurrenderChargeExists(string ContractId, int ChargeId, out OperationResult result)
        {
            result = new OperationResult();
            bool chargeExists = false;

            try
            {
                result.Successful = true;
                chargeExists = _iRawRapSiifDa.GetFullSurrenderChargeExists(ContractId, ChargeId);

                if (chargeExists == null)
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el contrato GetFullSurrenderChargeExists:", MessageType = SystemMessageTypes.Error });
                    result.Successful = false;
                }
            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información ampliada del contrato - GetContractExtBasicInfo - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return chargeExists;
        }

        public List<ContractPositionMonth> GetContractPositionByMonth(string ContractId, DateTime RequiredDate, out OperationResult result)
        {
            result = new OperationResult();
            List<ContractPositionMonth> _ContractPositionMonths = null;

            try
            {
                result.Successful = true;
                _ContractPositionMonths = _iRawRapSiifDa.GetContractPositionByMonth(ContractId, RequiredDate);

                if (_ContractPositionMonths == null)
                {
                    result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener el contrato GetContractPositionByMonth:", MessageType = SystemMessageTypes.Error });
                    result.Successful = false;
                }
            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información ampliada del contrato - GetContractExtBasicInfo - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return _ContractPositionMonths;
        }

        public List<TransactionWithdrawal> GetContractSurrenders(string contractId, DateTime initialDate, DateTime finalDate, int applied, out OperationResult result)
        {
            result = new OperationResult();
            List<TransactionWithdrawal> Trasactions = null;

            try
            {
                result.Successful = true;
                Trasactions = _iRawRapSiifDa.GetContractSurrenders(contractId, initialDate, finalDate, applied);
            }
            catch (Exception ex)
            {
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información ampliada del contrato - GetContractSurrenders - " + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return Trasactions;
        }

        public InvestmentContractMoneyTransaction GetMasterContractAppliedTransactionInfo(string ContractId, string TransactionId)
        {
            InvestmentContractMoneyTransaction Transaction = _iRawRapSiifDa.GetContractTransaction(ContractId, TransactionId);

            if(Transaction != null)
            {
                List<InvestmentFundOrder> Orders = _iRawRapSiifDa.GetAppliedTransactionInfo(ContractId, TransactionId);

                if(Orders != null && Orders.Count > 0)
                {
                    List<InvestmentFundOrder>  OrdersFilter = Orders.Where(O =>
                    (Transaction.TransactionType == ICMoneyTransactionType.LiquidityGroupedPlan)
                    ).ToList();

                    if(OrdersFilter != null && OrdersFilter.Count > 0)
                    {
                        foreach(InvestmentFundOrder O in OrdersFilter)
                        {
                            _iRawRapSiifDa.GetAppliedTransactionInfo("", "");
                        }
                    }
                }
            }

            return Transaction;
        }

        public InvestmentContractMoneyTransaction GetContractTransaction(string ContractId, string TransactionId)
        {
            InvestmentContractMoneyTransaction Transaction = _iRawRapSiifDa.GetContractTransaction(ContractId, TransactionId);

            return Transaction;
        }

        public DateTime GetNextLaboralDayGT(DateTime RequiredDate)
        {
            return _iFS_RAWRAPSIIFDa.GetNextLaboralDayGT(RequiredDate);
        }

        public int InsertCompoundTransaction(string contractIdentifier, string transactionIdentifier, string compoundTransactionIdentifier, int transactionType)
        {
            return _iFS_RAWRAPSIIFDa.InsertCompoundTransaction(contractIdentifier, transactionIdentifier, compoundTransactionIdentifier, transactionType);
        }

        public int InsertProgrammedCharges(string contractIdentifier, string compoundTransactionIdentifier, Int16 chargeIdentifier, double chargeAmountOriginal, double chargeAmount, double chargeTaxOriginal, double chargeTax, string chargeDescription)
        {
            return _iFS_RAWRAPSIIFDa.InsertProgrammedCharges(contractIdentifier, compoundTransactionIdentifier, chargeIdentifier, chargeAmountOriginal, chargeAmount, chargeTaxOriginal, chargeTax, chargeDescription);
        }
       
        public int InsertProgrammedTransaction(string contractIdentifier, string compoundTransactionIdentifier, int transactionType, DateTime requestDate,
            DateTime applyTransactionDate, int statusTransactionId, string errorDescription, string userId,
            string contextText1, string contextText2, string contextText3, string contextText4,
            string contextText5, string contextText6, Double contextNumeric1, Double contextNumeric2,
            Double contextNumeric3, Double contextNumeric4, Double contextNumeric5, Double contextNumeric6, int liquidationType, int surrenderProcessType, string migrationDestContract)
        {
            return _iFS_RAWRAPSIIFDa.InsertProgrammedTransaction(contractIdentifier, compoundTransactionIdentifier, transactionType, requestDate,
                                                                applyTransactionDate, statusTransactionId, errorDescription, userId,
                                                                contextText1, contextText2, contextText3, contextText4,
                                                                contextText5, contextText6, contextNumeric1, contextNumeric2,
                                                                contextNumeric3, contextNumeric4, contextNumeric5, contextNumeric6, liquidationType, 
                                                                surrenderProcessType, migrationDestContract);
        }


        public List<TipoTransaccionAutorizacion> GetTransactionsAuthorizations(out OperationResult result)
        {
            result = new OperationResult();
            List<TipoTransaccionAutorizacion> transactions = new List<TipoTransaccionAutorizacion>();
            try
            {
                result.Successful = true;
                transactions = _iFS_RAWRAPSIIFDa.GetTransactionsAuthorizations();

            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al obtener el listo de autorizaciones pára retiros totales");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message, MessageType = SystemMessageTypes.Error });

            }

            return transactions;
        }

        public BulkFileConfiguration GetBulkFileConfiguration(int processId, out OperationResult result)
        {
            result = new OperationResult();
            BulkFileConfiguration bulkFileConfiguration = null;
            try
            {
                bulkFileConfiguration = _iFS_RAWRAPSIIFDa.GetBulkFileConfiguration(processId);
                result.Successful = true;
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al obtener la configuracion del archivo masivo pára retiros totales");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message, MessageType = SystemMessageTypes.Error });
            }

            return bulkFileConfiguration;
        }

        public bool GenerateFundTransactionSIIF(string product, int transactionType, string transctionId,
            DateTime transactionDate, string contractId, string userIdentifier, out OperationResult result)
        {
            result = new OperationResult();
            try
            {
                _iFS_RAWRAPSIIFDa.GenerateFundTransactionSIIF(product, transactionType, transctionId, transactionDate, contractId, userIdentifier);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al Generar FundTransaction");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message, MessageType = SystemMessageTypes.Error });
                return false;
            }
            return true;
        }

        public List<FullFundSaleDates> GetContractFundsSaleDates(List<string> Funds, DateTime dateRequest, int platform, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                List<FullFundSaleDates> fundSaleDates = new List<FullFundSaleDates>();
                foreach (string fundId in Funds)
                {
                    var fundInfo = _iFS_RAWRAPSIIFDa.GetContractFundsLiquidityDates(fundId, dateRequest, platform);
                    fundSaleDates.Add(fundInfo);
                }
                return fundSaleDates;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el listado de fechas de liquidez de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al obtener el listado de fechas de liquidez de fondos - " + ex.Message + "-" });
                return null;
            }
        }

        public void UpdateClientPortafolioType(string contractId, int clientType, int Platform, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                _iFS_RAWRAPSIIFDa.UpdateClientPortafolioType(contractId, clientType, Platform);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el listado de fechas de liquidez de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al actulizar Portafolio RS - " + ex.Message + "-" });
            }
        }

        public int SetFullSurrenderLog(string contractIdentifier, int fullSurrenderCause, string transactionId, string documents,
            DateTime paymentDate, double amount, double balance, DateTime fullSurrenderDate, string userId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                return _iFS_RA.SetFullSurrenderLog(contractIdentifier, fullSurrenderCause, transactionId, documents,
                                                    paymentDate, amount, balance, fullSurrenderDate, userId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el listado de fechas de liquidez de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al guardar Full Surrender Log- " + ex.Message + "-" });
            }
            return 0;
        }

        public int ApplyFullSurrenderTran(List<InvestmentFundTransferOrder> InvestmentFundTransferOrder, List<InvestmentFundOrderLog> InvestmentFundOrderLog,
                                     List<InvestmentChargeOrder> InvestmentChargeOrder, List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo, string TransactionId, 
                                     DateTime transactionDate, FundTransaction FundTransaction, out OperationResult result)
        {
            //Validate active transaction in context

            result = new OperationResult { Successful = true };
            try
            {
                result = _iFS_RAWRAPSIIFDa.ApplyFullSurrenderTran(FundTransaction, InvestmentFundTransferOrder, TransactionId, transactionDate, 
                    InvestmentFundOrderLog, InvestmentChargeOrder, FullSurrenderConnectorInfo);

                //InsertTransaction(FundTransaction);

                //InsertInvestmentFundTransferOrder(InvestmentFundTransferOrder, TransactionId, transactionDate, InvestmentFundOrderLog);

                //InsertInvestmentChargeOrder(InvestmentChargeOrder, TransactionId, InvestmentFundOrderLog);

                //InsertPartialCharges(FullSurrenderConnectorInfo, TransactionId, InvestmentFundOrderLog);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al procesar las ordenes.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al procesar las ordenes. - " + ex.Message + "-" });
            }

            return 0;
        }

        private void InsertTransaction(FundTransaction FundTransaction)
        {
            _iFS_RAWRAPSIIFDa.GenerateFundTransactionSIIF(FundTransaction.Product, FundTransaction.TransactionType,
                                                            FundTransaction.TransctionId, FundTransaction.transactionDate, FundTransaction.ContractId,
                                                            FundTransaction.UserIdentifier);
        }

        private void InsertPartialCharges(List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo, string TransactionId, List<InvestmentFundOrderLog> _InvestmentFundOrderLog)
        {
            foreach(FullSurrenderConnectorInfo info in FullSurrenderConnectorInfo)
            {
                long OrderId = _iFS_RAWRAPSIIFDa.GeneratePartialWithdrawal(info.ContractId, info.EmisionId, info.Shares, info.Price, info.Amount, info.ProcessDate, info.OperationDate,
                    info.LiquidityDate, info.ComissionAmount, info.ComissionTaxAmount, info.BankId, info.BankAccountNumber, info.TypeAmount,
                    info.Comments, info.ValidRegAcct, info.NotValidateSalePos, info.LiquidationType
                    );

                InvestmentFundOrderLog _InvFundOrderLog = _InvestmentFundOrderLog.Where(I => I.EmisionId == info.EmisionId && I.Comments.Contains("FS")).FirstOrDefault();

                if(_InvFundOrderLog != null)
                    InsertInvestmentFundOrderLog(TransactionId, (int)OrderId, _InvFundOrderLog);

            }
            FullSurrenderConnectorInfo infoLog = FullSurrenderConnectorInfo.FirstOrDefault();
            if (infoLog != null)
                InsertDepositLog(infoLog.ContractId, TransactionId, infoLog.BankId.ToString(), infoLog.BankAccountNumber, "");
        }

        private void  InsertLogCharge(string ContractId, string TransactionId, string OrderLogId, int ChargerId, double OriginalAmount,
                                    double Amount, double ComissionTaxAmount, DateTime OrderApplicationDate, string ChargerReason, string User)
        {

            _iFS_RAWRAPSIIFDa.InsertChargeLog(ContractId, TransactionId, OrderLogId, ChargerId, OriginalAmount,
                                    Amount, ComissionTaxAmount, OrderApplicationDate, ChargerReason, User);
        }

        public void InsertDepositLog(string ContractId, string TransaccionId, string BanckId, string BankAccount, string BeneficiaryName)
        {
            _iFS_RAWRAPSIIFDa.InsertDepositLog(ContractId, TransaccionId, BanckId, BankAccount, BeneficiaryName);
        }

        private void InsertInvestmentChargeOrder(List<InvestmentChargeOrder> InvestmentChargeOrder, string TransactionId, List<InvestmentFundOrderLog> InvestmentFundOrderLog)
        {
            foreach(InvestmentChargeOrder inv in InvestmentChargeOrder)
            {
                long OrderId = _iFS_RAWRAPSIIFDa.InsertInvestmentChargeOrder(inv.ContractId, inv.CargoId, inv.Amount, inv.Comission, inv.ComissionTaxAmount, inv.Comments, inv.AvailableCash);

                InvestmentFundOrderLog _InvFundOrderLog = InvestmentFundOrderLog.Where(I => I.ChargeId == inv.CargoId).FirstOrDefault();

                if (_InvFundOrderLog != null)
                {
                    InsertInvestmentFundOrderLog(TransactionId, (int)OrderId, _InvFundOrderLog);

                    InsertLogCharge(inv.ContractId, TransactionId, _InvFundOrderLog.OrderLogId, inv.CargoId, inv.Amount, inv.Amount,
                        inv.ComissionTaxAmount, _InvFundOrderLog.OrderApplicationDate, inv.Comments, _InvFundOrderLog.User);
                }
            }
        }

        private void InsertInvestmentFundTransferOrder(List<InvestmentFundTransferOrder> InvestmentFundTransferOrder, string TransactionId, DateTime transactionDate, List<InvestmentFundOrderLog> InvestmentFundOrderLog)
        {
            int contador = 0;
            foreach (InvestmentFundTransferOrder inv in InvestmentFundTransferOrder)
            {
                int OrderId =_iFS_RAWRAPSIIFDa.InsertInvestmentFundTransferOrder(inv.ContractId, inv.OperationType, inv.AmountType, inv.EmisionId, inv.Shares,
                    inv.Price, inv.Amount, inv.OperationDate, inv.LiquidationDate, inv.ComissionAmount, inv.ComissionTaxAmount, inv.Comment, inv.OrderChainId,
                    inv.IsLastOrder, inv.OrderType, inv.NotValidateSalePos, inv.NotValidateCompromisedPos);

                var orderLog = InvestmentFundOrderLog.Where(f => f.EmisionId == inv.EmisionId && f.Comments.Contains("VE")).FirstOrDefault();
                InsertInvestmentFundOrderLog(TransactionId, OrderId, InvestmentFundOrderLog[contador]);
                contador++;
            }
        }

        private void InsertInvestmentFundOrderLog(string transactionId, int orderId, InvestmentFundOrderLog _InvestmentFundOrderLog)
        {
            _InvestmentFundOrderLog.OrderId = orderId;

            _iFS_RAWRAPSIIFDa.InsertInvestmentFundOrderLog(transactionId, _InvestmentFundOrderLog.OrderLogId.ToString(), _InvestmentFundOrderLog.OrderLogFatherId,
                                            _InvestmentFundOrderLog.OrderLogDepth, _InvestmentFundOrderLog.OrderLogLinage, _InvestmentFundOrderLog.OrderLoadDate,
                                            _InvestmentFundOrderLog.OrderApplicationDate,
                                            _InvestmentFundOrderLog.OrderLogEstatus, _InvestmentFundOrderLog.OrderLogContractId, orderId,
                                            _InvestmentFundOrderLog.OperationType, _InvestmentFundOrderLog.OrderTypeLog, _InvestmentFundOrderLog.EmisionId,
                                            _InvestmentFundOrderLog.Shares, _InvestmentFundOrderLog.Price, _InvestmentFundOrderLog.Amount, _InvestmentFundOrderLog.OperationDate,
                                            _InvestmentFundOrderLog.LiquidationDate, _InvestmentFundOrderLog.ComissionAmount, _InvestmentFundOrderLog.ComissionTaxAmount,
                                            _InvestmentFundOrderLog.Comments, _InvestmentFundOrderLog.OrdenVentaId, _InvestmentFundOrderLog.LiquidationType, _InvestmentFundOrderLog.OrderContractId, _InvestmentFundOrderLog.MarketType
                );
        }

        public bool GetContractRegularSavingsIsGrouping(string ContractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            try
            {
               return  _iFS_RAWRAPSIIFDa.GetContractRegularSavingsIsGrouping(ContractId);
            }catch(Exception Err)
            {
                _log.Error(Err, "Error al obtener GetContractRegularSavingsIsGrouping");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al obtener GetContractRegularSavingsIsGrouping- " + Err.Message + "-" });
                return false;
            }
        }
        public AuthorizationInfo GetAuthorizationToApply(string contractId, int transactionTypeId, int authorizationTypeId, out OperationResult result)
        {
            result = new OperationResult();
            AuthorizationInfo authorizationInfo = null;
            try
            {
                authorizationInfo = _iFS_RAWRAPSIIFDa.GetAuthorizationToApply(contractId, transactionTypeId, authorizationTypeId);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ha ocurrido un error al obtener la autorización");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = String.Format("Ha ocurrido un error al obtener la autorización {0}", ex.Message), MessageType = SystemMessageTypes.Error });
            }
            return authorizationInfo;
        }

        public OperationResult SetContractStatus(string contractId, Int16 statusId, string user)
        {
            OperationResult result = new OperationResult() { Successful = true };                ;
            try
            {
                string messageResult = _iFS_RAWRAPSIIFDa.SetContractStatus(contractId, statusId, user);
                if(messageResult.ToUpper().Contains("ERROR"))
                {
                    result.SystemMessages.Add(new SystemMessage { Message = messageResult, MessageType = SystemMessageTypes.Error });
                    result.Successful = false;
                }
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Ha ocurrido un error al actualizar el status del contrato.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = String.Format("Error al actualizar el status del contrato - {0}", ex.Message), MessageType = SystemMessageTypes.Error });
            }

            return result;
        }
    }
}
