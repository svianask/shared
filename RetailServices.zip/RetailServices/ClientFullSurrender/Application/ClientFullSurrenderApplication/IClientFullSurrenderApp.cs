﻿using ClientFullSurrender.Domain;
using Common.Domain;
using System;
using System.Collections.Generic;
using ClientFullSurrender.Domain.AuthorizationAggregate;
using ClientFullSurrender.Domain.BulkFileAggregate;
using ClientFullSurrenderDomainModel.AuthorizationAggregate;

namespace ClientFullSurrenderApplication
{
    public interface IClientFullSurrenderApp
    {
        decimal GetFullSurrenderCancellationChargeMultitros(int contractObjectiveNumContributions, decimal contractMonthsOnPlan, int planIdentifier, out OperationResult result);
        decimal GetFullSurrenderCancellationChargePercent(int contractObjectiveNumContributions, decimal contractMonthsOnPlan, int planIdentifier, out OperationResult result);
        decimal GetFinancialIndicators(DateTime requiredDate, short indicadorId, out OperationResult result);
        List<ChargeConfig> GetChargesPaysRS(int ProductId, out OperationResult result);
        double GetSIIFRateForAssetFeeChargeRS_GT(int ProductId, int planId, decimal balance, out OperationResult result);

        double GetDeducibilidadPeriod(string TypeDeductible, int Period, Int16 SubtipoEdad, out OperationResult result);
        decimal GetDeductibleConfigZone(int zoneIdentifier, DateTime currentDate, out OperationResult result);

        OperationalSummaryInfo GetOperationalSummaryInfo(string contractId, DateTime openingDate, out OperationResult result);
        List<InvestmentFundOrderGroups> GetInvestmentFundOrderGroups(string typeProduct, bool getSubGroup, out OperationResult result);
        bool GetFullSurrenderChargeExists(string ContractId, int ChargeId, out OperationResult result);
        List<ContractPositionMonth> GetContractPositionByMonth(string ContractId, DateTime RequiredDate, out OperationResult result);
        List<TransactionWithdrawal> GetContractSurrenders(string contractId, DateTime initialDate, DateTime finalDate, int applied, out OperationResult result);

        InvestmentContractMoneyTransaction GetMasterContractAppliedTransactionInfo(string ContractId, string TransactionId);
        InvestmentContractMoneyTransaction GetContractTransaction(string ContractId, string TransactionId);

        DateTime GetNextLaboralDayGT(DateTime RequiredDate);
        int InsertCompoundTransaction(string contractIdentifier, string transactionIdentifier, string compoundTransactionIdentifier, int transactionType);
        int InsertProgrammedCharges(string contractIdentifier, string compoundTransactionIdentifier, Int16 chargeIdentifier, double chargeAmountOriginal, double chargeAmount, double chargeTaxOriginal, double chargeTax, string chargeDescription);
        int InsertProgrammedTransaction(string contractIdentifier, string compoundTransactionIdentifier, int transactionType, DateTime requestDate,
            DateTime applyTransactionDate, int statusTransactionId, string errorDescription, string userId,
            string contextText1, string contextText2, string contextText3, string contextText4,
            string contextText5, string contextText6, Double contextNumeric1, Double contextNumeric2,
            Double contextNumeric3, Double contextNumeric4, Double contextNumeric5, Double contextNumeric6, int liquidationType, int surrenderProcessType, string migrationDestContract);

        List<TipoTransaccionAutorizacion> GetTransactionsAuthorizations(out OperationResult result);
        BulkFileConfiguration GetBulkFileConfiguration(int processId, out OperationResult result);

        bool GenerateFundTransactionSIIF(string product, int transactionType, string transctionId,
            DateTime transactionDate, string contractId, string userIdentifier, out OperationResult result);

        List<FullFundSaleDates> GetContractFundsSaleDates(List<string> Funds, DateTime dateRequest, int platform, out OperationResult result);
        void UpdateClientPortafolioType(string contractId, int clientType, int Platform, out OperationResult result);

        int SetFullSurrenderLog(string contractIdentifier, int fullSurrenderCause, string transactionId, string documents,
            DateTime paymentDate, double amount, double balance, DateTime fullSurrenderDate, string userId, out OperationResult result);

        int ApplyFullSurrenderTran(List<InvestmentFundTransferOrder> InvestmentFundTransferOrder, List<InvestmentFundOrderLog> InvestmentFundOrderLog,
                                     List<InvestmentChargeOrder> InvestmentChargeOrder, List<FullSurrenderConnectorInfo> FullSurrenderConnectorInfo, 
                                     string TransactionId, DateTime transactionDate, FundTransaction FundTransaction, out OperationResult result);

        bool GetContractRegularSavingsIsGrouping(string ContractId, out OperationResult result);

        void InsertDepositLog(string ContractId, string TransaccionId, string BanckId, string BankAccount, string BeneficiaryName);

        AuthorizationInfo GetAuthorizationToApply(string contractId, int transactionTypeId, int authorizationTypeId, out OperationResult result);
        OperationResult SetContractStatus(string contractId, Int16 statusId, string user);
    }
}
