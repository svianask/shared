﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class ContractPositionMonth
    {
        private string _ContractId;
        private DateTime _Date;
        private double _Position;

        public ContractPositionMonth(string ContractId, DateTime Date, double Position)
        {
            _ContractId = ContractId;
            _Date = Date;
            _Position = Position;
        }

        public static ContractPositionMonth Create(string ContractId, DateTime Date, double Position)
        {
            return new ContractPositionMonth(ContractId, Date, Position);
        }

        public string ContractId => _ContractId;
        public DateTime Date => _Date;
        public double Position => _Position;
    }
}
