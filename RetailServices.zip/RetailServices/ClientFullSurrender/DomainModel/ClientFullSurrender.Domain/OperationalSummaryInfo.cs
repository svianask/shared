﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class OperationalSummaryInfo
    {
        private decimal _ContractExactYears;
        private int monthsOnPlan;
        private DateTime _BeginDate;

        public OperationalSummaryInfo(decimal ContractExactYears, int MonthsOnPlan)
        {
            _ContractExactYears = ContractExactYears;
            monthsOnPlan = MonthsOnPlan;
        }

        public static OperationalSummaryInfo Create(decimal ContractExactYears, int MonthsOnPla)
        {
            return new OperationalSummaryInfo(ContractExactYears, MonthsOnPla);
        }

        public OperationalSummaryInfo AddBeginDate(DateTime BeginDate)
        {
            this._BeginDate = BeginDate;
            return this;
        }

        public decimal ContractExactYears => _ContractExactYears;
        public int MonthsOnPlan => monthsOnPlan;
        public DateTime BeginDate => _BeginDate;

    }
}
