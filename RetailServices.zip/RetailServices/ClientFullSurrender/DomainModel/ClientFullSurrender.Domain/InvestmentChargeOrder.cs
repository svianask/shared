﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class InvestmentChargeOrder
    {
        public string ContractId { get; set; }
        public int CargoId { get; set; }
        public float Amount { get; set; }
        public float Comission { get; set; }
        public float ComissionTaxAmount { get; set; }
        public string Comments { get; set; }
        public int AvailableCash { get; set; }
    }
}
