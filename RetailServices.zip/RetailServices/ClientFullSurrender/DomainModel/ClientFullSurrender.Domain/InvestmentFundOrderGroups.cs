﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class InvestmentFundOrderGroups
    {
        private string sourceBaseDate;
        private string typeMerchanId;
        private string typeOperationId;
        private string typeOrderId;
        private DateTime orderSetlemenDate;

        public InvestmentFundOrderGroups(string SourceBaseDate, string TypeMerchanId, string TypeOperationId, string TypeOrderId, DateTime OrderSeletmenDate)
        {
            sourceBaseDate = SourceBaseDate;
            typeMerchanId = TypeMerchanId;
            typeOperationId = TypeOperationId;
            typeOrderId = TypeOrderId;
            orderSetlemenDate = OrderSeletmenDate;
        }

        public static InvestmentFundOrderGroups Create(string SourceBaseDate, string TypeMerchanId, string TypeOperationId, string TypeOrderId, DateTime OrderSeletmenDate)
        {
            return new InvestmentFundOrderGroups(SourceBaseDate, TypeMerchanId, TypeOperationId, TypeOrderId, OrderSeletmenDate);
        }

        public string SourceBaseDate => sourceBaseDate;
        public string TypeMerchanId => typeMerchanId;
        public string TypeOperationId => typeOperationId;
        public string TypeOrderId => typeOrderId;
        public DateTime OrderSeletmenDate => orderSetlemenDate;
    }
}
