﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class FullFundSaleDates
    {
        private DateTime _saleLiquidityDate;
        private DateTime _saleOperationDate;
        private string _FundId;
        private bool _IsLiquidSale;
        private double _Valuation;
        private double _OperatorCommisionSale;

        private FullFundSaleDates(string fundId)
        {
            _FundId = fundId;
        }

        public DateTime SaleLiquidityDate => _saleLiquidityDate;
        public DateTime SaleOperationDate => _saleOperationDate;
        public string FundId => _FundId;
        public bool IsLiquidSale => _IsLiquidSale;
        public double Valuation => _Valuation;
        public double OperatorCommisionSale => _OperatorCommisionSale;

        public static FullFundSaleDates Create(string fundId)
        {
            return new FullFundSaleDates(fundId);
        }

        public FullFundSaleDates SetSaleLiquidityDate(DateTime saleLiquidityDate)
        {
            this._saleLiquidityDate = saleLiquidityDate;
            return this;
        }

        public FullFundSaleDates SetSaleOperationDate(DateTime saleOperationDate)
        {
            this._saleOperationDate = saleOperationDate;
            return this;
        }

        public FullFundSaleDates SetIsLiquidSale(bool IsLiquidSale)
        {
            this._IsLiquidSale = IsLiquidSale;
            return this;
        }

        public FullFundSaleDates SetValuation(double Valuation)
        {
            this._Valuation = Valuation;
            return this;
        }

        public FullFundSaleDates SetOperatorCommisionSale(double OperatorCommisionSale)
        {
            this._OperatorCommisionSale = OperatorCommisionSale;
            return this;
        }
    }
}
