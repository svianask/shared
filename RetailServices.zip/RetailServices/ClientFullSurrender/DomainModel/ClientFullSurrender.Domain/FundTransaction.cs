﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class FundTransaction
    {
        public string Product { get; set; }
        public int TransactionType { get; set; }
        public string TransctionId { get; set; }
        public DateTime transactionDate { get; set; }
        public string ContractId { get; set; }
        public string UserIdentifier { get; set; }
    }
}
