﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class ChargeConfig
    {
        private int _ChargerId;
        private string _Name;

        public ChargeConfig(int ChargerId, string Name)
        {
            _ChargerId = ChargerId;
            _Name = Name;
        }

        public int ChargerId => _ChargerId;
        public string Name =>  _Name;

        public static ChargeConfig Create(int ChargerId, string Name)
        {
            return new ChargeConfig(ChargerId, Name);
        }
    }
}
