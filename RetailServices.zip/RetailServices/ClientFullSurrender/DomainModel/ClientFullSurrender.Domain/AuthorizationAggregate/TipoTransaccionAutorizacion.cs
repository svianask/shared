﻿using System;
using System.Collections.Generic;
using Ddd;

namespace ClientFullSurrender.Domain.AuthorizationAggregate
{
    public class TipoTransaccionAutorizacion : ValueObject<TipoTransaccionAutorizacion>
    {

        private int _tipo_Transaccion_Id;
        private string _tipo_Transaccion_Dsc;
        private int _tipo_Autorizacion_Id;
        private string _tipo_Autorizacion_Dsc;
        private bool _monto_Requerido;


        private TipoTransaccionAutorizacion(int tipo_Transaccion_Id, string tipo_Transaccion_Dsc, int tipo_Autorizacion_Id, string tipo_Autorizacion_Dsc, bool monto_Requerido)
        {
            _tipo_Transaccion_Id = tipo_Transaccion_Id;
            _tipo_Transaccion_Dsc = tipo_Transaccion_Dsc;
            _tipo_Autorizacion_Id = tipo_Autorizacion_Id;
            _tipo_Autorizacion_Dsc = tipo_Autorizacion_Dsc;
            _monto_Requerido = monto_Requerido;
        }

        public int Tipo_Transaccion_Id => _tipo_Transaccion_Id;
        public string Tipo_Transaccion_Dsc => _tipo_Transaccion_Dsc;
        public int Tipo_Autorizacion_Id => _tipo_Autorizacion_Id;
        public string Tipo_Autorizacion_Dsc => _tipo_Autorizacion_Dsc;
        public bool Monto_Requerido => _monto_Requerido;

        public static TipoTransaccionAutorizacion Create(int tipo_Transaccion_Id, string tipo_Transaccion_Dsc, int tipo_Autorizacion_Id, string tipo_Autorizacion_Dsc, bool monto_Requerido)
        {
            return new TipoTransaccionAutorizacion(tipo_Transaccion_Id, tipo_Transaccion_Dsc, tipo_Autorizacion_Id, tipo_Autorizacion_Dsc, monto_Requerido);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
