﻿using System;
using Ddd;


namespace ClientFullSurrenderDomainModel.AuthorizationAggregate
{
    public class AuthorizationInfo : Entity<String>
    {
        private int _authorizationId;
        private DateTime _applicationDate;
        private string _user;
        private decimal _amount;

        private AuthorizationInfo(string contractId, int authorizationId, DateTime applicationDate, string user, decimal amount)
        {
            Id = contractId;
            _authorizationId = authorizationId;
            _applicationDate = applicationDate;
            _user = user;
            _amount = amount;
        }

        public static AuthorizationInfo Create(string contractId, int authorizationId, DateTime applicationDate, string user, decimal amount)
        {
            return new AuthorizationInfo(contractId, authorizationId, applicationDate, user, amount);
        }

        public int AuthorizationId => _authorizationId;
        public DateTime ApplicationDate => _applicationDate;
        public string User => _user;
        public decimal Amount => _amount;
    }
}
