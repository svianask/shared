﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.Domain.Enumerations;

namespace ClientFullSurrender.Domain
{
    public class InvestmentFundOrder
    {
        private int _orderType;
        private InvestmentFundSubOrderType _orderSubType;
        private string _contractIdentifier;
        private int _investmentFund;
        private DateTime _tradingDates;
        private double _price;
        private decimal _shares;
        private double _amount;
        private int _amountType;
        private int _orderFee;
        private string _contextInfoStr1;
        private string _contextInfoStr2;
        private string _contextInfoStr3;
        private string _contextInfoStr4;
        private string _contextInfoStr5;
        private string _contextInfoStr6;
        private string _contextInfoStr7;

        private int _Linage;

        private string _ContractId;
        private string _TransactionContract;

        public InvestmentFundOrder(int OrderType, InvestmentFundSubOrderType OrderSubType, int Linage)
        {
            _orderType = OrderType;
            _orderSubType = OrderSubType;
            _Linage = Linage;
        }

        public static InvestmentFundOrder Create(int OrderType, InvestmentFundSubOrderType OrderSubType, int Linage)
        {
            return new InvestmentFundOrder(OrderType, OrderSubType, Linage);
        }

        public InvestmentFundOrder AddAditional(string ContractId, string TransactionContract)
        {
            this._ContractId = ContractId;
            this._TransactionContract = TransactionContract;
            return this;
        }

        public int OrderType => _orderType;
        public InvestmentFundSubOrderType OrderSubType => _orderSubType;
        public string ContractIdentifier => _contractIdentifier;
        public int InvestmentFund => _investmentFund;
        public DateTime TradingDates => _tradingDates;
        public double Price => _price;
        public decimal Shares => _shares;
        public double Amount => _amount;
        public int AmountType => _amountType;
        public int OrderFee => _orderFee;
        public string ContextInfoStr1 => _contextInfoStr1;
        public string ContextInfoStr2 => _contextInfoStr2;
        public string ContextInfoStr3 => _contextInfoStr3;
        public string ContextInfoStr4 => _contextInfoStr4;
        public string ContextInfoStr5 => _contextInfoStr5;
        public string ContextInfoStr6 => _contextInfoStr6;
        public string ContextInfoStr7 => _contextInfoStr7;
        public int Linaje => _Linage;

        public string ContractId => _ContractId;
        public string TransactionContract => _TransactionContract;
    }
}
