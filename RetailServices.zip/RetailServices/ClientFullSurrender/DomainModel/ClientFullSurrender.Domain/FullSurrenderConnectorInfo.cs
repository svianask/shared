﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class FullSurrenderConnectorInfo
    {
        public string ContractId { get; set; }
        public string EmisionId { get; set; }
        public Int64 Shares { get; set; }
        public double Price { get; set; }
        public double Amount { get; set; }
        public DateTime ProcessDate { get; set; }
        public DateTime OperationDate { get; set; }
        public DateTime LiquidityDate { get; set; }
        public Double ComissionAmount { get; set; }
        public double ComissionTaxAmount { get; set; }
        public int BankId { get; set; }
        public string BankAccountNumber { get; set; }
        public int TypeAmount { get; set; }
        public string Comments { get; set; }

        public int ValidRegAcct { get; set; }
        public int NotValidateSalePos { get; set; }
        public int LiquidationType {
            get; set;
        }
    }
}
