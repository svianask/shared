﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class InvestmentFundOrderLog
    {
        public string TransaccionId{ get; set; }
        public string OrderLogId { get; set; }
        public string OrderLogFatherId { get; set; }
        public int OrderLogDepth { get; set; }
        public string OrderLogLinage { get; set; }
        public DateTime OrderLoadDate { get; set; }
        public DateTime OrderApplicationDate { get; set; }
        public int OrderLogEstatus { get; set; }
        public string OrderLogContractId { get; set; }
        public int OrderId { get; set; }
        public int OperationType { get; set; }
        public int OrderTypeLog { get; set; }
        public string EmisionId { get; set; }
        public double Shares { get; set; }
        public double Price { get; set; }
        public double Amount { get; set; }
        public DateTime OperationDate { get; set; }
        public DateTime LiquidationDate { get; set; }
        public double ComissionAmount { get; set; }
        public double ComissionTaxAmount { get; set; }
        public string Comments { get; set; }
        public int OrdenVentaId { get; set; }
        public int LiquidationType { get; set; }
        public string OrderContractId { get; set; }
        public int MarketType { get; set; }

        public int ChargeId { get; set; }
        public string User { get; set; }
    }
}
