﻿using Ddd;

namespace ClientFullSurrender.Domain.BulkFileAggregate
{
    public class BulkFileConfiguration : Entity<int>
    {
        private readonly string _inputPath;
        private readonly string _outputPath;
        private readonly string _backupPath;
        private string _user;
        private string _domain;
        private string _pwd;

        public BulkFileConfiguration(string inputPath, string outputPath, string backupPath)
        {
            _inputPath = inputPath;
            _outputPath = outputPath;
            _backupPath = backupPath;
        }

        public static BulkFileConfiguration Create(string inputPath, string outputPath, string backupPath)
        {
            return new BulkFileConfiguration(inputPath, outputPath, backupPath);
        }

        public void SetCredentials(string user, string domain, string pwd)
        {
            _user = user;
            _domain = domain;
            _pwd = pwd;
        }

        public string InputPath => _inputPath;
        public string OutputPath => _outputPath;
        public string BackupPath => _backupPath;
        public string User => _user;
        public string Domain => _domain;
        public string Password => _pwd;
    }
}
