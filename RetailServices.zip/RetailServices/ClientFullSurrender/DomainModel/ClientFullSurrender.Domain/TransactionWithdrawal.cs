﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class TransactionWithdrawal
    {
        private string _TransSign;
        private DateTime _TransDate;
        private decimal _TotalOrder;

        public TransactionWithdrawal(string TransSign, DateTime TransDate, decimal TotalOrder)
        {
            _TransSign = TransSign;
            _TransDate = TransDate;
            _TotalOrder = TotalOrder;
        }

        public static TransactionWithdrawal Create(string TransSign, DateTime TransDate, decimal TotalOrder)
        {
            return new TransactionWithdrawal(TransSign, TransDate, TotalOrder);
        }

        public string TransSign => _TransSign;
        public DateTime TransDate => _TransDate;
        public decimal TotalOrder => _TotalOrder;
    }
}
