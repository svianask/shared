﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class InvestmentFundTransferOrder
    {
        public string ContractId { get; set; }
        public int OperationType { get; set; }
        public int AmountType { get; set; }
        public string EmisionId { get; set; }
        public float Shares { get; set; }
        public float Price { get; set; }
        public float Amount { get; set; }
        public DateTime OperationDate { get; set; }
        public DateTime LiquidationDate { get; set; }
        public float ComissionAmount { get; set; }
        public float ComissionTaxAmount { get; set; }
        public string Comment { get; set; }
        public int OrderChainId { get; set; }
        public int IsLastOrder { get; set; }
        public int OrderType { get; set; }
        public int NotValidateSalePos { get; set; }
        public int NotValidateCompromisedPos { get; set; }
        public int OrderLogEstatus{get;set;}
    }
}
