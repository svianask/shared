﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFullSurrender.Domain
{
    public class InvestmentFundTrading
    {
        private int _anticipationDaysSale;
        private bool _countAnticipationDaysSaleLabor;
        private int _anticipationDaysBuy;
        private bool _countAnticipationDaysBuyLabor;
        private int _liquidationDaysSale;
        private bool _countLiquidationDaysSaleLabor;
        private int _liquidationDaysBuy;
        private bool _countLiquidationDaysBuyLabor;
        private double _operatorCommisionSale;
        private double _operatorCommisionBuy;
        private double _operatorCommisionSaleTax;
        private double _operatorCommisionBuyTax;
        private bool _buyAnticipateLiquidation;
        private bool _isLiquidBuy;
        private bool _isLiquidSale;
        private DateTime _lastSobSubDate;
        private bool _isFundOfFund;


        public int AnticipationDaysSale => _anticipationDaysSale;
        public bool CountAnticipationDaysSaleLabor =>_countAnticipationDaysSaleLabor;
        public int AnticipationDaysBuy => _anticipationDaysBuy;
        public bool CountAnticipationDaysBuyLabor => _countAnticipationDaysBuyLabor;
        public int LiquidationDaysSale => _liquidationDaysSale;
        public bool CountLiquidationDaysSaleLabor => _countLiquidationDaysSaleLabor;
        public int LiquidationDaysBuy => _liquidationDaysBuy;
        public bool CountLiquidationDaysBuyLabor => _countLiquidationDaysBuyLabor;
        public double OperatorCommisionSale => _operatorCommisionSale;
        public double OperatorCommisionBuy => _operatorCommisionBuy;
        public double OperatorCommisionSaleTax => _operatorCommisionSaleTax;
        public double OperatorCommisionBuyTax => _operatorCommisionBuyTax;
        public bool BuyAnticipateLiquidation => _buyAnticipateLiquidation;
        public bool IsLiquidBuy => _isLiquidBuy;
        public bool IsLiquidSale => _isLiquidSale;
        public DateTime LastSobSubDate => _lastSobSubDate;
        public bool IsFundOfFund => _isFundOfFund;
    }
}
