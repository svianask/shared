﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.Domain.Enumerations;

namespace ClientFullSurrender.Domain
{
    public class InvestmentContractMoneyTransaction
    {
        private string _transactionId;
        private ICMoneyTransactionType _transactionType;
       // private InvestmentContract _investmentContract;
        private List<List<InvestmentFundOrder>> _investmentFundOrders;
        private DateTime _transactionDate;
        private string _user;

        public InvestmentContractMoneyTransaction(string TransactionId, ICMoneyTransactionType TransactionType, DateTime TransactionDate, string User)
        {
            _transactionId = TransactionId;
            _transactionType = TransactionType;
            _transactionDate = TransactionDate;
            _user = User;
        }

        public static InvestmentContractMoneyTransaction Create(string TransactionId, ICMoneyTransactionType TransactionType, DateTime TransactionDate, string User)
        {
            return new InvestmentContractMoneyTransaction(TransactionId, TransactionType, TransactionDate, User);
        }

        public InvestmentContractMoneyTransaction AddInvestmentFundOrders(List<List<InvestmentFundOrder>> InvestmentFundOrders)
        {
            this._investmentFundOrders = InvestmentFundOrders;
            return this;
        }

        public string TransactionId => _transactionId;
        public ICMoneyTransactionType TransactionType => _transactionType;
        //public InvestmentContract InvestmentContract =>_investmentContract;
        public List<List<InvestmentFundOrder>> InvestmentFundOrders => _investmentFundOrders;
        public DateTime TransactionDate => _transactionDate;
        public string User => _user;
    }
}
