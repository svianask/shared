﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Utilities.Application
{
    public class Transform : ITransform
    {
        public string ObjectToXml<T>(T objectToTransform)
        {
            StringBuilder xmlString = new StringBuilder();
            string strType = string.Empty;
            string strFullXml = string.Empty;
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            XmlSerializer xmlSer = new XmlSerializer(typeof(T));
            using (StringWriter sww = new StringWriter())
            using (XmlWriter writer = XmlWriter.Create(sww))
            {
                xmlSer.Serialize(writer, objectToTransform, emptyNamepsaces);

                strFullXml = sww.ToString();
                strType = typeof(T).Name;
                xmlString.Append(strFullXml); // Your XML
            }

            return xmlString.ToString();
        }
    }
}
