﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities.Application
{
    public static partial class DateTimeExtensions
    {
        public static int ComparableDate(this DateTime dt)
        {

            return int.Parse(dt.Year.ToString("0000").Trim() + dt.Month.ToString("00").Trim() + dt.Day.ToString("00").Trim());

        }
    }
}
