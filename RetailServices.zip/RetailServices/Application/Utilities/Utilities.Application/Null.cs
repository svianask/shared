﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Utilities.Application
{
    public class Null
    {
        public Null()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // define application encoded null values 
        public static SByte NullByte
        {
            get { return -1; }
        }

        public static int NullInteger
        {
            get { return -1; }
        }

        public static Single NullSingle
        {
            get { return Single.MinValue; }
        }

        public static Double NullDouble
        {
            get { return Double.MinValue; }
        }

        public static Decimal NullDecimal
        {
            get { return Decimal.MinValue; }
        }

        public static DateTime NullDate
        {
            get { return DateTime.MinValue; }
        }

        public static String NullString
        {
            get { return ""; }
        }

        public static Boolean NullBoolean
        {
            get { return false; }
        }

        public static Guid NullGuid
        {
            get { return Guid.Empty; }
        }

        // sets a field to an application encoded null value ( used in BLL layer )
        public static Object SetNull(Object objValue, Object objField)
        {
            if (objValue == DBNull.Value)
            {
                if (objField.GetType() == typeof(Byte))
                {
                    return NullByte;
                }
                else if (objField.GetType() == typeof(int))
                {
                    return NullInteger;
                }
                else if (objField.GetType() == typeof(Single))
                {
                    return NullSingle;
                }
                else if (objField.GetType() == typeof(Double))
                {
                    return NullDouble;
                }
                else if (objField.GetType() == typeof(Decimal))
                    return NullDecimal;
                else if (objField.GetType() == typeof(DateTime))
                {
                    return NullDate;
                }
                else if (objField.GetType() == typeof(String))
                {
                    return NullString;
                }
                else if (objField.GetType() == typeof(Boolean))
                {
                    return NullBoolean;
                }
                else if (objField.GetType() == typeof(Guid))
                {
                    return NullGuid;
                }
                else // complex object
                    return null;
            }
            else    // return value
                return objValue;
        }

        // sets a field to an application encoded null value ( used in BLL layer )
        public static Object SetNull(PropertyInfo objPropertyInfo)
        {
            switch (objPropertyInfo.PropertyType.ToString())
            {
                case "System.Int16":
                    return NullByte;
                case "System.Int32":
                case "System.Int64":
                    return NullInteger;
                case "System.Single":
                    return NullSingle;
                case "System.Double":
                    return NullDouble;
                case "System.Decimal":
                    return NullDecimal;
                case "System.DateTime":
                    return NullDate;
                case "System.String":
                case "System.Char":
                    return NullString;
                case "System.Boolean":
                    return NullBoolean;
                case "System.Guid":
                    return NullGuid;
                default:
                    // Enumerations default to the first entry
                    Type pType = objPropertyInfo.PropertyType;
                    if (pType.BaseType.Equals(typeof(System.Enum)))
                    {
                        System.Array objEnumValues = System.Enum.GetValues(pType);
                        Array.Sort(objEnumValues);
                        return System.Enum.ToObject(pType, objEnumValues.GetValue(0));
                    }
                    else // complex object
                        return null;
            }
        }

        // convert an application encoded null value to a database null value ( used in DAL )
        public static Object GetNull(Object objField, Object objDBNull)
        {
            if (objField == null)
                return objDBNull;
            else if (objField.GetType() == typeof(Byte))
                if (Convert.ToInt16(objField) == NullByte)
                    return objDBNull;
                else if (objField.GetType() == typeof(int))
                    if (Convert.ToInt32(objField) == NullInteger)
                        return objDBNull;
                    else if (objField.GetType() == typeof(Single))
                        if (Convert.ToSingle(objField) == NullSingle)
                            return objDBNull;
                        else if (objField.GetType() == typeof(Double))
                            if (Convert.ToDouble(objField) == NullDouble)
                                return objDBNull;
                            else if (objField.GetType() == typeof(Decimal))
                                if (Convert.ToDecimal(objField) == NullDecimal)
                                    return objDBNull;
                                else if (objField.GetType() == typeof(DateTime))
                                    // compare the Date part of the DateTime with the DatePart of the NullDate ( this avoids subtle time differences )
                                    if (Convert.ToDateTime(objField).Date == NullDate.Date)
                                        return objDBNull;
                                    else if (objField.GetType() == typeof(String))
                                        if (objField == null)
                                            return objDBNull;
                                        else
                                            if (objField.ToString() == NullString)
                                            return objDBNull;
                                        else if (objField.GetType() == typeof(Boolean))
                                            if (Convert.ToBoolean(objField) == NullBoolean)
                                                return objDBNull;
                                            else if (objField.GetType() == typeof(Guid))
                                                if (((System.Guid)objField).Equals(NullGuid))
                                                    return objDBNull;

            return objField;
        }

        // checks if a field contains an application encoded null value
        public static Boolean IsNull(Object objField)
        {
            if (!(objField == null))
            {
                if (objField.GetType() == typeof(int))
                    return objField.Equals(NullInteger);
                else if (objField.GetType() == typeof(Single))
                    return objField.Equals(NullSingle);
                else if (objField.GetType() == typeof(Double))
                    return objField.Equals(NullDouble);
                else if (objField.GetType() == typeof(Decimal))
                    return objField.Equals(NullDecimal);
                else if (objField.GetType() == typeof(DateTime))
                {
                    DateTime objDate = Convert.ToDateTime(objField);
                    return objDate.Date.Equals(NullDate.Date);
                }
                else if (objField.GetType() == typeof(String))
                    return objField.Equals(NullString);
                else if (objField.GetType() == typeof(Boolean))
                    return objField.Equals(NullBoolean);
                else if (objField.GetType() == typeof(Guid))
                    return objField.Equals(NullGuid);
                else // complex object
                    return false;
            }
            else
                return true;
        }

        public static object NotNull(object Value01, object Value02)
        {

            if (!Value01.Equals(DBNull.Value))
                return Value01;
            else
                return Value02;
        }


    }

}
