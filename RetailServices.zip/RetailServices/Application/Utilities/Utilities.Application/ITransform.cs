﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities.Application
{
    public interface ITransform
    {
        string ObjectToXml<T>(T objectToTransform);
    }
}
