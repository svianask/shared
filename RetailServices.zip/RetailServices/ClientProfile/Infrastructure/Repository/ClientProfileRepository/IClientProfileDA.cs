﻿using ClientProfileDomain.PortafolioDetailAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileRepository
{
    public interface IClientProfileDA
    {
        List<FundAllocation> GetPortafolioDetailFundsByClientType(int clientType, string spName);
        List<FundAllocation> GetPortafolioDetailFundsByContract(string contractId, string spName);
        void SetPortafolioDistribution(string spName, string funds, string contractId, int fundsTotal, DateTime baseDate, bool asignType);
        void SetPortafolioDistributionLog(string currentPortafolio, string newPortafolio, string contractId, string transactionId);
    }
}
