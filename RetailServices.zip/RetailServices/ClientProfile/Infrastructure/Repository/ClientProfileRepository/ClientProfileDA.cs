﻿using ClientProfileDomain.PortafolioDetailAggregate;
using ClientProfileMapping;
using SqlClient.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace ClientProfileRepository
{
    public class ClientProfileDA : IClientProfileDA
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public ClientProfileDA([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            this._dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public List<FundAllocation> GetPortafolioDetailFundsByClientType(int clientType, string spName)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@pintPortafolioModelo", clientType);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return PortafolioDetailMapp.MappingPortafolioFunds(ds);
        }

        public List<FundAllocation> GetPortafolioDetailFundsByContract(string contractId, string spName)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@pstrContratoId", contractId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return PortafolioDetailMapp.MappingPortafolioFunds(ds);
        }

        public void SetPortafolioDistribution(string spName, string funds, string contractId, int fundsTotal, DateTime baseDate, bool asignType)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@ContratoId", contractId);
            cmd.AddParameterWithValue("@BaseDate", baseDate);
            cmd.AddParameterWithValue("@TotalFondos", fundsTotal);
            cmd.AddParameterWithValue("@Fondos", funds);
            cmd.AddParameterWithValue("@Asignar", asignType);
            _sqlClientHelper.ExecuteNonQuery(cmd);
        }

        public void SetPortafolioDistributionLog(string currentPortafolio, string newPortafolio, string contractId, string transactionId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertContratoTransaccionPortafolio", _dbConn);
            cmd.AddParameterWithValue("@pstrContratoId", contractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", transactionId);
            cmd.AddParameterWithValue("@pstrPortActFondosPorcentaje", currentPortafolio);
            cmd.AddParameterWithValue("@pstrPortNvoFondosPorcentaje", newPortafolio);
            _sqlClientHelper.ExecuteNonQuery(cmd);
        }
    }
}
