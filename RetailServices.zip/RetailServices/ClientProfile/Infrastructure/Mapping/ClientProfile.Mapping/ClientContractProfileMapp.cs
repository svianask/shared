﻿using ClientProfileDomain.ClientProfileAggregate;
using System.Data;

namespace ClientProfileMapping
{
    public class ClientContractProfileMapp
    {
        public static ClientProfile Mapp(string contractId, DataSet ds)
        {
            ClientProfile clientProfile =
                new ClientProfile(contractId)
                .SetClienType(
                    ds.Tables[0].Rows[0]["Tipo_Cliente_Id"].ToString(),
                    ds.Tables[0].Rows[0]["Tipo_Cliente_Dsc"].ToString()
                    )
                .SetServiceType(
                    ds.Tables[0].Rows[0]["Servicio_Inversion_Id"].ToString(),
                    ds.Tables[0].Rows[0]["Tipo_Servicio_Dsc"].ToString()
                    )
                .SetProductType(
                    ds.Tables[0].Rows[0]["Tipo_Producto_Id"].ToString()
                    );
            return clientProfile;
        }
    }
}
