﻿using ClientProfileDomain.PortafolioDetailAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMapping
{
    public class PortafolioDetailMapp
    {
        public static List<FundAllocation> MappingPortafolioFunds(DataSet ds)
        {
            var lstFunds = new List<FundAllocation>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                FundAllocation fund = FundAllocationMapp.Mapp(dr);
                lstFunds.Add(fund);
            }

            return lstFunds;
        }
    }
}
