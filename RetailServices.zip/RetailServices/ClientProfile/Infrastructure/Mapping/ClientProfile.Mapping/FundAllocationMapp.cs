﻿using ClientProfileDomain.PortafolioDetailAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMapping
{
    public class FundAllocationMapp
    {
        public static FundAllocation Mapp(DataRow dr)
        {
            return FundAllocation.Create(
                dr["Emision_Id"].ToString(),
                Convert.ToDecimal(dr["Porcentaje"])
                );
        }
    }
}
