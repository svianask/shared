﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientProfileDomain.PortfolioTypeAggregate;

namespace ClientProfileMapping
{
    public class PortfolioTypeMapp
    {
        public static SalesPractPortfolioType Mapp(DataSet ds)
        {
            return new SalesPractPortfolioType(
                id: ds.Tables[0].Rows[0]["Tipo_Portafolio_Id"].ToString(),
                description: ds.Tables[0].Rows[0]["Tipo_Portafolio_Dsc"].ToString()
            ).SetClienType(
                id: ds.Tables[0].Rows[0]["Tipo_Cliente_Id"].ToString(),
                description: ds.Tables[0].Rows[0]["Tipo_Cliente_Dsc"].ToString()
                );
        }
    }
}
