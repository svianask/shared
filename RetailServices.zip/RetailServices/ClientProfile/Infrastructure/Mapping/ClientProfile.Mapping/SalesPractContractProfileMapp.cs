﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientProfileDomain.SalesPractContractProfileAggregate;

namespace ClientProfileMapping
{
    public class SalesPractContractProfileMapp
    {
        public static SalesPractContractProfile Mapp(DataSet ds)
        {
            SalesPractContractProfile salesPractContractProfile = null;

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                salesPractContractProfile = new SalesPractContractProfile(
                    clientType_Id: ds.Tables[0].Rows[0]["Tipo_Cliente_Id"].ToString(),
                    clientType_Descrption: ds.Tables[0].Rows[0]["Tipo_Cliente_Dsc"].ToString(),
                    clientType_ShortDescription: ds.Tables[0].Rows[0]["Tipo_Cliente_Dsc_Corta"].ToString()
                );
            }

            return salesPractContractProfile;
        }
    }
}
