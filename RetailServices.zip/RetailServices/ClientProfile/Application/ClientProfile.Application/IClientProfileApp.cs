﻿using ClientProfileDomain.ClientProfileAggregate;
using ClientProfileDomain.PortafolioDetailAggregate;
using ClientProfileDomain.PortfolioTypeAggregate;
using ClientProfileDomain.SalesPractContractProfileAggregate;
using ClientProfileMessage;
using Common.Domain;
using System;
using System.Collections.Generic;

namespace ClientProfileApplication
{
    public interface IClientProfileApp
    {
        ClientProfile GetClientProfile(string contractId, int platform, out OperationResult result);
        SalesPractPortfolioType GetPortfolioProfile(string contractId, int platform, out OperationResult result);
        SalesPractContractProfile GetSalesPracticeContractProfile(string contractId, out OperationResult result);
        List<FundAllocation> GetPortafolioDetailFunds(string contractId, int portafolioType, int clientType, int platform, out OperationResult result);
        OperationResult SetPortafolioDistribution(List<FundAllocationPxy> fundAllocations, string contractId, DateTime baseDate, int platform);
        OperationResult SetPortafolioDistributionLog(List<FundAllocationPxy> currentPortafolio, List<FundAllocationPxy> newPortafolio, string contractId, string transactionId);
    }
}
