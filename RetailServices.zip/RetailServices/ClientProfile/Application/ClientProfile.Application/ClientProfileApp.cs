﻿using ClientContracts.Repository;
using ClientProfileDomain.ClientProfileAggregate;
using ClientProfileDomain.PortafolioDetailAggregate;
using ClientProfileDomain.PortfolioTypeAggregate;
using ClientProfileDomain.SalesPractContractProfileAggregate;
using ClientProfileMessage;
using ClientProfileRepository;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClientProfileApplication
{
    public class ClientProfileApp : IClientProfileApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IRAWRAPSIIFDa _siifDa;
        private readonly IClientProfileDA _profileDA;

        public ClientProfileApp(ISeriLogHelper log, IRAWRAPSIIFDa iRawRapSiifDa, IClientProfileDA clientProfileApp)
        {
            _log = log;
            _siifDa = iRawRapSiifDa;
            _profileDA = clientProfileApp;
        }


        /// <summary>
        /// Get the client profile for a contract
        /// </summary>
        /// <param name="contractId"></param>
        /// <param name="platform"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public ClientProfile GetClientProfile(string contractId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful=true };
            string spName = string.Empty;
            ClientProfile clientProfile = null;
            
            try
            {
                _log.Info("Obteniendo datos del perfil de cliente para el contrato: {cntx}", new { contractId, platform });
                spName = platform == 10 ? "usp_SOC_SIIF_RS_PV_GetContratoSalesPracticeInfo" : "usp_SOC_SIIF_GT_PV_GetContratoSalesPracticeInfo";
                clientProfile = _siifDa.GetClientContractProfile(spName, contractId);
                _log.Debug("Datos del perfil obtenidos para el contrato: {cntx} ", new { contractId, platform });
            }
            catch (Exception ex)
            {
                _log.Error(ex,"Error al obtener el perfil del cliente para el contrato: {cntx}", new { contractId, platform });

                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener el perfil del contrato - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error } };
            }

            return clientProfile;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contractId"></param>
        /// <param name="platform"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public SalesPractPortfolioType GetPortfolioProfile(string contractId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            string spName = string.Empty;
            SalesPractPortfolioType portfolioType = null;

            try
            {
                _log.Info("Obteniendo el portafolio para el contrato: {cntx}", new { contractId, platform });
                spName = platform == 10 ? "usp_SOC_SIIF_RS_GetContratoTipoPortafolios" : "usp_SOC_SIIF_GT_GetContratoTipoPortafolios";
                portfolioType = _siifDa.GetContractPortfolio(spName, contractId);
                _log.Debug("Datos del portafolio obtenido para el contrato: {cntx} ", new { contractId, platform });
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el portafolio para el contrato: {cntx}", new { contractId, platform });

                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener el portafolio del contrato - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error } };
            }

            return portfolioType;
        }

        public SalesPractContractProfile GetSalesPracticeContractProfile(string contractId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            string spName = string.Empty;
            SalesPractContractProfile salesPractContractProfile = null;

            try
            {
                _log.Info("Obteniendo el perfil de practica de ventas del contrato");
                _log.Debug("{cntx}", new { contractId });
                salesPractContractProfile = _siifDa.GetSalesPracticeContractProfile(contractId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el portafolio para el contrato: {cntx}", new { contractId });

                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener el portafolio del contrato - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error } };
            }

            return salesPractContractProfile;
        }

        public List<FundAllocation> GetPortafolioDetailFunds(string contractId, int portafolioType, int clientType, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var investmentFundAllocation = new List<FundAllocation>();

            try
            {
                var spName = "";
                _log.Info("Obteniendo el detalle de fondos del portafolio dependiendo del tipo de portafolio");
                switch (portafolioType)
                {
                    case 5:
                        spName = platform.Equals(10) ? "usp_SOC_SIIF_RS_GetPortafolioModeloDistribucion" : "usp_SOC_SIIF_GT_GetPortafolioModeloDistribucion";
                        investmentFundAllocation = _profileDA.GetPortafolioDetailFundsByClientType(clientType, spName);
                        break;
                    case 10:
                        spName = platform.Equals(10) ? "usp_SOC_SIIF_RS_GetContratoPortafolioDefinido" : "usp_SOC_SIIF_GT_GetContratoPortafolioDefinido";
                        investmentFundAllocation = _profileDA.GetPortafolioDetailFundsByContract(contractId, spName);
                        break;
                    case 20:
                        spName = platform.Equals(10) ? "usp_SOC_SIIF_RS_GetContratoPortafolioPlan" : "usp_SOC_SIIF_GT_GetContratoPortafolioPlan";
                        investmentFundAllocation = _profileDA.GetPortafolioDetailFundsByContract(contractId, spName);
                        break;
                }
                _log.Debug("{cntx}", investmentFundAllocation);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al obtener el portafolio detallado del contrato: {cntx}", contractId);
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al obtener el portafolio detallado - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error } };
            }

            return investmentFundAllocation;
        }

        public OperationResult SetPortafolioDistribution(List<FundAllocationPxy> fundAllocations, string contractId, DateTime baseDate, int platform)
        {
            var result = new OperationResult() { Successful = true };

            try
            {
                var spName = platform.Equals(10) ? "usp_SIIF_RS_Actualiza_Portafolio_Definido" : "usp_SIIF_GT_Actualiza_Portafolio_Definido";
                _log.Info("Se obtiene el formato de los fondos para el store");
                var funds = GetFormatFundsAllocationsToSP(fundAllocations);
                _log.Debug("{cntx}", funds);

                _log.Info("Se actualiza el portafolio");
                _profileDA.SetPortafolioDistribution(spName, funds, contractId, fundAllocations.Count, baseDate, false);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al Actualizar el portafolio con los fondos: {cntx}", fundAllocations);
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al Actualizar el portafolio - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error } };
            }

            return result;
        }

        public OperationResult SetPortafolioDistributionLog(List<FundAllocationPxy> currentPortafolio, List<FundAllocationPxy> newPortafolio, string contractId, string transactionId)
        {
            var result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Insertando log de distribucion del portafolio.");
                var stringCurrentFunds = GetFormatFundsAllocationsToSP(currentPortafolio);
                var stringNewFunds = GetFormatFundsAllocationsToSP(newPortafolio);
                _profileDA.SetPortafolioDistributionLog(stringCurrentFunds, stringNewFunds, contractId, transactionId);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al insertar en log de la distribucion del portafolio para la trasaccion: {cntx}", transactionId);
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error al Actualizar el portafolio - " + ex.Message + " - " + ex.StackTrace, MessageType = SystemMessageTypes.Error } };
            }

            return result;
        }

        private string GetFormatFundsAllocationsToSP(List<FundAllocationPxy> fundAllocations)
        {
            StringBuilder funds = new StringBuilder();

            fundAllocations.ForEach(fund =>
            {
                funds.Append(string.Format("{0}|{1};", fund.Id, fund.Percentage));
            });

            return funds.ToString();
        }
    }
}
