﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileDomain.PortafolioDetailAggregate
{
    public class FundAllocation : Entity<string>, IRootAggregate
    {
        private decimal _percentage;
        private FundAllocation(string fundId, decimal percent)
        {
            Id = fundId;
            _percentage = percent;
        }

        public decimal Percentage => _percentage;

        public static FundAllocation Create(string fundId, decimal percent)
        {
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El id del fondo no puede ser nulo."); }
            return new FundAllocation(fundId, percent);
        }
    }
}
