﻿using Ddd;

namespace ClientProfileDomain.ClientProfileAggregate
{
    public class ClientProfile : Entity<string>
    {
        private SalesPractClientType _clientType;
        private ServiceType _serviceType;
        private string _productType;

        public ClientProfile(string contractId)
        {
            Id = contractId;
        }

        public SalesPractClientType ClientType => _clientType;

        public ServiceType ServiceType => _serviceType;

        public string ProductType  => _productType;

        public ClientProfile SetClienType(string id, string description)
        {
            this._clientType = SalesPractClientType.Create(id, description);
            return this;
        }

        public ClientProfile SetServiceType(string id, string description)
        {
            this._serviceType = ServiceType.Create(id, description);
            return this;
        }

        public ClientProfile SetProductType(string productType)
        {
            this._productType = productType;
            return this;
        }
    }
}
