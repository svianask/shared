﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientProfileDomain.ClientProfileAggregate
{
    public class SalesPractClientType : ValueObject<SalesPractClientType>
    {
        private readonly string _id;
        private readonly string _description;

        private SalesPractClientType(string id, string description)
        {
            _id = id;
            _description = description;
        }

        public string Id => _id;

        public string Description => _description;

        internal static SalesPractClientType Create(string id, string description)
        {
            return new SalesPractClientType(id, description);
        }
        
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
