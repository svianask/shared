﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientProfileDomain.ClientProfileAggregate
{
    public class ServiceType : ValueObject<ServiceType>
    {
        private readonly string _id;
        private readonly string _description;

        private ServiceType(string id, string description)
        {
            _id = id;
            _description = description;
        }

        public string Id => _id;

        public string Description => _description;

        internal static ServiceType Create(string id, string description)
        {
            return new ServiceType(id, description);
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
