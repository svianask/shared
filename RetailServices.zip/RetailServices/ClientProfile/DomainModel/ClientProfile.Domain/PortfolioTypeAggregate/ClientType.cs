﻿using Ddd;
using System;
using System.Collections.Generic;

namespace ClientProfileDomain.PortfolioTypeAggregate
{
    public class ClientType : ValueObject<ClientType>
    {
        private readonly string _id;
        private readonly string _description;

        private ClientType(string id, string description)
        {
            _id = id;
            _description = description;
        }

        public string Id => _id;

        public string Description => _description;

        internal static ClientType Create(string id, string description)
        {
            return new ClientType(id, description);
        }
        
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
