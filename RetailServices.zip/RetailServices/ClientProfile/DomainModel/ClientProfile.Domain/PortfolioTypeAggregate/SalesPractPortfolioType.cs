﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileDomain.PortfolioTypeAggregate
{
    public class SalesPractPortfolioType : Entity<string>
    {

        private string _description;
        private ClientType _clientType;

        public SalesPractPortfolioType(string id, string description)
        {
            Id = id;
            _description = description.Substring(0,1).ToUpper() + description.Substring(1).ToLower();
        }

        public string Description => _description;

        public ClientType ClientType => _clientType; 

        public SalesPractPortfolioType SetClienType(string id, string description)
        {
            if (this.Id.Trim().Equals("5"))
            {
                this._description += " " + description.Substring(0, 1).ToUpper() + description.Substring(1).ToLower();
            }
            this._clientType = ClientType.Create(id, description);
            return this;


        }
    }
}
