﻿using ClientProfileDomain.PortafolioDetailAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMessage
{
    public class SetPortafolioDistributionLogResponse
    {
        public OperationResult Result;
    }

    public class SetPortafolioDistributionLogRequest
    {
        public List<FundAllocationPxy> CurrentPortafolio;
        public List<FundAllocationPxy> NewPortafolio;
        public string ContractId;
        public string TransactionId;
    }
}
