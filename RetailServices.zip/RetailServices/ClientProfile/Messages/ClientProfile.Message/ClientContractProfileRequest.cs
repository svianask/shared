﻿namespace ClientProfileMessage
{
    public class ClientProfileRequest
    {
        public string ContractId;
        public int Platform;
    }
}
