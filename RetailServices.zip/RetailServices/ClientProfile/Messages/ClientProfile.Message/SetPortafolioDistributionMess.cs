﻿using ClientProfileDomain.PortafolioDetailAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMessage
{
    public class SetPortafolioDistributionResponse
    {
        public OperationResult Result;
    }

    public class SetPortafolioDistributionRequest
    {
        public List<FundAllocationPxy> NewFundsDistribution;
        public string ContractId;
        public DateTime BaseDate;
        public int Platform;
    }

    public class FundAllocationPxy
    {
        public string Id;
        public decimal Percentage;
    }
}
