﻿using ClientProfileDomain.ClientProfileAggregate;
using Common.Domain;

namespace ClientProfileMessage
{
    public class ClientProfileResponse
    {
        
        public ClientProfileResponse()
        {
            Result = new OperationResult();
        }

        public ClientProfile ClientProfile;
        public OperationResult Result;
    }
}
