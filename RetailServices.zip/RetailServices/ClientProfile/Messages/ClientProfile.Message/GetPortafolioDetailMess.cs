﻿using ClientProfileDomain.PortafolioDetailAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMessage
{
    public class GetPortafolioDetailResponse
    {
        public List<FundAllocation> PortafolioDetailFunds;
        public OperationResult Result;
    }

    public class GetPortafolioDetailRequest
    {
        public string ContractId;
        public int ClientType;
        public int PortafolioType;
        public int Platform;
    }
}
