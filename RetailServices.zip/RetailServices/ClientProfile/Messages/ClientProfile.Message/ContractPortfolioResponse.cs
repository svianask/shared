﻿using ClientProfileDomain.PortfolioTypeAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMessage
{
    public class PortfolioProfileResponse
    {
        public PortfolioProfileResponse()
        {
            Result = new OperationResult();
        }

        public SalesPractPortfolioType PortfolioType;
        public OperationResult Result;
    }
}
