﻿using ClientProfileDomain.SalesPractContractProfileAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMessage
{
    public class SalesPracticeContractProfileResponse
    {
        public SalesPractContractProfile SalesPracticeContractProfile;
        public OperationResult Result;
    }
}
