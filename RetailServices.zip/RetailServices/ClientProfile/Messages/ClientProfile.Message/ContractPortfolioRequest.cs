﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientProfileMessage
{
    public class PortfolioProfileRequest
    {
        public string ContractId;
        public int Platform;
    }
}
