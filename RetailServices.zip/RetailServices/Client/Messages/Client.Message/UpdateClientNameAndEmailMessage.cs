﻿using Client.Domain.ClientGeneralDataAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.Message
{
    public class UpdateClientNameAndEmailRequest
    {
        public ClientGeneralData ClientData;
    }

    public class UpdateClientNameAndEmailResponse
    {
        public OperationResult Result;

        public UpdateClientNameAndEmailResponse() { Result = new OperationResult(); }
    }
}
