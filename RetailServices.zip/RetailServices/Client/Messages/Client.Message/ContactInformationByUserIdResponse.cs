﻿using Client.Domain.ContactInformationAggregate;
using Common.Domain;

namespace Client.Message
{
    public class ContactInformationByUserIdResponse
    {
        public ContactInformation ContactInformation;
        public OperationResult Result;
    }
}
