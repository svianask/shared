﻿using Common.Domain;

namespace Client.Message
{
    public class UpdateContactInformationResponse
    {
        public OperationResult Result;
    }
}
