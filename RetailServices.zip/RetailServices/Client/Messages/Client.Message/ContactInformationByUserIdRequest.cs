﻿using Common.Domain;
using System;

namespace Client.Message
{
    public class ContactInformationByUserIdRequest
    {
        public string ClientIdentifier;

        public bool OnlyActive { get; set; }
    }
}
