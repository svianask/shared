﻿using Client.Domain.ClientAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace Client.Message
{
    public class ClientsByContractsIdResponse
    {
        public List<ClientInfo> ClientsInfo;
        public OperationResult Result;
    }
}
