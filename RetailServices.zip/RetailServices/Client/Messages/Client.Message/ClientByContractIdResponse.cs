﻿using Client.Domain.ClientAggregate;
using Common.Domain;

namespace Client.Message
{
    public class ClientByContractIdResponse
    {
        public OperationResult Result;
        public ClientInfo ClientInfo;

        public ClientByContractIdResponse()
        {
            Result = new OperationResult();
        }
    }
}
