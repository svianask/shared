﻿namespace Client.Message
{
    public class UpdateContactInformationRequest
    {
        public string ClientIdentifier;
        public string Email;
        public string Phone;
    }
}
