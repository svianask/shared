﻿using Client.Domain.ClientAggregate;
using Client.Domain.ClientGeneralDataAggregate;
using Client.Domain.ContactInformationAggregate;
using Client.Mapping;
using SqlClient.Helper;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Unity;

namespace Client.Repository
{
    public class ClientRepository : IClientRepository
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public ClientRepository([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            this._dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public ClientInfo ClientByContractId(string contractId)
        {
            DataSet ds = new DataSet();

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("sp_GetClientByContractId", _dbConn);
            cmd.AddParameterWithValue("@contractId", contractId);
            ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ClientInfoMapp.Mapp(ds)[0];
        }
        
        public List<ClientInfo> GetClientsByContractsId(string stringXmlData)
        {
            DataSet ds = new DataSet();

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_GetClientsByContracstId", _dbConn);
            cmd.AddParameterWithValue("@xmlContratos", stringXmlData);
            ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ClientInfoMapp.MappCliInfo(ds);
        }
                
        public ContactInformation GetContactInformationClientId(string userIdentifier, bool OnlyActive)
        {
            DataSet ds = new DataSet();

            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_GetContractsContactInfo", _dbConn);
            cmd.AddParameterWithValue("@pstrRFC", userIdentifier);
            cmd.AddParameterWithValue("@onlyActive", OnlyActive);
            ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return  ContactInformationMapp.Mapp(ds);
        }


        public string UpdateContactInformation(string clientIdentifier, string email, string phone)
        {
            
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_ActualizarDatosContactoContratos", _dbConn);
            cmd.AddParameterWithValue("@pRFC", clientIdentifier);
            cmd.AddParameterWithValue("@pEmail", email);
            cmd.AddParameterWithValue("@pPhone", phone);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ContactInformationMapp.UpdateContactInformation(ds);
        }

        public void UpdateClientNameEmail(ClientGeneralData generalData)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_Actualiza_Nombre_Email", _dbConn);
            cmd.AddParameterWithValue("@RFC", generalData.RFC);
            cmd.AddParameterWithValue("@Nombre", generalData.FirstName);
            cmd.AddParameterWithValue("@ApellidoPaterno", generalData.LastName);
            cmd.AddParameterWithValue("@ApellidoMaterno", generalData.SecondLastName);
            cmd.AddParameterWithValue("@Email", generalData.Email);
            _sqlClientHelper.ExecuteDataSet(cmd);
        }
    }
}
