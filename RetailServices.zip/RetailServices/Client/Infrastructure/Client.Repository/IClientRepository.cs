﻿using System.Collections.Generic;
using Client.Domain.ClientAggregate;
using Client.Domain.ClientGeneralDataAggregate;
using Client.Domain.ContactInformationAggregate;

namespace Client.Repository
{
    public interface IClientRepository
    {
        ClientInfo ClientByContractId(string contractId);
        List<ClientInfo> GetClientsByContractsId(string stringXmlData);
        ContactInformation GetContactInformationClientId(string clientIdentifier, bool OnlyActive);
        void UpdateClientNameEmail(ClientGeneralData generalData);
        string UpdateContactInformation(string clientIdentifier, string Email, string Phone);
    }
}
