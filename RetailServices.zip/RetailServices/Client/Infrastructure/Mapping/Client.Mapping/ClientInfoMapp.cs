﻿using Client.Domain.ClientAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.Application;

namespace Client.Mapping
{
    public class ClientInfoMapp
    {
        public static List<ClientInfo> Mapp(DataSet ds)
        {
            List<ClientInfo> clientsInfo = new List<ClientInfo>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                clientsInfo.Add(
                    ClientInfo.Create(
                        dr["Contrato_Id"].ToString(), 
                        dr["Contrato_Repr_Nombre"].ToString(), 
                        dr["Contrato_Repr_Apellido_Pat"].ToString(), 
                        dr["Contrato_Repr_Apellido_Mat"].ToString()
                        )
                    .SetPersonalityFiscal(Convert.ToInt32(Null.SetNull(dr["Tipo_Persona_Id"], new Int32())))
                );
            }
            return clientsInfo;
        }

        public static List<ClientInfo> MappCliInfo(DataSet ds)
        {
            List<ClientInfo> clientsInfo = new List<ClientInfo>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                try
                {
                    var strBirthday = dr["Contrato_Repr_Fecha_Nacimiento"].ToString();
                    DateTime birthday = new DateTime(1900, 01, 01);
                    DateTime.TryParse(strBirthday, out birthday);
                    DateTime? nullableBirthday = (birthday == new DateTime(1900, 01, 01)) ? (DateTime?)null : birthday;


                    clientsInfo.Add(
                        ClientInfo.Create(dr["Contrato_Repr_RFC"].ToString(), dr["Contrato_Repr_Nombre"].ToString(), dr["Contrato_Repr_Apellido_Pat"].ToString(), dr["Contrato_Repr_Apellido_Mat"].ToString())
                        .SetBusinessRelation(dr["Contrato_Id"].ToString())
                        .SetPersonIdentifiers(dr["Contrato_Repr_RFC"].ToString(), dr["Contrato_Repr_Curp"].ToString())
                        .SetPersonInfoExtended(dr["Genero_Dsc_Corta"].ToString(), nullableBirthday)
                    );
                }
                catch { }

            }
            return clientsInfo;
        }
    }
}
