﻿using Client.Domain.ContactInformationAggregate;
using System.Data;

namespace Client.Mapping
{
    public class ContactInformationMapp
    {
        public static ContactInformation Mapp(DataSet ds)
        {
            DataRow dr = ds.Tables[0].Rows[0];

            return ContactInformation.Create(
                dr["Email"].ToString(),
                dr["Celular"].ToString(),
                "" /*country dial code implementation expected on SIIF*/
                )
                .SetName(
                    dr["Nombre"].ToString(),
                    dr["Apellido_Paterno"].ToString(),
                    dr["Apellido_Materno"].ToString()
                );
        }

        public static string UpdateContactInformation(DataSet ds)
        {
            DataRow dr = ds.Tables[0].Rows[0];
            string updateResult = dr["Resultado"].ToString();

            if (updateResult.Contains("Actualización exitosa.")) { updateResult = "OK"; }
            else { updateResult = "ERROR"; }

            return updateResult;
        }
    }
}
