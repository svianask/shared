﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.Domain.ClientAggregate
{
    public class ClientInfo : Entity<string>
    {
        private readonly string _name;
        private readonly string _lastNameOne;
        private readonly string _lastNameTwo;
        private string _rFC;
        private string _cURP;
        private string _gender;
        private DateTime _birthday;
        private string _contractId;
        private int _personTypeId;

        private ClientInfo(string clientId, string name, string lastNameOne, string lastNameTwo)
        {
            Id = clientId;
            _name = name;
            _lastNameOne = lastNameOne;
            _lastNameTwo = lastNameTwo;
        }

        public string Name => _name;
        public string LastNameOne => _lastNameOne;
        public string LastNameTwo => _lastNameTwo;
        public string RFC => _rFC;
        public string CURP => _cURP;
        public string Gender => _gender;
        public DateTime Birthday => _birthday;

        public string ContractId  => _contractId;
        public int PersonTypeId => _personTypeId;

        public static ClientInfo Create(string Id, string name, string lastNameOne, string lastNameTwo)
        {
            if (string.IsNullOrEmpty(Id)) { throw new ArgumentException("Id no puede ser nulo ni vacío."); }
            if (string.IsNullOrEmpty(name)) { throw new ArgumentException("El nombre no puede ser nulo ni vacío."); }
            if (string.IsNullOrEmpty(lastNameOne) && string.IsNullOrEmpty(lastNameTwo)) { throw new ArgumentException("Ambos apellidos no pueden ser nulos ni estar vacíos a la vez."); }

            return new ClientInfo(Id, name, lastNameOne, lastNameTwo);
        }

        public ClientInfo SetPersonIdentifiers(string rFC, string cURP)
        {
            if (!string.IsNullOrEmpty(rFC)) { this._rFC = rFC; }
            if (!string.IsNullOrEmpty(cURP)) { this._cURP = cURP; }

            return this;
        }

        public ClientInfo SetPersonInfoExtended(string gender, DateTime? birthDay)
        {
            if (!string.IsNullOrEmpty(gender)) { this._gender = gender; }
            if (birthDay != null) this._birthday = (DateTime)birthDay;

            return this;
        }

        public ClientInfo SetBusinessRelation(string contractId)
        {
            if (!string.IsNullOrEmpty(contractId)) { this._contractId = contractId; }

            return this;
        }

        public ClientInfo SetPersonalityFiscal(int personTypeId)
        {
            if(personTypeId < 1) { throw new ArgumentException("El id del tipo de persona debe ser mayor a 0."); }

            _personTypeId = personTypeId;
            return this;
        }
    }
}
