﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Client.Domain.ContactInformationAggregate
{
    public class ContactInformation : ValueObject<ContactInformation>
    {
        private readonly string _email;
        private readonly string _mobilePhone;
        private readonly string _countryDialCode;
        private string _name;
        private string _lastName;
        private string _secondLastName;

        public ContactInformation(string email, string mobilePhone, string countryDialCode) 
        {
            _email = email;
            _mobilePhone = mobilePhone;
            _countryDialCode = countryDialCode;
        }

        public string Email => _email;

        public string MobilePhone => _mobilePhone;

        public string CountryDialCode => _countryDialCode;
        public string Name => _name;
        public string LastName => _lastName;
        public string SecondLastName => _secondLastName;

        public static ContactInformation CreateNormalized(string email, string mobilePhone, string countryDialCode)
        {
            string emailPattern = @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$";
            Regex regexMail = new Regex(emailPattern);

            if (String.IsNullOrEmpty(email)) { throw new ArgumentException("No se permiten valores nulos o vacíos."); }
            if (!regexMail.IsMatch(email)) { throw new ArgumentException("El valor recibido no corresponde con un correo electrónico."); }
            if (email.Length > 60) { throw new ArgumentException("El correo electrónico no debe tener más de 60 carácteres de longitud."); }


            string phonePattern = @"^([0-9]{10})$";
            Regex regexPhone = new Regex(phonePattern);

            if (String.IsNullOrEmpty(mobilePhone)) { throw new ArgumentException("No se permiten valores nulos o vacíos."); }
            if (!regexPhone.IsMatch(mobilePhone)) { throw new ArgumentException("El valor recibido no corresponde a un teléfono."); }
            if (mobilePhone.Length > 10) { throw new ArgumentException("El teléfono no debe tener más de 10 carácteres de longitud."); }

            mobilePhone = StandarizePhone(mobilePhone);
            countryDialCode = StandarizeCountryDialCode(countryDialCode);

            return new ContactInformation(email, mobilePhone, countryDialCode);
        }

        public static ContactInformation Create(string email, string phone, string countryDialCode)
        {
            phone = StandarizePhone(phone);
            countryDialCode = StandarizeCountryDialCode(countryDialCode);

            return new ContactInformation(email, phone, countryDialCode);
        }

        private static string StandarizeCountryDialCode(string countryDialCode)
        {
            countryDialCode = countryDialCode.Replace(" ", "").Trim();
            if (countryDialCode.Length < 1 ) { countryDialCode = "52"; }
            return countryDialCode;
        }

        private static string StandarizePhone(string phone)
        {
            phone = phone.Replace(" ", "").Trim();
            if (phone.Length != 10) { phone = string.Empty; }
            return phone;
        }

        public ContactInformation SetName(string name, string lastName, string secondLastName)
        {
            _name = name;
            _lastName = lastName;
            _secondLastName = secondLastName;
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Email,
                MobilePhone,
                CountryDialCode,
                Name,
                LastName,
                SecondLastName
            };
        }
    }
}
