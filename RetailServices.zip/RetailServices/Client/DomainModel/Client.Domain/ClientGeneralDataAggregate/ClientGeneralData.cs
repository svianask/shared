﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.Domain.ClientGeneralDataAggregate
{
    public class ClientGeneralData
    {
        public ClientGeneralData()
        {

        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SecondLastName { get; set; }
        public string Email { get; set; }
        public string RFC { get; set; }
    }
}
