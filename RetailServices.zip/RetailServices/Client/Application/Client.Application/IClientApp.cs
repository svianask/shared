﻿using Client.Domain.ClientAggregate;
using Client.Domain.ClientGeneralDataAggregate;
using Client.Domain.ContactInformationAggregate;
using Common.Domain;
using System.Collections.Generic;

namespace Client.Application
{
    public interface IClientApp
    {
        ClientInfo GetClientByContractId(string contractId, out OperationResult result);
        List<ClientInfo> GetClientsByContractsId(List<string> contractsId, out OperationResult result);
        ContactInformation GetContactInformationByClientId(string clientIdentifier, bool OnlyActive, out OperationResult result);
        OperationResult UpdateClientNameAndEmail(ClientGeneralData generalData);
        void UpdateContactInformation(string clientIdentifier, string email, string phone, out OperationResult result);
    }
}
