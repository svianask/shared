﻿using Client.Domain.ClientAggregate;
using Client.Domain.ClientGeneralDataAggregate;
using Client.Domain.ContactInformationAggregate;
using Client.Repository;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace Client.Application
{
    public class ClientApp : IClientApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IClientRepository _clientRepository;
        private readonly ITransform _transform;

        public ClientApp(ISeriLogHelper log, IClientRepository clientRepository, ITransform transform)
        {
            _log = log;
            _clientRepository = clientRepository;
            _transform = transform;
        }

        public ClientInfo GetClientByContractId(string contractId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                _log.Info("Validando que contractId no sea nulo ni vacío.");
                if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contractId no puede ir vacío o null."); }
                _log.Debug("{cntx}", true);
                _log.Info("Obteniendo los datos del cliente de la base de datos.", contractId);
                var clientInfo = _clientRepository.ClientByContractId(contractId);
                _log.Debug("{cntx}", new { clientInfo });

                return clientInfo;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los datos del cliente {cntx}", new { contractId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener los datos del cliente - " + ex.Message + "-" });
                return null;
            }

        }

        public List<ClientInfo> GetClientsByContractsId(List<string> contractsId, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            try
            {
                _log.Info("Validando que se hayan enviado contratos");
                if (contractsId.Count <= 0) { _log.Debug("No se han enviado contratos"); return null; }
                _log.Debug("{cntx}", contractsId.Count);

                _log.Info("Transformando los contratos en Xml");
                var stringXmlContratos = _transform.ObjectToXml<List<string>>(contractsId);
                _log.Debug("{cntx}", stringXmlContratos);

                _log.Info("Obteniendo los datos de los clientes.", contractsId);
                var clientInfo = _clientRepository.GetClientsByContractsId(stringXmlContratos);
                _log.Debug("{cntx}", new { clientInfo });

                return clientInfo;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los datos del cliente {cntx}", new { contractsId });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Ocurrio un error al obtener los datos del cliente - " + ex.Message + "-" });
                return null;
            }
        }

        public ContactInformation GetContactInformationByClientId(string clientIdentifier, bool OnlyActive, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            ContactInformation contactInformation = null;

            try
            {
                _log.Info("Obteniendo los datos de contacto para el cliente {cntx}", clientIdentifier);
                contactInformation = _clientRepository.GetContactInformationClientId(clientIdentifier, OnlyActive);
                _log.Debug("{cntx}", new { contactInformation });

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener los datos de contacto del cliente: {cntx}", new { clientIdentifier });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al obtener los datos de contacto del cliente - " + ex.Message + "-" });
                return null;
            }

            return contactInformation;
        }

        public void UpdateContactInformation(string clientIdentifier, string email, string phone, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            
            try
            {
                _log.Info("Actualizando los datos de contacto para el cliente {cntx}", clientIdentifier);
                string updateResult =_clientRepository.UpdateContactInformation(clientIdentifier, email, phone);
                _log.Debug("Resultado de la actualización: {cntx}", new { updateResult });
            }
            catch (Exception ex)
            {
                var errMsg = $"Error al actualizar los datos de contacto del cliente: {clientIdentifier}";
                _log.Error(ex, errMsg);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = $"{errMsg} - {ex.Message}" + ex.Message, MessageType = SystemMessageTypes.Error });
            }
        }

        public OperationResult UpdateClientNameAndEmail(ClientGeneralData generalData)
        {
            OperationResult result = new OperationResult { Successful = true };
            if(generalData is null) { throw new ArgumentException("Los datos no pueden ser nulos."); }
            if (string.IsNullOrEmpty(generalData.FirstName)) { throw new ArgumentException(nameof(generalData.FirstName)); }
            if(string.IsNullOrEmpty(generalData.LastName)) { throw new ArgumentException(nameof(generalData.LastName)); }
            if (string.IsNullOrEmpty(generalData.Email)) { throw new ArgumentException(nameof(generalData.Email)); }
            if (string.IsNullOrEmpty(generalData.RFC)) { throw new ArgumentException(nameof(generalData.RFC)); }

            try
            {
                _log.Info("Actualizando los datos del cliente");
                _clientRepository.UpdateClientNameEmail(generalData);
            }
            catch(Exception ex)
            {
                _log.Error(ex, "Error al actualizar los datos del cliente: {cntx}", new { generalData.RFC });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = "Error al actualizar los datos del cliente - " + ex.Message + "-" });
            }

            return result;
        }

    }
}
