﻿using ClientContracts.Repository;
using Common.Domain;
using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using DomiciliationContract.Domain.ConnectorResultAggregate;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using DomiciliationContract.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace DomiciliationContract.Application.Test
{
    [TestClass]
    public class DomiciliationContractAppTest
    {
        private readonly DomiciliationContractApp _domiciliationBL;
        private readonly Mock<ISeriLogHelper> _SeriloHelper;
        private readonly Mock<IRAWRAPSIIFDa> _repositorySIIF = new Mock<IRAWRAPSIIFDa>();
        private readonly Mock<ITransform> _transform = new Mock<ITransform>();
        private readonly Mock<IDomiciliationContratRepository> _repository = new Mock<IDomiciliationContratRepository>();

        DomiciliationOnDemand domi;

        public DomiciliationContractAppTest()
        {
            _SeriloHelper = new Mock<ISeriLogHelper>();
            _repositorySIIF = new Mock<IRAWRAPSIIFDa>();
            _transform = new Mock<ITransform>();
            _domiciliationBL = new DomiciliationContractApp(_SeriloHelper.Object, _repositorySIIF.Object, _transform.Object, _repository.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            domi = new DomiciliationOnDemand("XXXXXX", 1, 2000.0, DateTime.Now, 12, 123456, "XXXXXX", true, true, "XXXX");
            _repositorySIIF.Setup(x => x.GenerateDomiciliationOnDemand(domi))
                .Returns(new ConnectorResult(0, "", "XXX"));

            _transform.Setup(x => x.ObjectToXml(domi))
                .Returns("<UserId>SIIFADMR</UserId><Successful>false</Successful>");

            _repositorySIIF.Setup(x => x.InsertLogDomiciliation("<UserId>SIIFADMR</UserId><Successful>false</Successful>"));

        }

        [ExpectedException(typeof(Exception))]
        public void GenerateDomiciliationOnDemandError()
        {
            _domiciliationBL.GenerateDomiciliationOnDemand(null, out OperationResult result);
            Assert.AreEqual(false, result.Successful);
        }

        [TestMethod, TestCategory("GenerateDomiciliationOnDemand")]
        public void GenerateDomiciliationOnDemandSuccess()
        {
            var response = _domiciliationBL.GenerateDomiciliationOnDemand(domi, out OperationResult result);
            Assert.IsTrue(result.Successful);
        }


        [TestMethod, TestCategory("ResgisterLogDomiciliation")]
        [ExpectedException(typeof(Exception))]
        public void ResgisterLogDomiciliationError()
        {
            _domiciliationBL.ResgisterLogDomiciliation("");
        }

        public void RegisterLogDomiliationSuccess()
        {
            var response = _domiciliationBL.ResgisterLogDomiciliation("<UserId>SIIFADMR</UserId><Successful>false</Successful>");
            Assert.IsTrue(response.Successful);
        }

        [TestMethod, TestCategory("GetDomiciliationsByContract")]
        public void GetDomiciliationsByContract()
        {
            _repositorySIIF.Setup(c => c.GetDomiciliationsByContract(It.IsAny<string>(), It.IsAny<string>())).Returns(Mock.Of<List<ClientDomiciliation>>());
            var clientDomiciliations = _domiciliationBL.GetDomiciliationsByContract("897071", "BEEJ930917SW1", out var result);
            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(clientDomiciliations);
        }

        [TestMethod, TestCategory("GetBankCatalogsCatalog")]
        public void GetBankCatalogsCatalog()
        {
            _repositorySIIF.Setup(c => c.GetBanksCatalog()).Returns(Mock.Of<List<BankCatalog>>());
            var clientDomiciliations = _domiciliationBL.GetBankCatalogsCatalog(out var result);
            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(clientDomiciliations);
        }
    }
}
