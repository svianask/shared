﻿using Common.Domain;
using DomiciliationContract.Domain.AllowAmountsAggregate;
using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using DomiciliationContract.Domain.GroupingContractAggregate;
using System.Collections.Generic;

namespace DomiciliationContract.Application
{
    public interface IDomiciliationContractApp
    {
        string GenerateDomiciliationOnDemand(DomiciliationOnDemand domiciliationInfo, out OperationResult result);
        OperationResult ResgisterLogDomiciliation(string xmlInfoDomiciliation);
        OperationResult CancelDomiciliationByContract(string contractId);
        DomiciliationAllowAmounts GetAllowAmountsMinMax(int domiciliationType, out OperationResult result);
        decimal GetPorcentageComission(string contractId, out OperationResult result);
        GroupingContract GetGroupingContract(string contractId, int platform, out OperationResult result);
        decimal GetAmountDue(string contractId, out OperationResult result);
        string GetDaysCalendar(int year, out OperationResult result);
        bool HasProgrammedPayment(string clientId, string contractId, out OperationResult result);
        List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier, out OperationResult result);
        List<BankCatalog> GetBankCatalogsCatalog(out OperationResult result);
    }
}
