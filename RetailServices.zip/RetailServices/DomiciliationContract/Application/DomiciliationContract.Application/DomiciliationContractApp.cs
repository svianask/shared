﻿using ClientContracts.Repository;
using Common.Domain;
using DomiciliationContract.Domain.AllowAmountsAggregate;
using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using DomiciliationContract.Domain.ConnectorResultAggregate;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using DomiciliationContract.Domain.GroupingContractAggregate;
using DomiciliationContract.Message;
using DomiciliationContract.Repository;
using SeriLogH;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace DomiciliationContract.Application
{
    public class DomiciliationContractApp : IDomiciliationContractApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IRAWRAPSIIFDa _repositoryRetail;
        private readonly ITransform _transform;
        private readonly IDomiciliationContratRepository _domiciliationRepository;

        /// <summary>
        /// Constructor
        /// </summary>
        public DomiciliationContractApp(ISeriLogHelper log, IRAWRAPSIIFDa rAWRAPSIIFDa, ITransform transform, IDomiciliationContratRepository domiciliationContratRepository)
        {
            _log = log;
            _repositoryRetail = rAWRAPSIIFDa;
            _transform = transform;
            _domiciliationRepository = domiciliationContratRepository;
        }

        public OperationResult CancelDomiciliationByContract(string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new Exception("El contrato no puede ser null o vacío, revisa los datos enviados"); }
            OperationResult result = new OperationResult();

            try
            {
                _repositoryRetail.CancelDomiciliationByContract(contractId);
                result.Successful = true;
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al cancelar la domiciliacion del} contrato { message }", contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }
            return result;
        }

        public string GenerateDomiciliationOnDemand(DomiciliationOnDemand domiciliationInfo, out OperationResult result)
        {
            if (domiciliationInfo is null) { throw new Exception("La informacion de la domiciliaicon no puede ser null, revisa los datos enviados"); }

            result = new OperationResult();
            var response = string.Empty;

            try
            {
                var domiciliationResult = _repositoryRetail.GenerateDomiciliationOnDemand(domiciliationInfo);

                if (domiciliationResult.Code > 0)
                {
                    result.Successful = false;
                    result.SystemMessages.Add(new SystemMessage { Message = domiciliationResult.Message });
                }
                else
                {
                    result.Successful = true;
                }

                response = TransformLogTransactionXml(domiciliationInfo, domiciliationResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al generar la aportacion { message }", new { domiciliationInfo });
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return response;
        }

        public OperationResult ResgisterLogDomiciliation(string xmlInfoDomiciliation)
        {
            if (string.IsNullOrEmpty(xmlInfoDomiciliation)) { throw new Exception("La informacion del log no puede ser nula."); }

            var result = new OperationResult() { Successful = true };

            try
            {
                _repositoryRetail.InsertLogDomiciliation(xmlInfoDomiciliation);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al insertar el log del conector");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return result;
        }

        private string TransformLogTransactionXml(DomiciliationOnDemand domiInfo, ConnectorResult result)
        {
            var request = new DomiciliationOnDemandLogRequest
            {
                Code = result.Code,
                Message = result.Message,
                DbInsert = result.DBInsert,
                ContractId = domiInfo.ContractId,
                DomiciliationType = domiInfo.DomiciliationType,
                Amount = domiInfo.Amount,
                PaymentDate = domiInfo.PaymentDate,
                BankAccountTypeId = domiInfo.BankAccountTypeId,
                BankClientId = domiInfo.BankClientId,
                AccountClient = domiInfo.AccountClient,
                CoverContribution = domiInfo.CoverContribution,
                ExistDomiciliation = domiInfo.ExistDomiciliation,
                UserId = domiInfo.UserId,
                DateTranssaction = DateTime.Now,
                Successful = result.Code > 0 ? false : true
            };

            return _transform.ObjectToXml(request);
        }

        public DomiciliationAllowAmounts GetAllowAmountsMinMax(int domiciliationType, out OperationResult result)
        {
            if (domiciliationType <= 0) { throw new ArgumentException(nameof(domiciliationType)); }

            result = new OperationResult() { Successful = true };
            DomiciliationAllowAmounts allowAmounts = null;

            try
            {
                allowAmounts = _domiciliationRepository.GetAllowAmounts(domiciliationType);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return allowAmounts;
        }


        public decimal GetPorcentageComission(string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            result = new OperationResult() { Successful = true };
            var comission = 0.0M;

            try
            {
                _log.Info("Obteniendo el porcentaje de comision para la aportacion.");
                comission = _domiciliationRepository.GetPorcentageComission(contractId);
                _log.Debug("Comision: {cntx}", comission);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return comission;
        }

        public GroupingContract GetGroupingContract(string contractId, int platform, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            result = new OperationResult() { Successful = true };
            GroupingContract grouping = null;
            try
            {
                var storeName = platform == 10 ? "usp_SOC_SIIF_RS_GetContratoMaestroDescendencia" : "usp_SOC_SIIF_GT_GetContratoMaestroDescendencia";
                _log.Info("obteniendo los datos agrupadores para la domiciliacion.");
                grouping = _domiciliationRepository.GetGroupingContract(contractId, storeName);
                _log.Debug("Datos agrupamiento: {cntx}", grouping);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return grouping;
        }

        public decimal GetAmountDue(string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            result = new OperationResult() { Successful = true };
            decimal amountDue = 0;
            try
            {
                _log.Info("Obteniendo el monto de las aportaciones vencidas");
                amountDue = _domiciliationRepository.GetAmountDue(contractId);
                _log.Debug("monto aportaciones vencidas: {cntx}", amountDue);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return amountDue;
        }

        public string GetDaysCalendar(int year, out OperationResult result)
        {
            if (year <= 0) { throw new ArgumentOutOfRangeException(nameof(year)); }

            result = new OperationResult() { Successful = true };
            string daysCalendar = string.Empty;
            try
            {
                _log.Info("Obteniendo los dias registrados en el calendario de SIIF");
                daysCalendar = _domiciliationRepository.GetDaysCalendar(year);
                _log.Debug("Calendario: {cntx}", daysCalendar);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return daysCalendar;
        }

        public bool HasProgrammedPayment(string clientId, string contractId, out OperationResult result)
        {
            if (string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }

            Boolean hasProgrammedPayment = false;
            result = new OperationResult() { Successful = true };
            try
            {
                _log.Info("Obteniendo si cliente ya ha realizado el pago.");
                hasProgrammedPayment = _domiciliationRepository.HasProgrammedPaymentContribution(clientId, contractId);
                _log.Debug("Valor obtenido: {cntx}", hasProgrammedPayment);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return hasProgrammedPayment;
        }

        public List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier, out OperationResult result)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException(nameof(contractId)); }
            if (string.IsNullOrEmpty(clientIdentifier)) { throw new ArgumentException(nameof(clientIdentifier)); }

            result = new OperationResult() { Successful = true };
            var clientDomiciliations = new List<ClientDomiciliation>();
            try
            {
                clientDomiciliations = _repositoryRetail.GetDomiciliationsByContract(contractId, clientIdentifier);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un problema al consumir el store.");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return clientDomiciliations;
        }

        public List<BankCatalog> GetBankCatalogsCatalog(out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            var lstBankCatalogs = new List<BankCatalog>();

            try
            {
                lstBankCatalogs = _repositoryRetail.GetBanksCatalog();
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener el catalogo de bancos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage { Message = ex.Message });
            }

            return lstBankCatalogs;
        }
    }
}
