﻿using Common.Domain;
using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using System.Collections.Generic;

namespace DomiciliationContract.Message
{
    public class GetDomiciliationsByContractResponse
    {
        public List<ClientDomiciliation> Domiciliation { get; set; }

        public OperationResult Result { get; set; } = new OperationResult();
    }
}
