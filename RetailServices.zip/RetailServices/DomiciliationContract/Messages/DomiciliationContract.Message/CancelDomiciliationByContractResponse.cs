﻿using Common.Domain;

namespace DomiciliationContract.Message
{
    public class CancelDomiciliationByContractResponse
    {
        public OperationResult Result;
    }
}
