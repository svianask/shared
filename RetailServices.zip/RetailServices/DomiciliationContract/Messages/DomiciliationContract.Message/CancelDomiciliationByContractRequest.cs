﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class CancelDomiciliationByContractRequest
    {
        public string ContractId { get; set; }
    }
}
