﻿using DomiciliationContract.Domain.ConnectorResultAggregate;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class DomiciliationOnDemandLogRequest
    {
        public int Code;
        public string Message;
        public string DbInsert;
        public string ContractId;
        public int DomiciliationType;
        public double Amount;
        public DateTime PaymentDate;
        public int BankAccountTypeId;
        public int BankClientId;
        public string AccountClient;
        public bool CoverContribution;
        public bool ExistDomiciliation;
        public string UserId;
        public bool Successful { get; set; }
        public DateTime DateTranssaction { get; set; }
    }
}
