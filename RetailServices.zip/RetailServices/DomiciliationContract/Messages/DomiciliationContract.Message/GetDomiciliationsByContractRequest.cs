﻿namespace DomiciliationContract.Message
{
    public class GetDomiciliationsByContractRequest
    {
        public string ClientIdentifier { get; set; } = string.Empty;
        public string ContractId { get; set; } = string.Empty;
    }
}
