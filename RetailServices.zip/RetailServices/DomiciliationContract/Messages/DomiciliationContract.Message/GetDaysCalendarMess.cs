﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class GetDaysCalendarResponse
    {
        public string DaysCalendar;
        public OperationResult Result;
    }

    public class GetDaysCalendarRequest
    {
        public int YearConsult;
    }
}
