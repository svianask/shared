﻿using Common.Domain;
using DomiciliationContract.Domain.AllowAmountsAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class GetAllowAmountsRequest
    {
        public int DomiciliationType;
    }


    public class GetAllowAmountsResponse
    {
        public OperationResult Result;
        public DomiciliationAllowAmounts AllowAmounts;
    }
}
