﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class LogConnetorDomiResponse
    {
        public OperationResult Result { get; set; }

        public LogConnetorDomiResponse() { Result = new OperationResult(); }
    }
}
