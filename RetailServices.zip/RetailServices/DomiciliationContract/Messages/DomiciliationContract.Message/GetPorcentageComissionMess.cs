﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class GetPorcentageComissionRequest
    {
        public string ContractId;
    }

    public class GetPorcentageComissionResponse
    {
        public decimal PorcentageCommision;
        public OperationResult Result;
    }
}
