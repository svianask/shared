﻿using Common.Domain;
using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using System.Collections.Generic;

namespace DomiciliationContract.Message
{
    public class GetBanksCatalogResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();
        public List<BankCatalog> Banks { get; set; } = new List<BankCatalog>();
    }
}
