﻿using Common.Domain;
using DomiciliationContract.Domain.GroupingContractAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class GetGroupingContractResponse
    {
        public OperationResult Result;
        public GroupingContract ContractsGrouping;
    }

    public class GetGroupingContractRequest
    {
        public string ContractId;
        public int Platform;
    }
}
