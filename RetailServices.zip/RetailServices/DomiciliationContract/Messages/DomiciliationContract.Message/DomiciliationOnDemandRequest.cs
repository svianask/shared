﻿using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class DomiciliationOnDemandRequest
    {
        public DomiciliationOnDemand DomiciliationInfo { get; set; }
        
        public DomiciliationOnDemandRequest() { }
    }
}
