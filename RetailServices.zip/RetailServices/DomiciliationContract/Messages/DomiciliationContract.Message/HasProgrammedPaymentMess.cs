﻿using Common.Domain;
using System;
namespace DomiciliationContract.Message
{
    public class HasProgrammedPaymentRequest
    {
        public string ClientId;
        public string ContractId;
    }

    public class HasProgrammedPaymentResponse
    {
        public Boolean HasProgrammedPaymentContribution;
        public OperationResult Result;
    }
}
