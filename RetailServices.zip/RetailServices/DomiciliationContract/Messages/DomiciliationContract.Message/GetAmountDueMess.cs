﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class GetAmountDueResponse
    {
        public decimal AmountDue;
        public OperationResult Result;
    }

    public class GetAmountDueRequest
    {
        public string ContractId;
    }
}
