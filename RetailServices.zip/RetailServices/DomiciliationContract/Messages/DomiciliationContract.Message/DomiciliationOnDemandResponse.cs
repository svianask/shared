﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Message
{
    public class DomiciliationOnDemandResponse
    {
        public OperationResult Result { get; set; }
        public string XmlResult { get; set; }
        public DomiciliationOnDemandResponse() { Result = new OperationResult(); }
    }
}
