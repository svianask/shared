﻿using DomiciliationContract.Domain.AllowAmountsAggregate;
using DomiciliationContract.Domain.ConnectorResultAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Mapping
{
    public class DomiciliationContractMap
    {
        public static ConnectorResult ResultConnectorMapping(DataSet dsConnector)
        {
            var code = dsConnector.Tables[0].Rows[0]["Code"] != DBNull.Value ? int.Parse(dsConnector.Tables[0].Rows[0]["Code"].ToString()) : 0;
            var message = dsConnector.Tables[0].Rows[0]["MessageError"] != DBNull.Value ? dsConnector.Tables[0].Rows[0]["MessageError"].ToString() : string.Empty;
            var dbInsert = dsConnector.Tables[0].Rows[0]["DBInsert"] != DBNull.Value ? dsConnector.Tables[0].Rows[0]["DBInsert"].ToString() : string.Empty;
            return new ConnectorResult(code, message, dbInsert);
        }

        public static DomiciliationAllowAmounts AllowAmountsMapping(DataSet ds)
        {
            var amountMin = ds.Tables[0].Rows[0]["Tipo_Domiciliacion_Importe_Minimo_Permitido"] != DBNull.Value ? decimal.Parse(ds.Tables[0].Rows[0]["Tipo_Domiciliacion_Importe_Minimo_Permitido"].ToString()) : decimal.MinValue;
            var amountMan = ds.Tables[0].Rows[0]["Tipo_Domiciliacion_ImporteMaximo"] != DBNull.Value ? decimal.Parse(ds.Tables[0].Rows[0]["Tipo_Domiciliacion_ImporteMaximo"].ToString()) : decimal.MaxValue;

            return DomiciliationAllowAmounts.Create(amountMin, amountMan);
        }
    }
}
