﻿using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace DomiciliationContract.Mapping
{
    public static class ClientDomiciliationMapp
    {
        public static List<ClientDomiciliation> Mapp(string contractId, DataSet ds)
        {
            var clientDomiciliations = new List<ClientDomiciliation>();
            if (ds.Tables.Count <= 0 || ds.Tables[0].Rows.Count <= 0)
                return clientDomiciliations;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                var domiciliationId = Convert.ToInt32(dr["Domiciliacion_Id"]);
                var startDate = Convert.ToDateTime(dr["Domiciliacion_Fecha_Inicio"].ToString());
                var nextPaymentDate = Convert.ToDateTime(dr["Domiciliacion_Fecha_Cobro"].ToString());
                var accountTypeId = Convert.ToInt16(dr["Tipo_CtaBanco_Id"]);
                var accountType = dr["Tipo_CtaBanco_Dsc_Corta"].ToString();
                var bankId = Convert.ToInt16(dr["Banco_Id_Cliente"]);
                var bankName = dr["Banco_Dsc"].ToString();
                var accountNumber = dr["Cuenta_Id_Cliente"].ToString();
                var amount = Convert.ToDecimal(dr["Domiciliacion_Importe"]);
                var payday = Convert.ToInt16(dr["Domiciliacion_Dia_Especifico"]);
                var frequencyTypeId = Convert.ToInt16(dr["Tipo_Frecuencia_Id"]);
                var frequencyType = dr["Tipo_Frecuencia_Dsc_Corta"].ToString();
                var origin = dr["Origen"].ToString();
                clientDomiciliations.Add(ClientDomiciliation.Create(domiciliationId, contractId)
                    .SetBankAccountInfo(bankId, bankName, accountTypeId, accountType, accountNumber)
                    .SetConfigInfo(startDate, amount, payday, frequencyTypeId, frequencyType, nextPaymentDate)
                    .SetOrigen(origin));
            }
            return clientDomiciliations;
        }
    }
}
