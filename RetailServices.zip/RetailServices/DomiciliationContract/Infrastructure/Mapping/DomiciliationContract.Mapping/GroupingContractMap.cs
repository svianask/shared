﻿using DomiciliationContract.Domain.GroupingContractAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ValidateH;

namespace DomiciliationContract.Mapping
{
    public class GroupingContractMap
    {
        public static GroupingContract Map(DataSet dsContract)
        {
            GroupingContract grouping = null;

            if (dsContract != null && dsContract.Tables.Count > 0 && dsContract.Tables[0].Rows.Count > 0)
            {
                var productId = int.Parse(ValidateNull.SetNull(dsContract.Tables[0].Rows[0]["producto_id"].ToString(), 0).ToString());
                var grouperContractIdentifier = (String)ValidateNull.SetNull(dsContract.Tables[0].Rows[0]["contrato_agrupador"].ToString(), string.Empty);
                var grouperPlanId = int.Parse(ValidateNull.SetNull(dsContract.Tables[0].Rows[0]["plan_agrupador"], 0).ToString());
                var contributionContractId = (String)ValidateNull.SetNull(dsContract.Tables[0].Rows[0]["contrato_aportaciones"].ToString(), string.Empty);
                var additionalContractId = (String)ValidateNull.SetNull(dsContract.Tables[0].Rows[0]["contrato_adiciones"].ToString(), string.Empty);
                var warningMessage = (String)ValidateNull.SetNull(dsContract.Tables[0].Rows[0]["mensaje_wrn"].ToString(), string.Empty);

                grouping = GroupingContract.Craete(productId, grouperContractIdentifier, grouperPlanId)
                    .SetDomiciliationContracts(contributionContractId, additionalContractId)
                    .SetMessage(warningMessage);
            }

            return grouping;
        }
    }
}
