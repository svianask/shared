﻿using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using System;
using System.Collections.Generic;
using System.Data;

namespace DomiciliationContract.Mapping
{
    public static class BankCatalogMapp
    {
        public static List<BankCatalog> MappList(DataSet dsBanks)
        {
            var lstBanks = new List<BankCatalog>();
            foreach (DataRow row in dsBanks.Tables[0].Rows)
            {
                var id = Convert.ToInt16(row["Banco_Id"].ToString());
                var description = row["Banco_Dsc"].ToString();
                var descrShort = row["Banco_Dsc_Corta"].ToString();

                var bank = BankCatalog.Create(id, description, descrShort);
                lstBanks.Add(bank);
            }
            return lstBanks;
        }
    }
}
