﻿using DomiciliationContract.Domain.AllowAmountsAggregate;
using DomiciliationContract.Domain.GroupingContractAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Repository
{
    public interface IDomiciliationContratRepository
    {
        DomiciliationAllowAmounts GetAllowAmounts(int domiciliationType);
        decimal GetPorcentageComission(string contractId);
        GroupingContract GetGroupingContract(string contractId, string storeName);
        decimal GetAmountDue(string contractId);
        string GetDaysCalendar(int year);
        Boolean HasProgrammedPaymentContribution(string clientId, string contractId);
    }
}
