﻿using DomiciliationContract.Domain.AllowAmountsAggregate;
using DomiciliationContract.Domain.GroupingContractAggregate;
using DomiciliationContract.Mapping;
using SqlClient.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using ValidateH;

namespace DomiciliationContract.Repository
{
    public class DomiciliationContratRepository : IDomiciliationContratRepository
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public DomiciliationContratRepository([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            _dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public DomiciliationAllowAmounts GetAllowAmounts(int domiciliationType)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_ACL_SIIF_GetMontoAportacionMinimaMaxima", _dbConn);
            cmd.AddParameterWithValue("@tipodomiciliacion", domiciliationType);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return DomiciliationContractMap.AllowAmountsMapping(ds);
        }


        public decimal GetPorcentageComission(string contractId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_GetPorcentajeComisionAportaciones", _dbConn);
            cmd.AddParameterWithValue("@contratoId", contractId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ds.Tables[0].Rows[0]["Plan_Nivel_Posicion_Comision"] != DBNull.Value ? decimal.Parse(ds.Tables[0].Rows[0]["Plan_Nivel_Posicion_Comision"].ToString()) : decimal.MinValue;
        }

        public GroupingContract GetGroupingContract(string contractId, string storeName)
        {
            DataSet dsFinal = new DataSet();
            IDbCommand cmd;
            cmd = _sqlClientHelper.CreateCmdSP(storeName, _dbConn);
            cmd.AddParameterWithValue("@contractId", contractId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            var dt = ds.Tables[0].Clone();
            var rows = ds.Tables[0].Select("producto_id='10'");

            foreach (DataRow item in rows)
            {
                dt.ImportRow(item);
            }
            dsFinal.Tables.Add(dt);

            return GroupingContractMap.Map(dsFinal);
        }

        public decimal GetAmountDue(string contractId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_GetContratoAportacionesVencidas", _dbConn);
            cmd.AddParameterWithValue("@contratoId", contractId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            var amount = 0M;
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                amount = Convert.ToDecimal(ValidateNull.SetNull(ds.Tables[0].Rows[0][0], 0M));
            }
            return amount;
        }

        public string GetDaysCalendar(int year)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIF_GetDiasCalendario", _dbConn);
            cmd.AddParameterWithValue("@year", year);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ds.Tables[0].Rows[0]["Calendario_Dias"] != DBNull.Value ? ds.Tables[0].Rows[0]["Calendario_Dias"].ToString() : string.Empty;
        }

        public Boolean HasProgrammedPaymentContribution(string clientId, string contractId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SOC_SIIF_HasProgrammedPaymentContribution", _dbConn);
            cmd.AddParameterWithValue("@clientId", clientId);
            cmd.AddParameterWithValue("@contractId", contractId);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return ds.Tables[0].Rows[0]["HasProgrammedPayment"] != DBNull.Value ? Convert.ToBoolean( ds.Tables[0].Rows[0]["HasProgrammedPayment"] ): false;

        }

        
    }
}
