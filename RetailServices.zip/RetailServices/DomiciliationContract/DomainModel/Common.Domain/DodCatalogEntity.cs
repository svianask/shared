﻿using System.Collections.Generic;

namespace DomiciliationContract.Common.Domain
{
    public class DodCatalogEntity
    {

        public DodCatalogEntity()
        {
            Identifier = string.Empty;
            Name = string.Empty;
        }

        public string Identifier { get; set; }

        public string Name { get; set; }

        public IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Identifier,
                Name
            };
        }
    }
}
