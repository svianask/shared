﻿using System.Collections.Generic;

namespace DomiciliationContract.Common.Domain
{
    public class DodOperationResult
    {
        public DodOperationResult()
        {
            SystemMessages = new List<DodSystemMessage>();
        }

        public bool Successful { get; set; }

        public List<DodSystemMessage> SystemMessages { get; set; }

        public IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                SystemMessages
            };
        }
    }
}
