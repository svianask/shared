﻿using System.Collections.Generic;

namespace DomiciliationContract.Common.Domain
{
    public class DodSystemMessage
    {
        public DodSystemMessage()
        {
            MessageType = SystemMessageTypes.Information;
            Message = string.Empty;
        }

        public SystemMessageTypes MessageType { get; set; }
        public string Message { get; set; }

        public IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                MessageType,
                Message
            };
        }
    }

    public enum SystemMessageTypes
    {
        Information = 0, Warning, Error
    }
}
