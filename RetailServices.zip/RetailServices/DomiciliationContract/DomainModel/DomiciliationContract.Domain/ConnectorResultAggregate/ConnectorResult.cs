﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Domain.ConnectorResultAggregate
{
    public class ConnectorResult : ValueObject<ConnectorResult>
    {
        private readonly int _code;
        private readonly string _message;
        private readonly string _dbInsert;

        public ConnectorResult(int code, string message, string dbInsert)
        {
            if (string.IsNullOrEmpty(dbInsert)){ throw new ArgumentException("La base de datos de insercion no puede ser nula."); }

            _code = code;
            _message = message;
            _dbInsert = dbInsert;
        }

        public int Code => _code;
        public string Message => _message;
        public string DBInsert => _dbInsert;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                Code,
                Message,
                DBInsert
            };
        }
    }
}
