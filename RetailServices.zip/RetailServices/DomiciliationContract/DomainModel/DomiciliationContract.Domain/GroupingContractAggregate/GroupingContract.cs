﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Domain.GroupingContractAggregate
{
    public class GroupingContract : ValueObject<GroupingContract>
    {
        private int _productId;
        private string _grouperContractIdentifier;
        private int _grouperPlanId;
        private string _contributionContractId;
        private string _additionalContractId;
        private string _warningMessage;

        private GroupingContract(int productId, string grouperContractIdentifier, int grouperPlanId)
        {
            _productId = productId;
            _grouperContractIdentifier = grouperContractIdentifier;
            _grouperPlanId = grouperPlanId;
        }

        public static GroupingContract Craete(int productId, string grouperContractIdentifier, int grouperPlanId)
        {
            return new GroupingContract(productId, grouperContractIdentifier, grouperPlanId);
        }

        public GroupingContract SetDomiciliationContracts(string contributionContractId, string additionalContractId)
        {
            _contributionContractId = contributionContractId;
            _additionalContractId = additionalContractId;
            return this;
        }

        public GroupingContract SetMessage(string message)
        {
            _warningMessage = message;
            return this;
        }

        public int ProductId => _productId;
        public string GrouperContractIdentifier => _grouperContractIdentifier;
        public int GrouperPlanId => _grouperPlanId;
        public string ContributionContractId => _contributionContractId;
        public string AdditionalContractId => _additionalContractId;
        public string WarningMessage => _warningMessage;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
