﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Domain.AllowAmountsAggregate
{
    public class DomiciliationAllowAmounts : ValueObject<DomiciliationAllowAmounts>
    {
        private decimal _amountMimimun;
        private decimal _amounteMaximun;
        private DomiciliationAllowAmounts(decimal amountMimimun, decimal amounteMaximun)
        {
            _amountMimimun = amountMimimun;
            _amounteMaximun = amounteMaximun;
        }

        public decimal AmountMinimun => _amountMimimun;
        public decimal AmountMaximun => _amounteMaximun;

        public static DomiciliationAllowAmounts Create(decimal amountMin, decimal amountMax)
        {
            return new DomiciliationAllowAmounts(amountMin, amountMax);
        }
        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            throw new NotImplementedException();
        }
    }
}
