﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.Domain.DomiciliationOnDemandAggregate
{
    public class DomiciliationOnDemand : ValueObject<DomiciliationOnDemand>
    {
        private readonly string _contractId;
        private readonly int _domiciliationType;
        private readonly double _amount;
        private readonly DateTime _paymentDate;
        private readonly int _bankAccountTypeId;
        private readonly int _bankClientId;
        private readonly string _accountClient;
        private readonly bool _coverContribution;
        private readonly bool _existDomiciliation;
        private readonly string _userId;

        public DomiciliationOnDemand(string contractId, int domiciliationType, double amount, DateTime paymentDate, int bankAccountTypeId,
            int bankClientId, string accountClient, bool coverContribution, bool existDomiciliation, string userId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("ContractId no puede ser nulo o vacio"); }
            if(domiciliationType < 1) { throw new ArgumentException("DomiciliationType debe de ser valido"); }
            if(amount <= 0) { throw new ArgumentException("El monto debe ser mayor a 0"); }
            if(bankAccountTypeId < 1) { throw new ArgumentException("BankAccountType no es valido"); }
            if(bankClientId < 1) { throw new ArgumentException("BankClientId no es valido"); }
            if (string.IsNullOrEmpty(accountClient)) { throw new ArgumentException("AccountClient no puede ser nulo o vacio"); }
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("UserId no puede ser nulo o vacio"); }

            _contractId = contractId;
            _domiciliationType = domiciliationType;
            _amount = amount;
            _paymentDate = paymentDate;
            _bankAccountTypeId = bankAccountTypeId;
            _bankClientId = bankClientId;
            _accountClient = accountClient;
            _coverContribution = coverContribution;
            _existDomiciliation = existDomiciliation;
            _userId = userId;
        }

        public string ContractId => _contractId;
        public int DomiciliationType => _domiciliationType;
        public double Amount => _amount;
        public DateTime PaymentDate => _paymentDate;
        public int BankAccountTypeId => _bankAccountTypeId;
        public int BankClientId => _bankClientId;
        public string AccountClient => _accountClient;
        public bool CoverContribution => _coverContribution;
        public bool ExistDomiciliation => _existDomiciliation;
        public string UserId => _userId;

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                ContractId,
                DomiciliationType,
                Amount,
                PaymentDate,
                BankAccountTypeId,
                BankClientId,
                AccountClient,
                CoverContribution,
                ExistDomiciliation,
                UserId
            };
        }
    }
}
