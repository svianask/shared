﻿using Ddd;
using System;

namespace DomiciliationContract.Domain.ClientDomiciliationAggregate
{
    public class BankCatalog : Entity<short>
    {
        private BankCatalog(short bankId, string description, string descriptionShort)
        {
            Id = bankId;
            Description = description;
            DescriptionShort = descriptionShort;
        }

        public string Description { get; }
        public string DescriptionShort { get; }

        public static BankCatalog Create(short bankId, string description, string descriptionShort)
        {
            if (bankId == 0) { throw new ArgumentException("El identificador del banco no puede ser nulo."); }
            if (string.IsNullOrEmpty(description)) { throw new ArgumentException("La descripcion del banco no pueder ir vacia."); }
            if (string.IsNullOrEmpty(descriptionShort)) { throw new ArgumentException("La descripcion corta del banco no pueder ir vacia."); }

            return new BankCatalog(bankId, description, descriptionShort);
        }
    }
}
