﻿using Ddd;
using System;
using System.Collections.Generic;

namespace DomiciliationContract.Domain.ClientDomiciliationAggregate
{
    public class ClientDomiciliation : ValueObject<ClientDomiciliation>
    {
        public int DomiciliationId { get; }
        public string ContractId { get; }
        public DateTime StartDate { get; private set; }
        public DateTime NextPaymentDate { get; private set; }
        public short AccountTypeId { get; private set; }
        public string AccountType { get; private set; } = string.Empty;
        public short BankId { get; private set; }
        public string BankName { get; private set; } = string.Empty;
        public string AccountNumber { get; private set; } = string.Empty;
        public decimal Amount { get; private set; }
        public short Payday { get; private set; }
        public short FrequencyTypeId { get; private set; }
        public string FrequencyType { get; private set; } = string.Empty;
        public string Origin { get; set; } = string.Empty;

        protected ClientDomiciliation(int domiciliationId, string contractId)
        {
            DomiciliationId = domiciliationId;
            ContractId = contractId;
        }

        public static ClientDomiciliation Create(int domiciliationId, string contractId)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("contractId no puede ser nulo o vacío."); }
            return new ClientDomiciliation(domiciliationId, contractId);
        }

        public ClientDomiciliation SetBankAccountInfo(short bankId, string bankName, short accountTypeId, string accountType, string accountNumber)
        {
            BankId = bankId;
            BankName = bankName;
            AccountTypeId = accountTypeId;
            AccountType = accountType;
            AccountNumber = accountNumber;
            return this;
        }

        public ClientDomiciliation SetConfigInfo(DateTime startDate, decimal amount, short payday, short frequencyTypeId, string frequencyType, DateTime nextPaymentDate)
        {
            StartDate = startDate;
            Amount = amount;
            Payday = payday;
            FrequencyTypeId = frequencyTypeId;
            FrequencyType = frequencyType;
            NextPaymentDate = nextPaymentDate;
            return this;
        }

        public ClientDomiciliation SetOrigen(string origin)
        {
            Origin = origin;
            return this;
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                DomiciliationId,
                ContractId,
                AccountTypeId,
                BankId,
                AccountNumber,
                FrequencyTypeId
            };
        }
    }
}
