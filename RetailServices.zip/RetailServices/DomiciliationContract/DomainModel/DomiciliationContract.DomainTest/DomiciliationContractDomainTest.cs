﻿using DomiciliationContract.Domain.ConnectorResultAggregate;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomiciliationContract.DomainTest
{
    [TestClass]
    public class DomiciliationContractDomainTest
    {
        [TestMethod, TestCategory("DomiciliationOnDemand")]
        [DataRow("", 1, 200, 1, 1, "12345678", "USER")]
        [DataRow("908890", 0, 200, 1, 1, "12345678", "USER")]
        [DataRow("908890", 1, 0, 1, 1, "12345678", "USER")]
        [DataRow("908890", 1, 200, 0, 1, "12345678", "USER")]
        [DataRow("908890", 1, 200, 1, 0, "12345678", "USER")]
        [DataRow("908890", 1, 200, 1, 1, "", "USER")]
        [DataRow("908890", 1, 200, 1, 1, "12345678", "")]
        public void DomiciliationOnDemandError(string contractId, int domiType, double mount, int bankTypeId, int bankClientId, 
            string accountClient, string userId)
        {
            var _date = DateTime.Now;
            Assert.ThrowsException<ArgumentException>(() => new DomiciliationOnDemand(contractId, domiType, mount, _date, bankTypeId,
                bankClientId, accountClient, true, true, userId));
        }

        [TestMethod, TestCategory("DomiciliationOnDemand")]
        [DataRow("900876", 1, 200, 1, 1, "12345678", "USER")]
        public void DomiciliationOnDemandSuccess(string contractId, int domiType, double mount, int bankTypeId, int bankClientId,
            string accountClient, string userId)
        {
            var _date = DateTime.Now;
            var domiObject = new DomiciliationOnDemand(contractId, domiType, mount, _date, bankTypeId,
                bankClientId, accountClient, true, true, userId);

            Assert.IsNotNull(domiObject);
            Assert.AreEqual(contractId, domiObject.ContractId);
            Assert.AreEqual(domiType, domiObject.DomiciliationType);
            Assert.AreEqual(mount, domiObject.Amount);
            Assert.AreEqual(bankTypeId, domiObject.BankAccountTypeId);
            Assert.AreEqual(bankClientId, domiObject.BankClientId);
            Assert.AreEqual(accountClient, domiObject.AccountClient);
            Assert.AreEqual(userId, domiObject.UserId);
        }

        [TestMethod, TestCategory("ConnectorResult")]
        public void ConnectorResultError()
        {
            Assert.ThrowsException<ArgumentException>(() => new ConnectorResult(1, "", ""));
        }

        [TestMethod, TestCategory("ConnectorResult")]
        public void ConnectorResultSuccess()
        {
            var response = new ConnectorResult(1, "MESSAGE", "DBINSERT");

            Assert.AreEqual(1, response.Code);
            Assert.AreEqual("MESSAGE", response.Message);
            Assert.AreEqual("DBINSERT", response.DBInsert);
        }
    }
}
