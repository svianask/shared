﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ClientDataDomain.StateAddressAggregate
{
    public class StateAddress : Entity<int>
    {
        private readonly string _name = string.Empty;

        public string Name => _name;

        private StateAddress(int stateId,String name) {
            if( stateId  < 0) { throw new Exception("StateId can't be null."); }
            if ( stateId < 1 &&  String.IsNullOrEmpty(name)) { throw new Exception("Name can't be null."); }
            Id = stateId;
            _name = name;
        }

        public static StateAddress Create(int stateId,String name) {
            return new StateAddress(stateId,name);
        }

    }
}
