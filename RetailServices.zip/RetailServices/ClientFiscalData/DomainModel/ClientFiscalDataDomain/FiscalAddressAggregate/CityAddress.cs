﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientDataDomain.CityAddressAggregate
{
    public class CityAddress : Entity<int>
    {
        private readonly string _name = string.Empty;

        public string Name => _name;

        private CityAddress(int cityId, String name)
        {
            if (cityId == 0) { throw new Exception("CityId can't be null."); }
            Id = cityId;
            _name = name;
        }

        public static CityAddress Create(int cityId, String name)
        {
            return new CityAddress(cityId,name);
        }
    }
}
