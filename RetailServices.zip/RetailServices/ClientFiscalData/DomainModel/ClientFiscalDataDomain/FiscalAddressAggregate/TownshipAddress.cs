﻿using ClientDataDomain.CityAddressAggregate;
using ClientDataDomain.StateAddressAggregate;
using Ddd;
using System;


namespace ClientDataDomain.TownshipAddressAggregate
{
    public class TownshipAddress:Entity<int>
    {
        private readonly string _townshipName;
        private StateAddress _state;
        private CityAddress _city;

        public string TownshipName => _townshipName;

        public StateAddress State => _state;

        public CityAddress City => _city;

        private TownshipAddress( int townshipId, string townshipname, StateAddress state, CityAddress city)
        {
            if( String.IsNullOrEmpty(townshipname)) { throw new Exception("TownshiptName can't be null."); }
            Id = townshipId; //Can be null the first time, because in SIIF* is saved just the name
            _townshipName = townshipname;
            _city = city;
            _state = state; 
        }

        public static TownshipAddress Create(int townshipId, String townshipname, StateAddress state, CityAddress city)
        {
            return new TownshipAddress(townshipId, townshipname, state, city);
        }

    }
}


