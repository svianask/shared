﻿using System;

namespace ClientFiscalDataDomain.DTO
{
    public class FiscalDataUpdateDTO
    {
        public string Names = string.Empty;
        public string PaternalSurname = String.Empty;
        public string MaternalSurname = String.Empty;
        public string RoadName = String.Empty;
        public string Curp = String.Empty;
        public string ZipCode = String.Empty;
        public string StateName = String.Empty;
        public int StateId;
        public string CityName = String.Empty;
        public int CityId;
        public string TownshipName = String.Empty;
        public int TownshipId;
        public string ClientId = String.Empty;
        public string Channel = String.Empty;

    }
}
