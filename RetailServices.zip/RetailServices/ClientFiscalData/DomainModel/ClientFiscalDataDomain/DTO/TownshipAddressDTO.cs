﻿using System;

namespace ClientFiscalDataDomain.DTO
{
    public class TownshipAddressDTO
    {
        public int Id;
        public String Name;

        public TownshipAddressDTO(int Id, String Name)
        {
            this.Id = Id;
            this.Name = Name;
        }
    }
}
