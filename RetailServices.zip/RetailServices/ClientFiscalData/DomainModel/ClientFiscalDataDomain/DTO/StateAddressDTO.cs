﻿using System;
using System.Collections.Generic;


namespace ClientFiscalDataDomain.DTO
{
    public  class StateAddressDTO
    {
        public int Id;
        public String Name;
    
        public StateAddressDTO(int Id, String Name) {
            this.Id = Id;
            this.Name = Name;
        }
    }
}
