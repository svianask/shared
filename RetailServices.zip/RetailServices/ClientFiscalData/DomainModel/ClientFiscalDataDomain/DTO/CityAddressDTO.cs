﻿using System;

namespace ClientFiscalDataDomain.DTO
{
    public class CityAddressDTO
    {
        public int Id;
        public String Name;
        
        public CityAddressDTO( int Id, String Name)
        {
            this.Id = Id;
            this.Name = Name;
        }
    }
}
