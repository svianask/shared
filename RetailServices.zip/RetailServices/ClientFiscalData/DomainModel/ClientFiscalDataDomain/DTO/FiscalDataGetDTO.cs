﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFiscalDataDomain.DTO
{
    public class FiscalDataGetDTO
    {
        public PersonalDataGetDTO PersonalData;
        public String ZipCode;
        public int CityId;
        public String CityName;
        public int StateId;
        public String StateName;
        public String TownshipName;
        public DateTime UpdatedDate;
    }
}
