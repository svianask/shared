﻿using System;

namespace ClientFiscalDataDomain.DTO
{
    public class TownshipAddressGetDTO
    {
        public int Id;
        public String TownshipName;
        public StateAddressDTO State;
        public CityAddressDTO City;

        public TownshipAddressGetDTO(int Id, String TownshipName, StateAddressDTO State, CityAddressDTO City) 
        {
            this.Id = Id;
            this.TownshipName = TownshipName;
            this.State = State; 
            this.City = City;
        }

    }
}
