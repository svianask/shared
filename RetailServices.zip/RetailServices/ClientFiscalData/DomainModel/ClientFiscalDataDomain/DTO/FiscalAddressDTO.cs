﻿using System;

namespace ClientFiscalDataDomain.DTO
{
    public class FiscalAddressDTO
    {
        public String ZipCode;
        public String Street;
        public TownshipAddressGetDTO TownshipAddress;

        public FiscalAddressDTO(String ZipCode,  TownshipAddressGetDTO TownshipAddress) { 
            this.ZipCode = ZipCode;
            this.TownshipAddress = TownshipAddress;
        }

    }
}
