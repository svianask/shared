﻿
namespace ClientFiscalDataDomain.DTO
{
    public class PersonalDataGetDTO
    {
        public string RFC;
        public string CURP;
        public string Names;
        public string PaternalSurname;
        public string MaternalSurname;
        public string RoadName;
    }
}
