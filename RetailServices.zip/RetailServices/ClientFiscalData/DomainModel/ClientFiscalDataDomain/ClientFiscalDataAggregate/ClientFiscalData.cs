﻿using ClientDataDomain.FiscalAddressAggregate;
using ClientFiscalDataDomain.PersonalDataAggregate;
using Ddd;
using System;

namespace ClientFiscalDataDomain.ClientFiscalDataAggregate
{
    public class FiscalData : Entity<string>
    {
        private string _clientId = string.Empty;
        private PersonalData _personalData;
        private FiscalAddress _address;
        private DateTime _updatedDate;

        public PersonalData PersonalData { get => _personalData; }
        public FiscalAddress Address { get => _address; set => _address = value; }
        public DateTime UpdatedDate { get => _updatedDate; set => _updatedDate = value; }

        private FiscalData( String clientId, PersonalData personalData, DateTime updateDate, FiscalAddress address)
        {
            Id = clientId;
            if (personalData == null) { throw new ArgumentException("PersonalData no puede ser nulo."); }
            _personalData = personalData;
            _updatedDate = updateDate;
            _address = address;
        }

        public static FiscalData Create(String clientId, PersonalData personalData, DateTime updateDate, FiscalAddress address)
        {
            return new FiscalData( clientId, personalData, updateDate, address);
        }
    }
}
