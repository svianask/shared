﻿using Ddd;
using System;
using System.Collections.Generic;


namespace ClientFiscalDataDomain.PersonalDataAggregate
{
    public class PersonalData : ValueObject<PersonalData>
    {
        private readonly string _rfc = String.Empty;
        private readonly string _curp = String.Empty;
        private readonly string _names = String.Empty;
        private readonly string _paternalSurname = String.Empty;
        private readonly string _maternalSurname = String.Empty;
        private readonly string _roadName = String.Empty;
        private readonly string _roadNameType = String.Empty;
        private readonly string _innerNumber;
        private readonly string _outerNumber;
        private readonly string _location = String.Empty;
        private readonly string _betweenStreet = String.Empty;

        public String CURP { get => _curp; }
        public String RFC { get => _rfc; }
        public String Names { get => _names; }
        public String PaternalSurname { get => _paternalSurname; }
        public String MaternalSurname { get => _maternalSurname; }
        public String RoadName { get => _roadName; }
        
        private PersonalData(string rfc, string curp, string names, string paternalSurname, string maternalSurname, string roadName)
        {
            _rfc = rfc;
            _curp = curp;
            _names = names;
            _paternalSurname = paternalSurname;
            _maternalSurname = maternalSurname;
            _roadName = roadName;

        }

        public static PersonalData Create(string rfc, string curp, string names, string paternalSurname, string maternalSurname, string roadName)
        {
            return new PersonalData(rfc, curp, names, paternalSurname, maternalSurname, roadName);
        }


        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                CURP,
                RFC,
                Names,
                PaternalSurname,
                MaternalSurname,
                RoadName
            };
        }
    }

}