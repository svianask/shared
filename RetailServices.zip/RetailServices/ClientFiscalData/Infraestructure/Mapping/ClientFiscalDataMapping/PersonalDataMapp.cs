﻿using ClientFiscalDataDomain.DTO;
using ClientFiscalDataDomain.PersonalDataAggregate;

namespace ClientFiscalDataMapping
{
    public class PersonalDataMapp
    {
        public static PersonalDataGetDTO Map(PersonalData pd)
        {
            PersonalDataGetDTO personalDataDto = new PersonalDataGetDTO();

            personalDataDto.RFC = pd.RFC;
            personalDataDto.CURP = pd.CURP;
            personalDataDto.Names = pd.Names;
            personalDataDto.PaternalSurname = pd.PaternalSurname;
            personalDataDto.MaternalSurname = pd.MaternalSurname;
            personalDataDto.RoadName = pd.RoadName;
            return personalDataDto;
        }
    }
}
