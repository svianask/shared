﻿using ClientDataDomain.CityAddressAggregate;
using ClientDataDomain.StateAddressAggregate;
using ClientDataDomain.TownshipAddressAggregate;
using ClientFiscalDataDomain.DTO;
using System;
using System.Collections.Generic;
using System.Data;

namespace ClientFiscalDataMapping
{
    public class TownshipAddressMapp
    {
        public static List<TownshipAddress> Map(DataSet ds)
        {
            List<TownshipAddress> townshipList = new List<TownshipAddress>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                var townshipId = Convert.ToInt32(dr["Id"]);
                var townshipName = dr["TownshipName"].ToString();
                var stateId = Convert.ToInt32(dr["StateId"]);
                var stateName = dr["StateName"].ToString();
                var cityId = Convert.ToInt32(dr["CityId"]);
                var cityName = dr["CityName"].ToString();

                StateAddress state = StateAddress.Create(stateId, stateName);
                CityAddress city = CityAddress.Create(cityId, cityName);

                townshipList.Add(
                        TownshipAddress.Create(townshipId, townshipName, state, city)
                    ); ;
            }
            return townshipList;
        }

        public static List<TownshipAddressGetDTO> Map(List<TownshipAddress> townshipList)
        {
            List<TownshipAddressGetDTO> townshipAddressGetDTO = new List<TownshipAddressGetDTO>();
            townshipList.ForEach((obj) =>
            {

                StateAddressDTO stateAddressDTO = new StateAddressDTO(obj.State.Id, obj.State.Name);
                CityAddressDTO cityAddressDTO = new CityAddressDTO( obj.City.Id, obj.City.Name);
                TownshipAddressGetDTO tmp = new TownshipAddressGetDTO(obj.Id, obj.TownshipName, stateAddressDTO , cityAddressDTO);
                townshipAddressGetDTO.Add(tmp);
            });

            return townshipAddressGetDTO;

        }

        public static TownshipAddress Map(TownshipAddressGetDTO townshipAddressGetDTO)
        {
            TownshipAddress townshipAddress = null;

            if( townshipAddressGetDTO != null )
            {
                var township = townshipAddressGetDTO;
                var state = StateAddress.Create( township.State.Id, township.State.Name);
                var city = CityAddress.Create( township.City.Id, township.City.Name);

                townshipAddress = TownshipAddress.Create(township.Id, township.TownshipName, state, city);
            }

            return townshipAddress;
        }

    }

}
