﻿using ClientDataDomain.CityAddressAggregate;
using ClientDataDomain.FiscalAddressAggregate;
using ClientDataDomain.StateAddressAggregate;
using ClientDataDomain.TownshipAddressAggregate;
using ClientFiscalDataDomain.ClientFiscalDataAggregate;
using ClientFiscalDataDomain.DTO;
using ClientFiscalDataDomain.PersonalDataAggregate;
using System;
using System.Data;
using System.Linq;

namespace ClientFiscalDataMapping
{
    public class FiscalDataMapp
    {
        public static FiscalData Map(DataSet ds)
        {
            FiscalData fiscalData = null;
            DataRow drfiscalInfo = ds.Tables[0].Rows.Count > 0 ? ds.Tables[0].Rows[0] : null;
            if (drfiscalInfo != null)
            {
                var names = drfiscalInfo["Names"].ToString();
                var lastname = drfiscalInfo["Lastname"].ToString();
                var surname = drfiscalInfo["Surname"].ToString();
                var rfc = drfiscalInfo["RFC"].ToString();
                var curp = drfiscalInfo["CURP"].ToString();
                var zipCode = drfiscalInfo["ZipCode"].ToString();
                var roadName = drfiscalInfo["Street"].ToString();
                var stateId = Convert.ToInt32(drfiscalInfo["StateId"]);
                var stateName = drfiscalInfo["StateName"].ToString();
                var cityId = Convert.ToInt32(drfiscalInfo["CityId"]);
                var cityName = drfiscalInfo["CityName"].ToString();
                var townshipId = Convert.ToInt32(drfiscalInfo["TownshipId"]);
                var townshipName = drfiscalInfo["TownshipName"].ToString();
                var updatedDate = Convert.ToDateTime(drfiscalInfo["UpdatedDate"]);


                CityAddress city = CityAddress.Create(cityId, cityName);
                StateAddress state = StateAddress.Create(stateId, stateName);
                TownshipAddress township = TownshipAddress.Create(townshipId, townshipName, state, city);

                FiscalAddress fiscalAddress = FiscalAddress.Create(zipCode, township);

                PersonalData personalData = PersonalData.Create(rfc, curp, names, lastname, surname, roadName);

                fiscalData = FiscalData.Create(rfc, personalData, updatedDate, fiscalAddress);

            }

            return fiscalData;
        }

        public static FiscalDataGetDTO Map( FiscalData obj)
        {
            FiscalDataGetDTO fiscalData = null;

            if(obj != null)
            {
                fiscalData = new FiscalDataGetDTO();
                fiscalData.PersonalData = PersonalDataMapp.Map(obj.PersonalData);
                fiscalData.ZipCode = obj.Address.ZipCode;
                fiscalData.StateId = obj.Address.Township.State.Id;
                fiscalData.StateName = obj.Address.Township.State.Name;
                fiscalData.CityId = obj.Address.Township.City.Id;
                fiscalData.CityName = obj.Address.Township.City.Name;
                fiscalData.TownshipName = obj.Address.Township.TownshipName;
                fiscalData.UpdatedDate = obj.UpdatedDate;
            }

            return fiscalData;
        }

    }
}
