﻿using ClientDataDomain.CityAddressAggregate;
using ClientDataDomain.FiscalAddressAggregate;
using ClientDataDomain.StateAddressAggregate;
using ClientDataDomain.TownshipAddressAggregate;
using ClientFiscalDataDomain.ClientFiscalDataAggregate;
using ClientFiscalDataDomain.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientFiscalDataMapping
{
    public class FiscalAddressMapp
    {
        public static FiscalAddress Map(FiscalAddressDTO dto)
        {
            FiscalAddress fiscalAddress = null;
            if (dto != null)
            {

                TownshipAddress townshipAddress = TownshipAddressMapp.Map(dto.TownshipAddress);


                fiscalAddress = FiscalAddress.Create(dto.ZipCode, townshipAddress);
            }

            return fiscalAddress;
        }

        public static FiscalAddressDTO Map(FiscalAddress obj)
        {
            FiscalAddressDTO fiscalAddressDTO = null;
            if (obj != null)
            {
                TownshipAddress townshipAddress = obj.Township;
                CityAddress cityAddress = obj.Township.City;
                StateAddress stateAddress = obj.Township.State;

                CityAddressDTO cityAddressDTO = new CityAddressDTO(cityAddress.Id, cityAddress.Name);   
                StateAddressDTO stateAddressDTO = new StateAddressDTO(stateAddress.Id, stateAddress.Name);


                TownshipAddressGetDTO townshipAddressGetDTO = new TownshipAddressGetDTO(townshipAddress.Id, townshipAddress.TownshipName, stateAddressDTO, cityAddressDTO);

                fiscalAddressDTO = new FiscalAddressDTO(obj.ZipCode, townshipAddressGetDTO );

            }

            return fiscalAddressDTO;
        }

    }
}
