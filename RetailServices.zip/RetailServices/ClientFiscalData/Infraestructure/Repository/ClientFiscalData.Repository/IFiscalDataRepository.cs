﻿using ClientFiscalDataDomain.ClientFiscalDataAggregate;
using ClientFiscalDataDomain.DTO;
using System;

namespace ClientFiscalData.Repository
{
    public interface IFiscalDataRepository{
        FiscalData GetFiscalData(String clientId);
        void UpdateFiscalData(FiscalDataUpdateDTO fiscalData);
    }
}
