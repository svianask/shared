﻿using ClientFiscalDataDomain.ClientFiscalDataAggregate;
using System;
using System.Data.SqlClient;
using Unity;
using System.Data;
using ClientFiscalDataMapping;
using ClientFiscalDataDomain.DTO;
using SqlClient.Helper;

namespace ClientFiscalData.Repository
{
    public class FiscalDataSIIFRepository : IFiscalDataRepository
    {
        private const String CONNECTIONSTRING_NAME_RAWRAPSSIF = "RAWRAPSIIF";
        private const String GET_CLIENTDATAINFOBYID_SP_NAME = "usp_SOC_SIIF_GetClientFiscalInfoByRFC";
        private const String UPDATE_CLIENTDATAINFOBYID_SP_NAME = "usp_SOC_SIIF_UpdateClientFiscalInfo";

        private const string CLIENTDATA_ID = "@ClientId";
        private const string RFC_PARM = "@Rfc";
        private const string CURP_PARM = "@Curp";
        private const string NAMES_PARM = "@Names";
        private const string PATERNAL_SURNAME_PARM = "@PaternalSurname";
        private const string MATERNAL_SURNAME_PARM = "@MaternalSurname";
        private const string ZIPCODE_PARM = "@ZipCode";
        private const string STATEID_PARM = "@StateId";
        private const string STATENAME_PARM = "@StateName";
        private const string CITYID_PARM = "@CityId";
        private const string CITYNAME_PARM = "@CityName";
        private const string TOWNSHIPID_PARM = "@TownshipId";
        private const string TOWNSHIPNAME_PARM = "@TownshipName";
        private const string STREET_PARM = "@Street";
        private const string CHANNEL_PARM = "@Channel";

        private readonly SqlConnection _dbRawrapsiif;
        private readonly ISqlClientHelper _sqlClientHelper;

        public FiscalDataSIIFRepository([Dependency(CONNECTIONSTRING_NAME_RAWRAPSSIF)] SqlConnection dbRawrapsiif, ISqlClientHelper sqlClientHelper)
        {
            _dbRawrapsiif = dbRawrapsiif;
            _sqlClientHelper = sqlClientHelper;
        }

        public FiscalData GetFiscalData(string clientId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(GET_CLIENTDATAINFOBYID_SP_NAME, _dbRawrapsiif);
            cmd.AddParameterWithValue(RFC_PARM, clientId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FiscalDataMapp.Map(ds);
        }

        public void UpdateFiscalData(FiscalDataUpdateDTO fiscalData)
        {

            IDbCommand cmdRaw = _sqlClientHelper.CreateCmdSP(UPDATE_CLIENTDATAINFOBYID_SP_NAME, _dbRawrapsiif);
            cmdRaw.AddParameterWithValue(CLIENTDATA_ID, fiscalData.ClientId);
            cmdRaw.AddParameterWithValue(CURP_PARM, fiscalData.Curp);
            cmdRaw.AddParameterWithValue(NAMES_PARM, fiscalData.Names);
            cmdRaw.AddParameterWithValue(PATERNAL_SURNAME_PARM, fiscalData.PaternalSurname);
            cmdRaw.AddParameterWithValue(MATERNAL_SURNAME_PARM, fiscalData.MaternalSurname);
            cmdRaw.AddParameterWithValue(ZIPCODE_PARM, fiscalData.ZipCode);
            cmdRaw.AddParameterWithValue(CITYID_PARM, fiscalData.CityId );
            cmdRaw.AddParameterWithValue(CITYNAME_PARM, fiscalData.CityName);
            cmdRaw.AddParameterWithValue(STATEID_PARM, fiscalData.StateId);
            cmdRaw.AddParameterWithValue(STATENAME_PARM, fiscalData.StateName);
            cmdRaw.AddParameterWithValue(TOWNSHIPID_PARM, fiscalData.TownshipId);
            cmdRaw.AddParameterWithValue(TOWNSHIPNAME_PARM, fiscalData.TownshipName);
            cmdRaw.AddParameterWithValue(STREET_PARM, fiscalData.RoadName );
            cmdRaw.AddParameterWithValue(CHANNEL_PARM, fiscalData.Channel);
            var result = _sqlClientHelper.ExecuteNonQuery(cmdRaw);
        }
    }
}
