﻿using ClientFiscalDataDomain.DTO;
using Common.Domain;
using System;
using System.Collections.Generic;


namespace FiscalDataApplication
{
    public interface IFiscalDataApp
    {
        void UpdateFiscalData( FiscalDataUpdateDTO fiscalDataDTO, out OperationResult result);
        FiscalDataGetDTO GetFiscalData(String clientId, out OperationResult result);

    }
}
