﻿using ClientDataDomain.TownshipAddressAggregate;
using ClientFiscalData.Repository;
using ClientFiscalDataDomain.ClientFiscalDataAggregate;
using ClientFiscalDataDomain.DTO;
using ClientFiscalDataMapping;
using ClientNotificationsProxy;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FiscalDataApplication
{
    public class FiscalDataApp : IFiscalDataApp
    {
        private readonly ISeriLogHelper _log;
        private readonly FiscalDataSIIFRepository _fiscalDataSIIF;

        
        public FiscalDataApp(ISeriLogHelper seriLog,
                             FiscalDataSIIFRepository fiscalDataSIIF
                             )
        {
            _log = seriLog;
            _fiscalDataSIIF = fiscalDataSIIF;
        }

        public void UpdateFiscalData(FiscalDataUpdateDTO fiscalDataDTO, out OperationResult result)
        {
            _log.Info("Starting update FiscalData from [SIIF]");
            result = new OperationResult() { Successful = true };
            String clientId = fiscalDataDTO.ClientId;
            _log.Info("Updating FiscalData from clientId: {cntx}", fiscalDataDTO.ClientId);
            _log.Debug("Receiving FiscalDataDTO: {cntx}", fiscalDataDTO);

            try
            {
                _fiscalDataSIIF.UpdateFiscalData(fiscalDataDTO);
                _log.Info("Update has been executed in RAWRAPSIIF");
            }
            catch (Exception ex)
            {
                _log.Error(ex, "An error has ocurred to update FiscalData.");
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error to execute UpdateFiscalData - " + ex.Message, MessageType = SystemMessageTypes.Error } };
            }

            _log.Info("Ending update FiscalData from [SIIF]");
        }

        public FiscalDataGetDTO GetFiscalData(string clientId, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            FiscalDataGetDTO fiscalDataDTO = null;
            try
            {
                _log.Info("Starting getting FiscalData from [SIIF]");
                fiscalDataDTO = FiscalDataMapp.Map( this._fiscalDataSIIF.GetFiscalData(clientId));
                _log.Debug("Mapping FiscalData Entity to DTO with result: {cntx}", fiscalDataDTO);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "An error has ocurred to get Fiscal Data");
                result.Successful = false;
                result.SystemMessages = new List<SystemMessage> { new SystemMessage { Message = "Error to execute GetFiscalData - " + ex.Message, MessageType = SystemMessageTypes.Error } };
            }

            _log.Debug("Result to execute GetFiscalData:  {cntx}", fiscalDataDTO);
            return fiscalDataDTO;
        }

    }
}
