﻿using ClientFiscalDataDomain.DTO;
using Common.Domain;
using System.Collections.Generic;

namespace ClientFiscalDataMessages
{
    public class GetTownshipResponse
    {
        public OperationResult Result;
        public List<TownshipAddressGetDTO> townshipList;
    }
}
