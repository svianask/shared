﻿

namespace ClientFiscalDataMessages
{
    public  class GetFiscalDataRequest
    {
        public string ClientId { get; set; }
    }
}
