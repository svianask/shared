﻿using ClientFiscalDataDomain.DTO;
using Common.Domain;

namespace ClientFiscalDataMessages
{
    public class GetFiscalDataResponse
    {
        public OperationResult Result;
        public FiscalDataGetDTO fiscalData;
    }
}
