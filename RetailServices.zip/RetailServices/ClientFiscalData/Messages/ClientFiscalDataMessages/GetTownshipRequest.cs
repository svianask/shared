﻿using System;

namespace ClientFiscalDataMessages
{
    public class GetTownshipRequest
    {
        public String ZipCode;
    }
}
