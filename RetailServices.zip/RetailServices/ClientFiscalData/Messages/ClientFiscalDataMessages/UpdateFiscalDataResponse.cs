﻿using Common.Domain;

namespace ClientFiscalDataMessages
{
    public class UpdateFiscalDataResponse
    {
        public OperationResult Result;
    }
}
