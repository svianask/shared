﻿using ClientFiscalDataDomain.DTO;
using System;

namespace ClientFiscalDataMessages
{
    public class UpdateFiscalDataRequest: FiscalDataUpdateDTO
    {

    }
}
