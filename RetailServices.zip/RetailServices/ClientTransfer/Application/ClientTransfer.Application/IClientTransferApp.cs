﻿using ClientTransfer.Domain.TransferOrderAggregate;
using ClientTransfer.Messages;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientTransfer.Application
{
    public interface IClientTransferApp
    {
        OperationResult GenerateTransferTransaction(string contractId, string userId, FundTransactionData transactionData);
        int InsertTransferOrder(TransferOrder orderData, int platform, out OperationResult result);
        OperationResult InsertTransferOrderLog(TransferOrderLog orderLog, int orderId);
        List<TransferPending> GetTransfersPending(string contractId, int platform, out OperationResult result);
    }
}
