﻿using ClientTransfer.Domain.TransferOrderAggregate;
using ClientTransfer.Messages;
using ClientTransfer.Repository;
using Common.Domain;
using SeriLogH;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace ClientTransfer.Application
{
    public class ClientTransferApp : IClientTransferApp
    {
        private readonly ISeriLogHelper _log;
        private readonly ITransform _transform;
        private readonly IClientTransferRepository _repository;
        public ClientTransferApp(ISeriLogHelper seriLog, ITransform transform, IClientTransferRepository repository)
        {
            _log = seriLog;
            _transform = transform;
            _repository = repository;
        }

        public OperationResult GenerateTransferTransaction(string contractId, string userId, FundTransactionData transactionData)
        {
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede der nulo."); }
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El usuario no puede ser nulo."); }
            if (transactionData is null) { throw new ArgumentException("No exiten datos de la transaccion"); }

            var result = new OperationResult() { Successful = true };
            try
            {
                var mapProduct = transactionData.Platform == 10 ? "RS" : "GT";
                _log.Info("Generando la transaccion en siif.");
                _repository.GenerateTransferTransactionSIIF(contractId, transactionData.TransctionId, transactionData.TransactionType, transactionData.TransactionDate, mapProduct, userId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un error al generar la transaccion en siif. - GenerateFundTransaction");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = ex.Message });
            }

            return result;
        }

        public int InsertTransferOrder(TransferOrder orderData, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (orderData is null) { throw new ArgumentException("No exiten datos de la transaccion"); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador"); }

            var orderId = -1;
            try
            {
                string spName = platform.Equals(10) ? "usp_SIIF_RS_Transferencia_Fondos" : "usp_SIIF_GT_Transferencia_Fondos";
                _log.Info("Convirtiendo los datos de la transferencia a xml");
                var xmlTansform = _transform.ObjectToXml(orderData);
                _log.Debug("{cntx}", xmlTansform);

                _log.Info("Generando la transferencia de fondos en la base.");
                orderId = _repository.InsertTransferOrder(spName, xmlTansform);
                _log.Debug("orderId: {cntx}", orderId);

                if (orderId < 0)
                {
                    result.Successful = false;
                    result.SystemMessages.Add(new SystemMessage() { Message = "Ocurrio un error al realizar la insercion de los datos. " + spName });
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Ocurrio un error al realizar la tranfererencia de fondos");
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al realizar la transferencia de fondos - " + ex.StackTrace });
            }

            return orderId;
        }

        public OperationResult InsertTransferOrderLog(TransferOrderLog orderLog, int orderId)
        {
            var result = new OperationResult() { Successful = true };
            if (orderLog is null) { throw new ArgumentException("Los datos para el LOG no pueden ser nulos"); }
            if (orderId <= 0) { throw new ArgumentException("El ID de la orden es incorrecto"); }

            try
            {
                _log.Info("Insertando log de transferencia de la orden {cntx}.", orderId);
                _repository.InsertTransferOrderLog(orderLog, orderId);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al insertar el log de transferencia de la orden {cntx}.", orderId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al insertar el log de transferencias. - " + ex.StackTrace });
            }

            return result;
        }

        public List<TransferPending> GetTransfersPending(string contractId, int platform, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador"); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato ni puede ser nulo."); }

            var orders = new List<TransferPending>();
            try
            {
                _log.Info($"Obteniendo las ordenes pendientes: ContractId: {contractId} - Platform: {platform}");
                orders = _repository.GetTransferPending(contractId, platform);
                _log.Debug("{cntx}", orders);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener las ordenes pendientes del contrato: " + contractId);
                result.Successful = false;
                result.SystemMessages.Add(new SystemMessage() { Message = "Error al obtener las ordenes pendientes" + ex.StackTrace });
            }

            return orders;
        }
    }
}
