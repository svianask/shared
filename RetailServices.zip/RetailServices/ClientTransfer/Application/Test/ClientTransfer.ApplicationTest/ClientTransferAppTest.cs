﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientTransfer.Application;
using ClientTransfer.Domain.TransferOrderAggregate;
using ClientTransfer.Messages;
using ClientTransfer.Repository;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using Utilities.Application;

namespace ClientTransfer.ApplicationTest
{
    [TestClass]
    public class ClientTransferAppTest
    {
        private readonly Mock<ISeriLogHelper> _log;
        private readonly Mock<ITransform> _transform;
        private readonly Mock<IClientTransferRepository> _repository;
        private readonly ClientTransferApp _transferAppBL;
        private OperationResult result;
        public ClientTransferAppTest()
        {
            _log = new Mock<ISeriLogHelper>();
            _transform = new Mock<ITransform>();
            _repository = new Mock<IClientTransferRepository>();
            _transferAppBL = new ClientTransferApp(_log.Object, _transform.Object, _repository.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            result = new OperationResult() { Successful = true };
            List<TransferPending> lstTranfers = new List<TransferPending>();
            _transform.Setup(x => x.ObjectToXml(new TransferOrder()))
               .Returns("<TransferOrder><ContractId>599500</ContractId><Shares>0</Shares><Price>0</Price><Amount>52.26</Amount><ProcessDate>0001-01-01T00:00:00</ProcessDate></TransferOrder>");
            _repository.Setup(x => x.GenerateTransferTransactionSIIF(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<string>(), It.IsAny<string>()));
            _repository.Setup(x => x.InsertTransferOrder(It.IsAny<string>(), It.IsAny<string>())).Returns(8541);
            _repository.Setup(x => x.InsertTransferOrderLog(It.IsAny<TransferOrderLog>(), It.IsAny<int>()));
            _repository.Setup(x => x.GetTransferPending(It.IsAny<string>(), It.IsAny<int>())).Returns(lstTranfers);
        }

        [TestMethod, TestCategory("GenerateTransferTransaction")]
        [DataRow("", "TOLE640719B53")]
        [DataRow("112533", "")]
        [ExpectedException(typeof(ArgumentException))]
        public void GenerateTransferTransactionError(string contractId, string userId)
        {
            FundTransactionData data = new FundTransactionData();
            var insertResult = _transferAppBL.GenerateTransferTransaction(contractId, userId, data);

            Assert.IsFalse(insertResult.Successful);
        }

        [TestMethod, TestCategory("GenerateTransferTransaction")]
        [ExpectedException(typeof(ArgumentException))]
        public void GenerateTransferTransactionErrorData()
        {
            var insertResult = _transferAppBL.GenerateTransferTransaction("112533", "TOLE640719B53", null);
            Assert.IsFalse(insertResult.Successful);
        }

        [TestMethod, TestCategory("GenerateTransferTransaction")]
        public void GenerateTransferTransactionSuccess()
        {
            FundTransactionData data = new FundTransactionData() { Platform = 10, TransactionDate = DateTime.Now, TransactionType = 2, TransctionId = "hgjhds" };
            var insertResult = _transferAppBL.GenerateTransferTransaction("112533", "TOLE640719B53", data);
            Assert.IsTrue(insertResult.Successful);
        }

        [TestMethod, TestCategory("InsertTransferOrder")]
        [ExpectedException(typeof(ArgumentException))]
        public void InsertTransferOrderErrorData()
        {
            var orderResult = _transferAppBL.InsertTransferOrder(null, 10, out result);
            Assert.IsFalse(result.Successful);
            Assert.IsTrue(orderResult < 0);
        }

        [TestMethod, TestCategory("InsertTransferOrder")]
        [ExpectedException(typeof(ArgumentException))]
        public void InsertTransferOrderErrorPlatform()
        {
            TransferOrder order = new TransferOrder();
            var orderResult = _transferAppBL.InsertTransferOrder(order, 0, out result);
            Assert.IsFalse(result.Successful);
            Assert.IsTrue(orderResult < 0);
        }

        [TestMethod, TestCategory("InsertTransferOrder")]
        public void InsertTransferOrderSuccess()
        {
            TransferOrder order = new TransferOrder();
            var orderResult = _transferAppBL.InsertTransferOrder(order, 10, out result);
            Assert.IsTrue(result.Successful);
            Assert.IsTrue(orderResult > 0);
        }

        [TestMethod, TestCategory("InsertTransferOrderLog")]
        [ExpectedException(typeof(ArgumentException))]
        public void InsertTransferOrderLogErrorData()
        {
            var orderLogResult = _transferAppBL.InsertTransferOrderLog(null, 1254);
            Assert.IsFalse(orderLogResult.Successful);
        }

        [TestMethod, TestCategory("InsertTransferOrderLog")]
        [ExpectedException(typeof(ArgumentException))]
        public void InsertTransferOrderLogErrorOrderId()
        {
            TransferOrderLog log = new TransferOrderLog();
            var orderLogResult = _transferAppBL.InsertTransferOrderLog(log, 0);
            Assert.IsFalse(orderLogResult.Successful);
        }

        [TestMethod, TestCategory("InsertTransferOrderLog")]
        public void InsertTransferOrderLogSuccess()
        {
            TransferOrderLog log = new TransferOrderLog();
            var orderLogResult = _transferAppBL.InsertTransferOrderLog(log, 10);
            Assert.IsTrue(orderLogResult.Successful);
        }

        [TestMethod, TestCategory("GetTransfersPending")]
        [ExpectedException(typeof(ArgumentException))]
        [DataRow("", 10)]
        [DataRow("112533", 0)]
        public void GetTransfersPendingError(string contractId, int platform)
        {
            var transferPending = _transferAppBL.GetTransfersPending(contractId, platform, out result);
            Assert.IsFalse(result.Successful);
            Assert.IsNull(transferPending);
        }

        [TestMethod, TestCategory("GetTransfersPending")]
        public void GetTransfersPendingSuccess()
        {
            var transferPending = _transferAppBL.GetTransfersPending("112533", 10, out result);
            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(transferPending);
        }
    }
}
