﻿using ClientTransfer.Domain.TransferOrderAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientTransfer.Messages
{
    public class GetTransfersPendingResponse
    {
        public List<TransferPending> FundOrders;
        public OperationResult Result;
    }

    public class GetTransfersPendingRequest
    {
        public string ContractId;
        public int Platform;
    }
}
