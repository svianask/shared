﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientTransfer.Messages
{
    public class GenerateTransferTransactionResponse
    {
        public OperationResult Result;
        public GenerateTransferTransactionResponse() { Result = new OperationResult(); }
    }

    public class GenerateTransferTransactionRequest
    {
        public string ContractId;
        public string UserId;
        public FundTransactionData TransactionData;
    }

    public class FundTransactionData
    {
        public int Platform;
        public int TransactionType;
        public string TransctionId;
        public DateTime TransactionDate;
    }

}
