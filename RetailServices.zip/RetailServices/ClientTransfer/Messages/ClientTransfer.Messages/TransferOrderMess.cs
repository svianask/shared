﻿using ClientTransfer.Domain.TransferOrderAggregate;
using Common.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientTransfer.Messages
{
    public class InsertClientTransferResponse
    {
        public OperationResult Result;
        public int OrderId;

        public InsertClientTransferResponse() { Result = new OperationResult(); }
    }

    public class InsertClientTransferRequest
    {
        public TransferOrder OrderData;
        public int Platform;
    }

    public class InsertTransferOrderLogResponse
    {
        public OperationResult Result;
    }

    public class TransferOrder
    {
        public string ContractId;
        public int OperationType;
        public int AmountType;
        public string EmisionId;
        public decimal Shares;
        public double Price;
        public double Amount;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public double ComissionAmount;
        public double ComissionTaxAmount;
        public string Comment;
        public int OrderChainId;
        public int IsLastOrder;
        public int OrderType;
        public int NotValidateSalePos;
        public int NotValidateCompromisedPos;
    }


    public class InsertTransferOrderLogRequest
    {
        public int OrderId;
        public TransferOrderLog OrderLog;
    }

    public class TransferOrderLog
    {
        public string TransactionId;
        public string OrderLogId;
        public Guid OrderLogFatherId;
        public DateTime OrderLoadDate;
        public int OrderLogDepth;
        public string OrderLogLinage;
        public int OrderTypeLog;
        public string ContractId;
        public int OperationType;
        public string EmisionId;
        public decimal Shares;
        public double Price;
        public double Amount;
        public double ComissionAmount;
        public double ComissionTaxAmount;
        public DateTime OperationDate;
        public DateTime LiquidationDate;
        public string Comment;
    }
}
