﻿using ClientTransfer.Domain.TransferOrderAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.Application;

namespace ClientTransfer.Mapping
{
    public class TransferPendingMapp
    {
        public static TransferPending Mapp(DataRow data)
        {
            TransferPending fundOrder = TransferPending.
                Create(Convert.ToInt32(Null.SetNull(data["Orden_Id"], new Int32())))
                .OrderDetails(
                    Convert.ToInt32(Null.SetNull(data["Orden_Titulos"], new Int32())),
                    Convert.ToDouble(Null.SetNull(data["Orden_Precio"], new Double())),
                    Convert.ToDouble(Null.SetNull(data["Orden_Importe"], new Double())))
                .SetStatus(Convert.ToInt32(Null.SetNull(data["Sts_Orden_Id"], new Int32())))
                .SetFundId(data["Emision_Id"].ToString())
                .DatesDetails(
                    Convert.ToDateTime(Null.SetNull(data["Orden_Fecha_Operacion"], new DateTime())),
                    Convert.ToDateTime(Null.SetNull(data["Orden_Fecha_Liquidacion"], new DateTime())),
                    Convert.ToDateTime(Null.SetNull(data["Orden_Fecha_Proceso"], new DateTime())));

            return fundOrder;
        }

        public static List<TransferPending> TranfersPendings(DataSet ds)
        {
            List<TransferPending> lstOrders = new List<TransferPending>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lstOrders.Add(TransferPendingMapp.Mapp(dr));
            }

            return lstOrders;
        }
    }
}
