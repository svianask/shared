﻿using ClientTransfer.Domain.TransferOrderAggregate;
using ClientTransfer.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientTransfer.Repository
{
    public interface IClientTransferRepository
    {
        void GenerateTransferTransactionSIIF(string contractId, string transactionId, int transactionType, DateTime transactionDate, string productType, string userId);
        int InsertTransferOrder(string spName, string xmlDataFunds);
        void InsertTransferOrderLog(TransferOrderLog orderData, int orderId);
        List<TransferPending> GetTransferPending(string contractId, int platform);
    }
}
