﻿using ClientTransfer.Domain.TransferOrderAggregate;
using ClientTransfer.Mapping;
using ClientTransfer.Messages;
using SqlClient.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using ValidateH;

namespace ClientTransfer.Repository
{
    public class ClientTransferRepository : IClientTransferRepository
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public ClientTransferRepository([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            this._dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public void GenerateTransferTransactionSIIF(string contractId, string transactionId, int transactionType, DateTime transactionDate, string productType, string userId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertaContratoTransaccion", _dbConn);
            cmd.AddParameterWithValue("@pstrContratoId", contractId);
            cmd.AddParameterWithValue("@pstrTransaccionId", transactionId);
            cmd.AddParameterWithValue("@psintTipoTransaccionId", transactionType);
            cmd.AddParameterWithValue("@pdtFechaTransaccion", transactionDate);
            cmd.AddParameterWithValue("@pstrTipoProducto", productType);
            cmd.AddParameterWithValue("@pstrUsuarioId", userId);
            _sqlClientHelper.ExecuteNonQuery(cmd);
        }

        public int InsertTransferOrder(string spName, string xmlDataFunds)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@orderData", xmlDataFunds);

            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return Convert.ToInt32(ValidateNull.SetNull(ds.Tables[0].Rows[0][0], new int()));
        }

        public void InsertTransferOrderLog(TransferOrderLog orderData, int orderId)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIFX_InsertOrdenProgramada", _dbConn);

            cmd.AddParameterWithValue("@pstrTransaccionId", orderData.TransactionId);
            cmd.AddParameterWithValue("@pstrOrdenProgramadaId", orderData.OrderLogId);
            if (orderData.OrderLogFatherId == Guid.Empty)
                cmd.AddParameterWithValue("@pstrOrdenProgramadaPadreId", DBNull.Value);
            else
                cmd.AddParameterWithValue("@pstrOrdenProgramadaPadreId", orderData.OrderLogFatherId);
            cmd.AddParameterWithValue("@pintProfundidad", orderData.OrderLogDepth);
            cmd.AddParameterWithValue("@pstrLinage", orderData.OrderLogLinage);
            cmd.AddParameterWithValue("@pdtmFechaProgramacion", orderData.OrderLoadDate);
            cmd.AddParameterWithValue("@pdtmFechaAplicacion", orderData.OrderLoadDate);
            cmd.AddParameterWithValue("@pintOrdenProgramadaEstatus", 2);
            cmd.AddParameterWithValue("@pstrContratoId", orderData.ContractId);
            cmd.AddParameterWithValue("@pintOrdenId", orderId);
            cmd.AddParameterWithValue("@psintTipoOperacionId", orderData.OperationType);
            cmd.AddParameterWithValue("@psintTipoOrdenId", orderData.OrderTypeLog);
            cmd.AddParameterWithValue("@pstrEmisionId", orderData.EmisionId);
            cmd.AddParameterWithValue("@pintOrdenTitulos", orderData.Shares);
            cmd.AddParameterWithValue("@pfltOrdenPrecio", orderData.Price);
            cmd.AddParameterWithValue("@pfltOrdenImporte", orderData.Amount);
            cmd.AddParameterWithValue("@pdtmOrdenFechaProceso", orderData.OrderLoadDate);
            cmd.AddParameterWithValue("@pdtmOrdenFechaOperacion", orderData.OperationDate);
            cmd.AddParameterWithValue("@pdtmOrdenFechaLiquidacion", orderData.LiquidationDate);
            cmd.AddParameterWithValue("@pfltOrdenComision", orderData.ComissionAmount);
            cmd.AddParameterWithValue("@pfltOrdenIVA", orderData.ComissionTaxAmount);
            cmd.AddParameterWithValue("@pstrOrdenObservaciones", orderData.Comment);
            //para simplificar la implementacion, no se registrara el 
            //identificador de la primera oren de veta
            cmd.AddParameterWithValue("@pintOrdenVentaId", 0);
            cmd.AddParameterWithValue("@pbitTipoLiquidacion", DBNull.Value);
            cmd.AddParameterWithValue("@OrdenContratoId", orderData.ContractId);
            cmd.AddParameterWithValue("@TipoMercadoId", DBNull.Value);

            _sqlClientHelper.ExecuteNonQuery(cmd);
        }

        public List<TransferPending> GetTransferPending(string contractId, int platform)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP("usp_SIIF_ObtenerTransferenciasPendientes", _dbConn);
            cmd.AddParameterWithValue("@ContractId", contractId);
            cmd.AddParameterWithValue("@Platform", platform);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return TransferPendingMapp.TranfersPendings(ds);
        }
    }
}
