﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientTransfer.Domain.TransferOrderAggregate
{
    public class TransferPending : Entity<int>, IRootAggregate
    {
        private string _emision_Id;
        private int _shares;
        private double _price;
        private double _amount;
        private DateTime _processDate;
        private DateTime _operationDate;
        private DateTime _liquidationDate;
        private int _comments;
        private int _userId;
        private int _statusId;

        private TransferPending(int orderId)
        {
            Id = orderId;
        }

        public static TransferPending Create(int orderId)
        {
            if (orderId <= 0) { throw new ArgumentException("El Id de la orden es incorrecta."); }
            return new TransferPending(orderId);
        }

        public TransferPending OrderDetails(int shares, double price, double amount)
        {
            _shares = shares;
            _price = price;
            _amount = amount;
            return this;
        }

        public TransferPending DatesDetails(DateTime operation, DateTime liquidation, DateTime process)
        {
            _operationDate = operation;
            _liquidationDate = liquidation;
            _processDate = process;
            return this;
        }

        public TransferPending SetFundId(string fundId)
        {
            _emision_Id = fundId;
            return this;
        }

        public TransferPending SetStatus(int statusId)
        {
            _statusId = statusId;
            return this;
        }

        public string EmisionId => _emision_Id;
        public int Shares => _shares;
        public double Price => _price;
        public double Amount => _amount;
        public DateTime OperationDate => _operationDate;
        public DateTime LiquidationDate => _liquidationDate;
        public DateTime ProcessDate => _processDate;
        public int StatusId => _statusId;
    }
}
