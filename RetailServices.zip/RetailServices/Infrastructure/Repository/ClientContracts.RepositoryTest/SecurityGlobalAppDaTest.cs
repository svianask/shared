﻿using ClientContracts.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SqlClient.Helper;
using System;
using System.Data;
using System.Data.SqlClient;

namespace ClientContracts.RepositoryTest
{
    [TestClass]
    public class SecurityGlobalAppDaTest
    {
        private readonly SqlConnection _dbConn;
        private readonly SecurityGlobalAppDa _securityGlobalrepository;
        private readonly Mock<ISqlClientHelper> mockSqlClientHelper;

        public SecurityGlobalAppDaTest()
        {
            _dbConn = new SqlConnection();
            mockSqlClientHelper = new Mock<ISqlClientHelper>();
            _securityGlobalrepository = new SecurityGlobalAppDa(_dbConn, mockSqlClientHelper.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            mockSqlClientHelper.Setup(x => x.GetConnection(_dbConn)).Returns(Mock.Of<IDbConnection>());
            mockSqlClientHelper.Setup(x => x.GetCommand(It.IsAny<IDbConnection>())).Returns(Mock.Of<IDbCommand>());
            mockSqlClientHelper.Setup(x => x.GetDataAdapter(It.IsAny<IDbCommand>())).Returns(Mock.Of<IDbDataAdapter>());
            mockSqlClientHelper.Setup(x => x.CreateCmdSP(It.IsAny<string>(), _dbConn)).Returns(Mock.Of<IDbCommand>());
        }

        [TestMethod]
        public void GetClienteDatosSolvenciaTest()
        {
            Assert.ThrowsException<NullReferenceException>(() => _securityGlobalrepository.GetClienteDatosSolvencia("XXXXXX000000XXX",1));
        }

        [TestMethod]
        public void GetClienteDatosSolvenciaTestData()
        {
            DataSet ds = new DataSet();
            string[] columns = { "UserName", "Email", "NombreCompleto" };
            string[] rows = { "test name", "test Email", "test full name" };
            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet().AddTable(() => new DataTable().AddColumns(columns).AddRow(rows)));
            var solvenciaData = _securityGlobalrepository.GetClienteDatosSolvencia("MEAJ720808J25",1);
            Assert.IsNotNull(solvenciaData);
        }
    }
}
