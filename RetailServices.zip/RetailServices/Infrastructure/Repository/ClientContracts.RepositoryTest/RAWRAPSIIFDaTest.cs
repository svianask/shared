﻿using ClientContracts.Repository;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SqlClient.Helper;
using System;
using System.Data;
using System.Data.SqlClient;

namespace ClientContracts.RepositoryTest
{
    [TestClass]
    public class RAWRAPSIIFDaTest
    {
        private readonly SqlConnection _dbConn;
        private readonly RAWRAPSIIFDa _planRepository;
        private readonly Mock<ISqlClientHelper> mockSqlClientHelper;

        public RAWRAPSIIFDaTest()
        {
            _dbConn = new SqlConnection();
            mockSqlClientHelper = new Mock<ISqlClientHelper>();
            _planRepository = new RAWRAPSIIFDa(_dbConn, mockSqlClientHelper.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            mockSqlClientHelper.Setup(x => x.GetConnection(_dbConn)).Returns(Mock.Of<IDbConnection>());
            mockSqlClientHelper.Setup(x => x.GetCommand(It.IsAny<IDbConnection>())).Returns(Mock.Of<IDbCommand>());
            mockSqlClientHelper.Setup(x => x.GetDataAdapter(It.IsAny<IDbCommand>())).Returns(Mock.Of<IDbDataAdapter>());
            mockSqlClientHelper.Setup(x => x.CreateCmdSP(It.IsAny<string>(), _dbConn)).Returns(Mock.Of<IDbCommand>());

        }


        [TestMethod, TestCategory("ParamError")]
        public void GetClientContractsParamError()
        {
            Assert.ThrowsException<NullReferenceException>(() => _planRepository.GetClientContracts("XXXX999999X0X"));
        }

        [TestMethod, TestCategory("ProcessFail")]
        public void GetClientContractsFailCorruptDB()
        {
            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet()
                .AddTable(
                    () => new DataTable()
                        .AddColumns("Contrato_RFC", "Contrato_Id", "Contrato_Plan_Id", "Email", "Telefono", "Celular")
                        .AddRow("MANO470320NA4", null, 15, "O579183@skANDia.com.mx", "50930200", "50930200")));
            
            Assert.ThrowsException<ArgumentException>(() => _planRepository.GetClientContracts("MANO470320NA4"));

            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet()
                .AddTable(
                    () => new DataTable()
                        .AddColumns("Contrato_RFC", "Contrato_Id", "Contrato_Plan_Id", "Email", "Telefono", "Celular")
                        .AddRow("MANO470320NA4", "", 480, "O579183@skANDia.com.mx", "50930200", "50930200")));

            Assert.ThrowsException<ArgumentException>(() => _planRepository.GetClientContracts("MANO470320NA4"));

            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet()
                .AddTable(
                    () => new DataTable()
                        .AddColumns("Contrato_RFC", "Contrato_Id", "Contrato_Plan_Id", "Email", "Telefono", "Celular")
                        .AddRow("MANO470320NA4", "579183", 0, "O579183@skANDia.com.mx", "50930200", "50930200")));

            Assert.ThrowsException<ArgumentException>(() => _planRepository.GetClientContracts("MANO470320NA4"));

            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet()
            .AddTable(
                () => new DataTable()
                    .AddColumns("Contrato_RFC", "Contrato_Id", "Contrato_Plan_Id", "Email", "Telefono", "Celular")
                    .AddRow(null, "579183", 0, "O579183@skANDia.com.mx", "50930200", "50930200")));

            Assert.ThrowsException<ArgumentException>(() => _planRepository.GetClientContracts("MANO470320NA4"));

        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void GetClientContractsSuccess()
        {
            DataSet ds = new DataSet();

            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet()
                .AddTable(
                    () => new DataTable()
                        .AddColumns("Contrato_RFC", "Contrato_Id", "Contrato_Plan_Id", "Email", "Telefono", "Celular")
                        .AddRow("MANO470320NA4", "102056", 15, "O102056@skANDia.com.mx", "50930200", "50930200")
                        .AddRow("MANO470320NA4", "579183", 480, "O579183@skANDia.com.mx", "50930200", "50930200")
                        .AddRow("MANO470320NA4", "613054", 15, "O613054@skANDia.com.mx", "50930200", "50930200")));

            var ContractsOfCliente = _planRepository.GetClientContracts("MANO470320NA4");
            Assert.IsNotNull(ContractsOfCliente);
        }


        [TestMethod, TestCategory("ParamError")]
        [DataRow("","")]
        [DataRow("102056", "")]
        [DataRow("", "O102056@skANDia.com.mx")]
        public void UpdateContactDataParamError(string contractIdentifier, string email)
        {
            mockSqlClientHelper.Setup(x => x.ExecuteNonQuery(It.IsAny<IDbCommand>())).Returns(1);

            Assert.ThrowsException<ArgumentException>(() => _planRepository.UpdateContactData(contractIdentifier, email));
        }

        [TestMethod, TestCategory("ProcessSuccessful")]
        public void UpdateContactDataSuccess()
        {

            mockSqlClientHelper.Setup(x => x.ExecuteNonQuery(It.IsAny<IDbCommand>())).Returns(1);

            var rowsUpdate = _planRepository.UpdateContactData("102056", "O102056@skANDia.com.mx");

            Assert.IsTrue(rowsUpdate >= 0);
        }

        [TestMethod, TestCategory("GenerateDomiciliationOnDemand")]
        public void GenerateDomiciliationOnDemandSuccess()
        {
            var domiInfo = new DomiciliationOnDemand("XXXXXX", 1, 200, DateTime.Now, 1, 1, "XXXXXXXX", true, true, "USER");
                mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>()))
                .Returns(new DataSet().AddTable(
                    () => new DataTable()
                        .AddColumns("Code", "MessageError", "DBInsert")
                        .AddRow(0, "Message", "DB")
                    ));
            var result = _planRepository.GenerateDomiciliationOnDemand(domiInfo);

            Assert.IsNotNull(result);
        }

        [TestMethod, TestCategory("GenerateDomiciliationOnDemand")]
        public void GenerateDomiciliationOnDemandError()
        {
            var domiInfo = new DomiciliationOnDemand("XXXXXX", 1, 200, DateTime.Now, 1, 1, "XXXXXXXX", true, true, "USER");
            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>()))
            .Returns(new DataSet().AddTable(
                () => new DataTable()
                    .AddColumns("Code", "MessageError", "DBInsert")
                    .AddRow(0, "Message", "")
                ));

            Assert.ThrowsException<ArgumentException>(() => _planRepository.GenerateDomiciliationOnDemand(domiInfo));
        }
    }
}
