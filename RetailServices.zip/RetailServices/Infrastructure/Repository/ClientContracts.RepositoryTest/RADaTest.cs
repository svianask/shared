﻿using ClientContracts.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SqlClient.Helper;
using System;
using System.Data;
using System.Data.SqlClient;

namespace ClientContracts.RepositoryTest
{
    [TestClass]
    public class RADaTest
    {
        private readonly SqlConnection _dbConn;
        private readonly RADa _planRepository;
        private readonly Mock<ISqlClientHelper> mockSqlClientHelper;


        public RADaTest()
        {
            _dbConn = new SqlConnection();
            mockSqlClientHelper = new Mock<ISqlClientHelper>();
            _planRepository = new RADa(_dbConn, mockSqlClientHelper.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            mockSqlClientHelper.Setup(x => x.GetConnection(_dbConn)).Returns(Mock.Of<IDbConnection>());
            mockSqlClientHelper.Setup(x => x.GetCommand(It.IsAny<IDbConnection>())).Returns(Mock.Of<IDbCommand>());
            mockSqlClientHelper.Setup(x => x.GetDataAdapter(It.IsAny<IDbCommand>())).Returns(Mock.Of<IDbDataAdapter>());
            mockSqlClientHelper.Setup(x => x.CreateCmdSP(It.IsAny<string>(),_dbConn)).Returns(Mock.Of<IDbCommand>());
        }

        [TestMethod]
        public void GetByContractTest()
        {
            Assert.ThrowsException<NullReferenceException>(() => _planRepository.GetByContract("000000"));
        }

        [TestMethod]
        public void GetByContractTestData()
        {
            DataSet ds = new DataSet();

            mockSqlClientHelper.Setup(x => x.ExecuteDataSet(It.IsAny<IDbCommand>())).Returns(new DataSet().AddTable(() => new DataTable().AddColumns("Plan_Descripcion_Comercial").AddRow("MULTITRUST")));
            
            var plan = _planRepository.GetByContract("102056");
            Assert.IsNotNull(plan);
        }
    }
}
