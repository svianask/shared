﻿using ClientContracts.Domain.ContractAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientContracts.Repository
{
    public interface IRADa
    {
        Plan GetByContract(string contractId);

        Plan GetComercialNameByPlanId(string planId);
        decimal GetContributionSum(string contractId);
        ContractPeriod GetContractPeriodByContract(string contractId);
    }
}
