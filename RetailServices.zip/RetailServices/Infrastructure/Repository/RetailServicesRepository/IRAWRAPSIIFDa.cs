﻿using ClientAccounts.Domain.AccountClabeAggregate;
using ClientContracts.Domain.AssociatedContractAggregate;
using ClientContracts.Domain.BankAggregate;
using ClientContracts.Domain.CashTransactionAggregate;
using ClientContracts.Domain.ContractAggregate;
using ClientContracts.Domain.ContractBankAccountAggregate;
using ClientContracts.Domain.ContractBeneficiariesAggregate;
using ClientContracts.Domain.ContractContributionsAggregate;
using ClientContracts.Domain.ContractInflationAggregate;
using ClientContracts.Domain.ContractMovementsAggregate;
using ClientContracts.Domain.ContractsAcceptedAggregate;
using ClientContracts.Domain.ContractsAggregate;
using ClientContracts.Domain.ContractsOfClientAggregate;
using ClientContracts.Domain.ContractsPeriodicityAggregate;
using ClientContracts.Domain.ContractTrackerAggregate;
using ClientContracts.Domain.ContractWithdrawalsAggregate;
using ClientContracts.Domain.ContributionsOnDemandAggregate;
using ClientContracts.Domain.DetailBankAccountAggregate;
using ClientContracts.Domain.FrecuencyTypeAggregate;
using ClientContracts.Domain.FundAggregate;
using ClientContracts.Domain.FundSaleDatesAggregate;
using ClientContracts.Domain.InvestmentsAggregate;
using ClientContracts.Domain.SummaryContributionsAggregate;
using ClientFullSurrender.Domain;
using ClientProfileDomain.ClientProfileAggregate;
using ClientProfileDomain.PortfolioTypeAggregate;
using ClientProfileDomain.SalesPractContractProfileAggregate;
using DomiciliationContract.Domain.ClientDomiciliationAggregate;
using DomiciliationContract.Domain.ConnectorResultAggregate;
using DomiciliationContract.Domain.DomiciliationOnDemandAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using WithdrawalContract.Domain.PartialWithdrawalConnectorAggregate;
using WithdrawalContract.Domain.WithdrawalContractAggregate;

namespace ClientContracts.Repository
{
    public interface IRAWRAPSIIFDa
    {
        ContractsOfClient GetClientContracts(string clientIdentifier);
        int UpdateContactData(string contractIdentifier, string email);
        ContractsOf GetContracts(string clientIdentifier);
        SummaryContributions GetSummaryContributionsNumber(string contractId);
        CashTransaction GetContractCashTransactions(string contractId, int platform, DateTime? startDate, DateTime? endDate);
        decimal GetOnDemandCash(string contractId);
        ConnectorResult GenerateDomiciliationOnDemand(DomiciliationOnDemand domiciliation);
        void InsertLogDomiciliation(string xmlToInsert);
        List<AssociatedContract> GetAssociateContracts(string clientIdentifier);
        List<AssociatedContract> GetAssociateContractsByContract(string contractId);
        decimal GetPortfolioProduct(string contractId, string sPName);
        decimal GetContractBalanceHistory(string contractId, string queryDates, string sPName, bool getLastBalance);
        decimal GetContractCharges(string stringXml, int platform);
        decimal GetContractHistoricCharges(string stringXml, int platform);
        Investments GetContractBalanceDetail(string stringXml, string sPName);
        decimal GetContractCommittedAmount(string contractId);
        ContractContributions GetContractContributions(string stringXml, int platform);
        ContractContributions GetContractHistoricContributions(string stringXml, int platform);
        ContractWithdrawals GetContractWithdrawals(string stringXml, int platform);
        ContractWithdrawals GetContractHistoricWithdrawals(string stringXml, int platform);
        ContributionsOnDemand GetContributionsOnDemand(string stringXml, int platform);
        string GetClientRFCByContract(string contractId);
        Contr GetContractInfo(string contractId);
        string GetClientIdByContract(string contractId);
        List<ContractBankAccount> GetContractBankAccounts(string contractId);
        List<ContractBankAccount> GetContractBankAccountsTddTdcClb(string contractId);
        List<string[]> usp_SOC_SIIF_GetContractsActPdUpWithIsAccountThirdByRFC(string rfc);
        decimal GetContractSummaryWithdrawalsCommitted(string contractId);
        FundSaleDates GetContractFundsLiquidityDates(string fundId, DateTime dateRequest, int platform);
        string GetContractChargeBonusDescriptionById(int operationType, int platform, string chargeId);
        Int64 GeneratePartialWithdrawalPortal(PartialWithdrawalConnectorInfo partialWithdrawalConnectorInfo);
        Int64 GeneratePartialWithdrawal(PartialWithdrawalConnectorInfo partialWithdrawalConnectorInfo);
        void GenerateContractTransactionSIIF(string contractId, string transactionId, int transactionType, DateTime transactionDate, string productType, string userId);
        WithdrawalsContractSummary GetContractWithdrawalsCurrentYear(string contractId, int platform);
        Int64 GenerateContractFundChargeOrder(string contractId, int chargeType, double amountCharge, double amountCommission, double amountTax, string comment, bool avalaibleCash);
        void SetContractWithdrawalChargeLog(WithdrawalContractChargeLog request);
        void SetContractDepositLog(string contractId, string transactionId, string bankId, string bankAccount, string beneficiaryName);
        ContractWithdrawals GetContractWithdrawalsByDate(string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        ContractWithdrawals GetHistoricContractWithdrawalsByDate(string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        ContractContributions GetContractContributionsByDate(string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        ContractContributions GetHistoricContractContributionsByDate(string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        ContributionsOnDemand GetContributionsOnDemandByDate(string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        decimal GetContractChargesByDate(string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        List<ContractDetailMovement> GetContractDetailCashMovementsByDate(string contractId, string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        List<ContractDetailMovement> GetContractDetailFundsMovementsByDate(string contractId, string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        List<ContractDetailMovement> GetHistoricContractDetailCashMovementsByDate(string contractId, string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        List<ContractDetailMovement> GetContractDetailPendingMovementsByDate(string contractId, string stringXml, int platform, DateTime initialDate, DateTime finalDate);
        #region client profile
        ClientProfile GetClientContractProfile(string spName, string contractId);
        SalesPractPortfolioType GetContractPortfolio(string spName, string contractId);
        SalesPractContractProfile GetSalesPracticeContractProfile(string contractId);
        #endregion
        List<Bank> GetBanksCatalog(int platform);
        string GetCRMKey(string contractId, int productType);
        void LogsRegisterBankAccountCRM(string xmlInsert);

        AccountClabeSchema GetAccountClabeSchema(string ClabeId);

        List<DetailBankAccount> GetAccountsByContract(string contractId);

        decimal GetFullSurrenderCancellationChargeMultitros(int contractObjectiveNumContributions, decimal contractMonthsOnPlan, int planIdentifier);
        decimal GetFullSurrenderCancellationChargePercent(int contractObjectiveNumContributions, decimal contractMonthsOnPlan, int planIdentifier);
        decimal GetFinancialIndicators(DateTime requiredDate, short indicadorId);

        List<ChargeConfig> GetChargesPaysRS(int operationType);
        List<ChargeConfig> GetChargesPaysGT(int operationType);

        double GetSIIFRateForAssetFeeChargeRS_GT(int ProductId, int planId, decimal balance);

        double GetDeducibilidadPeriod(string TypeDeductible, int Period, Int16 SubtipoEdad);
        decimal GetDeductibleConfigZone(int zoneIdentifier, DateTime currentDate);

        DataSet GetContractCashTransactions(string contractId, DateTime StartDate, DateTime EndDate);

        List<InvestmentFundOrderGroups> GetInvestmentFundOrderGroups(string typeProduct, bool getSubGroup);

        bool GetFullSurrenderChargeExists(string ContractId, int ChargeId);
        List<ContractPositionMonth> GetContractPositionByMonth(string ContractId, DateTime RequiredDate);
        List<TransactionWithdrawal> GetContractSurrenders(string contractId, DateTime initialDate, DateTime finalDate, int applied);

        List<InvestmentFundOrder> GetAppliedTransactionInfo(string ContractId, string TransactionId);
        InvestmentContractMoneyTransaction GetContractTransaction(string ContractId, string TransactionId);
        void CancelDomiciliationByContract(string contractId);
        ContractStatus GetContractStatusInfo(string contractId);

        string GetReferenceNumber(string contractId, int platform);
        List<ContractAccepted> GetContractsAccepted(string rfc);
        int UpdateContractsAccepted(string rfc, string contractId, bool isCommited);
        ContractPeriodicity GetPeriodicityByContract(string contractMaster);

        List<ClientDomiciliation> GetDomiciliationsByContract(string contractId, string clientIdentifier);

        List<BankCatalog> GetBanksCatalog();
        ContractsOf GetContractsActivePaidUp(string clientIdentifier);
        List<AssociatedContract> GetAssociateContractsPaidUp(string clientIdentifier);
        decimal GetPendingContributionAmount(string contractId);
        ContractInflation GetContractInflation(string contractId);
        int GetAllowedUnpaidContributions(string contractId);
        List<ContractTrackerGraphicInfo> GetContractTrackerGraphicInformation(string contractId);
        List<ContractBankAccountAllowDomi> GetContractBankAccountsAllowDomi(string contractId, string clientIdentifier);
        List<FrecuencyTypeCatalog> GetFrecuencyTypeCatalogForDomi();
        List<FundPortfolio> GetPortfolioByContractId(string contractId);
        bool UpdatePerfilPortfolio(string contractId, int platformId);
        void UpdateDefinedPortfolio(string strPercentagesFounds, int totalFounds, string strSseparator, DateTime tranDate, string contractId, int platformId);
        void InsertContractPortfolioDefinedLogs(string strPorfolioOld, string strPorfolioNew, string contractId, string identifier);
        void GenerateFundTransactionSIIF(int transactionType, string strPlatform, string tranId, DateTime tranDate, string contractId, string clientId);
        List<Beneficiary> GetContractBeneficiariesGT(string contractId);
        List<Beneficiary> GetContractBeneficiariesRS(string contractId);
    }
}
