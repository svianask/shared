﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Domain;

namespace ClientContracts.Repository
{
    public interface INotificationsProxy
    {
        OperationResult NotificationsAppSync(NotificationsProxyTypes.SendNotificationDistListNRequest request);
    }
}
