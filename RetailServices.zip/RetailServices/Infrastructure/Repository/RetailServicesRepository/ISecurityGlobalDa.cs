﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientContracts.Domain.ContractAggregate;

namespace ClientContracts.Repository
{
    public interface ISecurityGlobalAppDa
    {
         SolvenciaData GetClienteDatosSolvencia(string clientIdentifier, int portalId);
    }
}
