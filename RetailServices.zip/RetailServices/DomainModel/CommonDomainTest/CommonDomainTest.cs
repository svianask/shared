﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Common.DomainTest
{
    [TestClass]
    public class CommonDomainTest
    {
        [TestMethod]
        public void CatalogEntityCreateSuccess()
        {
            var catalogEntity = new CatalogEntity
            {
                Identifier = "1",
                Name = "TestIdentity"
            };

            Assert.IsTrue(
                catalogEntity.GetAttributesToIncludeInEqualityCheck().SequenceEqual(
                    new CatalogEntity() { Identifier = "1", Name = "TestIdentity" }.GetAttributesToIncludeInEqualityCheck()
                )
            );
        }


        [TestMethod]
        public void OperationResultCreateSuccess()
        {
            var operationResult = new OperationResult
            {
                Successful = true,
                SystemMessages = new List<SystemMessage>
                {
                }
            };

            operationResult.GetAttributesToIncludeInEqualityCheck().SequenceEqual(
                new OperationResult()
                    {
                        Successful = true,
                        SystemMessages = new List<SystemMessage>
                        {
                        }
                    }.GetAttributesToIncludeInEqualityCheck()
            );
        }


        [TestMethod]
        public void SystemMessageCreateSuccess()
        {
            var systemMessage = new SystemMessage
            {
                Message = "Create system message test",
                MessageType = SystemMessageTypes.Information
            };

            systemMessage.GetAttributesToIncludeInEqualityCheck().SequenceEqual(
                new SystemMessage
                {
                    Message = "Create system message test",
                    MessageType = SystemMessageTypes.Information
                }.GetAttributesToIncludeInEqualityCheck()
            );
        }
    }
}
