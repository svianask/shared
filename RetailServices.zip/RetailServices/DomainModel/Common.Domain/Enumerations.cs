﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Domain
{
    public class Enumerations
    {
        /// <summary>
        /// Use only for data access and data access intagration
        /// </summary>
        public enum Platform
        {
            SIIFAS = 0, SIIFSK = 1, OMNI = 2, OMSA = 3
        }

        /// <summary>
        /// Use only for business logic
        /// </summary>
        public enum Product
        {
            GlobalTrust = 5, RegularSaving = 10, CajaAhorro = 15, FondoAhorro = 20, PlanPensiones = 25, GreenLight = 30, RetailMass = 35
        }

        //Note: This enumeration is linked to the SIIF platform
        public enum ChargesIdentifierSIIF
        {
            AssetFee = 33,
            PartialSurrenderCharge = 55,
            FullSurrenderCharge = 30,
            YearlyFee = 27,
            YearlyFeeConf = 15147,//    AE02/01/2019 cargo anualidad : MX01-215110
            ContributionCharge = 60,
            MinimumBalanceCharge = 13207,
            TaxRetentionCharge = 13205,
            OvercomeContributionCharge = 13203,
            ExcessivePartialSurrenderCharge = 0,
            FullSurrenderCharge2008 = 1,
            CapitalBonusCharge = 13215,
            DCCancellationChargeSK = 13219,
            DCCancellationCuadreSK = 13220,
            DCCancellationChargeAS = 13223,
            DCCancellationCuadreAS = 13224,
            EmissionCheck = 15105,
            LiquidationCashChargeSK = 52,
            LiquidationCashCuadreSK = 51,
            LiquidationCashChargeAS = 52,
            LiquidationCashCuadreAS = 51,
            RetentionChargeRescue = 15117,
            TaxRetentionChargeRescue = 15135,
        }

        public enum InvestmentFundSubOrderType
        {
            SaleFundToBuyFund = 10,
            SaleFundToBuyCash = 11,
            SaleFundToDeposit = 12,
            BuyFundFromSaleFund = 20,
            BuyFundFromCash = 21,
            InDepositCash = 30,
            OutDepositCash = 40,
            ChargeCash = 50,
            ChargeTransfer = 51,
            PaymetTransfer = 61,
            CompensationCash = 60,
            SaleFundToBuyFundOtherContract = 13,
            BuyFundFromSaleFundOtherContract = 22
        }

        public enum InvestmentFundOrderType
        {
            SaleFund = 1,
            BuyFund = 2,
            InDepositCash = 3,
            DepositOutCash = 4,
            ChargeCash = 5,
            CompensationCash = 6
        }

        public enum ICMoneyTransactionType
        {
            None = 0,
            TransferFundsManyToMany = 1,
            FullSurrenderClientCancellataion = 2,//20 
            FullSurrenderAutomaticCanellation = 3,//21
            PartialSurrender = 4, //10
            MinimumBalanceCharge = 8,
            //segric 16/02/2011
            PortfolioRebalance = 5,
            WKGenerationCharge = 6,
            LiquidationBalanceCash = 9,
            LiquidityGroupedPlan = 10,
            LiquidityGrouperPlan = 11,
            FullSurrenderGroupedPlan = 12,
            CorpSurrenders = 13,
            CorpLoans = 14,
            RescueWealthRequest = 15,
            RescuePayment = 16
        }
    }
}
