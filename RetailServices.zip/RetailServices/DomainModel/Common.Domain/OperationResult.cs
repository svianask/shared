﻿using System.Collections.Generic;

namespace Common.Domain
{
    public class OperationResult
    {
        public OperationResult()
        {
            SystemMessages = new List<SystemMessage>();
        }

        public bool Successful { get; set; }

        public List<SystemMessage> SystemMessages { get; set; }

        public IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                SystemMessages
            };
        }
    }
}
