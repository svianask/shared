﻿using Common.Domain;
using Funds.Domain.FundTradingAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funds.Messages
{
    public class GetFundsTradingsResponse
    {
        public List<FundTrading> FundTradings;
        public OperationResult Result;

        public GetFundsTradingsResponse() { FundTradings = new List<FundTrading>(); Result = new OperationResult(); }
    }

    public class GetFundsTradingsRequest
    {
        public List<string> ListFunds;
        public int Platform;
        public DateTime? BaseDate;
    }
}
