﻿using Common.Domain;
using Funds.Domain.TradeInfoAggregate;
using System.Collections.Generic;

namespace Funds.Messages
{
    public class TradeInfoResponse
    {
        public OperationResult Result;
        public List<TradeInfo> FundsTradeInfo;
    }
}