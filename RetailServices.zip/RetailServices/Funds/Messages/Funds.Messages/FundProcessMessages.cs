﻿using Common.Domain;
using Funds.Domain.FundProcessAggregate;
using System;
using System.Collections.Generic;

namespace Funds.Messages
{
    public class FundProcessCreateRequest
    {
        public string ProcessId { get; set; }
        public string UserId { get; set; }
        public string FundSource { get; set; }
        public string FundTarget { get; set; }
        public string FundReinvestment { get; set; }
        public short ProcessTypeId { get; set; }
    }

    public class FundProcessUpdateRequest : FundProcessCreateRequest
    {
        public short StatusId { get; set; }
        public string ErrorDescription { get; set; }
    }

    public class FundProcessResponse : BaseResponse
    {
        public FundProcess FundProcess { get; set; } = FundProcess.Empty();
    }

    public class FundProcessTransferCreateRequest
    {
        public string Id { get; set; }
        public string ProcessId { get; set; }
        public string ContractId { get; set; }
        public double PortfolioTitImp { get; set; }
        public double PortfolioCommitted { get; set; }
        public string UserId { get; set; }
    }

    public class FundProcessTransferUpdateRequest : FundProcessTransferCreateRequest
    {
        public double PortfolioTransferred { get; set; }
        public int PortfolioOrderId { get; set; }
        public double SourcePortfolioTransferred { get; set; }
        public int SourcePortfolioOrderId { get; set; }
        public short StatusId { get; set; }
        public string Comment { get; set; }
    }

    public abstract class BaseResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class FundProcessTransferResponse : BaseResponse
    {
        public FundProcessMovement FundProcessTransfer { get; set; } = FundProcessMovement.Empty();
    }

    public abstract class FundProcessRequestByDaysBefore
    {
        public int NoDaysBefore { get; set; }
    }

    public class FundProcessTransferRequest : FundProcessRequestByDaysBefore
    {
        public short ProcessTypeId { get; set; }
    }

    public class FundProcessReinvestmentRequest : FundProcessRequestByDaysBefore { }

    public abstract class CavFundsToMovementResponse : BaseResponse
    {
        public short ProcessTypeId { get; set; }
        public List<FundProcess> FundProcesses { get; set; } = new List<FundProcess>();
    }

    public class CavFundsToReprocessResponse : CavFundsToMovementResponse
    {
        public CavFundsToReprocessResponse()
        {
            ProcessTypeId = (short)FundProcessType.Transfer;
        }
    }

    public class CavFundsToReinvestmentResponse : CavFundsToMovementResponse
    {
        public CavFundsToReinvestmentResponse()
        {
            ProcessTypeId = (short)FundProcessType.Reinvestment;
        }
    }

    public abstract class FundAdministrationRequest
    {
        public string FundSource { get; set; }
        public string FundReinvestment { get; set; }
        public string ContractId { get; set; }
        public string UserId { get; set; }
    }

    public class FundAdministrationCreateRequest : FundAdministrationRequest
    {
        public string FundTarget { get; set; }
        public string TransferProcessLogId { get; set; }
    }

    public class FundAdministrationUpdateRequest : FundAdministrationRequest
    {
        public string ReinvestmentProcessLogId { get; set; }
    }

    public class FundAdministrationResponse : BaseResponse
    {
        public FundAdministration FundAdministration { get; set; } = FundAdministration.Empty();
    }

    public class FundClientAdministrationUpdateRequest
    {
        public string FundSource { get; set; }
        public string ContractId { get; set; }
        public short StatusId { get; set; }
        public string UserId { get; set; }
    }

    public class FundClientAdministrationRequest
    {
        public List<string> Funds { get; set; } = new List<string>();
    }

    public class FundClientAdministrationUpdateResponse : BaseResponse
    {
        public FundAdministration FundAdministration { get; set; } = FundAdministration.Empty();
    }

    public class FundClientAdministrationResponse : BaseResponse
    {
        public List<FundAdministration> FundAdministrations { get; set; } = new List<FundAdministration>();
    }

    public class BusinessDateDaysBeforeRequest
    {
        public int NoDaysBefore { get; set; }
        public DateTime CurrentDate { get; set; }
    }

    public class BusinessDateDaysBeforeResponse : BaseResponse
    {
        public DateTime BusinessDate { set; get; }
    }

    public class FundsAdministrationConfigRequest
    {
        public DateTime BaseDate { get; set; }
        public int NoMonthsLater { get; set; }
    }

    public class FundsAdministrationConfigResponse : BaseResponse
    {
        public List<FundAdministrationConfig> FundsAdministrationConfig { get; set; } = new List<FundAdministrationConfig>();
    }
}
