﻿using Common.Domain;
using Funds.Domain.FundSalesInfoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funds.Messages
{
    public class GetFundsForSaleResponse
    {
        public OperationResult Result;
        public List<FundSalesInfo> FundsForSale;

        public GetFundsForSaleResponse() { Result = new OperationResult(); FundsForSale = new List<FundSalesInfo>(); }
    }

    public class GetFundsForSaleRequest
    {
        public List<string> FundIdentifiers;
        public DateTime? BaseDate;
        public int Platform;
    }
}
