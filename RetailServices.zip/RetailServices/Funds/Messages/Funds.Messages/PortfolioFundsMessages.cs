﻿using Common.Domain;
using Funds.Domain.PortfolioFundAggregate;
using System.Collections.Generic;

namespace Funds.Messages
{
    public class PortfolioFundsRequest
    {
        public string FundId { get; set; }
        public int Platform { get; set; } = 10;
    }

    public abstract class PortfolioFundsResponse
    {
        public OperationResult Result { get; set; } = new OperationResult();
    }

    public class PortfolioFundsTransferResponse : PortfolioFundsResponse
    {
        public List<PortfolioFundTransfer> PortfolioFunds { get; set; } = new List<PortfolioFundTransfer>();
    }

    public class PortfolioFundsReinvestmentResponse : PortfolioFundsResponse
    {
        public List<PortfolioFundReinvestment> PortfolioFunds { get; set; } = new List<PortfolioFundReinvestment>();
    }

    public class PortfolioFundsReinvestmentRequest
    {
        public string FundBridge { get; set; }
        public string FundReinvestment { get; set; }
        public string FundPreviousId { get; set; }
        public int NoDaysBefore { get; set; }
    }
}
