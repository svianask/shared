﻿using System;
using System.Collections.Generic;

namespace Funds.Messages
{
    public class TradeInfoRequest
    {
        public List<string> FundIdentifiers;
        public DateTime? BaseDate;
        public int Platform;
    }
}
