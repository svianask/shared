﻿using Ddd;
using System;
using System.Collections.Generic;

namespace Funds.Domain.TradeInfoAggregate
{
    public class PurchaseInfo : ValueObject<PurchaseInfo>
    {
        //DaysPurchaseOperation
        private int _anticipationDaysForPurchase;
        private int _daysForPurchaseSettlement;

        //PurchaseConfiguration
        private bool _countAnticipationDaysByPurchaseLabor;
        private bool _countLiquidationDaysByPurchaseLabor;
        private bool _purchaseByAnticipatedLiquidation;
        private bool _isLiquidPurchase;

        //PurchaseComision
        private double _operatorCommissionPerPurchase;
        private double _operatorCommissionTaxPerPurchase;

        private PurchaseInfo()
        {
            _anticipationDaysForPurchase = int.MinValue;
            _daysForPurchaseSettlement = int.MinValue;
            _operatorCommissionPerPurchase = double.MinValue;
            _operatorCommissionTaxPerPurchase = double.MinValue;
        }

        public int AnticipationDaysForPurchase => _anticipationDaysForPurchase;

        public int DaysForPurchaseSettlement => _daysForPurchaseSettlement;

        public bool CountAnticipationDaysByPurchaseLabor => _countAnticipationDaysByPurchaseLabor;

        public bool CountLiquidationDaysByPurchaseLabor => _countLiquidationDaysByPurchaseLabor;

        public bool PurchaseByAnticipatedLiquidation => _purchaseByAnticipatedLiquidation;

        public bool IsLiquidPurchase => _isLiquidPurchase;

        public double OperatorCommissionPerPurchase => _operatorCommissionPerPurchase;

        public double OperatorCommissionTaxPerPurchase => _operatorCommissionTaxPerPurchase;

        internal static PurchaseInfo Create()
        {
            return new PurchaseInfo();
        }

        protected override IEnumerable<object> GetAttributesToIncludeInEqualityCheck()
        {
            return new List<object>
            {
                AnticipationDaysForPurchase,
                DaysForPurchaseSettlement,
                CountAnticipationDaysByPurchaseLabor,
                CountLiquidationDaysByPurchaseLabor,
                PurchaseByAnticipatedLiquidation,
                IsLiquidPurchase,
                OperatorCommissionPerPurchase,
                OperatorCommissionTaxPerPurchase
            };
        }

        internal PurchaseInfo SetDaysPurchaseOperation(int anticipationDaysForPurchase, int daysForPurchaseSettlement)
        {
            if (anticipationDaysForPurchase < 0) { throw new ArgumentException("Los días de anticipación para la compra no deben ser menores a 0"); }
            if (daysForPurchaseSettlement < 0) { throw new ArgumentException("Los días de anticipación para la liquidación de la compra no deben ser menores a 0"); }

            this._anticipationDaysForPurchase = anticipationDaysForPurchase;
            this._daysForPurchaseSettlement = daysForPurchaseSettlement;
            return this;
        }

        internal PurchaseInfo SetPurchaseConfiguration(bool countAnticipationDaysByPurchaseLabor, bool countLiquidationDaysByPurchaseLabor, bool purchaseByAnticipatedLiquidation, bool isLiquidPurchase)
        {
            this._countAnticipationDaysByPurchaseLabor = countAnticipationDaysByPurchaseLabor;
            this._countLiquidationDaysByPurchaseLabor = countLiquidationDaysByPurchaseLabor;
            this._purchaseByAnticipatedLiquidation = purchaseByAnticipatedLiquidation;
            this._isLiquidPurchase = isLiquidPurchase;
            return this;
        }

        internal PurchaseInfo SetPurchaseComision(double operatorCommissionPerPurchase, double operatorCommissionTaxPerPurchase)
        {
            if (operatorCommissionPerPurchase < 0) { throw new ArgumentException("El monto de la comisión no puede ser menor a 0 "); }
            if (operatorCommissionTaxPerPurchase < 0 || operatorCommissionTaxPerPurchase > 99.99) { throw new ArgumentException("El porcentaje de los no puede ser menor a 0 y mayor a 99.99 "); }

            this._operatorCommissionPerPurchase = operatorCommissionPerPurchase;
            this._operatorCommissionTaxPerPurchase = operatorCommissionTaxPerPurchase;
            return this;
        }
    }
}
