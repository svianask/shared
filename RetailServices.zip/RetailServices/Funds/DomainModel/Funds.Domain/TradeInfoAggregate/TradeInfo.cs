﻿using Ddd;
using System;

namespace Funds.Domain.TradeInfoAggregate
{
    public class TradeInfo : Entity<string>, IRootAggregate
    {
        private bool _buyAvailable;
        private bool _saleAvailable;
        
        private PurchaseTradeDates _purchaseTradeDates;
        private SaleTradeDates _saleTradeDates;

        private PurchaseInfo _purchaseInfo;
        private SaleInfo _saleInfo;
        
        private DateTime _lastSobSubDate;

        private TradeInfo(string fundIdentifier)
        {
            Id = fundIdentifier;
            _lastSobSubDate = DateTime.Now.AddDays(1);
        }

        public bool BuyAvailable => _buyAvailable;

        public bool SaleAvailable => _saleAvailable;
        
        public SaleTradeDates SaleTradeDates => _saleTradeDates;

        public PurchaseInfo PurchaseInfo => _purchaseInfo;

        public SaleInfo SaleInfo => _saleInfo;

        public DateTime LastSobSubDate => _lastSobSubDate;

        public PurchaseTradeDates PurchaseTradeDates => _purchaseTradeDates;

        public static TradeInfo Create(string fundIdentifier)
        {
            return new TradeInfo(fundIdentifier);
        }

        public TradeInfo SetAvailableOperations(bool saleAvailable, bool buyAvailable)
        {
            _saleAvailable = saleAvailable;
            _buyAvailable = buyAvailable;

            return this;
        }

        public TradeInfo SetLastSobSubDate(DateTime lastSobSubDate)
        {
            this._lastSobSubDate = lastSobSubDate;
            return this;
        }

        public TradeInfo SetPurchaseTradeDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            this._purchaseTradeDates = PurchaseTradeDates.Create(requestDate, operationDate, liquidationDate);
            return this;
        }

        public TradeInfo SetSaleTradeDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            this._saleTradeDates = SaleTradeDates.Create(requestDate, operationDate, liquidationDate);
            return this;
        }

        public TradeInfo SetDaysPurchaseOperation(int anticipationDaysForPurchase, int daysForPurchaseSettlement)
        {
            if (_purchaseInfo == null) { this._purchaseInfo = PurchaseInfo.Create(); }
            _purchaseInfo.SetDaysPurchaseOperation(anticipationDaysForPurchase, daysForPurchaseSettlement);
            return this;
        }
        
        public TradeInfo SetPurchaseComision(double operatorCommissionPerPurchase, double operatorCommissionTaxPerPurchase)
        {
            if (_purchaseInfo == null) { this._purchaseInfo = PurchaseInfo.Create(); }
            _purchaseInfo.SetPurchaseComision(operatorCommissionPerPurchase, operatorCommissionTaxPerPurchase);
            return this;
        }

        public TradeInfo SetPurchaseConfiguration(bool countAnticipationDaysByPurchaseLabor, bool countLiquidationDaysByPurchaseLabor, bool purchaseByAnticipatedLiquidation, bool isLiquidPurchase)
        {
            if (_purchaseInfo == null) { this._purchaseInfo = PurchaseInfo.Create(); }
            _purchaseInfo.SetPurchaseConfiguration(countAnticipationDaysByPurchaseLabor, countLiquidationDaysByPurchaseLabor, purchaseByAnticipatedLiquidation, isLiquidPurchase);
            return this;
        }

        public TradeInfo SetDaysSalesOperation(int anticipationDaysForSales, int liquidationDaysForSales)
        {
            if (_saleInfo == null) { this._saleInfo = SaleInfo.Create(); }
            _saleInfo.SetDaysSalesOperation(anticipationDaysForSales, liquidationDaysForSales);
            return this;
        }

        public TradeInfo SetSalesComision(double operatorCommissionPerSale, double operatorCommissionTaxPerSale)
        {
            if (_saleInfo == null) { this._saleInfo = SaleInfo.Create(); }
            _saleInfo.SetSalesComision(operatorCommissionPerSale, operatorCommissionTaxPerSale);
            return this;
        }

        public TradeInfo SetSalesConfiguration(bool countAnticipationDaysBySaleLabor, bool countLiquidationDaysBySaleLabor, bool isLiquidSale)
        {
            if (_saleInfo == null) { this._saleInfo = SaleInfo.Create(); }
            _saleInfo.SetSalesConfiguration(countAnticipationDaysBySaleLabor, countLiquidationDaysBySaleLabor, isLiquidSale);
            return this;
        }

    }
}
