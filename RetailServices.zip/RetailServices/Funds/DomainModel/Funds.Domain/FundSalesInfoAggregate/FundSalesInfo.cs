﻿using Ddd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funds.Domain.FundSalesInfoAggregate
{
    public class FundSalesInfo : Entity<string>
    {
        //DaysSalesOperation
        private int _anticipationDaysForSales;
        private int _liquidationDaysForSales;

        //SalesConfiguration
        private bool _countAnticipationDaysBySaleLabor;
        private bool _countLiquidationDaysBySaleLabor;
        private bool _isLiquidSale;

        //SalesComision
        private double _operatorCommissionPerSale;
        private double _operatorCommissionTaxPerSale;

        private bool _buyAvailable;
        private SaleTradeDates _saleTradeDates;
        private DateTime _lastSobSubDate;

        private FundSalesInfo(string fundId)
        {
            Id = fundId;

            _anticipationDaysForSales = int.MinValue;
            _liquidationDaysForSales = int.MinValue;
            _operatorCommissionPerSale = double.MinValue;
            _operatorCommissionTaxPerSale = double.MinValue;
        }

        public static FundSalesInfo Create(string fundId)
        {
            return new FundSalesInfo(fundId);
        }

        public int AnticipationDaysSale => _anticipationDaysForSales;
        public bool CountAnticipationDaysSaleLabor => _countAnticipationDaysBySaleLabor;
        public int LiquidationDaysSale => _liquidationDaysForSales;
        public bool CountLiquidationDaysSaleLabor => _countLiquidationDaysBySaleLabor;
        public double OperatorCommisionSale => _operatorCommissionPerSale;
        public double OperatorCommisionSaleTax => _operatorCommissionTaxPerSale;
        public bool IsLiquidSale => _isLiquidSale;
        public bool BuyAvailable => _buyAvailable;
        public SaleTradeDates SaleTradeDates => _saleTradeDates;
        public DateTime LastSobSubDate => _lastSobSubDate;

        public FundSalesInfo SetDaysSalesOperation(int anticipationDaysForSales, int liquidationDaysForSales)
        {
            if (anticipationDaysForSales < 0) { throw new ArgumentException("Los días de anticipación para la venta no deben ser menores a 0"); }
            if (liquidationDaysForSales < 0) { throw new ArgumentException("Los días de anticipación para la liquidación de la venta no deben ser menores a 0"); }

            this._anticipationDaysForSales = anticipationDaysForSales;
            this._liquidationDaysForSales = liquidationDaysForSales;
            return this;
        }

        public FundSalesInfo SetSalesConfiguration(bool countAnticipationDaysBySaleLabor, bool countLiquidationDaysBySaleLabor, bool isLiquidSale)
        {
            this._countAnticipationDaysBySaleLabor = countAnticipationDaysBySaleLabor;
            this._countLiquidationDaysBySaleLabor = countLiquidationDaysBySaleLabor;
            this._isLiquidSale = isLiquidSale;
            return this;
        }

        public FundSalesInfo SetSalesComision(double operatorCommissionPerSale, double operatorCommissionTaxPerSale)
        {
            if (operatorCommissionPerSale < 0) { throw new ArgumentException("El monto de la comisión por ventas no puede ser menor a 0 "); }
            if (operatorCommissionTaxPerSale < 0 || operatorCommissionTaxPerSale > 99.99) { throw new ArgumentException("El porcentaje de los impuestos por ventas no puede ser menor a 0 y mayor a 99.99 "); }

            this._operatorCommissionPerSale = operatorCommissionPerSale;
            this._operatorCommissionTaxPerSale = operatorCommissionTaxPerSale;
            return this;
        }

        public FundSalesInfo SetSaleTradeDates(DateTime requestDate, DateTime operationDate, DateTime liquidationDate)
        {
            this._saleTradeDates = SaleTradeDates.Create(requestDate, operationDate, liquidationDate);
            return this;
        }

        public FundSalesInfo SetAvailableOperations(bool buyAvailable)
        {
            _buyAvailable = buyAvailable;
            return this;
        }

        public FundSalesInfo SetLastSobSubDate(DateTime lastSobSubDate)
        {
            this._lastSobSubDate = lastSobSubDate;
            return this;
        }
    }
}
