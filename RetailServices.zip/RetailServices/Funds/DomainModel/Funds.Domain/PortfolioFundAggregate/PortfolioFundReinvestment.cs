﻿using System;

namespace Funds.Domain.PortfolioFundAggregate
{
    public class PortfolioFundReinvestment : PortfolioFund
    {
        protected PortfolioFundReinvestment(string fundId, string contractId) : base(fundId, contractId) { }

        public static PortfolioFundReinvestment Create(string fundId, string contractId)
        {
            return new PortfolioFundReinvestment(fundId, contractId);

        }

        public new PortfolioFundReinvestment SetEmision(string emisionId, string emisionName)
        {
            base.SetEmision(emisionId, emisionName);
            return this;
        }
        public new PortfolioFundReinvestment SetPortfolio(double portfolioTitImp, double portfolioCommitted, double portfolioNoCommitted)
        {
            base.SetPortfolio(portfolioTitImp, portfolioCommitted, portfolioNoCommitted);
            return this;
        }

        public new PortfolioFundReinvestment SetFund(double priceFundAmount, DateTime priceFundDate)
        {
            base.SetFund(priceFundAmount, priceFundDate);
            return this;
        }
    }
}
