﻿using Ddd;
using System;

namespace Funds.Domain.FundProcessAggregate
{
    public class FundAdministration : Entity<int>, IRootAggregate
    {
        public string FundSource { get; private set; }
        public string FundTarget { get; private set; }
        public string FundReinvestment { get; private set; }
        public string ContractId { get; private set; }
        public short StatusId { get; private set; }
        public string UserId { get; private set; }
        public string TransferProcessLogId { get; private set; }
        public string ReinvestmentProcessLogId { get; private set; }

        private FundAdministration(int id, string fundSource, string contractId, string userId)
        {
            Id = id;
            FundSource = fundSource;
            ContractId = contractId;
            UserId = userId;
        }

        public static FundAdministration Create(string fundSource, string contractId, string userId)
        {
            if (string.IsNullOrEmpty(fundSource)) { throw new ArgumentException("El fondo origen no puede ser nulo."); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El usuario puede ser nulo."); }

            return new FundAdministration(0, fundSource, contractId, userId);
        }

        public static FundAdministration Create(int id, string fundSource, string contractId, string userId)
        {
            if (string.IsNullOrEmpty(fundSource)) { throw new ArgumentException("El fondo origen no puede ser nulo."); }
            if (string.IsNullOrEmpty(contractId)) { throw new ArgumentException("El contrato no puede ser nulo."); }
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El usuario puede ser nulo."); }

            return new FundAdministration(id, fundSource, contractId, userId);
        }

        public FundAdministration SetFundTarget(string fundTarget)
        {
            FundTarget = fundTarget;
            return this;
        }

        public FundAdministration SetFundReinvestment(string fundReinvestment)
        {
            FundReinvestment = fundReinvestment;
            return this;
        }

        public FundAdministration SetStatus(short statusId)
        {
            StatusId = statusId;
            return this;
        }

        public FundAdministration SetTransferProcessLogId(string transferProcessLogId)
        {
            TransferProcessLogId = transferProcessLogId;
            return this;
        }

        public FundAdministration SetReinvestmentProcessLogId(string reinvestmentProcessLogId)
        {
            ReinvestmentProcessLogId = reinvestmentProcessLogId;
            return this;
        }

        public static FundAdministration Empty()
        {
            return new FundAdministration(0, string.Empty, string.Empty, string.Empty);
        }
    }
}
