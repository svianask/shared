﻿using Ddd;
using System;

namespace Funds.Domain.FundProcessAggregate
{
    public class FundProcess : Entity<string>, IRootAggregate
    {
        public DateTime? StartDate { get; private set; }
        public DateTime? EndDate { get; private set; }

        public string FundSource { get; private set; }
        public string FundTarget { get; private set; }
        public string FundReinvestment { get; private set; }

        public string UserId { get; private set; }
        public short StatusId { get; private set; }
        public short ProcessTypeId { get; private set; }
        public string ErrorDescription { get; private set; } = string.Empty;

        private FundProcess(string processId, string userId, short processTypeId)
        {
            Id = processId;
            UserId = userId;
            ProcessTypeId = processTypeId;
        }

        public static FundProcess Create(string processId, string userId, short processTypeId)
        {
            if (string.IsNullOrEmpty(processId)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(userId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }
            if (processTypeId <= 0) { throw new ArgumentException("El tipo de proceso no puede ser nulo."); }
            return new FundProcess(processId, userId, processTypeId);
        }

        public FundProcess SetStatus(short statusId, string errorDescription = "")
        {
            StatusId = statusId;
            ErrorDescription = errorDescription;
            return this;
        }

        public FundProcess SetProcessDates(DateTime? startDate = null, DateTime? endDate = null)
        {
            StartDate = startDate;
            EndDate = endDate;
            return this;
        }

        public FundProcess SetFund(string fundSource, string fundTarget, string fundReinvestment)
        {
            FundSource = fundSource;
            FundTarget = fundTarget;
            FundReinvestment = fundReinvestment;
            return this;
        }

        public void InitProcess()
        {
            StatusId = (int)FundProcessStatus.EnProceso;
        }

        public void EndProcess(string errorDescription)
        {
            ErrorDescription = errorDescription;
            StatusId = string.IsNullOrEmpty(ErrorDescription) ? (short)FundProcessStatus.Terminado : (short)FundProcessStatus.Error;
            EndDate = DateTime.Now;
        }

        public static FundProcess Empty()
        {
            return new FundProcess(Guid.Empty.ToString(), string.Empty, 0);
        }
    }
}
