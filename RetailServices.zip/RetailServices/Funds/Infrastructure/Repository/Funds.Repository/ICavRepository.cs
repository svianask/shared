﻿using Funds.Domain.FundProcessAggregate;
using Funds.Domain.PortfolioFundAggregate;
using System;
using System.Collections.Generic;

namespace Funds.Repository
{
    public interface ICavRepository
    {
        List<PortfolioFundTransfer> GetPortfolioFunds(string spName, string fundId);
        FundProcess InsertProcess(string spName, FundProcess fundProcess);
        FundProcess UpdateProcess(string spName, FundProcess fundProcess);
        FundProcessMovement InsertProcessTransfer(string spName, FundProcessMovement transferMovement);
        FundProcessMovement UpdateProcessTransfer(string spName, FundProcessMovement transferMovement);
        List<FundProcess> GetFundProcessToReprocess(string spName, short processTypeId, int nDaysBefore);
        List<FundProcess> GetFundProcessToReinvestment(string spName, int nDaysBefore);
        List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string spName, string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore);
        FundProcessMovement InsertProcessReinvestment(string spName, FundProcessMovement reinvestmentMovement);
        FundProcessMovement UpdateProcessReinvestment(string spName, FundProcessMovement reinvestmentMovement);
        FundAdministration InsertAdministration(string spName, FundAdministration fundAdministration);
        FundAdministration UpdateAdministration(string spName, FundAdministration fundAdministration);
        List<FundAdministration> GetClientAdministration(string spName, string xmlFunds);
        FundAdministration UpdateClientAdministration(string spName, FundAdministration fundAdministration);
        DateTime GetBusinessDateDaysBefore(string spName, int nDaysBefore, DateTime currentDate);
        List<FundAdministrationConfig> GetFundsAdministrationConfig(string spName, DateTime baseDate, int nMonthsLater);
    }
}
