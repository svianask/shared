﻿using Funds.Domain.FundSalesInfoAggregate;
using Funds.Domain.FundTradingAggregate;
using Funds.Mappings;
using SqlClient.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Unity;

namespace Funds.Repository
{

    public class FundsRepository : IFundsRepository
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public FundsRepository([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            this._dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public List<FundSalesInfo> GetFundsForSale(string spName, string xmlFunIdentifiers, DateTime? baseDate)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@xmlFondos", xmlFunIdentifiers);
            cmd.AddParameterWithValue("@pFecha", baseDate);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return FundSalesInfoMapp.Mapp(ds);
        }

        public List<FundTrading> GetFundTradings(string spName, string xmlFundIdentifiers, DateTime? baseDate)
        {
            IDbCommand cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@xmlFondos", xmlFundIdentifiers);
            cmd.AddParameterWithValue("@pFecha", baseDate);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);

            return FundTradingMapp.Mapp(ds);
        }
    }
}
