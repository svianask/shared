﻿using Funds.Domain.FundProcessAggregate;
using Funds.Domain.PortfolioFundAggregate;
using Funds.Mappings;
using SqlClient.Helper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Unity;


namespace Funds.Repository
{
    public class CavRepository : ICavRepository
    {
        private readonly SqlConnection _dbConn;
        private readonly ISqlClientHelper _sqlClientHelper;

        public CavRepository([Dependency("RAWRAPSIIF")] SqlConnection dbConn, ISqlClientHelper sqlClientHelper)
        {
            _dbConn = dbConn;
            _sqlClientHelper = sqlClientHelper;
        }

        public List<PortfolioFundTransfer> GetPortfolioFunds(string spName, string fundId)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@pstrEmisionId", fundId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return PortfolioFundMapp.MappTransfers(ds);
        }

        public FundProcess InsertProcess(string spName, FundProcess fundProcess)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Proceso_Id", fundProcess.Id);
            cmd.AddParameterWithValue("@Usuario_Id", fundProcess.UserId);
            cmd.AddParameterWithValue("@Fondo_Origen", fundProcess.FundSource);
            cmd.AddParameterWithValue("@Fondo_Destino", fundProcess.FundTarget);
            cmd.AddParameterWithValue("@Fondo_Reinversion", fundProcess.FundReinvestment);
            cmd.AddParameterWithValue("@Tipo_Proceso_Id", fundProcess.ProcessTypeId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessMapp.Mapp(ds).First() ?? FundProcess.Empty();
        }

        public FundProcess UpdateProcess(string spName, FundProcess fundProcess)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Proceso_Id", fundProcess.Id);
            cmd.AddParameterWithValue("@Usuario_Id", fundProcess.UserId);
            cmd.AddParameterWithValue("@Estatus_Id", fundProcess.StatusId);
            cmd.AddParameterWithValue("@Error_Descripcion", fundProcess.ErrorDescription);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessMapp.Mapp(ds).First() ?? FundProcess.Empty();
        }

        public FundProcessMovement InsertProcessTransfer(string spName, FundProcessMovement transferMovement)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Transferencia_Id", transferMovement.Id);
            cmd.AddParameterWithValue("@Proceso_Log_Id", transferMovement.ProcessId);
            cmd.AddParameterWithValue("@Portafolio_Contrato_Id", transferMovement.ContractId);
            cmd.AddParameterWithValue("@Portafolio_Titulos", transferMovement.PortfolioTitImp);
            cmd.AddParameterWithValue("@Portafolio_Comprometido", transferMovement.PortfolioCommitted);
            cmd.AddParameterWithValue("@Usuario_Id", transferMovement.UserId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessTransferMapp.Mapp(ds).First() ?? FundProcessMovement.Empty();
        }

        public FundProcessMovement UpdateProcessTransfer(string spName, FundProcessMovement transferMovement)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Transferencia_Id", transferMovement.Id);
            cmd.AddParameterWithValue("@Proceso_Log_Id", transferMovement.ProcessId);
            cmd.AddParameterWithValue("@Portafolio_Contrato_Id", transferMovement.ContractId);
            cmd.AddParameterWithValue("@Portafolio_Transferido", transferMovement.PortfolioTransferred);
            cmd.AddParameterWithValue("@Portafolio_Orden_Id", transferMovement.PortfolioOrderId);
            cmd.AddParameterWithValue("@Portafolio_Transferido_Origen", transferMovement.SourcePortfolioTransferred);
            cmd.AddParameterWithValue("@Portafolio_Orden_Id_Origen", transferMovement.SourcePortfolioOrderId);
            cmd.AddParameterWithValue("@Usuario_Id", transferMovement.UserId);
            cmd.AddParameterWithValue("@Estatus_Id", transferMovement.StatusId);
            cmd.AddParameterWithValue("@Comentario", transferMovement.Comment);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessTransferMapp.Mapp(ds).First() ?? FundProcessMovement.Empty();
        }

        public List<FundProcess> GetFundProcessToReprocess(string spName, short processTypeId, int nDaysBefore)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Tipo_Proceso_Id", processTypeId);
            cmd.AddParameterWithValue("@No_Days_Before", nDaysBefore);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessMapp.Mapp(ds);
        }

        public List<FundProcess> GetFundProcessToReinvestment(string spName, int nDaysBefore)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@No_Days_Before", nDaysBefore);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessMapp.Mapp(ds);
        }

        public List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string spName, string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Fondo_Puente", fundBridge);
            cmd.AddParameterWithValue("@Fondo_Reinversion", fundReinvestment);
            cmd.AddParameterWithValue("@Fondo_Anterior", fundPreviousId);
            cmd.AddParameterWithValue("@No_Days_Before", nDaysBefore);
            cmd.CommandTimeout = 60;
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return PortfolioFundMapp.MappReinvestments(ds);
        }

        public FundProcessMovement InsertProcessReinvestment(string spName, FundProcessMovement reinvestmentMovement)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Transferencia_Id", reinvestmentMovement.Id);
            cmd.AddParameterWithValue("@Proceso_Log_Id", reinvestmentMovement.ProcessId);
            cmd.AddParameterWithValue("@Portafolio_Contrato_Id", reinvestmentMovement.ContractId);
            cmd.AddParameterWithValue("@Portafolio_Titulos", reinvestmentMovement.PortfolioTitImp);
            cmd.AddParameterWithValue("@Portafolio_Comprometido", reinvestmentMovement.PortfolioCommitted);
            cmd.AddParameterWithValue("@Usuario_Id", reinvestmentMovement.UserId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessTransferMapp.Mapp(ds).First() ?? FundProcessMovement.Empty();
        }

        public FundProcessMovement UpdateProcessReinvestment(string spName, FundProcessMovement reinvestmentMovement)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Transferencia_Id", reinvestmentMovement.Id);
            cmd.AddParameterWithValue("@Proceso_Log_Id", reinvestmentMovement.ProcessId);
            cmd.AddParameterWithValue("@Portafolio_Contrato_Id", reinvestmentMovement.ContractId);
            cmd.AddParameterWithValue("@Portafolio_Transferido", reinvestmentMovement.PortfolioTransferred);
            cmd.AddParameterWithValue("@Portafolio_Orden_Id", reinvestmentMovement.PortfolioOrderId);
            cmd.AddParameterWithValue("@Portafolio_Transferido_Origen", reinvestmentMovement.SourcePortfolioTransferred);
            cmd.AddParameterWithValue("@Portafolio_Orden_Id_Origen", reinvestmentMovement.SourcePortfolioOrderId);
            cmd.AddParameterWithValue("@Usuario_Id", reinvestmentMovement.UserId);
            cmd.AddParameterWithValue("@Estatus_Id", reinvestmentMovement.StatusId);
            cmd.AddParameterWithValue("@Comentario", reinvestmentMovement.Comment);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundProcessTransferMapp.Mapp(ds).First() ?? FundProcessMovement.Empty();
        }

        public FundAdministration InsertAdministration(string spName, FundAdministration fundAdministration)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Fondo_Origen", fundAdministration.FundSource);
            cmd.AddParameterWithValue("@Fondo_Destino", fundAdministration.FundTarget);
            cmd.AddParameterWithValue("@Fondo_Reinversion", fundAdministration.FundReinvestment);
            cmd.AddParameterWithValue("@Contrato_Id", fundAdministration.ContractId);
            cmd.AddParameterWithValue("@Usuario_Id", fundAdministration.UserId);
            cmd.AddParameterWithValue("@Transferencia_Proceso_Log_Id", fundAdministration.TransferProcessLogId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundAdministrationMapp.Mapp(ds).First() ?? FundAdministration.Empty();
        }

        public FundAdministration UpdateAdministration(string spName, FundAdministration fundAdministration)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Fondo_Origen", fundAdministration.FundSource);
            cmd.AddParameterWithValue("@Fondo_Reinversion", fundAdministration.FundReinvestment);
            cmd.AddParameterWithValue("@Contrato_Id", fundAdministration.ContractId);
            cmd.AddParameterWithValue("@Usuario_Id", fundAdministration.UserId);
            cmd.AddParameterWithValue("@Reinversion_Proceso_Log_Id", fundAdministration.ReinvestmentProcessLogId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundAdministrationMapp.Mapp(ds).First() ?? FundAdministration.Empty();
        }


        public List<FundAdministration> GetClientAdministration(string spName, string xmlFunds)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Xml_Fondos", xmlFunds);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundAdministrationMapp.Mapp(ds);
        }

        public FundAdministration UpdateClientAdministration(string spName, FundAdministration fundAdministration)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Fondo_Origen", fundAdministration.FundSource);
            cmd.AddParameterWithValue("@Contrato_Id", fundAdministration.ContractId);
            cmd.AddParameterWithValue("@Estatus_Id", fundAdministration.StatusId);
            cmd.AddParameterWithValue("@Usuario_Id", fundAdministration.UserId);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundAdministrationMapp.Mapp(ds).First() ?? FundAdministration.Empty();
        }

        public DateTime GetBusinessDateDaysBefore(string spName, int nDaysBefore, DateTime currentDate)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@No_Days_Before", nDaysBefore);
            cmd.AddParameterWithValue("@Current_Date", currentDate);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundAdministrationMapp.MappBusinessDays(ds, currentDate.Date).FirstOrDefault();
        }

        public List<FundAdministrationConfig> GetFundsAdministrationConfig(string spName, DateTime baseDate, int nMonthsLater)
        {
            var cmd = _sqlClientHelper.CreateCmdSP(spName, _dbConn);
            cmd.AddParameterWithValue("@Current_Date", baseDate);
            cmd.AddParameterWithValue("@No_Months_Later", nMonthsLater);
            var ds = _sqlClientHelper.ExecuteDataSet(cmd);
            return FundAdministrationConfigMapp.Mapp(ds);
        }
    }
}
