﻿using Funds.Domain.FundSalesInfoAggregate;
using Funds.Domain.FundTradingAggregate;
using System;
using System.Collections.Generic;

namespace Funds.Repository
{
    public interface IFundsRepository
    {
        List<FundSalesInfo> GetFundsForSale(string spName, string xmlFunIdentifiers, DateTime? baseDate);
        List<FundTrading> GetFundTradings(string spName, string xmlFundIdentifiers, DateTime? baseDate);
    }
}
