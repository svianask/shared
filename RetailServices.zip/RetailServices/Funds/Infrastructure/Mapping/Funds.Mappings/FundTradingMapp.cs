﻿using Funds.Domain.FundTradingAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.Application;

namespace Funds.Mappings
{
    public class FundTradingMapp
    {
        public static List<FundTrading> Mapp(DataSet ds)
        {
            List<FundTrading> fundTradings = new List<FundTrading>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                fundTradings.Add(
                    FundTrading.Create(dr["Emision"].ToString())
                    .SetSalesConfig(
                        Convert.ToInt32(Null.SetNull(dr["DiasAnticVenta"], new Int32())),
                        Convert.ToBoolean(Null.SetNull(dr["DiasAnticVentaHab"], new Boolean())),
                        Convert.ToInt32(Null.SetNull(dr["DiasAnticCompra"], new Int32())),
                        Convert.ToBoolean(Null.SetNull(dr["DiasAnticCompraHab"],new Boolean())))
                    .SetLiquidationConfig(
                        Convert.ToInt32(Null.SetNull(dr["DiasLiquidezVenta"],new Int32())),
                        Convert.ToBoolean(Null.SetNull(dr["DiaHabilLiquidezVenta"],new Boolean())),
                        Convert.ToInt32(Null.SetNull(dr["DiasLiquidezCompra"],new Int32())),
                        Convert.ToBoolean(Null.SetNull(dr["DiaHabilLiquidezCompra"],new Boolean())))
                    .SetOperationConfig(
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Venta"],new Double())),
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Compra"],new Double())),
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Venta_IVA"],new Double())),
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Compra_IVA"],new Double())))
                    .SetLiquidConfig(
                        Convert.ToBoolean(Null.SetNull(dr["Liquidacion_Anticipada"],new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["FondoLiquidoVenta"],new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["FondoLiquidoCompra"],new Boolean())),
                        Convert.ToDateTime(Null.SetNull(dr["UltimaFechaSobSubValuacion"],new DateTime())))
                    .SetFundConfig(
                        bool.Parse(dr["Fondo_Habilita_Compra"].ToString()),
                        bool.Parse(dr["Fondo_Habilita_Venta"].ToString()),
                        false)
                    .SetSaleTradingDates(
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Solicitud_Venta"],new DateTime())),
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Operacion_Venta"],new DateTime())),
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Liquidez_Venta"],new DateTime())))
                    .SetBuyTradingDates(
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Solicitud_Compra"], new DateTime())),
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Operacion_Compra"], new DateTime())),
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Liquidez_Compra"], new DateTime())))
                    .SetPricesConfig(
                        Convert.ToDouble(Null.SetNull(dr["PrecioFondo"], new Double())),
                        Convert.ToDouble(Null.SetNull(dr["PrecioFondoCompra"], new Double())),
                        Convert.ToDouble(Null.SetNull(dr["PrecioFondoVenta"], new Double())),
                        DateTime.MinValue)
                    );
            }

            return fundTradings;
        }
    }
}
