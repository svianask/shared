﻿using Funds.Domain.TradeInfoAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using Utilities.Application;

namespace Funds.Mappings
{
    public class TradeInfoMapp
    {
        public static List<TradeInfo> Mapp(DataSet ds)
        {
            List<TradeInfo> fundsTradeInfo = new List<TradeInfo>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                fundsTradeInfo.Add(
                    TradeInfo.Create(dr["Emision"].ToString())
                    .SetAvailableOperations(bool.Parse(dr["Fondo_Habilita_Venta"].ToString()), bool.Parse(dr["Fondo_Habilita_Compra"].ToString()))
                    .SetDaysPurchaseOperation(
                        Convert.ToInt32(Null.SetNull(dr["DiasAnticCompra"], new Int32())),
                        Convert.ToInt32(Null.SetNull(dr["DiasLiquidezCompra"], new Int32()))
                        )
                    .SetDaysSalesOperation(
                        Convert.ToInt32(Null.SetNull(dr["DiasAnticVenta"], new Int32())),
                        Convert.ToInt32(Null.SetNull(dr["DiasLiquidezVenta"], new Int32()))
                        )
                    .SetLastSobSubDate(Convert.ToDateTime(Null.SetNull(dr["UltimaFechaSobSubValuacion"],new DateTime())))
                    .SetPurchaseComision(
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Compra"],new Double())),
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Compra_IVA"],new Double()))
                        )
                    .SetPurchaseConfiguration(
                        Convert.ToBoolean(Null.SetNull(dr["DiasAnticCompraHab"],new Boolean())), 
                        Convert.ToBoolean(Null.SetNull(dr["DiaHabilLiquidezCompra"],new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["Liquidacion_Anticipada"],new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["FondoLiquidoCompra"],new Boolean()))
                        )
                    .SetPurchaseTradeDates(
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Solicitud_Compra"], new DateTime())), 
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Operacion_Compra"], new DateTime())), 
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Liquidez_Compra"], new DateTime()))
                        )
                    .SetSalesComision(
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Venta"],new Double())),
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Venta_IVA"],new Double()))
                        )
                    .SetSalesConfiguration(
                        Convert.ToBoolean(Null.SetNull(dr["DiasAnticVentaHab"], new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["DiaHabilLiquidezVenta"], new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["FondoLiquidoVenta"], new Boolean()))
                        )
                    .SetSaleTradeDates(
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Solicitud_Venta"], new DateTime())), 
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Operacion_Venta"], new DateTime())), 
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Liquidez_Venta"], new DateTime()))
                        )
                );
            }     

            /*
            investmentFundTradeInfo.InvestmentFund.Serie = (String)Null.SetNull(dr["EmisionSerie"].ToString(), String.Empty);
            investmentFundTradeInfo.Price.Valuation =
                Convert.ToDouble(Null.SetNull(dr["PrecioFondo"], new Double()));
            investmentFundTradeInfo.Price.Sale =
                Convert.ToDouble(Null.SetNull(dr["PrecioFondoVenta"],
                    new Double()));
            investmentFundTradeInfo.Price.Buy =
                Convert.ToDouble(Null.SetNull(dr["PrecioFondoCompra"],
                    new Double()));
            investmentFundTradeInfo.InvestmentFund.FundType.Identifier =
                (String)
                    Null.SetNull(dr["Tipo_FondoId"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.FundType.Name =
                (String)
                    Null.SetNull(dr["Tipo_FondoDsc"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.FundClasification.Identifier =
                (String)
                    Null.SetNull(dr["ClasifFondoId"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.FundClasification.Name =
                (String)
                    Null.SetNull(dr["ClasifFondoDsc"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.PersonType.Identifier =
                (String)
                    Null.SetNull(dr["TipoPersonalidadId"].ToString(),
                        String.Empty);
            investmentFundTradeInfo.InvestmentFund.PersonType.Name =
                (String)
                    Null.SetNull(dr["TipoPersonalidadDsc"].ToString(),
                        String.Empty);
            investmentFundTradeInfo.InvestmentFund.CurrencyType.Identifier =
                (String)Null.SetNull(dr["DivisaId"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.CurrencyType.Name =
                (String)
                    Null.SetNull(dr["DivisaDsc"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.Operator.Identifier =
                (String)Null.SetNull(dr["EmisorId"].ToString(), String.Empty);
            investmentFundTradeInfo.InvestmentFund.Operator.Name =
                (String)
                    Null.SetNull(dr["EmisorDsc"].ToString(), String.Empty);
            //added null to investmentFundTradeInfo.InvestmentFund.FundValuationType
            investmentFundTradeInfo.InvestmentFund.FundValuationType = null;
            */








            return fundsTradeInfo;
        }
    }
}
