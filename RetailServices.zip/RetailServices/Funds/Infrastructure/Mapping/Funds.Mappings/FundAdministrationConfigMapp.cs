﻿using Funds.Domain.FundProcessAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using Utilities.Application;

namespace Funds.Mappings
{
    public static class FundAdministrationConfigMapp
    {
        public static List<FundAdministrationConfig> Mapp(DataSet ds)
        {
            var administrationConfigs = new List<FundAdministrationConfig>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                administrationConfigs.Add(FundAdministrationConfig.Create(dr["Fondo_Origen"].ToString(), dr["Fondo_Destino"].ToString(), dr["Fondo_Reinversion"].ToString()).SetDates(Convert.ToDateTime(Null.SetNull(dr["Fecha_Liquidacion"], DateTime.Now))));
            }

            return administrationConfigs;
        }

    }
}
