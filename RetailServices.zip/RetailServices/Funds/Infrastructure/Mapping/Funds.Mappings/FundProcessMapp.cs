﻿using Funds.Domain.FundProcessAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using Utilities.Application;

namespace Funds.Mappings
{
    public static class FundProcessMapp
    {

        public static List<FundProcess> Mapp(DataSet ds)
        {
            var fundProcesses = new List<FundProcess>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                fundProcesses.Add(FundProcess.Create(dr["Id"].ToString(), dr["Usuario_Id"].ToString(), Convert.ToInt16(Null.SetNull(dr["Tipo_Proceso_Id"], 0)))
                    .SetFund(dr["Fondo_Origen"].ToString(), dr["Fondo_Destino"].ToString(), dr["Fondo_Reinversion"].ToString())
                    .SetStatus(Convert.ToInt16(Null.SetNull(dr["Estatus_Id"], 0)))
                    .SetProcessDates(Convert.ToDateTime(Null.SetNull(dr["Fecha_Inicio"], DateTime.Now)), Convert.ToDateTime(Null.SetNull(dr["Fecha_Fin"], DateTime.Now))));
            }

            return fundProcesses;
        }
    }
}
