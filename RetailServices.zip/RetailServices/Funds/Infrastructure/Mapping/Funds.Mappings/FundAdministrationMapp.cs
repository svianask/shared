﻿using Funds.Domain.FundProcessAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using Utilities.Application;

namespace Funds.Mappings
{
    public static class FundAdministrationMapp
    {
        public static List<FundAdministration> Mapp(DataSet ds)
        {
            var fundAdministrations = new List<FundAdministration>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                fundAdministrations.Add(
                    FundAdministration.Create(Convert.ToInt32(Null.SetNull(dr["Id"], 0)), dr["Fondo_Origen"].ToString(), dr["Contrato_Id"].ToString(), dr["Usuario_Id"].ToString())
                        .SetFundTarget(dr["Fondo_Destino"].ToString())
                        .SetFundReinvestment(dr["Fondo_Reinversion"].ToString())
                        .SetStatus(Convert.ToInt16(Null.SetNull(dr["Estatus_Id"], 0)))
                        .SetTransferProcessLogId(dr["CAV_Transferencia_Proceso_Log_Id"].ToString())
                        .SetReinvestmentProcessLogId(dr["CAV_Reinversion_Proceso_Log_Id"].ToString()));
            }

            return fundAdministrations;
        }

        public static List<DateTime> MappBusinessDays(DataSet ds, DateTime businessDate)
        {
            var businessDays = new List<DateTime>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                businessDays.Add(Convert.ToDateTime(Null.SetNull(dr["Filter_Date"], businessDate)));
            }

            if (businessDays.Count <= 0)
                businessDays.Add(businessDate);
            return businessDays;
        }
    }
}
