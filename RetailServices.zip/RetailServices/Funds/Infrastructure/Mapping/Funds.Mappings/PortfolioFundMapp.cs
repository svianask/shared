﻿using Funds.Domain.PortfolioFundAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using Utilities.Application;

namespace Funds.Mappings
{
    public static class PortfolioFundMapp
    {
        public static List<PortfolioFundTransfer> MappTransfers(DataSet ds)
        {
            var portfolioFunds = new List<PortfolioFundTransfer>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                portfolioFunds.Add(
                    PortfolioFundTransfer.Create(dr["Emision_Id"].ToString()
                                        , dr["Contrato_Id"].ToString())
                    .SetFundValue(Convert.ToDouble(Null.SetNull(dr["Valor_Fondo"], 0)))
                    .SetStatus(Convert.ToInt16(Null.SetNull(dr["Estatus_Id"], 0)), dr["Estatus"].ToString())
                    .SetEmision(dr["Emision_Id"].ToString()
                        , dr["Emision_Nombre"].ToString())
                    .SetPortfolio(Convert.ToDouble(Null.SetNull(dr["Portafolio_Tit_Imp"], 0))
                        , Convert.ToDouble(Null.SetNull(dr["Portafolio_Comprometido"], 0))
                        , Convert.ToDouble(Null.SetNull(dr["Portafolio_No_Comprometido"], 0)))
                    .SetFund(Convert.ToDouble(Null.SetNull(dr["Precio_Fondo_Importe"], 0))
                        , Convert.ToDateTime(Null.SetNull(dr["Precio_Fondo_Fecha"], DateTime.UtcNow)))
                    );
            }

            return portfolioFunds;
        }
        public static List<PortfolioFundReinvestment> MappReinvestments(DataSet ds)
        {
            var portfolioFunds = new List<PortfolioFundReinvestment>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                portfolioFunds.Add(
                    PortfolioFundReinvestment.Create(dr["Emision_Id"].ToString()
                            , dr["Contrato_Id"].ToString())
                        .SetEmision(dr["Emision_Id"].ToString()
                            , dr["Emision_Nombre"].ToString())
                        .SetPortfolio(Convert.ToDouble(Null.SetNull(dr["Portafolio_Tit_Imp"], 0))
                            , Convert.ToDouble(Null.SetNull(dr["Portafolio_Comprometido"], 0))
                            , Convert.ToDouble(Null.SetNull(dr["Portafolio_No_Comprometido"], 0)))
                        .SetFund(Convert.ToDouble(Null.SetNull(dr["Precio_Fondo_Importe"], 0))
                            , Convert.ToDateTime(Null.SetNull(dr["Precio_Fondo_Fecha"], DateTime.UtcNow)))
                );
            }

            return portfolioFunds;
        }
    }
}
