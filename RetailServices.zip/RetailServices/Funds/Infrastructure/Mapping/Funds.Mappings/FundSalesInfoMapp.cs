﻿using Funds.Domain.FundSalesInfoAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities.Application;

namespace Funds.Mappings
{
    public class FundSalesInfoMapp
    {
        public static List<FundSalesInfo> Mapp(DataSet ds)
        {
            List<FundSalesInfo> fundsSalesInfo = new List<FundSalesInfo>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                fundsSalesInfo.Add(
                    FundSalesInfo.Create(dr["Emision"].ToString())
                    .SetAvailableOperations(bool.Parse(dr["Fondo_Habilita_Venta"].ToString()))
                    .SetDaysSalesOperation(
                        Convert.ToInt32(Null.SetNull(dr["DiasAnticVenta"], new Int32())),
                        Convert.ToInt32(Null.SetNull(dr["DiasLiquidezVenta"], new Int32()))
                        )
                    .SetLastSobSubDate(Convert.ToDateTime(Null.SetNull(dr["UltimaFechaSobSubValuacion"], new DateTime())))
                    .SetSalesComision(
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Venta"], new Double())),
                        Convert.ToDouble(Null.SetNull(dr["Fondo_Comision_Venta_IVA"], new Double()))
                        )
                    .SetSalesConfiguration(
                        Convert.ToBoolean(Null.SetNull(dr["DiasAnticVentaHab"], new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["DiaHabilLiquidezVenta"], new Boolean())),
                        Convert.ToBoolean(Null.SetNull(dr["FondoLiquidoVenta"], new Boolean()))
                        )
                    .SetSaleTradeDates(
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Solicitud_Venta"], new DateTime())),
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Operacion_Venta"], new DateTime())),
                        Convert.ToDateTime(Null.SetNull(dr["Fecha_Liquidez_Venta"], new DateTime()))
                        )
                );
            }

            return fundsSalesInfo;
        }
    }
}
