﻿using Funds.Domain.FundProcessAggregate;
using System;
using System.Collections.Generic;
using System.Data;
using Utilities.Application;

namespace Funds.Mappings
{
    public static class FundProcessTransferMapp
    {
        public static List<FundProcessMovement> Mapp(DataSet ds)
        {
            var fundProcessTransfers = new List<FundProcessMovement>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                fundProcessTransfers.Add(
                    FundProcessMovement.Create(dr["Id"].ToString(), dr["Proceso_Log_Id"].ToString(), dr["Portafolio_Contrato_Id"].ToString(), dr["Usuario_Id"].ToString())
                        .SetPorfolio(Convert.ToDouble(Null.SetNull(dr["Portafolio_Titulos"], 0)), Convert.ToDouble(Null.SetNull(dr["Portafolio_Comprometido"], 0)))
                        .SetPortfolioTransferred(Convert.ToDouble(Null.SetNull(dr["Portafolio_Transferido"], 0)), Convert.ToInt32(Null.SetNull(dr["Portafolio_Orden_Id"], 0)))
                        .SetSourcePortfolioTransferred(Convert.ToDouble(Null.SetNull(dr["Portafolio_Transferido_Origen"], 0)), Convert.ToInt32(Null.SetNull(dr["Portafolio_Orden_Id_Origen"], 0)))
                        .SetStatus(Convert.ToInt16(Null.SetNull(dr["Estatus_Id"], 0)))
                        .SetTransferDates(Convert.ToDateTime(Null.SetNull(dr["Fecha_Creacion"], DateTime.Now)), Convert.ToDateTime(Null.SetNull(dr["Fecha_Actualizacion"], DateTime.Now))));
            }

            return fundProcessTransfers;
        }
    }
}
