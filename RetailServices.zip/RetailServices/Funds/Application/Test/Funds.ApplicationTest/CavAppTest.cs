﻿using Common.Domain;
using Funds.Application;
using Funds.Domain.FundProcessAggregate;
using Funds.Domain.PortfolioFundAggregate;
using Funds.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SeriLogH;
using System;
using System.Collections.Generic;
using System.Configuration;
using Utilities.Application;

namespace Funds.ApplicationTest
{
    [TestClass]

    public class CavAppTest
    {
        private readonly Mock<ITransform> _transform;
        private readonly Mock<ICavRepository> _cavRepository;
        private readonly CavApp _cavApp;

        private Random _randomGenerator;
        private OperationResult _result;
        private int _platform;
        private string _userId;
        private short _processTypeId;
        private string _processId;
        private string _transferId;
        private string _contractId;
        private double _portfolioTitImp;
        private double _portfolioCommitted;
        private double _portfolioTransferred;
        private int _portfolioOrderId;
        private double _priceFundAmount;
        private DateTime _priceFundDate;
        private string _fundSource;
        private string _fundTarget;
        private string _fundReinvestment;
        private short _statusTransferId;
        private string _statusTransfer;

        public CavAppTest()
        {
            ConfigurationManager.AppSettings["SeriLog:LogEventLevel"] = "1";
            ConfigurationManager.AppSettings["SeriLog:FileName"] = @"C:\Files\TestRetailService-.txt";

            var log = new Mock<ISeriLogHelper>();
            _transform = new Mock<ITransform>();
            _cavRepository = new Mock<ICavRepository>();
            _cavApp = new CavApp(log.Object, _cavRepository.Object, _transform.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            _randomGenerator = new Random();

            _result = new OperationResult() { Successful = true };

            _platform = 10;
            _userId = "OCEANS\\MunAnt";
            _processTypeId = 1;
            _processId = Guid.NewGuid().ToString().ToUpper();
            _transferId = Guid.NewGuid().ToString().ToUpper();
            _contractId = "768407";
            _portfolioTitImp = 78397;
            _portfolioCommitted = 1040;
            _portfolioTransferred = _portfolioTitImp - _portfolioCommitted;
            _portfolioOrderId = _randomGenerator.Next(1, int.MaxValue);
            _priceFundAmount = 1.057722;
            _priceFundDate = DateTime.Now;
            _fundSource = "CAVPRO 1";
            _fundTarget = "SK-DCP B";
            _fundReinvestment = "CAVTEST 1";
            _statusTransferId = 1;
            _statusTransfer = "Pendiente";

        }


        [TestMethod, TestCategory("GetPortfolioFunds")]
        public void GetFundsForSaleEmtpyFund()
        {
            _result = new OperationResult() { Successful = true };
            Assert.ThrowsException<ArgumentException>(() => _cavApp.GetPortfolioFunds("", _platform, out _result));
        }

        [TestMethod, TestCategory("GetPortfolioFunds")]
        public void GetPortfolioFunds()
        {
            _result = new OperationResult() { Successful = true };
            var portfolioFund = PortfolioFundTransfer.Create(_fundSource
                    , _contractId)
                .SetEmision(_fundSource, _fundSource)
                .SetPortfolio(_portfolioTitImp, _portfolioCommitted, (_portfolioTitImp - _portfolioCommitted))
                .SetFund(_priceFundAmount, _priceFundDate)
                .SetFundValue(82922.23)
                .SetStatus(_statusTransferId, _statusTransfer);
            var portfolioFunds = new List<PortfolioFundTransfer>() { portfolioFund };

            _cavRepository.Setup(x => x.GetPortfolioFunds(It.IsAny<string>(), It.IsAny<string>())).Returns(portfolioFunds);

            var portfolioFundsResult = _cavApp.GetPortfolioFunds(_fundSource, _platform, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(portfolioFundsResult);
        }

        [TestMethod, TestCategory("GetFundProcessToReprocess")]
        public void GetFundProcessToReprocess()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcess = FundProcess.Create(_processId, _userId, _processTypeId)
                .SetFund(_fundSource, _fundTarget, _fundReinvestment)
                .SetStatus((int)FundProcessStatus.Pendiente)
                .SetProcessDates(DateTime.Now);
            var fundProcesses = new List<FundProcess>() { fundProcess };

            _cavRepository.Setup(x => x.GetFundProcessToReprocess(It.IsAny<string>(), It.IsAny<short>(), It.IsAny<int>())).Returns(fundProcesses);

            var portfolioFundsResult = _cavApp.GetFundProcessToReprocess((short)FundProcessType.Transfer, 0, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(portfolioFundsResult);
        }

        [TestMethod, TestCategory("GetFundProcessToReprocess")]
        public void GetFundProcessToReinvestment()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcess = FundProcess.Create(_processId, _userId, _processTypeId)
                .SetFund(_fundSource, _fundTarget, _fundReinvestment)
                .SetStatus((int)FundProcessStatus.Pendiente)
                .SetProcessDates(DateTime.Now);
            var fundProcesses = new List<FundProcess>() { fundProcess };

            _cavRepository.Setup(x => x.GetFundProcessToReinvestment(It.IsAny<string>(), It.IsAny<short>())).Returns(fundProcesses);

            var portfolioFundsResult = _cavApp.GetFundProcessToReinvestment(31, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(portfolioFundsResult);
        }

        [TestMethod, TestCategory("GetPortfolioFunds")]
        public void GetPortfolioFundsToReinvestment()
        {
            _result = new OperationResult() { Successful = true };
            var portfolioFund = PortfolioFundReinvestment.Create(_fundSource, _contractId)
                .SetEmision(_fundSource, _fundSource)
                .SetPortfolio(_portfolioTitImp, _portfolioCommitted, (_portfolioTitImp - _portfolioCommitted))
                .SetFund(_priceFundAmount, _priceFundDate);
            var portfolioFunds = new List<PortfolioFundReinvestment>() { portfolioFund };

            _cavRepository.Setup(x => x.GetPortfolioFundsToReinvestment(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>())).Returns(portfolioFunds);

            var portfolioFundsResult = _cavApp.GetPortfolioFundsToReinvestment(_fundTarget, _fundReinvestment, _fundSource, 0, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(portfolioFundsResult);
        }

        #region Process

        [TestMethod, TestCategory("Process")]
        public void InsertProcess()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcess = FundProcess.Create(_processId, _userId, _processTypeId)
                .SetFund(_fundSource, _fundTarget, _fundReinvestment)
                .SetStatus((int)FundProcessStatus.Pendiente)
                .SetProcessDates(DateTime.Now);

            _cavRepository.Setup(x => x.InsertProcess(It.IsAny<string>(), It.IsAny<FundProcess>())).Returns(fundProcess);

            var fundProcessResult = _cavApp.InsertProcess(fundProcess, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessResult);
        }

        [TestMethod, TestCategory("Process")]
        public void UpdateProcess()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcess = FundProcess.Create(_processId, _userId, _processTypeId)
                .SetFund(_fundSource, _fundTarget, _fundReinvestment)
                .SetStatus((int)FundProcessStatus.Pendiente)
                .SetProcessDates(DateTime.Now);
            fundProcess.InitProcess();

            _cavRepository.Setup(x => x.UpdateProcess(It.IsAny<string>(), It.IsAny<FundProcess>())).Returns(fundProcess);

            var fundProcessResult = _cavApp.UpdateProcess(fundProcess, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessResult);
        }

        [TestMethod, TestCategory("Process")]
        public void EndProcess()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcess = FundProcess.Create(_processId, _userId, _processTypeId)
                .SetFund(_fundSource, _fundTarget, _fundReinvestment)
                .SetStatus((int)FundProcessStatus.EnProceso)
                .SetProcessDates(DateTime.Now);
            fundProcess.EndProcess("");

            _cavRepository.Setup(x => x.UpdateProcess(It.IsAny<string>(), It.IsAny<FundProcess>())).Returns(fundProcess);

            var fundProcessResult = _cavApp.UpdateProcess(fundProcess, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessResult);
        }

        [TestMethod, TestCategory("Process")]
        public void EndErrorProcess()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcess = FundProcess.Create(_processId, _userId, _processTypeId)
                .SetFund(_fundSource, _fundTarget, _fundReinvestment)
                .SetStatus((int)FundProcessStatus.EnProceso)
                .SetProcessDates(DateTime.Now);
            fundProcess.EndProcess("Error");

            _cavRepository.Setup(x => x.UpdateProcess(It.IsAny<string>(), It.IsAny<FundProcess>())).Returns(fundProcess);

            var fundProcessResult = _cavApp.UpdateProcess(fundProcess, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessResult);
        }

        #endregion Process

        #region ProcessTransfer

        [TestMethod, TestCategory("ProcessTransfer")]
        public void InsertProcessTransfer()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcessTransfer = FundProcessMovement.Create(_transferId, _processId, _contractId, _userId)
                .SetPorfolio(_portfolioTitImp, _portfolioCommitted)
                .SetPortfolioTransferred(_portfolioTransferred, _portfolioOrderId)
                .SetSourcePortfolioTransferred(_portfolioTransferred, _portfolioOrderId)
                .SetStatus((int)FundProcessMovementStatus.EnProceso)
                .SetTransferDates(DateTime.Now).InitTransfer();

            _cavRepository.Setup(x => x.InsertProcessTransfer(It.IsAny<string>(), It.IsAny<FundProcessMovement>())).Returns(fundProcessTransfer);

            var fundProcessTransferResult = _cavApp.InsertProcessTransfer(fundProcessTransfer, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessTransferResult);
        }

        [TestMethod, TestCategory("ProcessTransfer")]
        public void EndProcessTransfer()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcessTransfer = FundProcessMovement.Create(_transferId, _processId, _contractId, _userId)
                .SetPorfolio(_portfolioTitImp, _portfolioCommitted)
                .SetPortfolioTransferred(_portfolioTransferred, _portfolioOrderId)
                .SetSourcePortfolioTransferred(_portfolioTransferred, _portfolioOrderId)
                .SetStatus((int)FundProcessMovementStatus.EnProceso)
                .SetTransferDates(DateTime.Now)
                .EndTransfer(string.Empty);

            _cavRepository.Setup(x => x.UpdateProcessTransfer(It.IsAny<string>(), It.IsAny<FundProcessMovement>())).Returns(fundProcessTransfer);

            var fundProcessTransferResult = _cavApp.UpdateProcessTransfer(fundProcessTransfer, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessTransferResult);
        }

        [TestMethod, TestCategory("ProcessTransfer")]
        public void EndErrorProcessTransfer()
        {
            _result = new OperationResult() { Successful = true };
            var fundProcessTransfer = FundProcessMovement.Create(_transferId, _processId, _contractId, _userId)
                .SetPorfolio(_portfolioTitImp, _portfolioCommitted)
                .SetPortfolioTransferred(_portfolioTransferred, _portfolioOrderId)
                .SetSourcePortfolioTransferred(_portfolioTransferred, _portfolioOrderId)
                .SetStatus((int)FundProcessMovementStatus.EnProceso)
                .SetTransferDates(DateTime.Now)
                .EndTransfer("Error");

            _cavRepository.Setup(x => x.UpdateProcessTransfer(It.IsAny<string>(), It.IsAny<FundProcessMovement>())).Returns(fundProcessTransfer);

            var fundProcessTransferResult = _cavApp.UpdateProcessTransfer(fundProcessTransfer, out _result);

            Assert.IsTrue(_result.Successful);
            Assert.IsNotNull(fundProcessTransferResult);
        }
        #endregion ProcessTransfer

    }
}
