﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using Funds.Application;
using SeriLogH;
using Funds.Repository;
using Utilities.Application;
using Common.Domain;
using Funds.Domain.FundSalesInfoAggregate;
using Funds.Domain.FundTradingAggregate;

namespace Funds.ApplicationTest
{
    [TestClass]
    public class FundsAppTest
    {
        private readonly Mock<ISeriLogHelper> _log;
        private readonly Mock<IFundsRepository> _fundsRepository;
        private readonly Mock<ITransform> _transform;
        private readonly FundsApp _fundsAppBL;

        private List<string> lstFunds;
        private OperationResult result;

        public FundsAppTest()
        {
            _log = new Mock<ISeriLogHelper>();
            _fundsRepository = new Mock<IFundsRepository>();
            _transform = new Mock<ITransform>();
            _fundsAppBL = new FundsApp(_log.Object, _fundsRepository.Object, _transform.Object);
        }

        [TestInitialize]
        public void Initialize()
        {
            lstFunds = new List<string>();
            result = new OperationResult() { Successful = true };
            var baseDate = DateTime.Now;
            var sale = FundSalesInfo.Create("STERDOWB1")
                .SetAvailableOperations(true)
                .SetDaysSalesOperation(2, 2)
                .SetLastSobSubDate(baseDate)
                .SetSalesComision(0, 0)
                .SetSalesConfiguration(false, false, true)
                .SetSaleTradeDates(baseDate, baseDate, baseDate);

            var trading = FundTrading.Create("STERDOWB1")
                .SetBuyTradingDates(baseDate, baseDate, baseDate)
                .SetFundConfig(true, true, false)
                .SetLiquidationConfig(2, false, 2, false)
                .SetLiquidConfig(false, true, true, baseDate)
                .SetOperationConfig(0, 0, 0, 0)
                .SetPricesConfig(1.26, 5.26, 54.26, baseDate)
                .SetSalesConfig(2, false, 2, false)
                .SetSaleTradingDates(baseDate, baseDate, baseDate);

            List<FundSalesInfo> fundsSale = new List<FundSalesInfo>() { sale };
            List<FundTrading> fundsTrading = new List<FundTrading>() { trading };
            _transform.Setup(x => x.ObjectToXml(lstFunds))
                .Returns("<ArrayOfString><string>STERDOWB1</string></ArrayOfString>");
            _fundsRepository.Setup(x => x.GetFundsForSale(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTime>()))
                .Returns(fundsSale);
            _fundsRepository.Setup(x => x.GetFundTradings(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTime>()))
                .Returns(fundsTrading);
        }

        [TestMethod, TestCategory("GetFundsForSale")]
        [ExpectedException(typeof(ArgumentException), "El listado de fondos a buscar no contiene items.")]
        public void GetFundsForSaleErrorListFunds()
        {
            var fundsToSale = _fundsAppBL.GetFundsForSale(lstFunds, 10, DateTime.Now, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(fundsToSale);
        }

        [TestMethod, TestCategory("GetFundsForSale")]
        [ExpectedException(typeof(ArgumentException), "No existe plataforma con ese identificador.")]
        public void GetFundsForSaleErrorPlatfor()
        {
            lstFunds.Add("STERDOWB1");
            var fundsToSale = _fundsAppBL.GetFundsForSale(lstFunds, 0, DateTime.Now, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(fundsToSale);
        }

        [TestMethod, TestCategory("GetFundsForSale")]
        [ExpectedException(typeof(ArgumentException), "La fecha no puede ser nula.")]
        public void GetFundsForSaleErrorBaseDate()
        {
            lstFunds.Add("STERDOWB1");
            var fundsToSale = _fundsAppBL.GetFundsForSale(lstFunds, 10, null, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(fundsToSale);
        }

        [TestMethod, TestCategory("GetFundsForSale")]
        public void GetFundsForSaleSuccess()
        {
            lstFunds.Add("STERDOWB1");
            var fundsToSale = _fundsAppBL.GetFundsForSale(lstFunds, 10, DateTime.Now, out result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(fundsToSale);
        }


        [TestMethod, TestCategory("GetFundsTradings")]
        [ExpectedException(typeof(ArgumentException), "El listado de fondos a buscar no contiene items.")]
        public void GetFundsTradingsErrorListFunds()
        {
            var fundsToSale = _fundsAppBL.GetFundsTradings(lstFunds, 10, DateTime.Now, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(fundsToSale);
        }

        [TestMethod, TestCategory("GetFundsTradings")]
        [ExpectedException(typeof(ArgumentException), "No existe plataforma con ese identificador.")]
        public void GetFundsTradingsErrorPlatfor()
        {
            lstFunds.Add("STERDOWB1");
            var fundsToSale = _fundsAppBL.GetFundsTradings(lstFunds, 0, DateTime.Now, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(fundsToSale);
        }

        [TestMethod, TestCategory("GetFundsTradings")]
        [ExpectedException(typeof(ArgumentException), "La fecha no puede ser nula.")]
        public void GetFundsTradingsErrorBaseDate()
        {
            lstFunds.Add("STERDOWB1");
            var fundsToSale = _fundsAppBL.GetFundsTradings(lstFunds, 10, null, out result);

            Assert.IsFalse(result.Successful);
            Assert.IsNull(fundsToSale);
        }

        [TestMethod, TestCategory("GetFundsTradings")]
        public void GetFundsTradingsSuccess()
        {
            lstFunds.Add("STERDOWB1");
            var fundsTradingResult = _fundsAppBL.GetFundsTradings(lstFunds, 10, DateTime.Now, out result);

            Assert.IsTrue(result.Successful);
            Assert.IsNotNull(fundsTradingResult);
            Assert.IsTrue(fundsTradingResult.Count > 0);
        }

    }
}
