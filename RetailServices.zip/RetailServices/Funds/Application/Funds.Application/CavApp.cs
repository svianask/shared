﻿using Common.Domain;
using Funds.Domain.FundProcessAggregate;
using Funds.Domain.PortfolioFundAggregate;
using Funds.Repository;
using SeriLogH;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace Funds.Application
{
    public class CavApp : ICavApp
    {
        private const string PsrRsGetFondoPortafolio = "[dbo].[usp_SOC_SIIF_RS_GetFondoPortafolio]";
        private const string PsrGtGetFondoPortafolio = "[dbo].[usp_SOC_SIIF_RS_GetFondoPortafolio]";
        private const string PsrCavInsertProceso = "[dbo].[usp_SOC_SIIF_CAV_InsertProceso]";
        private const string PsrCavUpdateProceso = "[dbo].[usp_SOC_SIIF_CAV_UpdateProceso]";
        private const string PsrCavInsertTransferencia = "[dbo].[usp_SOC_SIIF_CAV_InsertTransferencia]";
        private const string PsrCavUpdateTransferencia = "[dbo].[usp_SOC_SIIF_CAV_UpdateTransferencia]";
        private const string PsrCavGetProcesoFondos = "[dbo].[usp_SOC_SIIF_CAV_GetProcesoFondos]";
        private const string PsrCavGetProcesoFondosReinversion = "[dbo].[usp_SOC_SIIF_CAV_GetProcesoFondosReinversion]";
        private const string PsrCavGetFondoPortafolioReinversion = "[dbo].[usp_SOC_SIIF_CAV_GetFondoPortafolioReinversion]";
        private const string PsrCavInsertReinversion = "[dbo].[usp_SOC_SIIF_CAV_InsertReinversion]";
        private const string PsrCavUpdateReinversion = "[dbo].[usp_SOC_SIIF_CAV_UpdateReinversion]";
        private const string PsrCavInsertAdministracion = "[dbo].[usp_SOC_SIIF_CAV_InsertAdministracion]";
        private const string PsrCavUpdateAdministracion = "[dbo].[usp_SOC_SIIF_CAV_UpdateAdministracion]";
        private const string PsrCavGetAdministracionCliente = "[dbo].[usp_SOC_SIIF_CAV_GetAdministracionCliente]";
        private const string PsrCavInsUpdAdministracionCliente = "[dbo].[usp_SOC_SIIF_CAV_InsUpdAdministracionCliente]";
        private const string PsrCavGetFechaHabilDiasAntes = "[dbo].[usp_SOC_SIIF_CAV_GetFechaHabilDiasAntes]";
        private const string PsrCavGetConfigAdministracionFondos = "[dbo].[usp_SOC_SIIF_CAV_GetConfigAdministracionFondos]";

        private readonly ISeriLogHelper _log;
        private readonly ICavRepository _cavRepository;
        private readonly ITransform _transform;

        public CavApp(ISeriLogHelper log, ICavRepository cavRepository, ITransform transform)
        {
            _log = log;
            _cavRepository = cavRepository;
            _transform = transform;
        }

        public List<PortfolioFundTransfer> GetPortfolioFunds(string fundId, int platform, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundId)) { throw new ArgumentException("El Fondo a buscar no puede estar vacio."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }

            var portfolioFunds = new List<PortfolioFundTransfer>();

            try
            {
                _log.Info("Determinando el sp de acuerdo a la plataforma");
                var spName = platform == 10 ? PsrRsGetFondoPortafolio : PsrGtGetFondoPortafolio;
                _log.Debug("{cntx}", spName);
                _log.Info($"Obteniendo la información detallada de Plataforma-{platform} / Fondo-{fundId}");
                portfolioFunds = _cavRepository.GetPortfolioFunds(spName, fundId);
                _log.Debug("{cntx}", portfolioFunds);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los fondos" + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return portfolioFunds;
        }

        public FundProcess InsertProcess(FundProcess fundProcess, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundProcess.Id)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(fundProcess.UserId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }

            var fpResult = FundProcess.Empty();

            try
            {
                _log.Info($"CAV Generado ProcesoId-{fundProcess.Id} / UsuarioId-{fundProcess.UserId} / FundSource-{fundProcess.FundSource} / FundTarget-{fundProcess.FundTarget} / FundReinvestment-{fundProcess.FundReinvestment}");
                _log.Debug("{cntx}", PsrCavInsertProceso);
                fpResult = _cavRepository.InsertProcess(PsrCavInsertProceso, fundProcess);
                _log.Debug("{cntx}", fpResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al generar proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al generar proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fpResult;
        }

        public FundProcess UpdateProcess(FundProcess fundProcess, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundProcess.Id)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(fundProcess.UserId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }
            if (fundProcess.StatusId <= 0) { throw new ArgumentException("El estatus del proceso no puede ser menor a 1."); }

            var fpResult = FundProcess.Empty();

            try
            {
                _log.Info($"CAV Actualizando ProcesoId-{fundProcess.Id} / UsuarioId-{fundProcess.UserId} / EstatusId-{fundProcess.StatusId} / Error-{fundProcess.ErrorDescription}");
                _log.Debug("{cntx}", PsrCavUpdateProceso);
                fpResult = _cavRepository.UpdateProcess(PsrCavUpdateProceso, fundProcess);
                _log.Debug("{cntx}", fpResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al actualizar proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fpResult;
        }

        public FundProcessMovement InsertProcessTransfer(FundProcessMovement transferMovement, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(transferMovement.Id)) { throw new ArgumentException("El id de la transferencia no puede ser nulo."); }
            if (string.IsNullOrEmpty(transferMovement.ProcessId)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(transferMovement.ContractId)) { throw new ArgumentException("El contrato del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(transferMovement.UserId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }

            var fptResult = FundProcessMovement.Empty();

            try
            {
                _log.Info($"CAV Generado TransferenciaId-{transferMovement.Id} / ProcesoId-{transferMovement.ProcessId} / ContractId-{transferMovement.ContractId} / UsuarioId-{transferMovement.UserId}");
                _log.Debug("{cntx}", PsrCavInsertTransferencia);
                fptResult = _cavRepository.InsertProcessTransfer(PsrCavInsertTransferencia, transferMovement);
                _log.Debug("{cntx}", fptResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al generar transferencia del proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al generar transferencia del proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public FundProcessMovement UpdateProcessTransfer(FundProcessMovement transferMovement, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(transferMovement.Id)) { throw new ArgumentException("El id de la transferencia no puede ser nulo."); }
            if (string.IsNullOrEmpty(transferMovement.ProcessId)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(transferMovement.ContractId)) { throw new ArgumentException("El contrato del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(transferMovement.UserId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }

            var fptResult = FundProcessMovement.Empty();

            try
            {
                _log.Info($"CAV Actualizando TransferenciaId-{transferMovement.Id} / ProcesoId-{transferMovement.ProcessId} / ContractId-{transferMovement.ContractId} / UsuarioId-{transferMovement.UserId}");
                _log.Debug("{cntx}", PsrCavUpdateTransferencia);
                fptResult = _cavRepository.UpdateProcessTransfer(PsrCavUpdateTransferencia, transferMovement);
                _log.Debug("{cntx}", fptResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar transferencia del proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al actualizar transferencia del proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public List<FundProcess> GetFundProcessToReprocess(short processTypeId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (processTypeId <= 0) { throw new ArgumentException("No existe tipo de proceso con ese identificador."); }
            if (nDaysBefore < 0) { throw new ArgumentException("El numero de dias antes no puede ser menor a 0."); }

            var fundProcesses = new List<FundProcess>();

            try
            {
                _log.Info("Obteniendo la información detallada de los procesos");
                _log.Debug("{cntx}", PsrCavGetProcesoFondos);
                fundProcesses = _cavRepository.GetFundProcessToReprocess(PsrCavGetProcesoFondos, processTypeId, nDaysBefore);
                _log.Debug("{cntx}", fundProcesses);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los procesos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los procesos" + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fundProcesses;
        }

        public List<FundProcess> GetFundProcessToReinvestment(int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (nDaysBefore < 0) { throw new ArgumentException("El filtro de numero de dias antes para buscar transferencias no puede ser menor a 0."); }

            var fundProcesses = new List<FundProcess>();

            try
            {
                _log.Info("Obteniendo la información detallada de los procesos");
                _log.Debug("{cntx}", PsrCavGetProcesoFondosReinversion);
                fundProcesses = _cavRepository.GetFundProcessToReinvestment(PsrCavGetProcesoFondosReinversion, nDaysBefore);
                _log.Debug("{cntx}", fundProcesses);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los procesos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los procesos" + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fundProcesses;
        }

        public List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundBridge)) { throw new ArgumentException("El Fondo Puente a buscar no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundReinvestment)) { throw new ArgumentException("El Fondo Reinversion a buscar no puede estar vacio."); }
            if (string.IsNullOrEmpty(fundPreviousId)) { throw new ArgumentException("El Fondo Previo a buscar no puede estar vacio."); }
            if (nDaysBefore < 0) { throw new ArgumentException("El filtro de numero de dias antes para buscar transferencias no puede ser menor a 0."); }

            var fundProcesses = new List<PortfolioFundReinvestment>();

            try
            {
                _log.Info("Obteniendo la información detallada de los fondos");
                _log.Debug("{cntx}", PsrCavGetFondoPortafolioReinversion);
                fundProcesses = _cavRepository.GetPortfolioFundsToReinvestment(PsrCavGetFondoPortafolioReinversion, fundBridge, fundReinvestment, fundPreviousId, nDaysBefore);
                _log.Debug("{cntx}", fundProcesses);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los fondos" + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fundProcesses;
        }

        public FundProcessMovement InsertProcessReinvestment(FundProcessMovement reinvestmentMovement, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(reinvestmentMovement.Id)) { throw new ArgumentException("El id de la reinversion no puede ser nulo."); }
            if (string.IsNullOrEmpty(reinvestmentMovement.ProcessId)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(reinvestmentMovement.ContractId)) { throw new ArgumentException("El contrato del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(reinvestmentMovement.UserId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }

            var fptResult = FundProcessMovement.Empty();

            try
            {
                _log.Info($"CAV Generado ReinversionId-{reinvestmentMovement.Id} / ProcesoId-{reinvestmentMovement.ProcessId} / ContractId-{reinvestmentMovement.ContractId} / UsuarioId-{reinvestmentMovement.UserId}");
                _log.Debug("{cntx}", PsrCavInsertReinversion);
                fptResult = _cavRepository.InsertProcessReinvestment(PsrCavInsertReinversion, reinvestmentMovement);
                _log.Debug("{cntx}", fptResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al generar reinversion del proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al generar reinversion del proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public FundProcessMovement UpdateProcessReinvestment(FundProcessMovement reinvestmentMovement, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(reinvestmentMovement.Id)) { throw new ArgumentException("El id de la reinversion no puede ser nulo."); }
            if (string.IsNullOrEmpty(reinvestmentMovement.ProcessId)) { throw new ArgumentException("El id del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(reinvestmentMovement.ContractId)) { throw new ArgumentException("El contrato del proceso no puede ser nulo."); }
            if (string.IsNullOrEmpty(reinvestmentMovement.UserId)) { throw new ArgumentException("El usuario del proceso no puede ser nulo."); }

            var fptResult = FundProcessMovement.Empty();

            try
            {
                _log.Info($"CAV Actualizando ReinversionId-{reinvestmentMovement.Id} / ProcesoId-{reinvestmentMovement.ProcessId} / ContractId-{reinvestmentMovement.ContractId} / UsuarioId-{reinvestmentMovement.UserId}");
                _log.Debug("{cntx}", PsrCavUpdateReinversion);
                fptResult = _cavRepository.UpdateProcessReinvestment(PsrCavUpdateReinversion, reinvestmentMovement);
                _log.Debug("{cntx}", fptResult);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar reinversion del proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al actualizar reinversion del proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public FundAdministration InsertAdministration(FundAdministration fundAdministration, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundAdministration.FundSource)) { throw new ArgumentException("El fondo origen no puede ser nulo."); }
            if (string.IsNullOrEmpty(fundAdministration.ContractId)) { throw new ArgumentException("El contrato puede ser nulo."); }
            if (string.IsNullOrEmpty(fundAdministration.UserId)) { throw new ArgumentException("El usuario no puede ser nulo."); }

            var fptResult = FundAdministration.Empty();

            try
            {
                _log.Info($"CAV Generado AdministrationId-{fundAdministration.Id} / ProcesoId-{fundAdministration.FundSource} / ContractId-{fundAdministration.ContractId} / UsuarioId-{fundAdministration.UserId}");
                _log.Debug("{cntx}", PsrCavInsertAdministracion);
                _log.Debug("{cntx}", fundAdministration);
                fptResult = _cavRepository.InsertAdministration(PsrCavInsertAdministracion, fundAdministration);
                _log.Debug("{cntx}", fptResult);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al generar reinversion del proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al generar reinversion del proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public FundAdministration UpdateAdministration(FundAdministration fundAdministration, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundAdministration.FundSource)) { throw new ArgumentException("El fondo origen no puede ser nulo."); }
            if (string.IsNullOrEmpty(fundAdministration.ContractId)) { throw new ArgumentException("El contrato puede ser nulo."); }
            if (string.IsNullOrEmpty(fundAdministration.UserId)) { throw new ArgumentException("El usuario no puede ser nulo."); }

            var fptResult = FundAdministration.Empty();

            try
            {
                _log.Info($"CAV Generado AdministrationId-{fundAdministration.Id} / ProcesoId-{fundAdministration.FundSource} / ContractId-{fundAdministration.ContractId} / UsuarioId-{fundAdministration.UserId}");
                _log.Debug("{cntx}", PsrCavUpdateAdministracion);
                _log.Debug("{cntx}", fundAdministration);
                fptResult = _cavRepository.UpdateAdministration(PsrCavUpdateAdministracion, fundAdministration);
                _log.Debug("{cntx}", fptResult);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al actualizar reinversion del proceso CAV");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al actualizar reinversion del proceso CAV: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public List<FundAdministration> GetClientAdministration(List<string> funds, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (funds.Count <= 0) { throw new ArgumentException("El listado de fondos a buscar no contiene elementos."); }
            var fundAdministrations = new List<FundAdministration>();

            try
            {
                _log.Info("Obteniendo la información detallada de CAV administacion de clientes");
                _log.Debug("{cntx}", PsrCavGetAdministracionCliente);
                _log.Info("Transformando identificadores de fondo en xml: {cntx}", funds);
                var xmlFunds = _transform.ObjectToXml(funds);
                _log.Debug("{cntx}", xmlFunds);
                fundAdministrations = _cavRepository.GetClientAdministration(PsrCavGetAdministracionCliente, xmlFunds);
                _log.Debug("{cntx}", fundAdministrations);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de CAV administacion de clientes");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de CAV administacion de clientes" + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fundAdministrations;
        }

        public FundAdministration UpdateClientAdministration(FundAdministration fundAdministration, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (string.IsNullOrEmpty(fundAdministration.FundSource)) { throw new ArgumentException("El fondo origen no puede ser nulo."); }
            if (string.IsNullOrEmpty(fundAdministration.ContractId)) { throw new ArgumentException("El contrato puede ser nulo."); }
            if (string.IsNullOrEmpty(fundAdministration.UserId)) { throw new ArgumentException("El usuario no puede ser nulo."); }
            if (fundAdministration.StatusId <= 0) { throw new ArgumentException("El estatus no puede ser menor a 0."); }

            var fptResult = FundAdministration.Empty();

            try
            {
                _log.Info($"CAV Generado AdministrationId-{fundAdministration.Id} / ProcesoId-{fundAdministration.FundSource} / ContractId-{fundAdministration.ContractId} / UsuarioId-{fundAdministration.UserId} / StatusId-{fundAdministration.StatusId}");
                _log.Debug("{cntx}", PsrCavInsUpdAdministracionCliente);
                _log.Debug("{cntx}", fundAdministration);
                fptResult = _cavRepository.UpdateClientAdministration(PsrCavInsUpdAdministracionCliente, fundAdministration);
                _log.Debug("{cntx}", fptResult);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al guardar la información de administacion de clientes");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al guardar la información de administacion de clientes: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return fptResult;
        }

        public DateTime GetBusinessDateDaysBefore(int nDaysBefore, DateTime currentDate, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (nDaysBefore < 0) { throw new ArgumentException("El filtro de numero de dias antes no puede ser menor a 0."); }
            var businessDate = currentDate.Date;

            try
            {
                _log.Debug("{cntx}", PsrCavGetFechaHabilDiasAntes);
                _log.Info($"Calcular la fecha habil dias antes de nDaysBefore-{nDaysBefore} / currentDate-{currentDate.ToShortDateString()}");
                businessDate = _cavRepository.GetBusinessDateDaysBefore(PsrCavGetFechaHabilDiasAntes, nDaysBefore, currentDate);
                _log.Debug("{cntx}", businessDate);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al calcular la fecha habil dias antes");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al calcular la fecha habil dias antes: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return businessDate;
        }

        public List<FundAdministrationConfig> GetFundsAdministrationConfig(DateTime baseDate, int nMonthsLater, out OperationResult result)
        {
            result = new OperationResult { Successful = true };
            if (nMonthsLater < 0) { throw new ArgumentException("El filtro de numero de meses no puede ser menor a 0."); }

            var cavFundConfigs = new List<FundAdministrationConfig>();

            try
            {
                _log.Debug("{cntx}", PsrCavGetConfigAdministracionFondos);
                _log.Info($"Consultar el listado de fondos proximos a liquidar: nDaysBefore-{nMonthsLater} / currentDate-{baseDate.ToShortDateString()}");
                cavFundConfigs = _cavRepository.GetFundsAdministrationConfig(PsrCavGetConfigAdministracionFondos, baseDate, nMonthsLater);
                _log.Debug("{cntx}", cavFundConfigs);

            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al consultar el listado de fondos proximos a liquidar.");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al consultar el listado de fondos proximos a liquidar: " + ex.Message, MessageType = SystemMessageTypes.Error }
                );
            }
            return cavFundConfigs;
        }
    }
}
