﻿using Common.Domain;
using Funds.Domain.FundSalesInfoAggregate;
using Funds.Domain.FundTradingAggregate;
using Funds.Repository;
using SeriLogH;
using System;
using System.Collections.Generic;
using Utilities.Application;

namespace Funds.Application
{
    public class FundsApp : IFundsApp
    {
        private readonly ISeriLogHelper _log;
        private readonly IFundsRepository _fundsRepository;
        private readonly ITransform _transform;

        public FundsApp(ISeriLogHelper log, IFundsRepository fundsRepository, ITransform transform)
        {
            _log = log;
            _fundsRepository = fundsRepository;
            _transform = transform;
        }

        public List<FundSalesInfo> GetFundsForSale(List<string> fundIdentifiers, int platform, DateTime? baseDate, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };

            if (fundIdentifiers.Count <= 0) { throw new ArgumentException("El listado de fondos a buscar no contiene items."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }
            if (baseDate is null) { throw new ArgumentException("La fecha no puede ser nula."); }

            List<FundSalesInfo> fundSales = new List<FundSalesInfo>();

            try
            {
                _log.Info("Determinando el sp de acuerdo a la plataforma");
                var spName = platform == 10 ? "usp_SOC_SIIF_RS_GetFondosDetalleCpaVta" : "usp_SOC_SIIF_GT_GetFondosDetalleCpaVta";
                _log.Debug("{cntx}", spName);

                _log.Info("Transformando identificadores de fondo en xml: {cntx}", new { fundIdentifiers });
                var xmlFunIdentifiers = _transform.ObjectToXml(fundIdentifiers);
                _log.Debug("{cntx}", xmlFunIdentifiers);

                _log.Info("Obteniendo la información comercial de los fondos");
                fundSales = _fundsRepository.GetFundsForSale(spName, xmlFunIdentifiers, baseDate);
                _log.Debug("{cntx}", fundSales);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información comercial de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información comercial de los fondos" + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return fundSales;
        }

        public List<FundTrading> GetFundsTradings(List<string> fundsIndentifiers, int platform, DateTime? baseDate, out OperationResult result)
        {
            result = new OperationResult() { Successful = true };
            if (fundsIndentifiers.Count <= 0) { throw new ArgumentException("El listado de fondos a buscar no contiene items."); }
            if (platform <= 0) { throw new ArgumentException("No existe plataforma con ese identificador."); }
            if (baseDate is null) { throw new ArgumentException("La fecha no puede ser nula."); }

            List<FundTrading> fundTradings = new List<FundTrading>();

            try
            {
                _log.Info("Determinando el sp de acuerdo a la plataforma");
                var spName = platform == 10 ? "usp_SOC_SIIF_RS_GetFondosDetalleCpaVta" : "usp_SOC_SIIF_GT_GetFondosDetalleCpaVta";
                _log.Debug("{cntx}", spName);

                _log.Info("Transformando identificadores de fondo en xml: {cntx}", new { fundsIndentifiers });
                var xmlFunIdentifiers = _transform.ObjectToXml(fundsIndentifiers);
                _log.Debug("{cntx}", xmlFunIdentifiers);

                _log.Info("Obteniendo la información detallada de los fondos");
                fundTradings = _fundsRepository.GetFundTradings(spName, xmlFunIdentifiers, baseDate);
                _log.Debug("{cntx}", fundTradings);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "Error al obtener la información de los fondos");
                result.Successful = false;
                result.SystemMessages.Add(
                    new SystemMessage { Message = "Error al obtener la información de los fondos" + ex.StackTrace, MessageType = SystemMessageTypes.Error }
                );
            }

            return fundTradings;
        }
    }
}
