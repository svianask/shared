﻿using Common.Domain;
using Funds.Domain.FundSalesInfoAggregate;
using Funds.Domain.FundTradingAggregate;
using System;
using System.Collections.Generic;

namespace Funds.Application
{
    public interface IFundsApp
    {
        List<FundSalesInfo> GetFundsForSale(List<string> fundIdentifiers, int platform, DateTime? baseDate, out OperationResult result);
        List<FundTrading> GetFundsTradings(List<string> fundsIndentifiers, int platform, DateTime? baseDate, out OperationResult result);

    }
}
