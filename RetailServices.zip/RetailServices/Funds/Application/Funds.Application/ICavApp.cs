﻿using Common.Domain;
using Funds.Domain.FundProcessAggregate;
using Funds.Domain.PortfolioFundAggregate;
using System;
using System.Collections.Generic;

namespace Funds.Application
{
    public interface ICavApp
    {

        List<PortfolioFundTransfer> GetPortfolioFunds(string fundId, int platform, out OperationResult result);

        FundProcess InsertProcess(FundProcess fundProcess, out OperationResult result);

        FundProcess UpdateProcess(FundProcess fundProcess, out OperationResult result);

        FundProcessMovement InsertProcessTransfer(FundProcessMovement transferMovement, out OperationResult result);

        FundProcessMovement UpdateProcessTransfer(FundProcessMovement transferMovement, out OperationResult result);

        List<FundProcess> GetFundProcessToReprocess(short processTypeId, int nDaysBefore, out OperationResult result);

        List<FundProcess> GetFundProcessToReinvestment(int nDaysBefore, out OperationResult result);

        List<PortfolioFundReinvestment> GetPortfolioFundsToReinvestment(string fundBridge, string fundReinvestment, string fundPreviousId, int nDaysBefore, out OperationResult result);

        FundProcessMovement InsertProcessReinvestment(FundProcessMovement reinvestmentMovement, out OperationResult result);

        FundProcessMovement UpdateProcessReinvestment(FundProcessMovement reinvestmentMovement, out OperationResult result);

        FundAdministration InsertAdministration(FundAdministration fundAdministration, out OperationResult result);

        FundAdministration UpdateAdministration(FundAdministration fundAdministration, out OperationResult result);

        List<FundAdministration> GetClientAdministration(List<string> funds, out OperationResult result);

        FundAdministration UpdateClientAdministration(FundAdministration fundAdministration, out OperationResult result);

        DateTime GetBusinessDateDaysBefore(int nDaysBefore, DateTime currentDate, out OperationResult result);

        List<FundAdministrationConfig> GetFundsAdministrationConfig(DateTime baseDate, int nMonthsLater, out OperationResult result);

    }
}
