# Changelog

Generado automáticamente usando solamente los cambios importantes.

## [1.1.0](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/compare/v1.0.0...v1.1.0) (2025-01-27)

### Features

* dinamically fetches files js ([72f4707](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/commit/72f4707cc116d6cd77386ca2899ecda04af85ffb))

## 1.0.0 (2025-01-17)

### Features

* update branch main ([f6b9133](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/commit/f6b9133c2f29efcfd71586f317ddcd4845166c2c))

## [1.0.0-develop.3](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/compare/v1.0.0-develop.2...v1.0.0-develop.3) (2024-10-07)

### Features

* contraType is added ([89f60ed](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/commit/89f60ed91a4c377649a58744d84e2f97dc875639))

## [1.0.0-develop.2](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/compare/v1.0.0-develop.1...v1.0.0-develop.2) (2024-09-06)

### Features

* **resumensaldos:** karma coverage sonar is added ([75d5aca](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/commit/75d5acad9f12de9ab2354e8b1c0e26deb846f5ba))

## 1.0.0-develop.1 (2024-09-05)

### Features

* ✨ Add semantic release ([ce1791a](https://gitlab-devops.oceans.local/sklatamliferay/angular-modules/skmx-personas-resumen-saldos/commit/ce1791a16f08d3c1492463917f7b5a6e3a7cc4eb))
