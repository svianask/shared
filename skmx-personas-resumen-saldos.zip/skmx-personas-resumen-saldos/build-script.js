const fs = require("fs-extra");
const concat = require("concat");

(async function build() {
  const filesAndDirectories = await fs.readdir(
    "./dist\\skmx-personas-resumensaldos"
  );
  const files = filesAndDirectories
    .filter((file) => file.includes(".js"))
    .map((fileName) => `./dist/skmx-personas-resumensaldos/${fileName}`);

  await fs.ensureDir("elements");
  await concat(files, "elements/skmx-personas-resumensaldos.js");
  await fs.copyFile(
    "./dist/skmx-personas-resumensaldos/styles.css",
    "elements/skmx-personas-resumensaldos.css"
  );
})();
