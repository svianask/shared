export const webpersonasApiUrlBase = 'https://skmx.skandia.com.mx';
export const environment = {
  Name: '',
  liferayUrlBase: 'https://cliente.skandia.com.mx',
  firebaseConfig: {
    apiKey: 'AIzaSyD1mk8SsaY062ImrFvhJlMxa9mnZCcXagU',
    authDomain: 'nuevo-skandia-net-prod.firebaseapp.com',
    projectId: 'nuevo-skandia-net-prod',
    storageBucket: 'nuevo-skandia-net-prod.firebasestorage.app',
    messagingSenderId: '713419069957',
    appId: '1:713419069957:web:8554c22920a394f4d85a6c',
    measurementId: 'G-GR946WBC6S',
  },
  params: {
    option1: '13172484184415997795113899813033',
    option2: '2611197347833731',
  },
};

export const configBootstrap = { bootstrap: [] };
