export const webpersonasApiUrlBase = 'https://stgapi.skandia.com.mx';
export const environment = {
  Name: 'QA',
  liferayUrlBase: 'https://uatcliente.skandia.com.mx',
  firebaseConfig: {
    apiKey: 'AIzaSyDtJUCETigsaS-3s3q_T12fRsHTeiW_oAU',
    authDomain: 'nuevo-skandia-net.firebaseapp.com',
    projectId: 'nuevo-skandia-net',
    storageBucket: 'nuevo-skandia-net.firebasestorage.app',
    messagingSenderId: '913485351546',
    appId: '1:913485351546:web:391817fe1e2ef548c0c9c3',
    measurementId: 'G-WSJM54EYPW',
  },
  params: {
    option1: '',
    option2: '',
  },
};

export const configBootstrap = { bootstrap: [] };
