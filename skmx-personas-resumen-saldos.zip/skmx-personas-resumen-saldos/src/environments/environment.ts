import { AppComponent } from '../app/app.component';

export const webpersonasApiUrlBase = 'https://devapi.skandia.com.mx';
export const environment = {
  Name: 'DEV',
  liferayUrlBase: 'https://devcliente.skandia.com.mx',
  firebaseConfig: {
    apiKey: 'AIzaSyDtJUCETigsaS-3s3q_T12fRsHTeiW_oAU',
    authDomain: 'nuevo-skandia-net.firebaseapp.com',
    projectId: 'nuevo-skandia-net',
    storageBucket: 'nuevo-skandia-net.firebasestorage.app',
    messagingSenderId: '913485351546',
    appId: '1:913485351546:web:391817fe1e2ef548c0c9c3',
    measurementId: 'G-WSJM54EYPW',
  },
  params: {
    option1: '36452589520210852045236984123685',
    option2: '7621845861982051',
  },
};

export const configBootstrap = { bootstrap: [AppComponent] };
