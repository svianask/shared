import { NgModule } from '@angular/core';
import { CardComponent } from './card/card.component';
import { CollapseComponent } from './collapse/collapse.component';
import { TotalsComponent } from './totals/totals.component';
import { SummaryComponent } from './summary/summary.component';
import { SkeletonComponent } from './skeleton/skeleton.component';

@NgModule({
  imports: [
    CardComponent,
    CollapseComponent,
    TotalsComponent,
    SummaryComponent,
    SkeletonComponent,
  ],
  exports: [
    CardComponent,
    CollapseComponent,
    TotalsComponent,
    SummaryComponent,
    SkeletonComponent,
  ],
})
export class UIModule {}
