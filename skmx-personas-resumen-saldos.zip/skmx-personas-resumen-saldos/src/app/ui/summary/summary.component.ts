import { CommonModule } from '@angular/common';
import { Component, input } from '@angular/core';
import { OperationStatusEnum } from '@core/enum/status-operation.enum';
import { SummaryTypeEnum } from '@core/enum/summary.enum';

@Component({
  selector: 'summary',
  templateUrl: './summary.component.html',
  styleUrl: './summary.component.scss',
  standalone: true,
  imports:[CommonModule]
})
export class SummaryComponent {
  index = input<number>();
  type = input<SummaryTypeEnum>();
  operationStatus = input<OperationStatusEnum | undefined>();
  title = input<string>();
  balance = input<number>();
  summaryType = SummaryTypeEnum;
  operationStatusEnumCat = OperationStatusEnum;
}
