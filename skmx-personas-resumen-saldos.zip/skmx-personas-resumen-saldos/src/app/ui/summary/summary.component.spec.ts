import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SummaryComponent } from './summary.component';
import { SummaryTypeEnum } from '@core/enum/summary.enum';

describe('SummaryComponent', () => {
  let component: SummaryComponent;
  let fixture: ComponentFixture<SummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SummaryComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('🧪 should create', () => {
    expect(component).toBeTruthy();
  });

  it('🧪 should initialize with default values', function () {
    expect(component.index()).toBeUndefined();
    expect(component.type()).toBeUndefined();
    expect(component.title()).toBeUndefined();
    expect(component.balance()).toBeUndefined();
    expect(component.summaryType).toEqual(SummaryTypeEnum);
  });
});
