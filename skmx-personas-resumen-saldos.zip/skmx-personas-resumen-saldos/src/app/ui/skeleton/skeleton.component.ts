import { Component, computed, input } from '@angular/core';

@Component({
  selector: 'skeleton',
  templateUrl: './skeleton.component.html',
  styleUrl: './skeleton.component.scss',
  standalone: true,
})
export class SkeletonComponent {
  private readonly DEFAULT = 1;
  rows = input<number>(this.DEFAULT);
  rowsArray = computed(() => Array.from({ length: this.rows() }));
}
