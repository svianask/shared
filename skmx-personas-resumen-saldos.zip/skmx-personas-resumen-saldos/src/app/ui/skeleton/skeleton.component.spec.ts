import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SkeletonComponent } from './skeleton.component';

describe('SkeletonComponent', () => {
  let component: SkeletonComponent;
  let fixture: ComponentFixture<SkeletonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SkeletonComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SkeletonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('🧪 should create', () => {
    expect(component).toBeTruthy();
  });

  it('🧪 should render correctly with default row value', () => {
    expect(component.rows()).toBe(1);
    expect(component.rowsArray().length).toBe(1);
  });

  it('🧪 should handle negative row values gracefully', function () {
    fixture.componentRef.setInput('rows', -5);
    expect(component.rows()).toBe(-5);
    expect(component.rowsArray().length).toBe(0);
  });
});
