import { CommonModule } from '@angular/common';
import { Component, input, signal } from '@angular/core';
import { TotalTypeEnum } from '@core/enum/totals.enum';

@Component({
  selector: 'totals',
  templateUrl: './totals.component.html',
  styleUrl: './totals.component.scss',
  standalone: true,
  imports: [CommonModule],
})
export class TotalsComponent {
  title = input<string>();
  amount = input<number>();
  icon = input<TotalTypeEnum>();
  showText = input<boolean>();
  legend = input<string>();
  type = TotalTypeEnum;
}
