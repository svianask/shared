import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TotalsComponent } from './totals.component';

describe('TotalComponent', () => {
  let component: TotalsComponent;
  let fixture: ComponentFixture<TotalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TotalsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TotalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('🧪 should create', () => {
    expect(component).toBeTruthy();
  });

  it('🧪 should initialize with default values for title, amount, and icon', () => {
    expect(component.title()).toBeUndefined();
    expect(component.amount()).toBeUndefined();
    expect(component.icon()).toBeUndefined();
  });

  it('🧪 should handle null or undefined values for title, amount, and icon inputs', () => {
    fixture.componentRef.setInput('title', null);
    fixture.componentRef.setInput('amount', undefined);
    fixture.componentRef.setInput('icon', null);

    expect(component.title()).toBeNull();
    expect(component.amount()).toBeUndefined();
    expect(component.icon()).toBeNull();
  });
});
