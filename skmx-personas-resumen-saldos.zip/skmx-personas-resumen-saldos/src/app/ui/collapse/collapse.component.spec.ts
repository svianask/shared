import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CollapseComponent } from './collapse.component';
import { input } from '@angular/core';

describe('CollapseComponent', () => {
  let component: CollapseComponent;
  let fixture: ComponentFixture<CollapseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CollapseComponent],
    }).compileComponents();
    fixture = TestBed.createComponent(CollapseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('🧪 should create', () => {
    expect(component).toBeTruthy();
  });

  it('🧪 should initialize with default values', function () {
    expect(component.title()).toBeUndefined();
    expect(component.amount()).toBeUndefined();
    expect(component.id).toBeGreaterThanOrEqual(0);
    expect(component.id).toBeLessThan(1);
  });

  it('🧪 should initialize with empty title and amount', function () {
    fixture.componentRef.setInput('title', '');
    fixture.componentRef.setInput('amount', 0);
    expect(component.title()).toBe('');
    expect(component.amount()).toBe(0);
  });
});
