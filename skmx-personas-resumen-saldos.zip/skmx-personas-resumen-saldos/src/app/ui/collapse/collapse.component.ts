import { CommonModule } from '@angular/common';
import { Component, input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'collapse',
  templateUrl: './collapse.component.html',
  styleUrl: './collapse.component.scss',
  encapsulation: ViewEncapsulation.Emulated,
  standalone: true,
  imports: [CommonModule],
})
export class CollapseComponent {
  title = input<string>();
  amount = input<number>();
  showText = input<boolean>();
  legend = input<string>();
  id = Math.random();
}
