export interface IUserPreferences {
  isRetail: boolean;
  isUserCorp: boolean;
  displayName: string;
  name: string;
  lastname: string;
  planId: string;
  partId: string;
  retailUser: string;
}