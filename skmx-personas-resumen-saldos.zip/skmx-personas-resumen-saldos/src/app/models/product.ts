export interface IParamsProduct {
  contractType: number;
  id: string;
  partId: string;
  planId: string;
}
