export interface ResponseContractSummary {
  result: Result;
  contractsSummaryBalance: ContractsSummaryBalance;
}

export interface ContractsSummaryBalance {
  lstContractsSavingInvestment: ContractBasicInfo[];
  lstContractsCorporate: ContractBasicInfo[];
  lstContractsRetirement: ContractBasicInfo[];
}

export interface ContractBasicInfo {
  comercialName: string;
  platform: number;
  status: number;
  statusOperation: number;
  balance: number;
  lifeInsurance: number;
  partId: string;
  planId: string;
  id: string;
  contractType: number;
}

export interface Result {
  successful: boolean;
  systemMessages: unknown[];
  exception: null;
}

export interface IContractSummaryDTO {
  rfc: string;
  isRetail: boolean;
  partId: string;
  planId: string;
}
