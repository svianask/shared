import { CommonModule } from '@angular/common';
import {
  HTTP_INTERCEPTORS,
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { importProvidersFrom, NgModule } from '@angular/core';
import { ProxyApisInterceptor } from './interceptors/proxy-apis.interceptor';
import { JwtModule } from '@auth0/angular-jwt';

@NgModule({
  declarations: [],
  imports: [CommonModule],
  providers: [
    importProvidersFrom(
      JwtModule.forRoot({
        config: {
          tokenGetter: () => {
            return sessionStorage.getItem('SKTknAuht');
          },
        },
      })
    ),
    provideHttpClient(withInterceptorsFromDi()),
    { provide: HTTP_INTERCEPTORS, useClass: ProxyApisInterceptor, multi: true },
  ],
})
export class CoreModule {}
