import * as CryptoJS from 'crypto-js';

export default class EncryptTools {
  private keyString!: string;
  private ivString!: string;

  private key!: CryptoJS.lib.WordArray;
  private iv!: CryptoJS.lib.WordArray;

  constructor(key: string, iv: string) {
    this.setKey(key);
    this.setIv(iv);
  }

  private setKey = (key: string): CryptoJS.lib.WordArray => {
    this.keyString = key;
    this.key = CryptoJS.enc.Utf8.parse(this.keyString);
    return this.key;
  };

  private setIv = (iv: string): CryptoJS.lib.WordArray => {
    this.ivString = iv;
    this.iv = CryptoJS.enc.Utf8.parse(this.ivString);
    return this.iv;
  };

  /**
   * Encrypts the information.
   * Can receive an object or any primitive type.
   *
   * @param data
   * @returns string
   */
  encrypt(data: unknown): string {
    return CryptoJS.AES.encrypt(
      CryptoJS.enc.Utf8.parse(JSON.stringify(data)),
      this.key,
      {
        iv: this.iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    )?.ciphertext?.toString();
  }

  /**
   * Decrypts the information.
   *
   * @param data:string
   * @returns unknown
   */
  decrypt(data: string) {
    const encryptedHexStr = CryptoJS.enc.Hex.parse(data);
    const decrypt = CryptoJS.AES.decrypt(
      CryptoJS.enc.Base64.stringify(encryptedHexStr),
      this.key,
      {
        iv: this.iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    );
    const decryptData = decrypt?.toString(CryptoJS.enc.Utf8);
    try {
      return JSON.parse(decryptData);
    } catch (error) {
      return decryptData;
    }
  }
}
