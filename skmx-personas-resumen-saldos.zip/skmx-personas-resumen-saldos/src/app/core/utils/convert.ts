/**
 * Converts an object to a string and passes it to base64
 * @param value:Object
 * @returns {string}
 */
export const convertBase64ToParams = (value: Object): string => {
  const objectString = JSON.stringify(value);
  const params = `params=${objectString}`;
  const encode = btoa(params);

  return encode;
};
