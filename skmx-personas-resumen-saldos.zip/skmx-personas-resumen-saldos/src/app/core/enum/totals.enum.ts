export enum TotalTypeEnum {
  TOTAL_UNDER_MANAGEMENT = 'totals',
  INSURANCE_AMOUNT = 'insurance',
}
