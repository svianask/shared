export enum OperationStatusEnum {
    NORMAL =  5,
    PAIDUP = 10,
    DISABILITY = 15, //inválidez
    DECEASED = 20, //Finado
    RETIRED = 25,//Jubilado
    DISASTER = 30 //Siniestrado
}
  