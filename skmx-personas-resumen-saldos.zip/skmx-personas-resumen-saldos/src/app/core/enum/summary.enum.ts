export enum SummaryTypeEnum {
  CANCEL = 'cancel',
  ACCEPt = 'accept',
  DISABLED = 'disabled',
}
