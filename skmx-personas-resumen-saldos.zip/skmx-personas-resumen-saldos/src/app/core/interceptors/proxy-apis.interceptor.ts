import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment, webpersonasApiUrlBase } from '@env/environment';
import { Observable } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable()
export class ProxyApisInterceptor implements HttpInterceptor {
  constructor(private jwtHelper: JwtHelperService) {}
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const token = sessionStorage.getItem('SKTknAuht');
    const tokenValidate = sessionStorage.getItem('Dato');

    if (!token || this.jwtHelper.isTokenExpired(token)) {
      window.location.href = `${environment.liferayUrlBase}/group/retail/validadatoscontacto`;
      return next.handle(req);
    }
    if (req.url.includes(webpersonasApiUrlBase)) {
      const cloneReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
          Dato: `${tokenValidate}`,
        },
      });
      return next.handle(cloneReq);
    }
    return next.handle(req);
  }
}
