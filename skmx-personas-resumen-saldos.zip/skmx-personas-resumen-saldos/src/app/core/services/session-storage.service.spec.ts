import { TestBed } from '@angular/core/testing';
import { SessionStorageService } from './session-storage.service';
import { HttpClientModule } from '@angular/common/http';

describe('SessionStorage', () => {
  let service: SessionStorageService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
    });

    service = TestBed.inject(SessionStorageService);
  });

  it('🧪 should be created SessionStorage', () => {
    expect(service).toBeTruthy();
  });
});
