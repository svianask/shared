import { Injectable } from "@angular/core";

declare const Liferay: any;
@Injectable({
    providedIn: 'root'
})
export class LiferayService {
    async fetchUserDisplayName(): Promise<string> {
        return new Promise((resolve, reject) => {
            if (Liferay.ThemeDisplay.isSignedIn()) {
                const userId = Liferay.ThemeDisplay.getUserId();
                Liferay.Service(
                    '/user/get-user-by-id',
                    { userId: userId },
                    (user: any) => {
                        if (user) {
                            resolve(user.screenName);
                        } else {
                            reject('No se pudo obtener la información del usuario.');
                        }
                    }
                );
            } else {
                reject('Usuario no autenticado.');
            }
        });
    }
}