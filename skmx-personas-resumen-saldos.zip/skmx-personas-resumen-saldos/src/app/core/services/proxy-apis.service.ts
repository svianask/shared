import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { webpersonasApiUrlBase } from '@env/environment';
import { Observable } from 'rxjs';
import { ResponseContractSummary } from '../../models/contract-summary.interface';

@Injectable({
  providedIn: 'root',
})
export class ProxyApiService {
  private readonly apiName: string = '/WebPersonasApiv2/api/';
  private readonly urlGetSummaryBalance: string = `${this.apiName}ClientContracts/GetContractsActiveAndPaidUp`;
  private readonly urlFetchBalanceSummary: string = `${this.apiName}ClientContracts/FetchBalanceSummary`;
  constructor(private readonly http: HttpClient) {}

  fetchSummaryBalance(
    usrRfc: string,
    isRetail: boolean,
    partId: string,
    planId: string
  ): Observable<ResponseContractSummary> {
    const body = {
      rfc: usrRfc,
      isRetail: isRetail,
      partId: partId,
      planId: planId,
    };
    const urlRequest = `${webpersonasApiUrlBase}${this.urlGetSummaryBalance}`;
    return this.http.post<ResponseContractSummary>(urlRequest, body);
  }

  FetchBalanceSummary(customerId: string, businessLine: string): Observable<ResponseContractSummary> {
    const body = {
      custmerId: customerId,
      businessLine: businessLine
    };
    const urlRequest = `${webpersonasApiUrlBase}${this.urlFetchBalanceSummary}`;
    return this.http.post<ResponseContractSummary>(urlRequest, body);
  }
}
