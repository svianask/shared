import { Injectable } from "@angular/core";
import { IUserPreferences } from "../../models/user-preferents.interface";
import { LiferayService } from "./liferay.service";

@Injectable({
    providedIn: 'root'
})
export class SessionStorageService {
    private readonly STORAGE_NAME_PREFERENCES = 'preference-session-skclt';
    constructor(private readonly liferayServices: LiferayService) { }

    awaitSession(): Promise<IUserPreferences> {
        return new Promise(async (resolve) => {
            const usrLogged = await this.liferayServices.fetchUserDisplayName();
            const checkInterval = setInterval(() => {
                const data = sessionStorage.getItem(this.STORAGE_NAME_PREFERENCES);
                if (data) {
                    const preference = JSON.parse(data);
                    if (preference.displayName == usrLogged) {
                        clearInterval(checkInterval);
                        resolve(preference);
                    }
                }
            }, 100); // ms
        });
    }
}