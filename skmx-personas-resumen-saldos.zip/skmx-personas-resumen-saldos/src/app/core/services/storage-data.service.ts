import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'any',
})
export class StorageDataService {
  private readonly NAME_STORAGE_PRODUCT_TYPE = 'value1';

  /**
   * Stores information in browser data
   * @param data:string
   */
  saveData(data: string): void {
    const { NAME_STORAGE_PRODUCT_TYPE } = this;
    sessionStorage.setItem(NAME_STORAGE_PRODUCT_TYPE, data);
  }

  /**
   * Delete information storage in browser
   */
  clearData(): void {
    const { NAME_STORAGE_PRODUCT_TYPE } = this;

    sessionStorage.removeItem(NAME_STORAGE_PRODUCT_TYPE);
  }
}
