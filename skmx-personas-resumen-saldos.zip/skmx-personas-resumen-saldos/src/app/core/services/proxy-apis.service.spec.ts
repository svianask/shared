import { TestBed } from '@angular/core/testing';
import { ProxyApiService } from './proxy-apis.service';
import { HttpClientModule } from '@angular/common/http';
import { ResponseContractSummary } from '../../models/contract-summary.interface';
import { of, throwError } from 'rxjs';
import { webpersonasApiUrlBase } from '@env/environment';

describe('ProxyApiService', () => {
  let service: ProxyApiService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
    });

    service = TestBed.inject(ProxyApiService);
  });

  it('🧪 should be created ProxyApiService', () => {
    expect(service).toBeTruthy();
  });

  it('🧪 should return an Observable of ResponseContractSummary when input is valid', () => {
    const http = jasmine.createSpyObj('HttpClient', ['post']);
    const service = new ProxyApiService(http);
    const usrRfc = 'validRfc';
    const isRetail = true;
    const isCorp = false;
    const response: ResponseContractSummary = {
      result: { successful: true, exception: null, systemMessages: [] },
      contractsSummaryBalance: {
        lstContractsCorporate: [],
        lstContractsRetirement: [],
        lstContractsSavingInvestment: [],
      },
    };
    http.post.and.returnValue(of(response));

    service
      .fetchSummaryBalance(usrRfc, isRetail, isCorp)
      .subscribe((result) => {
        expect(result).toEqual(response);
      });

    expect(http.post).toHaveBeenCalledWith(
      `${webpersonasApiUrlBase}/WebPersonasApiv2/api/ClientContracts/GetContractsActiveAndPaidUp`,
      { rfc: usrRfc, isRetail: isRetail, isCorp: isCorp }
    );
  });

  it('🧪 should handle empty or null usrRfc gracefully', () => {
    const http = jasmine.createSpyObj('HttpClient', ['post']);
    const service = new ProxyApiService(http);
    const mockResponse: ResponseContractSummary = {
      result: { successful: true, exception: null, systemMessages: [] },
      contractsSummaryBalance: {
        lstContractsCorporate: [],
        lstContractsRetirement: [],
        lstContractsSavingInvestment: [],
      },
    };
    const usrRfc = '';
    const isRetail = true;
    const isCorp = false;
    const urlRequest = `${webpersonasApiUrlBase}/WebPersonasApiv2/api/ClientContracts/GetContractsActiveAndPaidUp`;

    http.post.and.returnValue(of(mockResponse));

    service
      .fetchSummaryBalance(usrRfc, isRetail, isCorp)
      .subscribe((response) => {
        expect(response).toEqual(mockResponse);
      });

    expect(http.post).toHaveBeenCalledWith(urlRequest, {
      rfc: usrRfc,
      isRetail: isRetail,
      isCorp: isCorp,
    });
  });

  it('🧪 should handle network errors or HTTP errors from the server', () => {
    const http = jasmine.createSpyObj('HttpClient', ['post']);
    const service = new ProxyApiService(http);
    const usrRfc = 'validRfc';
    const isRetail = true;
    const isCorp = false;
    const urlRequest = `${webpersonasApiUrlBase}/WebPersonasApiv2/api/ClientContracts/GetContractsActiveAndPaidUp`;
    const errorResponse = new ErrorEvent('Network error');

    http.post.and.returnValue(throwError(errorResponse));

    service.fetchSummaryBalance(usrRfc, isRetail, isCorp).subscribe(
      () => fail('expected an error, not a response'),
      (error) => expect(error).toBe(errorResponse)
    );

    expect(http.post).toHaveBeenCalledWith(urlRequest, {
      rfc: usrRfc,
      isRetail: isRetail,
      isCorp: isCorp,
    });
  });
});
