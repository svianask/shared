import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { SummaryTypeEnum } from '@core/enum/summary.enum';
import { TotalTypeEnum } from '@core/enum/totals.enum';
import { ProxyApiService } from '@core/services/proxy-apis.service';
import { catchError, of, Subject, takeUntil } from 'rxjs';
import {
  ContractBasicInfo,
  ContractsSummaryBalance,
  IContractSummaryDTO,
  ResponseContractSummary,
} from './models/contract-summary.interface';
import { SessionStorageService } from '@core/services/session-storage.service';
import { environment } from '@env/environment';
import { OperationStatusEnum } from '@core/enum/status-operation.enum';
import Swal from 'sweetalert2';
import { AngularFireAnalytics } from '@angular/fire/compat/analytics';
import EncryptTools from '@core/utils/crypto-tools';
import { StorageDataService } from '@core/services/storage-data.service';
import { convertBase64ToParams } from '@core/utils/convert';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, OnDestroy {
  private readonly unSubscribe: Subject<void> = new Subject<void>();
  private readonly encryptTools = new EncryptTools(
    environment.params.option1,
    environment.params.option2
  );
  private isRetail = false;
  iconType = TotalTypeEnum;
  summaryType = SummaryTypeEnum;
  loadingCorporate = signal<boolean>(true);
  loadingRetail = signal<boolean>(true);
  loadingTotals = signal<boolean>(true);
  contractsSummaryCorpData = signal<ContractsSummaryBalance | undefined>(
    undefined
  );
  contractsSummaryRetailData = signal<ContractsSummaryBalance | undefined>(
    undefined
  );
  contractsSavingInvestment = signal<ContractsSummaryBalance | undefined>(
    undefined
  );
  totalContractsSavingInvestment = signal<number>(0);
  totalContractsCorporate = signal<number>(0);
  totalContractsRetirement = signal<number>(0);
  totalManagement = signal<number>(0);
  safeAmount = signal<number>(0);
  errorSavingsProduct = signal<boolean>(false);
  errorCorporateProduct = signal<boolean>(false);
  errorDeductibleProduct = signal<boolean>(false);
  errorCalculateTotals = signal<boolean>(false);
  messagesError = 'Error al cargar el saldo';

  readonly cancelProduct = signal<number>(15);

  constructor(
    private readonly proxyApi: ProxyApiService,
    private readonly sessionService: SessionStorageService,
    private readonly analytics: AngularFireAnalytics,
    private readonly storageDataService: StorageDataService
  ) {}

  ngOnInit(): void {
    this.storageDataService.clearData();
    this.fetchSummaryBalance();
  }

  ngOnDestroy(): void {
    this.unSubscribe.next();
    this.unSubscribe.complete();
  }

  private fetchSummaryBalance() {
    this.sessionService.awaitSession().then((data) => {
      const segmentType =
        data.isRetail && data.isUserCorp
          ? 'AMBOS'
          : data.isRetail
          ? 'RETAIL'
          : 'CORP';

      this.trackPageView(data.displayName, data.planId, segmentType);
      const dataRequest: IContractSummaryDTO = {
        rfc: data.retailUser,
        isRetail: data.isRetail,
        partId: data.partId,
        planId: data.planId,
      };
      this.getsRequestForProducts(dataRequest);
    });
  }

  private getsRequestForProducts(data: IContractSummaryDTO): void {
    if (data.isRetail) {
      this.getRetailProduct(data);
      this.isRetail = true;
    } else {
      this.loadingRetail.set(false);
    }

    if (data.partId.length > 0) {
      this.getCorporateProduct(data);
    } else {
      this.loadingCorporate.set(false);
    }
  }

  private getRetailProduct(data: IContractSummaryDTO): void {
    const { unSubscribe } = this;
    this.proxyApi
      .FetchBalanceSummary(data.rfc, 'RETAIL')
      .pipe(
        catchError(() => of(null)),
        takeUntil(unSubscribe)
      )
      .subscribe((response) => {
        const isValidRequest = this.validatesErrorsByProduct(response);
        this.loadingRetail.set(false);
        this.loadingTotals.set(false);
        if (!isValidRequest) {
          this.messagesErrorRequest();
          this.errorDeductibleProduct.set(true);
          this.errorSavingsProduct.set(true);

          return;
        }

        if (response?.contractsSummaryBalance) {
          this.contractsSavingInvestment.set(response?.contractsSummaryBalance);
          this.contractsSummaryRetailData.set(response.contractsSummaryBalance);
          this.calculateTotalSavingInvestment(
            response?.contractsSummaryBalance
          );
          this.calculateTotalContractsRetirement(
            response?.contractsSummaryBalance
          );
          this.getSafeAmount(response.contractsSummaryBalance);
        }
      });
  }

  private getCorporateProduct(data: IContractSummaryDTO): void {
    this.proxyApi
      .FetchBalanceSummary(`${data.planId}${data.partId}`, 'CORP')
      .pipe(catchError(() => of(null)))
      .subscribe((response) => {
        const isValidRequest = this.validatesErrorsByProduct(response);
        this.loadingCorporate.set(false);
        this.loadingTotals.set(false);
        if (!isValidRequest) {
          this.messagesErrorRequest();
          this.errorCorporateProduct.set(true);

          return;
        }

        if (response?.contractsSummaryBalance) {
          this.contractsSummaryCorpData.set(response?.contractsSummaryBalance);
          this.calculateTotalCorporate(response?.contractsSummaryBalance);
          this.getSafeAmount(response.contractsSummaryBalance);
        }
      });
  }

  private validatesErrorsByProduct(
    request: ResponseContractSummary | null
  ): boolean {
    if (!request || !request.result.successful) return false;

    return true;
  }

  private messagesErrorRequest(): void {
    Swal.fire({
      title: 'Indicaciones',
      text: 'Lo sentimos, estamos experimentando problemas técnicos. Tu dinero está seguro',
      icon: 'info',
      confirmButtonColor: '#02b1ff',
      confirmButtonText: 'Aceptar',
    });
  }

  private calculateTotalCorporate(data: ContractsSummaryBalance): void {
    const INITIAL_VALUE = 0;
    const totalCorporate = data.lstContractsCorporate.reduce(
      (accumulator, current) => accumulator + current.balance,
      INITIAL_VALUE
    );
    this.totalContractsCorporate.set(totalCorporate);
    this.totalManagement.set(this.totalManagement() + totalCorporate);
  }

  private calculateTotalSavingInvestment(data: ContractsSummaryBalance): void {
    const INITIAL_VALUE = 0;
    const totalSavingInvestmen = data.lstContractsSavingInvestment.reduce(
      (accumulator, current) => accumulator + current.balance,
      INITIAL_VALUE
    );
    this.totalContractsSavingInvestment.set(totalSavingInvestmen);
    this.totalManagement.set(this.totalManagement() + totalSavingInvestmen);
  }

  private calculateTotalContractsRetirement(
    data: ContractsSummaryBalance
  ): void {
    const INITIAL_VALUE = 0;
    const totalRetirement = data.lstContractsRetirement.reduce(
      (accumulator, current) => accumulator + current.balance,
      INITIAL_VALUE
    );

    this.totalContractsRetirement.set(totalRetirement);
    this.totalManagement.set(this.totalManagement() + totalRetirement);
  }

  private getSafeAmount(data: ContractsSummaryBalance): void {
    const INITIAL_VALUE = 0;
    const {
      lstContractsCorporate,
      lstContractsRetirement,
      lstContractsSavingInvestment,
    } = data;

    const lifeInsuranceCorporate = lstContractsCorporate.reduce(
      (accumulator, current) => accumulator + current.lifeInsurance,
      INITIAL_VALUE
    );
    const lifeInsuranceRetirement = lstContractsRetirement.reduce(
      (accumulator, current) => accumulator + current.lifeInsurance,
      INITIAL_VALUE
    );
    const lifeInsuranceSavingInvestment = lstContractsSavingInvestment.reduce(
      (accumulator, current) => accumulator + current.lifeInsurance,
      INITIAL_VALUE
    );

    this.safeAmount.set(
      lifeInsuranceCorporate +
        lifeInsuranceRetirement +
        lifeInsuranceSavingInvestment
    );
  }

  /**
   * Navegue hacia la sección detalle producto
   * @param params:string
   */
  private navegateProductDetail(params: string): void {
    const profielUrl = `${environment.liferayUrlBase}/group/retail/detalle-producto`;
    this.storageDataService.saveData(params);
    window.location.href = profielUrl;
  }

  /**
   * Validates the status to be displayed by the card
   * @param data:ContractBasicInfo
   * @returns {string}
   */
  private statusForDetailRetail(data: ContractBasicInfo) {
    const { status, statusOperation } = data;
    const { cancelProduct, summaryType } = this;
    const STATUS_SUCCESS = 5;

    if (status !== STATUS_SUCCESS || statusOperation !== STATUS_SUCCESS)
      return summaryType.DISABLED;

    if (data.status === cancelProduct()) return summaryType.CANCEL;

    return this.summaryType.ACCEPt;
  }

  get statusRetil() {
    return this.statusForDetailRetail;
  }

  set statusRetail(item: ContractBasicInfo) {
    this.statusForDetailRetail(item);
  }

  /**
   * Add the parameters for the coporate detail product
   * @param data:ContractBasicInfo
   */
  handleProductDetailCorp(data: ContractBasicInfo): void {
    const { id, partId, planId, contractType, status } = data;
    const { encryptTools } = this;

    if (status === this.cancelProduct()) return;

    const params = { id, partId, planId, contractType };
    const encode = encryptTools.encrypt(params);
    this.navegateProductDetail(encode);
  }

  /**
   * Add the parameters fot the retail detail product
   * @param data:ContractBasicInfo
   */
  handleProductDetailRetail(data: ContractBasicInfo): void {
    const { id, contractType, status, statusOperation } = data;
    const params = { id, contractType };
    const encode = convertBase64ToParams(params);
    this.navegateProductDetail(encode);
    const STATUS_SUCCESS: OperationStatusEnum = OperationStatusEnum.NORMAL;

    if (status === STATUS_SUCCESS && statusOperation === STATUS_SUCCESS) {
      if (status === this.cancelProduct()) return;

      const params = { id, contractType };
      const encode = this.encryptTools.encrypt(params);
      this.navegateProductDetail(encode);
    } else if (statusOperation === OperationStatusEnum.PAIDUP) {
      Swal.fire({
        title: '',
        text: 'El contrato se encuentra inactivo, comunícate al 55 5093 0220 para conocer tus opciones',
        icon: 'warning',
        confirmButtonColor: '#00c83c',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  trackPageView(currentUser: string, planId: string, segmentType: string) {
    this.analytics.logEvent('page_view', {
      Action: 'Ingreso exitoso',
      Channel: 'Nuevo Skandia Net',
      Page: `Resumen de Saldos ${environment.Name}`,
      User: currentUser,
      Plan: planId.length > 0 ? planId : 'N/A',
      SegmentType: segmentType,
    });
  }

  get validatesErrorMessage() {
    if (this.errorCorporateProduct() && !this.isRetail) {
      return true;
    }

    if (this.errorDeductibleProduct() && this.errorSavingsProduct()) {
      return true;
    }

    return false;
  }
}
